/**
 * constants.js — All game constants, conversion factors, and configuration.
 *
 * Core conversion:
 *   1 km = 100 px
 *   1 knot = 0.01 km/s = 1 px/s
 *   1000 gun-speed units = 0.57 km/s = 57 px/s
 *      → 1 gun-speed unit = 0.057 px/s
 */

// ── Deep Freeze Utility ───────────────────────────────────────────────────
// 递归冻结对象及其所有嵌套对象/数组，防止运行时意外修改常量结构。
// 相比 Object.freeze（仅浅冻结），deepFreeze 确保嵌套字段也不可变。
// 已冻结的对象再次调用是安全无副作用的（no-op）。
const _freeze = Object.freeze;
function deepFreeze(obj) {
  if (obj && typeof obj === 'object' && !Object.isFrozen(obj)) {
    _freeze(obj);
    Object.keys(obj).forEach(key => deepFreeze(obj[key]));
  }
  return obj;
}

// ── Coordinate System ──────────────────────────────────────────────────────
const PX_PER_KM = 100;
const MAP_SIZE_KM  = 50;
let MAP_SIZE_PX    = MAP_SIZE_KM * PX_PER_KM; // 5000 px (mutable for custom battles)

// ── 战役环境上下文（2026-09-19 字人规范，AGENTS §5.30）────────────────────────
// 战役 vs 非战役的差异会越来越多（技能"战役"属性、百分比扣血基数、特殊武损等）。
// **唯一开关源 = BattleRules.isCampaign**，由 main.js 的 setCampaignContext() 统一设置：
//   真战役 → true；自定义战斗 → 「视同战役」开关；快速战斗 → false。
// ⚠️ 以后新增"只在战役生效/行为不同"的效果，一律读这里，禁止新造布尔散落各处。
const BattleRules = {
  isCampaign: false,   // 默认非战役（开始界面/快速战斗）
};

// ── Speed Gears (single shared table for player & enemy) ────────────────────
const SPEED_GEARS = deepFreeze([
  deepFreeze({ name: '半速后退', speed: -17.5 }), // index 0
  deepFreeze({ name: '停止',     speed: 0     }), // index 1
  deepFreeze({ name: '半速',     speed: 17.5  }), // index 2
  deepFreeze({ name: '全速',     speed: 35    }), // index 3
]);
const INITIAL_GEAR_INDEX = 1; // "停止"
const MAX_SHIP_SPEED_KN = 110;  // 实际航速上限（节），对冲减速可超但 currentSpeed 钳制

// ── Main Gun ────────────────────────────────────────────────────────────────
const MAIN_GUN_CONFIG = deepFreeze({
  mountCount: 3,
  barrelsPerMount: 2,           // 二联装
  cooldownSec: 4,               // seconds per mount
  shellSpeed: 513,              // px/s  (= 9000 × 0.057)
  damage: 500,
  spreadAngle: 1 * Math.PI / 180,   // ±1°
  landingDeviation: 15,         // ±15 px random offset on arrival (narrower for accuracy)
  shellRadius: 3,               // visual radius
  trailFrames: 3,               // trail persistence in frames
  playerColor: '#FF2222',       // red
  enemyColor: '#FF3333',        // red
});

// ── Torpedo ─────────────────────────────────────────────────────────────────
const TORPEDO_CONFIG = deepFreeze({
  mountCount: 2,
  barrelsPerMount: 3,           // 三联装
  cooldownSec: 10,              // seconds per mount
  speed: 55,                    // px/s  (= 55 kt)
  damage: 2000,
  scatterAngle: 5 * Math.PI / 180, // ±5°
  torpedoRadius: 4,             // visual radius
  trailFrames: 8,               // trail persistence in frames
  playerColor: '#FFFFFF',       // white
  enemyColor: '#CC3333',        // dark red
});

const MAIN_GUN_RANGE = 15 * PX_PER_KM;   // 1500 px = 15 km
const TORPEDO_RANGE  = 12 * PX_PER_KM;   // 1200 px = 12 km

// ── Mine (水雷系统) ──────────────────────────────────────────────────────────
const MINE_DETONATION_KM  = 0.75;    // 引爆半径 公里
const MINE_EXPLOSION_KM   = 2.45;    // 爆炸半径 公里
const MINE_LIFETIME_SEC   = 135;     // 存在时间 秒（到点消失，不爆炸）
const MINE_REVEAL_EXTRA_KM = 0.5;    // 敌方水雷显示：引爆半径 + 0.5 km
const MINE_HIT_BG         = '#4488CC'; // 水雷命中统计底色（与漏水同色）
const MINE_HOLD_INTERVAL  = 500;     // ms, 布雷间隔
const MINE_CONFIG = deepFreeze({
  mountCount: 0,          // 每舰配置，这里仅作 fallback
  cooldownSec: 26,        // 每槽冷却 秒
  holdInterval: MINE_HOLD_INTERVAL,
});

// ── Hold-to-Fire Intervals ──────────────────────────────────────────────────
const MAIN_GUN_HOLD_INTERVAL = 100;    // ms, main-gun auto-fire interval on hold
const TORPEDO_HOLD_INTERVAL  = 300;    // ms, torpedo auto-fire interval on hold

// ── 武器极限装填（2026-09-19 字人规范）────────────────────────────────────
// 任何减装填手段（百分比 / 常数）计算完成后，实际装填时间都不得低于此值（对所有武器生效）。
// 统一入口：Ship.getWeaponReloadSec()（ship-weapons.js）；公式说明见 js/data/formulas.js
const MIN_RELOAD_SEC = 1.5;   // 秒

// ── Enemy Ship（2026-08-08 人机武器改革：巡洋默认 4主炮8s / 2鱼雷20s，全向射界，每炮独立冷却）──
const ENEMY_CONFIG = deepFreeze({
  name: '敌舰',
  hp: 50000,
  length: 100,
  width: 20,
  color: '#D94040',
  bowColor: '#F06060',
  outlineColor: '#FF8888',
  rotationSpeed: 45 * Math.PI / 180,
  engagementRange: 15 * PX_PER_KM,  // 交战距离 15km（=巡洋主炮射程）
  critChance: 0.1,
  shatterChance: 0.05,
  // 攻击侧几率补齐（2026-09-19 字人确认"全部执行"）：此前 ENEMY_CONFIG 只有
  //   critChance/shatterChance → 快速战斗敌舰**永远无法穿甲、点燃、造成漏水**
  //   （配损/武损已于 2026-09-13 补齐，同样原因）。取值对齐 SHIP_TYPE_DEFAULTS.cruiser（自定义战斗巡洋默认）
  penetrationChance: 0.1,     // 穿甲几率（主炮专属）
  burnChance: 0.05,           // 燃烧几率（主炮专属）
  floodChance: 0.05,          // 漏水几率（鱼雷/水雷）
  // 状态类几率（2026-09-13 补）：此前 ENEMY_CONFIG 完全没有状态几率字段 →
  //   快速战斗敌舰作为攻击方永远无法造成配损（AGENTS §5.25 声称"敌舰均 0.03"但实际缺失）
  //   与本次新增的武损（字人确认"对称：敌我都能触发"）一并补齐
  accessoryChance: 0.03,      // 配损几率（主炮/鱼雷/水雷命中触发）
  weaponDamageChance: 0.03,   // 武损几率（武器损毁，2026-09-13）
  // 武器真伤（2026-09-19）：trueDmg 通用 + 四类武器专属（同类相加）；resistTrueDmg 对冲玩家真伤。
  //   ⚠️ 攻击侧属性的清单与「对哪些武器/哪些路径生效」只在 js/data/attack-stats.js 维护；
  //      本文件只提供快速战斗敌舰的默认数值。漏字段会 max(0, undefined − 抵抗) = 0 静默失效
  trueDmg: 0, mainTrueDmg: 0, torpTrueDmg: 0, mineTrueDmg: 0, secTrueDmg: 0,
  resistTrueDmg: 0,           // 抵抗武器真伤（对冲，不增伤）
  repairEff: 0,                // 维修效率（敌人不回血，占位保一致，2026-10-01）
  weapon: {
    mainGun: {
      mountCount: 4,           // 巡洋默认 4 主炮
      barrelsPerMount: 2,
      cooldownSec: 8,          // 装填 8s（每门独立冷却）
      damage: 1000,            // 回退值（实际从挂载武器读）
      shellSpeed: 10000 * 0.057,
      spreadAngle: 1 * Math.PI / 180,
      landingDeviation: 15,
      shellRadius: 3,
      trailFrames: 3,
      playerColor: '#FF6B35',
      enemyColor: '#FF3333',
      range: 17 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['all', 'all', 'all', 'all'],   // 无发射角度限制
    },
    torpedo: {
      mountCount: 2,           // 巡洋默认 2 鱼雷
      barrelsPerMount: 4,
      cooldownSec: 20,         // 装填 20s
      damage: 2000,
      speed: 55,
      scatterAngle: 5 * Math.PI / 180,
      torpedoRadius: 4,
      trailFrames: 8,
      playerColor: '#1E5FBF',
      enemyColor: '#CC3333',
      range: 12 * PX_PER_KM,
      holdInterval: 300,
      mountArcs: ['all', 'all'],                 // 无发射角度限制
    },
  },
});

// ── Ship–Ship Collision ─────────────────────────────────────────────────────
const SHIP_COLLISION_DIST = 200; // px centre-to-centre to trigger mutual stop

// ── Spawn Positioning (2026-09-18 Phase 1 M2) ──────────────────────────────
const MAP_EDGE_MARGIN     = 300;   // 出生位置最小离边距（px），用于 clamp 地图边缘
const ENEMY_SPAWN_GAP     = 600;   // 固定排布网格间距（px）
const ENEMY_SPAWN_MIN_DIST = 1000;  // 敌人与玩家最小出生距离（px）
const ENEMY_SPAWN_SEP_DIST = 400;   // 敌人与其他舰船最小出生间距（px）
const ENEMY_SPAWN_MAX_TRIES = 100;  // 随机出生位置最大尝试次数
const CAMPAIGN_ALLY_KEEP_RANGE_KM = 5;  // 战役友军保持距离（km）
const CAMPAIGN_ALLY_SPAWN_RANGE = 500;  // 战役友军出生区域范围（px）
const QUICK_BATTLE_MAP_KM = 20;         // 快速战斗地图边长（km）

// ── UI Canvas Dimensions ────────────────────────────────────────────────────
const MINIMAP_SIZE = 200;       // px square
const COMPASS_SIZE = 80;        // px square

// ── Movement Smoothing (exponential approach: dv/dt = (target-v) × power/normalizer) ─
const ACCEL_POWER      = 1300;   // 古鹰加速功率
const ACCEL_NORMALIZER = 2600;   // 航速时间常数 ≈ 2 s
const TURN_POWER       = 350;    // 古鹰转向功率
const TURN_NORMALIZER  = 500;    // 转向时间常数 ≈ 1.4 s（350 / 500 = 0.7 s⁻¹）

// ── Burn (燃烧系统) ──────────────────────────────────────────────────────────
const BURN_DURATION    = 20;     // 燃烧持续时间 秒
const BURN_INTERVAL    = 4;      // 燃烧间隔 秒
const BURN_DAMAGE_PCT  = 0.02;   // 每次伤害 = 玩家血量上限 × 2%
const BURN_MAX_STACKS  = 3;      // 最大层数
const BURN_HIT_BG      = '#882200';  // 燃烧命中统计底色（深橙红）
const WEP_DAMAGE_HIT_BG = '#882200'; // 武损（武器损毁）命中统计底色（红，同燃烧；2026-09-13）

// ── Flood (漏水系统) ─────────────────────────────────────────────────────────
const FLOOD_DURATION       = 10;     // 漏水持续时间 秒
const FLOOD_INTERVAL       = 2;      // 漏水间隔 秒
const FLOOD_DAMAGE_PCT     = 0.04;   // 每次伤害 = 玩家血量上限 × 4%
const FLOOD_SPEED_PENALTY  = 0.2;    // 漏水期间减速 20%
const FLOOD_HIT_BG         = '#4488CC'; // 漏水命中统计底色（淡蓝）

// ── Zoom Smoothing ──────────────────────────────────────────────────────────
const ZOOM_SMOOTH_TAU  = 0.12;   // 缩放平滑时间常数（秒），越小越快

// ── Zoom Levels (M to zoom in, N to zoom out) ──────────────────────────────
// 等比档位（2026-10-01 字人选定 B 方案）：相邻档跳跃 ~×1.26，消除旧 5 档的中远段断层
// （旧档 [0.25,0.4,0.55,0.75,1.0] 的 0.25→0.4 一步跨 28.8km/1920 屏）。
// FOV（1920 宽）：76.8 / 61.4 / 50.2 / 39.2 / 30.6 / 24.1 / 19.2 km
const ZOOM_LEVELS = deepFreeze([0.25, 0.32, 0.41, 0.53, 0.68, 0.87, 1.0]);
const DEFAULT_ZOOM_INDEX = 3; // 0.53, ≈旧默认 0.55 的手感（~22km FOV on a 1200px-wide screen）

// ── Damage Popup Animation ─────────────────────────────────────────────────
// Floating "-XXX" text spawned on hit, with ballistic + fade animation.
const DAMAGE_POPUP = deepFreeze({
  initialVy: -320,        // initial upward velocity (px/s in world units)
  gravity:   640,         // downward acceleration (px/s² in world units)
  lifetime:  1.0,         // total lifetime in seconds
  fontSize:  28,
  font:          'bold 28px "Microsoft YaHei", Arial, sans-serif',
  color:         '#FF3333',
  strokeColor:   '#000000',
  critColor:       '#66CCFF',     // 暴击浅蓝（与海面深蓝区分）
  critStrokeColor: '#003366',     // 深蓝描边
  penetrationColor:       '#B8731E',   // 穿甲橙红（同碎甲统计颜色）
  penetrationStrokeColor: '#4A1A00',   // 深褐描边
  executeColor:       '#C0C0C0',   // 收割银灰
  executeStrokeColor: '#3A3A3A',   // 深灰描边
  scatterRadius: 180,     // random scatter radius around the hit point (world px)
});

// ── Damage Variance & Critical Hit ──────────────────────────────────────
const CRIT_CHANCE     = 0.1;    // 10% 暴击率
const DAMAGE_VARIANCE = 0.1;    // ±10% 伤害浮动

// ── Armor & Shatter ────────────────────────────────────────────────────
const ARMOR_BASE            = 2000;    // 古鹰 / 敌舰基础装甲值
const SHATTER_CHANCE        = 0.05;    // 5 % 主炮碎甲概率
const PENETRATION_CHANCE    = 0;       // 0 % 穿甲几率（按舰种配置，这里设默认值）
const SHATTER_DURATION      = 10;      // 碎甲持续秒数
const SHATTER_ARMOR_REDUCTION = 0.2;  // 碎甲后装甲减少 20 %
const SHATTER_HIT_BG = '#B8731E';      // 碎甲命中统计药丸：橙黄

// ── Hit Counter (top-right) ─────────────────────────────────────────────────
// Two pill-shaped counters shown for HIT_STAT.duration ms after the last hit.
const HIT_STAT = deepFreeze({
  duration:       3000,   // ms — visible window after the latest hit
  width:          130,    // pill width (screen px)
  height:          40,    // pill height (screen px)
  marginTop:       80,    // distance from top of canvas
  marginRight:     40,    // distance from right edge of canvas
  mainGunBgColor:  '#8B1A1A',  // dark-red background for main-gun hits
  torpedoBgColor:  '#8B6A1A',  // dark-yellow background for torpedo hits
  textColor:       '#FFFFFF',
  font:            'bold 24px "Microsoft YaHei", Arial, sans-serif',
  iconSize:         28,
});

// ── 受击反馈 (screen shake + red edge flash) ──────────────────────────────
// 仅由武器命中（主炮/鱼雷/水雷）触发，燃烧/漏水等 DOT 不触发。
//
// 屏幕摇晃：正弦衰减波形，不是白噪声——
//   offset = 方向向量 × shakeAmp×强度 × e^(-t/shakeTau) × sin(2π×shakeFreq×t)
//   方向 = 命中点指向屏幕中心的反向（炮弹从哪来就朝哪震）。
//   强度按连击叠加（齐射 6 发 → 2 倍封顶），连击重置相位 → 有节奏感。
// 边缘泛红：纯红径向渐变遮罩，0.3s 快速淡出；中心恒透明、封顶 flashAlpha。
//
// 调参经验：
//   - 曾加过相机 roll 旋转（±1.5°）想增强"船感"，但平直的地图边界在
//     低缩放时被旋成斜线、视觉扭曲，已整体移除旋转。
//   - 位移峰值 2px（齐射全中也只 4px），轻微可辨、不干扰瞄准。
const HIT_FEEDBACK = deepFreeze({
  shakeAmp:       2,     // 位移幅度峰值（屏幕 px，单次受击）
  shakeTau:       0.12,  // 位移衰减时间常数（秒）
  shakeFreq:      6,     // 位移振荡频率（Hz，低频"震一下"而非"抖动"）
  shakeEndTime:   0.8,   // 波形结束时间（秒，之后位移归零）
  flashAlpha:     0.30,  // 泛红最大透明度
  flashTau:       0.30,  // 泛红快速淡出时间常数（秒）
  streakWindow:   0.12,  // 连击判定窗口（秒）：窗口内再受击 → 强度叠加
  shakeMaxStreak: 2,     // 连击强度封顶（齐射全中也只翻倍，不过猛）
});

// ── Weapon Firing Arcs ─────────────────────────────────────────────────
// Each arc is defined as an array of { center, halfSpread } segments.
// center = 0 is ship-bow direction, positive = clockwise.
// halfSpread in radians — the mount can fire at any direction within
// ±halfSpread of center.
const WEAPON_ARCS = deepFreeze({
  forward:      deepFreeze([deepFreeze({ center: 0,          halfSpread: 140 * Math.PI / 180 })]),
  aft:         deepFreeze([deepFreeze({ center: Math.PI,    halfSpread: 140 * Math.PI / 180 })]),
  port:        deepFreeze([deepFreeze({ center: -Math.PI/2, halfSpread: 60  * Math.PI / 180 })]),
  starboard:   deepFreeze([deepFreeze({ center:  Math.PI/2, halfSpread: 60  * Math.PI / 180 })]),
  // centerline = left + right union (no dead zone fore/aft)
  centerline:  deepFreeze([
                  deepFreeze({ center: -Math.PI/2, halfSpread: 60 * Math.PI / 180 }),
                  deepFreeze({ center:  Math.PI/2, halfSpread: 60 * Math.PI / 180 }),
                ]),
});

// ── Ship Library (populated by js/ships/*.js) ─────────────────────────
const SHIP_LIBRARY = [];

// ── Commander Library (populated by js/commanders/*.js) ───────────────
const COMMANDER_LIBRARY = [];

const START_SCREEN = deepFreeze({
  bgColor:    'rgba(10,15,25,0.92)',
  panelColor: 'rgba(20,30,50,0.85)',
  accent:     '#4488FF',
  highlight:  '#FFCC00',
  font:       '12px "Microsoft YaHei", Arial, sans-serif',
  titleFont:  'bold 32px "Microsoft YaHei", Arial, sans-serif',
  cardSize:   { w: 130, h: 70 },
  previewSize:{ w: 600, h: 360 },
});
