/**
 * compass.js — Compass rendering (prototype extension for Renderer).
 */
Renderer.prototype.renderCompass = function (player) {
  const ctx = this.cpCtx;
  const s = COMPASS_SIZE;
  const cx = s / 2;
  const cy = s / 2;
  const r = s / 2 - 6;

  ctx.clearRect(0, 0, s, s);

  // outer ring
  ctx.fillStyle = 'rgba(0, 10, 30, 0.75)';
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#557799';
  ctx.lineWidth = 2;
  ctx.stroke();

  // cardinal marks
  const dirs = [
    { label: 'N', angle: 0 },
    { label: 'E', angle: Math.PI / 2 },
    { label: 'S', angle: Math.PI },
    { label: 'W', angle: -Math.PI / 2 },
  ];
  ctx.fillStyle = '#AABBCC';
  ctx.font = 'bold 11px "Microsoft YaHei", Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (const d of dirs) {
    const lx = cx + Math.sin(d.angle) * (r - 12);
    const ly = cy - Math.cos(d.angle) * (r - 12);
    ctx.fillText(d.label, lx, ly);
  }

  // pointer (rotates with ship heading)
  if (player && player.isAlive) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(player.heading);

    // north pointer
    ctx.fillStyle = '#FF6644';
    ctx.beginPath();
    ctx.moveTo(0, -r + 8);
    ctx.lineTo(-5, 2);
    ctx.lineTo(5, 2);
    ctx.closePath();
    ctx.fill();

    // south tail
    ctx.fillStyle = '#8899AA';
    ctx.beginPath();
    ctx.moveTo(0, r - 8);
    ctx.lineTo(-4, -2);
    ctx.lineTo(4, -2);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  // centre dot
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(cx, cy, 2.5, 0, Math.PI * 2);
  ctx.fill();
};
