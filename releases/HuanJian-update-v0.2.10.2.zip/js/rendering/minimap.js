/**
 * minimap.js — Minimap rendering (prototype extension for Renderer).
 * allies 为可选参数（AI 友军，青色点）。玩家死亡（旁观）时不过滤视野。
 */
Renderer.prototype.renderMinimap = function (player, enemies, allies) {
  const ctx = this.mmCtx;
  const s = MINIMAP_SIZE;
  const scale = s / MAP_SIZE_PX;
  enemies = enemies || [];
  allies = allies || [];
  const seeAll = !player || !player.isAlive;
  // 蓝方共享视野观察者（玩家 + 友军）
  const obs = [player].concat(allies);

  ctx.clearRect(0, 0, s, s);

  // background
  ctx.fillStyle = 'rgba(0, 10, 25, 0.80)';
  ctx.fillRect(0, 0, s, s);

  // border
  ctx.strokeStyle = '#556677';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(0.5, 0.5, s - 1, s - 1);

  // enemy dots (detection-gated, colour by ship type)
  for (var ei = 0; ei < enemies.length; ei++) {
    var e = enemies[ei];
    if (e && e.isAlive && (seeAll || Detection.canSeeShipByAny(obs, e) || (e.hasBuff && e.hasBuff('lit')))) {
      ctx.fillStyle = e.color || '#FF4444';
      ctx.beginPath();
      ctx.arc(e.x * scale, e.y * scale, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // ally dots (cyan)
  for (var ai = 0; ai < allies.length; ai++) {
    var a = allies[ai];
    if (a && a.isAlive && (seeAll || Detection.canSeeShipByAny(obs, a))) {
      ctx.fillStyle = '#2EC4B6';
      ctx.beginPath();
      ctx.arc(a.x * scale, a.y * scale, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // player dot
  if (player && player.isAlive) {
    ctx.fillStyle = '#4488FF';
    ctx.beginPath();
    ctx.arc(player.x * scale, player.y * scale, 4, 0, Math.PI * 2);
    ctx.fill();
    // direction indicator
    const px = player.x * scale;
    const py = player.y * scale;
    const tipX = px + Math.sin(player.heading) * 8;
    const tipY = py - Math.cos(player.heading) * 8;
    ctx.strokeStyle = '#88BBFF';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(tipX, tipY);
    ctx.stroke();
  }

  // main-gun range ring on minimap
  if (player && player.isAlive) {
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 0.8;
    ctx.setLineDash([3, 5]);
    ctx.beginPath();
    ctx.arc(player.x * scale, player.y * scale, player.weaponCfg.mainGun.range * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // view-rectangle
  if (player && player.isAlive) {
    const vw = (this.width / this.zoom) * scale;
    const vh = (this.height / this.zoom) * scale;
    const vx = player.x * scale - vw / 2;
    const vy = player.y * scale - vh / 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1;
    ctx.strokeRect(vx, vy, vw, vh);
  }
};
