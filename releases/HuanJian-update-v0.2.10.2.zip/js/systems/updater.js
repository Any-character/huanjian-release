﻿/**
 * updater.js — 游戏内「检查更新」（2026-09-26）
 *
 * 版本源（按序尝试，任一成功即返回）：
 *   ① GitHub Releases API（releases/latest）：tag=版本、body=更新公告、assets=zip
 *   ② jsDelivr 镜像 manifest.json（发布脚本 tools/release.py 每次发版同步更新）
 *   两者都带 Access-Control-Allow-Origin: *，file:// 页面可直接 fetch。
 *
 * 更新方式（给朋友）：游戏目录下双击 update.bat（下载 zip → 覆盖 css/js/index，
 * 自动跳过 js/mods 保 mod）。本模块只做「检查 + 展示公告 + 引导」，不做文件替换——
 * 浏览器 file:// 页面无写盘权限，这是刻意的架构边界（AGENTS §5.31）。
 *
 * 配套：js/version.js（当前版本）/ tools/release.py（发版）/ update.bat + update.ps1（朋友侧更新）
 */
const Updater = {
  REPO: 'Any-character/huanjian-release',
  API_URL: 'https://api.github.com/repos/Any-character/huanjian-release/releases/latest',
  MANIFEST_URL: 'https://cdn.jsdelivr.net/gh/Any-character/huanjian-release@main/manifest.json',
  RELEASE_PAGE: 'https://github.com/Any-character/huanjian-release/releases/latest',

  // ── 会话级状态（模块内唯一，页面不刷新就一直有效）────────────────────
  //   _autoCheckStarted：自动检查是否已发起过（去重，一会话只查一次）
  //   _manualChecked   ：本会话用户是否已手动点过「检查」
  // ⚠ 这两个标志是「自动检查静默」的全部依据，改动前先看 autoCheck 注释。
  _autoCheckStarted: false,
  _manualChecked: false,

  /** 当前版本（读 version.js 的 GAME_VERSION） */
  current() {
    return (typeof GAME_VERSION !== 'undefined') ? GAME_VERSION : '0.0.0';
  },

  /**
   * 版本比较：a>b → 1，a<b → -1，相等 → 0
   *
   * 逐段取整比较（0.2.7 < 0.2.10，不能字典序），**最多 4 段、缺段按 0**（2026-10-02）：
   *   0.2.9 == 0.2.9.0   0.2.9.1 > 0.2.9   0.2.10 > 0.2.9.1   0.2.9.1.2 截断为 0.2.9.1
   *
   * ⚠️ 循环上限 4 必须与下面两处保持一致（AGENTS §5.31 / 单测第 84 节守卫）：
   *     ① tools/release.py → VER_SEG_MAX / ver_parts（4）
   *     ② update.ps1       → Compare-Ver 的 `for ($i = 0; $i -lt 4; $i++)`
   *   本项目历史上真实故障：update.ps1 的 Compare-Ver 方向写反 → 「发版成功但玩家
   *   判定已是最新」→ 更新静默失效。段数上限三处只改一处是同一类故障。
   */
  compareVersions(a, b) {
    var pa = String(a || '').replace(/^v/i, '').split('.');
    var pb = String(b || '').replace(/^v/i, '').split('.');
    for (var i = 0; i < 4; i++) {
      var x = parseInt(pa[i] || '0', 10) || 0;
      var y = parseInt(pb[i] || '0', 10) || 0;
      if (x > y) return 1;
      if (x < y) return -1;
    }
    return 0;
  },

  /** 解析 GitHub Releases API 响应 → { version, notes, zipUrl } */
  parseRelease(j) {
    if (!j || !j.tag_name) return null;
    var zipUrl = this.RELEASE_PAGE.replace('/releases/latest', '/releases/latest/download/HuanJian-update.zip');
    if (j.assets && j.assets.length) {
      for (var i = 0; i < j.assets.length; i++) {
        if (/\.zip$/i.test(j.assets[i].name || '')) { zipUrl = j.assets[i].browser_download_url; break; }
      }
    }
    return { version: String(j.tag_name).replace(/^v/i, ''), notes: j.body || '', zipUrl: zipUrl };
  },

  /** 解析 manifest.json（jsDelivr 备源）→ { version, notes, zipUrl } */
  parseManifest(j) {
    if (!j || !j.version) return null;
    return { version: String(j.version), notes: j.notes || '', zipUrl: j.zip || '' };
  },

  /**
   * 带超时的 fetch JSON。
   * 超时用 AbortController 真正中断请求（否则 fetch 仍在后台跑完，白耗流量）；
   * 老浏览器无 AbortController 时退回「只 reject 外层 Promise」的旧行为。
   */
  _fetchJson(url, timeoutMs) {
    return new Promise(function(resolve, reject) {
      var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      var settled = false;
      var timer = null;
      function finish(fn, v) { if (settled) return; settled = true; clearTimeout(timer); fn(v); }
      timer = setTimeout(function() {
        if (ctrl) { try { ctrl.abort(); } catch (e) { /* 某些旧实现 abort 抛错，忽略 */ } }
        finish(reject, new Error('timeout'));
      }, timeoutMs || 8000);
      var opts = { headers: { 'Accept': 'application/json' } };
      if (ctrl) opts.signal = ctrl.signal;
      fetch(url, opts)
        .then(function(r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function(j) { finish(resolve, j); })
        .catch(function(e) {
          // 超时已先 reject（abort 引发的 AbortError 属预期），这里忽略重复结算
          finish(reject, e);
        });
    });
  },

  /** 组装检查结果（同步纯函数；69.05 单测直接覆盖）。note 为可选补充提示（主源降级时填） */
  buildResult(cur, r) {
    return {
      ok: true,
      hasUpdate: this.compareVersions(r.version, cur) > 0,
      current: cur,
      latest: r.version,
      notes: r.notes,
      zipUrl: r.zipUrl,
      source: r.source,
      note: r.note || '',
    };
  },

  /**
   * 检查更新（两个版本源按序尝试）。
   * 主源失败原因会被记录：降级成功 → 放进 result.note；双源都失败 → 并列写进 error。
   * @param {Function} cb — 完成回调：{ ok, hasUpdate, latest, notes, zipUrl, source, note } 或 { ok:false, error }
   */
  check(cb) {
    var self = this;
    var cur = this.current();
    var ghErr = null;   // 主源 GitHub 失败原因（降级提示 / 双失败报错用）
    this._fetchJson(this.API_URL).then(function(j) {
      var r = self.parseRelease(j);
      if (!r) throw new Error('bad release payload');
      r.source = 'github';
      return r;
    }).catch(function(e) {
      ghErr = (e && e.message) || String(e) || 'network error';
      return self._fetchJson(self.MANIFEST_URL).then(function(j) {
        var r = self.parseManifest(j);
        if (!r) throw new Error('bad manifest payload');
        r.source = 'jsdelivr';
        r.note = '主源 GitHub 暂不可用（' + ghErr + '），已改用 jsDelivr 镜像';
        return r;
      });
    }).then(function(r) {
      cb(self.buildResult(cur, r));
    }).catch(function(e) {
      var jsErr = (e && e.message) || String(e) || 'network error';
      cb({ ok: false, error: ghErr ? ('GitHub: ' + ghErr + '；jsDelivr: ' + jsErr) : jsErr });
    });
  },

  /**
   * 标记「本会话用户已手动检查过」（设置界面「检查」按钮调用，2026-10-02）。
   * 作用：用户刚手动看完公告后，启动自动检查不该再弹一次同样的窗（同一会话内）。
   * 纯会话内存，不落盘——重开游戏理应重新自动检查一次。
   */
  markManualCheck() { this._manualChecked = true; },

  /**
   * 自动检查的静默判定（**纯函数，静默语义的唯一判定点**，69.12 单测直测本函数）：
   *   'popup'   → 弹窗（复用 showResult 默认模式）
   *   'silent'  → 完全静默：不弹窗 / 不 alert / 不 toast / 不改任何按钮文字
   *
   * 三条静默规则（任一命中即静默）：
   *   ① res 缺失或 res.ok === false  → 断网/超时/双源都挂。用户没主动要求检查，
   *      此时任何 UI 打扰都只是噪音（还要冒「游戏是不是坏了」的误导）。
   *   ② manualChecked                → 用户本会话已手动点过「检查」，该看的他看过了。
   *   ③ res.ok && !res.hasUpdate     → 已是最新，没什么可说的。
   * 唯一会弹的情况：**检查成功 + 有新版本 + 用户没手动查过**。
   *
   * @param {Object} res  check() 的结果
   * @param {boolean} manualChecked  发起自动检查的那一刻用户是否已手动检查过
   * @returns {'popup'|'silent'}
   */
  _autoPopupDecision(res, manualChecked) {
    if (!res || !res.ok) return 'silent';          // 规则①
    if (manualChecked) return 'silent';            // 规则②
    if (!res.hasUpdate) return 'silent';           // 规则③
    return 'popup';
  },

  /**
   * 启动静默检查（2026-10-02）。时机由调用方（js/main.js 选船界面挂载后 setTimeout）
   * 决定，本方法只管「查一次 + 该不该弹」。
   *
   * 绝不抛异常：check() 本身保证只回调不抛；这里再包一层 try/catch，
   * 因为 check 的 .then(...).catch(...) 结构下，回调里抛错会被链尾 catch 当成
   * 「网络失败」再回调一次 cb（重复结算）——自动检查绝不能因此弹出失败窗。
   *
   * @param {Object} [opts] 测试注入口（生产不传）
   * @param {Function} [opts.check]  默认 this.check
   * @param {Function} [opts.popup]  默认走 this.showResult(res)
   * @returns {boolean} 是否真的发起了检查（false = 本会话已查过，跳过）
   */
  autoCheck(opts) {
    opts = opts || {};
    if (this._autoCheckStarted) return false;      // 一会话只查一次
    this._autoCheckStarted = true;
    var self = this;
    var manual = this._manualChecked;              // 取发起时刻的快照（check 是异步的）
    var doCheck = opts.check || this.check;
    var doPopup = opts.popup || function(res) { self.showResult(res); };
    var warn = (typeof console !== 'undefined' && console.warn) ? console.warn : null;
    try {
      doCheck(function(res) {
        var d = self._autoPopupDecision(res, manual);
        if (d === 'silent') {
          // 静默 ≠ 不做事：失败留一条 console.warn 供自查，但**绝不**产生任何 UI
          if (!res || !res.ok) {
            if (warn) warn('[Updater] 启动自动检查失败（已静默忽略）:', (res && res.error) || res);
          }
          return;
        }
        try { doPopup(res); }
        catch (e) { if (warn) warn('[Updater] 自动检查弹窗失败:', e); }
      });
    } catch (e) {
      if (warn) warn('[Updater] 启动自动检查发起失败（已静默忽略）:', e);
    }
    return true;
  },

  /** HTML 转义（公告文本来自网络，必须防注入） */
  esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  },

  /**
   * 弹窗 HTML 组装（**纯函数**，无 DOM 副作用，69.10 单测直测本函数）。
   * showResult 只负责挂载与事件，逻辑全在这里——这样静默/转义/分支都能在
   * 无 DOM 的 node 单测里断言，不必给项目引 jsdom（AGENTS §1 无依赖红线）。
   *
   * @param {Object} res  check() 的结果
   * @param {Object} [opts]
   * @param {string} [opts.mode] ''（默认，三分支：新版本/已最新/失败）
   *                       'notes'（更新公告模式，见下）
   * 公告模式语义（设置界面「公告」按钮，2026-10-02）：
   *   **无论 hasUpdate  true 还是 false 都显示公告正文**——用户主动点「公告」
   *   要的是「线上最新版写了什么」，不是「有没有更新」；已是最新版时也照样显示。
   *   失败时也必须有提示（主动点的不能静默），但文案与检查模式区分开。
   */
  buildPopupHtml(res, opts) {
    opts = opts || {};
    if (opts.mode === 'notes') return this._popupNotesHtml(res);
    var html = '<div class="update-popup"><div class="update-popup-title">';
    if (res.ok && res.hasUpdate) {
      // 换行交给 CSS 的 white-space: pre-wrap 处理；再插 <br> 会让空行变成双倍行距
      var noteHtml = res.note ? '<p class="update-popup-hint">' + this.esc(res.note) + '</p>' : '';
      html += '发现新版本 v' + this.esc(res.latest) + '</div>'
        + '<div class="update-popup-body">'
        + '<p>当前版本 v' + this.esc(res.current) + ' → 最新版本 v' + this.esc(res.latest) + '</p>'
        + noteHtml
        + '<div class="update-popup-notes">' + this.esc(res.notes) + '</div>'
        + '<div class="update-popup-howto"><b>推荐：双击游戏目录下的 update.bat</b>'
        + '<p>它会自动完成：查版本 → 下载 → 校验 → 备份旧文件 → 覆盖更新，全程不用你操作。</p>'
        + '<p class="update-popup-hint">· 你放在 <b>js\\mods</b> 里的 Mod <b>不会被覆盖、不会被删除</b>；'
        + '更新包里本来就不含这个目录（所以在更新包里找不到 mods 是正常的，你的 Mod 在游戏目录里）。<br>'
        + '· 覆盖前会自动把旧文件备份到临时目录，万一出问题可以手动还原。<br>'
        + '· 卡在某个下载源时脚本会自动换下一个，不用重试。</p></div></div>'
        + '<div class="update-popup-btns">'
        + '<button class="update-popup-btn" id="update-open-page">打不开？手动下载（备用）</button>'
        + '<button class="update-popup-btn" id="update-close">关闭</button></div>';
    } else if (res.ok) {
      html += '检查完成</div>'
        + '<div class="update-popup-body"><p>当前已是最新版本 v' + this.esc(res.current) + '。</p></div>'
        + '<div class="update-popup-btns"><button class="update-popup-btn" id="update-close">关闭</button></div>';
    } else {
      html += '检查失败</div>'
        + '<div class="update-popup-body"><p>无法连接更新源（' + this.esc(res.error) + '）。</p>'
        + '<p class="update-popup-hint">请检查网络；也可到发布页手动查看新版本。</p></div>'
        + '<div class="update-popup-howto">直接双击游戏目录下的 <b>update.bat</b> 即可，'
        + '它和这里用的是同一套地址，但会自动依次尝试 GitHub 和国内镜像，成功率更高。</div>'
        + '<div class="update-popup-btns">'
        + '<button class="update-popup-btn primary" id="update-open-page">手动下载（备用）</button>'
        + '<button class="update-popup-btn" id="update-close">关闭</button></div>';
    }
    return html + '</div>';
  },

  /** 公告模式 HTML（buildPopupHtml(mode:'notes') 的实现，独立成方法便于 69.10 直测） */
  _popupNotesHtml(res) {
    var html = '<div class="update-popup"><div class="update-popup-title">';
    if (res && res.ok) {
      // 标题刻意**不写**「发现新版本」：本模式 hasUpdate 可能为 false（已是最新）
      var noteHtml = (res.note && res.note !== '') ? '<p class="update-popup-hint">' + this.esc(res.note) + '</p>' : '';
      // 三种相对位置分别给不同落点文案（公告模式不假定 hasUpdate，故不能只看它）
      var diff = this.compareVersions(res.latest, res.current);
      var tips;
      if (diff > 0) {
        tips = '<p class="update-popup-hint">这就是线上最新版的完整更新公告。'
          + '需要更新的话，双击游戏目录下的 <b>update.bat</b> 即可。</p>';
      } else if (diff === 0) {
        tips = '<p class="update-popup-hint">你的本地版本就是线上最新版，无需更新。'
          + '下面是这一版的完整更新公告，随时可以回看。</p>';
      } else {
        tips = '<p class="update-popup-hint">你的本地版本比线上还新（自己改过或装了 mod 版），'
          + '双击 update.bat 可能会提示无需更新，这是正常的。</p>';
      }
      html += 'v' + this.esc(res.latest) + ' 更新公告</div>'
        + '<div class="update-popup-body">'
        + '<p>当前线上版本 v' + this.esc(res.latest)
        + '（你的本地版本 v' + this.esc(res.current) + '）</p>'
        + noteHtml
        + '<div class="update-popup-notes">' + (res.notes ? this.esc(res.notes) : '（本次发布没有填写公告）') + '</div>'
        + '<div class="update-popup-howto">' + tips + '</div></div>'
        + '<div class="update-popup-btns">'
        + '<button class="update-popup-btn" id="update-open-page">到发布页看全部版本</button>'
        + '<button class="update-popup-btn" id="update-close">关闭</button></div>';
    } else {
      // 主动点的检查失败**不能静默**（与启动自动检查的完全静默相反），
      // 但文案要区分：这里是「公告拿不到」，不是「检查失败」
      html += '没能取到更新公告</div>'
        + '<div class="update-popup-body"><p>连不上更新源（' + this.esc(res && res.error) + '），取不到线上公告。</p>'
        + '<p class="update-popup-hint">启动时游戏已经自动检查过一次了（那时没提示就说明当时正常）。'
        + '请检查网络后点「刷新」再试，或直接到发布页查看。</p></div>'
        + '<div class="update-popup-howto">也可以直接双击游戏目录下的 <b>update.bat</b>，'
        + '它会自动依次尝试 GitHub 和国内镜像，成功率比这里更高。</div>'
        + '<div class="update-popup-btns">'
        + '<button class="update-popup-btn primary" id="update-open-page">手动打开发布页</button>'
        + '<button class="update-popup-btn" id="update-close">关闭</button></div>';
    }
    return html + '</div>';
  },

  /**
   * 结果弹窗：新版本公告 / 已是最新 / 检查失败 / 更新公告模式。
   * @param {Object} res  check() 的结果
   * @param {Object} [opts] 见 buildPopupHtml（opts.mode = 'notes' = 公告模式）
   */
  showResult(res, opts) {
    // 防重复弹窗：连点「检查更新」时先清掉上一次的遮罩，避免叠层
    var old = document.querySelector('.update-popup-mask');
    if (old && old.parentNode) old.parentNode.removeChild(old);
    var mask = document.createElement('div');
    mask.className = 'update-popup-mask';
    mask.innerHTML = this.buildPopupHtml(res, opts);
    document.body.appendChild(mask);
    function close() { if (mask.parentNode) mask.parentNode.removeChild(mask); }
    mask.addEventListener('click', function(e) { if (e.target === mask) close(); });
    var closeBtn = mask.querySelector('#update-close');
    if (closeBtn) closeBtn.addEventListener('click', close);
    var openBtn = mask.querySelector('#update-open-page');
    if (openBtn) openBtn.addEventListener('click', function() { window.open(Updater.RELEASE_PAGE, '_blank'); });
  },
};
