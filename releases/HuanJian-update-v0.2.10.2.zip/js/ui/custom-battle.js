/**
 * custom-battle.js — 自定义战斗配置界面
 *
 * 配置地图规格、敌人列表、方案管理，确认后回调进入战斗。
 */
class CustomBattleScreen {
  /**
   * @param {function} onStart — callback(battleConfig)
   * @param {function} onBack  — callback() when "返回" clicked
   */
  constructor(onStart, onBack) {
    this._onStart = onStart;
    this._onBack = onBack;
    this._config = JSON.parse(JSON.stringify(DEFAULT_BATTLE_CONFIG));
    this._expanded = { enemy: -1, ally: -1 };
    this._build();
    this._popup = new TermOverridesPopup();
  }

  _build() {
    var overlay = document.getElementById('custom-battle-overlay');
    if (!overlay) return;
    this._overlay = overlay;
  }

  show() {
    if (!this._overlay) return;
    // 尝试恢复上次配置
    try {
      var raw = localStorage.getItem('huanjian.lastCustomConfig');
      if (raw) {
        this._config = JSON.parse(raw);
        if (!this._config.allies) this._config.allies = [];  // 旧存档兼容
        // 旧存档兼容（2026-11-08）：机制词条从「基础属性覆写」挪到「自定义加成」
        migrateCustomConfig(this._config);
      }
    } catch (e) {}
    this._overlay.style.display = 'flex';
    this._render();
  }

  hide() {
    if (this._overlay) this._overlay.style.display = 'none';
  }

  /* ── 全量渲染 ──────────────────────────────────────────────────────── */
  _render() {
    var self = this;
    var html = '';

    // ── 顶栏：标题 + 方案管理 ────────────────────────────────────────
    html += '<div class="cb-top-bar">'
      + '<span class="cb-title">自定义战斗</span>'
      + '<div class="cb-preset-row">'
      + '<button id="cb-save-btn" class="cb-btn-sm">保存方案</button>'
      + '</div></div>'
      + '<div class="cb-preset-list" id="cb-preset-list"></div>';

    // ── 地图规格 ──────────────────────────────────────────────────────
    html += '<div class="cb-section"><div class="cb-section-label">地图规格</div><div class="cb-map-row">';
    for (var mi = 0; mi < MAP_OPTIONS.length; mi++) {
      var m = MAP_OPTIONS[mi];
      var active = this._config.mapSizeKm === m ? ' active' : '';
      html += '<button class="cb-map-btn' + active + '" data-km="' + m + '">' + m + '×' + m + ' km</button>';
    }
    html += '</div>';

    // 出生模式
    html += '<div class="cb-spawn-row">'
      + '<span class="cb-spawn-label">出生模式：</span>'
      + '<button class="cb-spawn-btn' + (this._config.spawnMode === 'random' ? ' active' : '') + '" data-spawn="random">随机</button>'
      + '<button class="cb-spawn-btn' + (this._config.spawnMode === 'fixed' ? ' active' : '') + '" data-spawn="fixed">固定排布</button>'
      + '</div>'
      // 视同战役（2026-08-08 原为裸 checkbox 与界面风格不匹配，2026-09-19 改为与出生模式同款的按钮）：
      //   开启后**按战役规则处理**——战舰技能「战役」属性生效；燃烧/漏水等百分比扣血读取我舰血量（AGENTS §5.30）
      + '<div class="cb-spawn-row">'
      + '<span class="cb-spawn-label">视同战役：</span>'
      + '<button type="button" class="cb-spawn-btn' + (this._config.campaign ? ' active' : '') + '" id="cb-campaign-btn"'
      + ' title="开启后按战役规则处理：战舰技能「战役」属性生效；燃烧/漏水等百分比扣血读取我舰血量">'
      + (this._config.campaign ? '开 · 战役规则' : '关 · 普通规则') + '</button>'
      + '<span class="cb-campaign-hint">「战役」属性生效 · 百分比扣血读我舰血量</span></div></div>';

    // ── 敌人列表 ──────────────────────────────────────────────────────
    html += '<div class="cb-section">'
      + '<div class="cb-section-label">敌人列表 <span class="cb-enemy-count">(' + this._config.enemies.length + '/' + MAX_CUSTOM_ENEMIES + ')</span></div>'
      + '<div class="cb-enemy-list" id="cb-enemy-list">';

    for (var ei = 0; ei < this._config.enemies.length; ei++) {
      var ecfg = this._config.enemies[ei];
      html += this._renderShipCard(ei, ecfg, 'enemy');
    }

    html += '</div>';

    // 添加按钮
    if (this._config.enemies.length < MAX_CUSTOM_ENEMIES) {
      html += '<button id="cb-add-enemy-btn" class="cb-btn-sm">+ 添加敌人</button>';
    }

    html += '</div>';

    // ── AI 友军列表（青色）────────────────────────────────────────────
    html += '<div class="cb-section">'
      + '<div class="cb-section-label cb-ally-title">AI 友军 <span class="cb-enemy-count">(' + this._config.allies.length + '/' + MAX_CUSTOM_ALLIES + ')</span></div>'
      + '<div class="cb-enemy-list" id="cb-ally-list">';

    for (var ai = 0; ai < this._config.allies.length; ai++) {
      var acfg = this._config.allies[ai];
      html += this._renderShipCard(ai, acfg, 'ally');
    }

    html += '</div>';

    // 添加按钮
    if (this._config.allies.length < MAX_CUSTOM_ALLIES) {
      html += '<button id="cb-add-ally-btn" class="cb-btn-sm">+ 添加友军</button>';
    }

    html += '</div>';

    // ── 底部按钮 ──────────────────────────────────────────────────────
    html += '<div class="cb-bottom-bar">'
      + '<button id="cb-back-btn" class="cb-btn-back">← 返回</button>'
      + '<button id="cb-start-btn" class="cb-start-btn">开始战斗</button>'
      + '</div>';

    this._overlay.innerHTML = html;

    // ── 绑定事件 ────────────────────────────────────────────────────
    this._bindMapButtons();
    this._bindSpawnButtons();
    this._bindShipEvents('enemy');
    this._bindShipEvents('ally');
    this._bindPresets();

    document.getElementById('cb-back-btn').addEventListener('click', function() { self.hide(); if (self._onBack) self._onBack(); });
    // 视同战役开关（2026-08-08；2026-09-19 checkbox → 按钮，语义扩为"战役规则总开关"）
    //   显示一律由 _render() 从 config 派生（与地图/出生模式按钮同款约定），
    //   不在 handler 里手补 textContent —— 那样会出现"显示与实际不一致"（2026-09-19 修）
    var cbCampBtn = document.getElementById('cb-campaign-btn');
    if (cbCampBtn) {
      cbCampBtn.addEventListener('click', function() {
        self._config.campaign = !self._config.campaign;
        self._render();
      });
    }
    document.getElementById('cb-start-btn').addEventListener('click', function() {
      // 保存配置记忆
      try { localStorage.setItem('huanjian.lastCustomConfig', JSON.stringify(self._config)); } catch (e) {}
      self._onStart(self._config);
    });
  }



  /* ── 人机武器槽 HTML（同类统一槽；2026-08-08 抽出供 count 变更局部刷新）── */
  _weaponSlotsHtml(ecfg, index, team) {
    var h = '';
    var wTypes = [['mainGun', '主炮', 'mainGunCount'], ['torpedo', '鱼雷', 'torpedoCount'], ['secondary', '副炮', 'secondaryCount'], ['mine', '水雷', 'mineCount']];
    var stDef = SHIP_TYPE_DEFAULTS[ecfg.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
    for (var wi = 0; wi < wTypes.length; wi++) {
      var wtKey = wTypes[wi][2];
      var wtCount = (ecfg.overrides && ecfg.overrides[wtKey] != null)
        ? ecfg.overrides[wtKey] : (stDef[wtKey] != null ? stDef[wtKey] : 0);
      if (wtCount <= 0) continue;
      var wId = ecfg.weapons && ecfg.weapons[wTypes[wi][0]];
      var wObj = wId ? getEnemyWeaponById(wId) : getEnemyDefaultWeapon(wTypes[wi][0], ecfg.shipType);
      h += '<div class="cb-enemy-weapon-row">'
        + '<span class="cb-enemy-weapon-type">' + wTypes[wi][1] + '×' + wtCount + '</span>'
        + '<span class="cb-enemy-weapon-name">' + (wObj ? wObj.name : '—') + '</span>'
        + '<button class="cb-enemy-weapon-swap" data-ei="' + index + '" data-team="' + team + '" data-wt="' + wTypes[wi][0] + '">更换</button>'
        + '</div>';
    }
    return h;
  }



  /* ── 人机武器替换弹窗（2026-08-08：同类统一槽，人机武器库，舰种隔离）── */
  _showEnemyWeaponReplace(team, ei, wType) {
    var self = this;
    var listKey = team === 'ally' ? 'allies' : 'enemies';
    var ecfg = this._config[listKey][ei];
    var shipType = ecfg.shipType || 'cruiser';
    var typeLabel = { mainGun: '主炮', torpedo: '鱼雷', secondary: '副炮', mine: '水雷' }[wType] || wType;
    var weapons = getAvailableEnemyWeapons(wType, shipType);
    var curId = ecfg.weapons && ecfg.weapons[wType];

    var popup = document.createElement('div');
    popup.className = 'cb-weapon-popup';
    popup.innerHTML = ''
      + '<div class="cb-weapon-popup-box">'
      + '<div class="cb-weapon-popup-title">更换' + typeLabel + ' — ' + ecfg.name + '（' + SHIP_TYPE_LABELS[shipType] + '）</div>'
      + '<div class="cb-weapon-popup-list">';
    for (var i = 0; i < weapons.length; i++) {
      var w = weapons[i];
      var isCur = w.id === curId;
      popup.innerHTML += '<div class="cb-weapon-option' + (isCur ? ' current' : '') + '" data-id="' + w.id + '">'
        + '<span class="cb-weapon-opt-name">' + w.name + (isCur ? '（当前）' : '') + '</span>'
        + '<span class="cb-weapon-opt-info">伤害 ' + w.damage
        + (w.barrelsPerMount ? ' · ' + w.barrelsPerMount + ' 联装' : '')
        + (w.shellSpeed ? ' · 炮速 ' + w.shellSpeed : (w.speed ? ' · ' + w.speed + ' 节' : '')) + '</span>'
        + '</div>';
    }
    if (weapons.length === 0) {
      popup.innerHTML += '<div class="cb-weapon-popup-empty">该舰种暂无此类型人机武器</div>';
    }
    popup.innerHTML += '</div>'
      + '<button class="cb-weapon-popup-close">关闭</button>'
      + '</div>';

    // 选择武器
    popup.querySelectorAll('.cb-weapon-option').forEach(function(opt) {
      opt.addEventListener('click', function() {
        if (!ecfg.weapons) ecfg.weapons = {};
        ecfg.weapons[wType] = this.dataset.id;
        popup.remove();
        self._render();
      });
    });
    popup.querySelector('.cb-weapon-popup-close').addEventListener('click', function() { popup.remove(); });
    this._overlay.appendChild(popup);
  }

  /* ── 地图规格按钮 ──────────────────────────────────────────────────── */
  _bindMapButtons() {
    var self = this;
    this._overlay.querySelectorAll('.cb-map-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var km = parseInt(this.dataset.km);
        self._config.mapSizeKm = km;
        self._render();
      });
    });
  }

  /* ── 出生模式按钮 ──────────────────────────────────────────────────── */
  _bindSpawnButtons() {
    var self = this;
    // ⚠️ 选择器必须带 [data-spawn]（2026-09-19 修 BUG）：视同战役按钮为复用样式也挂了
    //   .cb-spawn-btn 类，但它是双态开关而非二选一——若不排除，点击它会被这里再绑一层
    //   "写 spawnMode=undefined + 整屏重渲染"，导致 ① 视同战役显示与实际相反
    //   ② 出生模式被悄悄清空。规范：**复用样式类时，行为绑定必须按 data 属性收窄**。
    this._overlay.querySelectorAll('.cb-spawn-btn[data-spawn]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        self._config.spawnMode = this.dataset.spawn;
        self._render();
      });
    });
  }

  /* ── 方案管理 ──────────────────────────────────────────────────────── */
  _bindPresets() {
    var self = this;
    var listEl = document.getElementById('cb-preset-list');
    if (!listEl) return;

    var presets = loadPresets();
    if (presets.length === 0) { listEl.innerHTML = ''; }

    // 方案列表：每个方案一条，可点击加载，可删除
    var h = '';
    for (var i = 0; i < presets.length; i++) {
      h += '<div class="cb-preset-item">'
        + '<span class="cb-preset-name" data-idx="' + i + '">' + (presets[i].name || '方案' + (i + 1)) + '</span>'
        + '<button class="cb-preset-delete" data-idx="' + i + '" title="删除">🗑</button>'
        + '</div>';
    }
    listEl.innerHTML = h;

    // 点击方案名 → 加载
    listEl.querySelectorAll('.cb-preset-name').forEach(function(span) {
      span.addEventListener('click', function() {
        var idx = parseInt(this.dataset.idx);
        var presets = loadPresets();
        if (presets[idx] && presets[idx].config) {
          self._config = JSON.parse(JSON.stringify(presets[idx].config));
          migrateCustomConfig(self._config);   // 旧存档兼容（2026-11-08）：机制词条挪到「自定义加成」
          self._render();
        }
      });
    });

    // 点击垃圾桶 → 删除
    listEl.querySelectorAll('.cb-preset-delete').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        var idx = parseInt(this.dataset.idx);
        var presets = loadPresets();
        if (!presets[idx]) return;
        if (!confirm('删除方案 "' + (presets[idx].name || '') + '" ？')) return;
        presets.splice(idx, 1);
        savePresets(presets);
        self._render();
      });
    });

    // 保存
    var saveBtn = document.getElementById('cb-save-btn');
    if (saveBtn) {
      saveBtn.addEventListener('click', function() {
        var presets = loadPresets();
        if (presets.length >= MAX_PRESETS) {
          alert('最多保存 ' + MAX_PRESETS + ' 个方案');
          return;
        }
        var name = prompt('方案名称：', '自定义方案' + (presets.length + 1));
        if (!name) return;
        presets.push({
          name: name,
          createdAt: Date.now(),
          config: JSON.parse(JSON.stringify(self._config)),
        });
        savePresets(presets);
        self._render();
      });
    }
  }
}
