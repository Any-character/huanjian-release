/**
 * start-screen.js — Pre-battle ship selection screen.
 *
 * Two modes:
 *   ship-select  — 战舰选择 + 属性面板 + 预览 (default)
 *   enhancement  — 强化界面（tab 栏切换进入）
 *
 * Calls onStart(ship) when the player confirms a ship.
 */

class StartScreen {
  /**
   * @param {string} overlayId — DOM id of the overlay container
   * @param {string} canvasId  — DOM id of the preview canvas
   * @param {function} onStart — callback (ship) when "开始战斗" clicked
   */
  constructor(overlayId, canvasId, onStart) {
    this.overlay = document.getElementById(overlayId);
    this.canvas  = document.getElementById(canvasId);
    this.ctx     = this.canvas.getContext('2d');
    this.onStart = onStart;
    // 恢复上次选船
    var savedIdx = parseInt(localStorage.getItem('huanjian.selectedShipIndex'));
    this.selectedIndex = (!isNaN(savedIdx) && savedIdx >= 0 && savedIdx < SHIP_LIBRARY.length) ? savedIdx : 0;
    this.state = 'ship-select';
    this._currentPopup = null;    // 当前弹窗引用，确保同时只有一个
    this._settingsScreen = new SettingsScreen();
    this._popup = new TermOverridesPopup();
    this._build();
    this._drawPreview();
  }

  _build() {
    var cfg = START_SCREEN;
    this.overlay.innerHTML = ''
      + '<div id="ss-tab-bar">'
      + '  <div class="ss-tab active" data-tab="enhancement">强化</div>'
      + '  <div class="ss-tab" data-tab="commander">指挥官</div>'
      // ⚠️ 文案必须是「舰种技能」：与强化页里的「战舰技能」（单艘船独有，enhance.js 渲染）
      //    是两个系统，同叫「技能」会让玩家分不清。第 85 节有断言守着这个文案。
      + '  <div class="ss-tab" data-tab="classskill">舰种技能</div>'
      + '  <div class="ss-tab disabled" data-tab="skin">涂装</div>'
      + '</div>'
      + '<div id="ss-body">'
      + '  <div id="ss-ship-select" style="display:flex;flex-direction:column;flex:1;gap:16px">'
      + '    <div id="ss-top">'
      + '      <div id="ss-stats-panel">'
      + '        <div id="ss-stats-title">战舰属性</div>'
      + '        <div id="ss-stats-list"></div>'
      + '      </div>'
      + '      <div id="ss-preview-panel">'
      + '        <div id="ss-ship-name"></div>'
      + '        <canvas id="ss-preview-canvas-actual" width="' + cfg.previewSize.w + '" height="' + cfg.previewSize.h + '"></canvas>'
      + '      </div>'
      + '      <button id="ss-help-btn" title="设置">⚙</button>'
      + '    </div>'
      + '    <div id="ss-bottom">'
      + '      <div id="ss-ships-row"></div>'
      + '      <button id="ss-start-btn">开始战斗</button>'
      + '    </div>'
      + '  </div>'
      + '  <div id="ss-enhancement" style="display:none;flex:1"></div>'
      + '  <div id="ss-commander" style="display:none;flex:1"></div>'
      // 舰种技能页签容器（内容由 js/ui/class-skills.js 渲染）
      + '  <div id="ss-classskill" style="display:none;flex:1"></div>'
      + '</div>';
    // use the in-DOM canvas (browsers may swap innerHTML's canvas)
    this.canvas = document.getElementById('ss-preview-canvas-actual');
    this.ctx = this.canvas.getContext('2d');

    this._renderStats();
    this._renderShipCards();

    document.getElementById('ss-start-btn').addEventListener('click', () => {
      var ship = SHIP_LIBRARY[this.selectedIndex];
      this.hide();
      this.onStart(ship);
    });

    // 设置（齿轮）
    document.getElementById('ss-help-btn').addEventListener('click', () => {
      this._settingsScreen.show();
    });

    this._bindTabs();
  }

  /* ── 弹窗管理 ──────────────────────────────────────────────────── */

  /** 关闭当前弹窗（如果存在），显示新弹窗 */
  _openPopup(popup) {
    if (this._currentPopup) {
      this._currentPopup.remove();
      this._currentPopup = null;
    }
    this._currentPopup = popup;
    this.overlay.appendChild(popup);
  }

  /** 关闭当前弹窗 */
  _closePopup() {
    if (this._currentPopup) {
      this._currentPopup.remove();
      this._currentPopup = null;
    }
  }

  /* ── tab 切换 ──────────────────────────────────────────────────── */

  _bindTabs() {
    var self = this;
    document.querySelectorAll('.ss-tab').forEach(function(tab) {
      tab.addEventListener('click', function() {
        if (this.classList.contains('disabled')) return;
        document.querySelectorAll('.ss-tab').forEach(function(t) { t.classList.remove('active'); });
        this.classList.add('active');
        if (this.dataset.tab === 'enhancement') { self._showEnhancement(); }
        if (this.dataset.tab === 'commander') { self._showCommander(); }
        // 舰种技能（js/ui/class-skills.js 提供 _showClassSkills）
        if (this.dataset.tab === 'classskill') { self._showClassSkills(); }
      });
    });
  }

  _showShipSelect() {
    this.state = 'ship-select';
    this._closePopup();
    document.getElementById('ss-enhancement').style.display = 'none';
    document.getElementById('ss-commander').style.display = 'none';
    document.getElementById('ss-classskill').style.display = 'none';
    document.getElementById('ss-ship-select').style.display = 'flex';
    document.querySelectorAll('.ss-tab').forEach(function(t) { t.classList.remove('active'); });
  }

  /* ── 指挥官界面 ────────────────────────────────────────────────── */

  _showCommander() {
    this.state = 'commander';
    this._closePopup();
    document.getElementById('ss-ship-select').style.display = 'none';
    document.getElementById('ss-enhancement').style.display = 'none';
    document.getElementById('ss-classskill').style.display = 'none';
    var el = document.getElementById('ss-commander');
    el.style.display = 'flex';
    var self = this;
    if (!this._commanderScreen) {
      this._commanderScreen = new CommanderScreen(el, function() { self._showShipSelect(); });
    }
    this._commanderScreen.render();
  }

  /* ── 强化界面 ──────────────────────────────────────────────────── */

  /* ── 原有方法 ─────────────────────────────────────────────────── */

  /**
   * 战舰属性栏：基础属性 / 附加词条 分组显示（2026-11-08）
   *
   * 分类唯一来源 = js/data/stat-groups.js（基础属性百分比乘算、词条百分比加算）。
   * 船自带的词条（如阳炎抵抗配损）与基础属性性质不同，必须分开显示——
   * 单测第 92 节守卫：舰船 stats 里出现未登记的属性名会直接红。
   * ⚠️ 口径只写在文档/代码里，**不进界面**（字人 2026-11-08）：面板只显示组名。
   */
  _renderStats() {
    var ship = SHIP_LIBRARY[this.selectedIndex];
    var nameEl = document.getElementById('ss-ship-name');
    nameEl.textContent = ship.name + ' · ' + ship.desc;
    var list = document.getElementById('ss-stats-list');

    var base = [], terms = [], info = [];
    for (var key in ship.stats) {
      if (!ship.stats.hasOwnProperty(key)) continue;
      if (isBaseStatLabel(key)) base.push(key);
      else if (isInfoStatLabel(key)) info.push(key);
      else terms.push(key);   // 未登记的新属性默认按词条显示（单测会红，提示去登记）
    }

    // 一次性拼到局部变量再赋值（禁 el.innerHTML +=）
    var h = this._statGroupHtml('基础属性', 'base');
    for (var b = 0; b < base.length; b++) h += this._statRowHtml(base[b], ship.stats[base[b]], 'base');
    if (terms.length) {
      h += this._statGroupHtml('附加词条', 'term');
      for (var t = 0; t < terms.length; t++) h += this._statRowHtml(terms[t], ship.stats[terms[t]], 'term');
    }
    for (var i = 0; i < info.length; i++) h += this._statRowHtml(info[i], ship.stats[info[i]], 'info');
    list.innerHTML = h;
  }

  /** 属性分组标题（只写组名；乘算/加算口径不进界面） */
  _statGroupHtml(label, kind) {
    return '<div class="ss-stat-group ss-stat-group-' + kind + '">' + label + '</div>';
  }

  /** 单行属性 */
  _statRowHtml(key, val, kind) {
    return '<div class="ss-stat-row ss-stat-' + kind + '">'
      + '<span class="ss-stat-key">' + key + '</span>'
      + '<span class="ss-stat-val">' + val + '</span></div>';
  }

  _renderShipCards() {
    var row = document.getElementById('ss-ships-row');
    row.innerHTML = '';
    SHIP_LIBRARY.forEach(function(ship, idx) {
      var self = this;
      var card = document.createElement('div');
      card.className = 'ss-ship-card' + (idx === this.selectedIndex ? ' selected' : '');
      var cardHtml = '<div class="ss-ship-card-name">' + ship.name + '</div>';
      // 古鹰（测试舰）专属「加成」按钮（填入值 = 对基础属性的额外加成），其余战舰没有
      if (ship.id === 'guying') {
        cardHtml += '<button class="ss-card-more-btn" title="调节加成（填入值作为基础属性的额外加成）">加成</button>';
      }
      card.innerHTML = cardHtml;
      card.addEventListener('click', function() {
        self.selectedIndex = idx;
        try { localStorage.setItem('huanjian.selectedShipIndex', idx); } catch (e) {}
        self._renderStats();
        self._renderShipCards();
        self._drawPreview();
      });
      if (ship.id === 'guying') {
        card.querySelector('.ss-card-more-btn').addEventListener('click', function(e) {
          e.stopPropagation();
          var vals = loadGuyingTermOverrides();
          self._popup.open({
            title: '古鹰加成',
            values: vals,
            onCommit: function() { saveGuyingTermOverrides(vals); },
          });
        });
      }
      row.appendChild(card);
    }.bind(this));
  }

  /** Render the selected ship top-down inside the preview canvas. */
  _drawPreview() {
    var ctx = this.ctx;
    var W   = this.canvas.width;
    var H   = this.canvas.height;
    var ship = SHIP_LIBRARY[this.selectedIndex];
    var cfg  = ship.config;

    // background gradient
    var grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#123A5C');
    grad.addColorStop(1, '#0D2B45');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // subtle sea grid
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    for (var x = 0; x < W; x += 30) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (var y = 0; y < H; y += 30) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    // ship centered, length × width scaled up for visibility
    var cx = W / 2;
    var cy = H / 2;
    var scale = 2.6;
    var hl = cfg.length * scale / 2;
    var hw = cfg.width  * scale / 2;
    ctx.save();
    ctx.translate(cx, cy);

    // hull
    ctx.fillStyle = cfg.color;
    ctx.fillRect(-hw, -hl, cfg.width * scale, cfg.length * scale);
    ctx.strokeStyle = cfg.outlineColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(-hw, -hl, cfg.width * scale, cfg.length * scale);

    // turrets: row 1 (main guns front)
    ctx.fillStyle = '#666';
    var mt = (ship.mainGunCount != null) ? ship.mainGunCount : MAIN_GUN_CONFIG.mountCount;
    for (var i = 0; i < mt; i++) {
      var tx = (i - (mt - 1) / 2) * (cfg.width * scale / (mt + 1));
      ctx.beginPath();
      ctx.arc(tx, -hl * 0.5, cfg.width * scale * 0.08, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    // torpedoes (rear)
    var tt = (ship.torpedoCount != null) ? ship.torpedoCount : TORPEDO_CONFIG.mountCount;
    for (var i = 0; i < tt; i++) {
      var tx = (i - (tt - 1) / 2) * (cfg.width * scale / (tt + 1));
      ctx.fillStyle = '#4488FF';
      ctx.fillRect(tx - 4, hl * 0.4, 8, hl * 0.3);
    }

    // secondary turrets (sides, white dots)
    var st = (ship.secondaryCount != null) ? ship.secondaryCount : 0;
    var perSide = Math.floor(st / 2);
    if (perSide > 0) {
      ctx.fillStyle = '#FFFFFF';
      for (var i = 0; i < perSide; i++) {
        var sy = -hl * 0.6 + i * (hl * 1.2 / (perSide - 1 || 1));
        ctx.beginPath(); ctx.arc(-hw * 0.9, sy, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc( hw * 0.9, sy, 3, 0, Math.PI * 2); ctx.fill();
      }
    }

    // mines (stern, black dots)
    var mc = (ship.mineCount != null) ? ship.mineCount : 0;
    for (var i = 0; i < mc; i++) {
      var mx = (i - (mc - 1) / 2) * (cfg.width * scale / (mc + 1));
      ctx.fillStyle = '#111111';
      ctx.beginPath();
      ctx.arc(mx, hl * 0.55, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#666666';
      ctx.stroke();
    }

    // bow indicator
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.beginPath();
    ctx.moveTo(0, -hl);
    ctx.lineTo(-hw * 0.4, -hl * 0.5);
    ctx.lineTo(hw * 0.4, -hl * 0.5);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  show() { this.overlay.style.display = 'flex'; }
  hide() { this.overlay.style.display = 'none'; }
}
