/**
 * class-skills.js — 舰种技能界面（start-screen「舰种技能」页签，2026-10-03）
 *
 * ⚠️ 与「战舰技能」（js/ui/enhance.js 的 _renderShipSkills，单艘船独有）是两个东西 —— 叫法见 `docs/glossary.md`。
 *    本页是**整个舰种共有**的舰种技能，数据在 js/data/ship-class-skills.js，
 *    生效走 js/systems/class-skills.js 的 ClassSkills（单一入口 getEffects）。
 *
 * 结构（设计文档 §六）：
 *   顶部 enh-top-bar（返回选船，与强化/指挥官同款）
 *   舰种切换行：巡洋舰 战列舰 驱逐舰 潜艇 航母 特种（后 3 个项目无此舰种 → 「敬请期待」）
 *   每系一块：系标题（未启用者「点此切换」→ 即时写 localStorage）+ 技能图标网格
 *   点图标 → 弹窗（复用 enhance.js 的 .skill-card / .skill-name / .skill-effect）
 *
 * 设计约束：
 *   ① **不显示等级**（设计文档 §5.2 字人确认）——弹窗与图标都不出「等级 N」。
 *   ② ready:false 的技能图标**可点**，弹窗显示「敬请期待」，不产生任何战斗效果。
 *   ③ 被动偏绿、主动偏蓝。
 *   ④ 两系切换只在这里（战场中 UI 不出现 → 自然满足「战斗中不可切」）。
 *   ⑤ 弹窗 z-index ≥400（AGENTS.md §5.8），沿用 .cb-weapon-popup 的 600 层。
 *
 * 挂载方式与 js/ui/enhance.js 一致：**扩展 StartScreen.prototype**（本文件不新建 class），
 * 但把 HTML 生成抽成**纯函数**挂在全局 ClassSkillsUI 上（不碰 DOM），
 * 这样 tests/run_tests.js 在 Node 无 DOM 环境下也能真跑渲染结果验证（第 85 节 G 组）。
 */

/** 舰种技能界面（纯函数 + 挂载入口） */
const ClassSkillsUI = {
  /** 舰种切换行。顺序照设计文档 §六；后 3 个项目里没有对应舰种，永远显示「敬请期待」。 */
  SHIP_TYPE_ROWS: [
    { type: 'cruiser',    label: '巡洋舰' },
    { type: 'battleship', label: '战列舰' },
    { type: 'destroyer',  label: '驱逐舰' },
    { type: 'submarine',  label: '潜艇' },
    { type: 'carrier',    label: '航母' },
    { type: 'special',    label: '特种' },
  ],

  /** 「敬请期待」统一文案（与数据文件里 ready:false 技能的 desc 一致）。 */
  SOON_TEXT: '敬请期待',

  /* ── 纯函数（不碰 DOM，第 85 节可直接调用验证）───────────────────────── */

  /** HTML 转义。数据来自本地文件（非网络），但仍按习惯转义防注入。 */
  escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },

  /** 取舰船的舰种（SHIP_LIBRARY 项是 _shipConfig 的扁平副本，优先读它）。 */
  typeOfShip(ship) {
    if (!ship) return null;
    if (ship._shipConfig && ship._shipConfig.shipType) return ship._shipConfig.shipType;
    if (ship.shipType) return ship.shipType;
    if (ship.config && ship.config.shipType) return ship.config.shipType;
    return null;
  },

  /** 舰种显示名：优先取数据文件里的 label（单一来源），否则取切换行定义。 */
  typeLabel(shipType) {
    var def = CLASS_SKILLS[shipType];
    if (def && def.label) return def.label;
    for (var i = 0; i < this.SHIP_TYPE_ROWS.length; i++) {
      if (this.SHIP_TYPE_ROWS[i].type === shipType) return this.SHIP_TYPE_ROWS[i].label;
    }
    return String(shipType == null ? '' : shipType);
  },

  /** 单个技能图标（网格里的一格）。ready:false 仍可点，只是显示为「未开放」态。 */
  buildSkillIconHtml(skill, pathIndex, skillIndex) {
    var isActive = skill.type === 'active';
    var cls = 'csk-icon ' + (isActive ? 'csk-icon-active' : 'csk-icon-passive')
      + (skill.ready === true ? '' : ' csk-icon-locked');
    return '<div class="' + cls + '" data-path="' + pathIndex + '" data-skill="' + skillIndex + '"'
      + ' title="' + this.escapeHtml(skill.name) + '">'
      + '<div class="csk-icon-name">' + this.escapeHtml(skill.name) + '</div>'
      + '<div class="csk-icon-tag">' + (isActive ? '主动' : '被动') + '</div>'
      + '</div>';
  },

  /** 一个系（含标题 + 图标网格）。未启用的系标题可点 → 切系。 */
  buildPathHtml(path, pathIndex, activeIndex) {
    var isOn = pathIndex === activeIndex;
    var h = '<div class="csk-path">'
      + '<div class="csk-path-head' + (isOn ? '' : ' csk-path-head-switch') + '"'
      + (isOn ? '' : ' data-switch="' + pathIndex + '" title="点此切换到该系"') + '>'
      + '<span class="csk-path-idx">' + (pathIndex + 1) + '</span>'
      + '<span class="csk-path-name">' + this.escapeHtml(path.name) + '</span>'
      + '<span class="csk-path-state' + (isOn ? '' : ' csk-path-state-off') + '">'
      + (isOn ? '已启用' : '未启用 · 点此切换') + '</span>'
      + '</div>'
      + '<div class="csk-grid">';
    for (var i = 0; i < path.skills.length; i++) {
      h += this.buildSkillIconHtml(path.skills[i], pathIndex, i);
    }
    return h + '</div></div>';
  },

  /** 舰种主体：空壳舰种（巡洋/战列/潜艇/航母/特种）→ 「敬请期待」，绝不抛异常（§9.3）。 */
  buildBodyHtml(shipType) {
    var paths = ClassSkills.getPaths(shipType);
    if (!paths || paths.length === 0) {
      return '<div class="csk-empty">「' + this.escapeHtml(this.typeLabel(shipType))
        + '」舰种技能敬请期待</div>';
    }
    var activeIndex = ClassSkills.getPathIndex(shipType);
    var h = '';
    for (var i = 0; i < paths.length; i++) h += this.buildPathHtml(paths[i], i, activeIndex);
    return h;
  },

  /** 舰种切换行。 */
  buildTypeBarHtml(shipType) {
    var h = '<div class="csk-typebar">';
    for (var i = 0; i < this.SHIP_TYPE_ROWS.length; i++) {
      var row = this.SHIP_TYPE_ROWS[i];
      h += '<div class="csk-type-btn' + (row.type === shipType ? ' csk-type-btn-on' : '')
        + '" data-type="' + row.type + '">' + this.escapeHtml(row.label) + '</div>';
    }
    return h + '</div>';
  },

  /** 整块面板 HTML。 */
  buildHtml(shipType) {
    return '<div class="enh-top-bar">'
      + '  <button id="csk-back-btn">← 返回选船</button>'
      + '  <span class="enh-title">舰种技能 — ' + this.escapeHtml(this.typeLabel(shipType)) + '</span>'
      + '</div>'
      + this.buildTypeBarHtml(shipType)
      + '<div class="csk-body">' + this.buildBodyHtml(shipType) + '</div>';
  },

  /**
   * 技能弹窗内容（复用 enhance.js 的 .skill-card 体系，不新造一套）。
   * ⚠️ 不显示等级（设计文档 §5.2）。
   * ready:false → 正文固定「敬请期待」，**不读数据里的 desc**（数据可能被改，UI 不该跟着失守）。
   */
  buildSkillCardHtml(skill) {
    var isActive = skill.type === 'active';
    var h = '<div class="skill-card csk-detail-card">'
      + '<div class="skill-name">' + this.escapeHtml(skill.name)
      + '<span class="csk-type-tag ' + (isActive ? 'csk-tag-active' : 'csk-tag-passive') + '">'
      + (isActive ? '主动' : '被动') + '</span></div>'
      + '<div class="skill-effects">';
    if (skill.ready === true) {
      var lines = String(skill.desc == null ? '' : skill.desc).split('\n');
      for (var i = 0; i < lines.length; i++) {
        if (lines[i]) {
          h += '<div class="skill-effect"><span class="skill-eff-text">'
            + this.escapeHtml(lines[i]) + '</span></div>';
        }
      }
    } else {
      h += '<div class="skill-effect"><span class="skill-eff-text">' + this.SOON_TEXT + '</span></div>'
        + '<div class="skill-effect"><span class="skill-eff-text">该技能尚未开放，暂不产生任何战斗效果</span></div>';
    }
    return h + '</div></div>';
  },
};

/* ── 挂载到 StartScreen（与 enhance.js 的 _showEnhancement 同一套路）───────── */

  /**
   * 「舰种技能」页签入口（start-screen.js 的 _bindTabs 调）。
   * 三个面板互斥：必须把 ship-select / enhancement / commander 全藏起来
   *（69.11 记的历史 bug：漏藏一个就两个面板叠一起）。
   */
  StartScreen.prototype._showClassSkills = function() {
    this.state = 'classskill';
    this._closePopup();
    document.getElementById('ss-ship-select').style.display = 'none';
    document.getElementById('ss-enhancement').style.display = 'none';
    document.getElementById('ss-commander').style.display = 'none';
    var el = document.getElementById('ss-classskill');
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    // 默认展示当前选中战舰的舰种；取不到就退回驱逐舰（本轮唯一有内容的舰种）
    if (!this._classSkillType) {
      this._classSkillType = ClassSkillsUI.typeOfShip(SHIP_LIBRARY[this.selectedIndex]) || 'destroyer';
    }
    this._renderClassSkills();
  };

  /** 渲染当前舰种面板并绑事件（切舰种 / 切系 / 点图标）。 */
  StartScreen.prototype._renderClassSkills = function() {
    var self = this;
    var el = document.getElementById('ss-classskill');
    el.innerHTML = ClassSkillsUI.buildHtml(this._classSkillType);

    document.getElementById('csk-back-btn').addEventListener('click', function() {
      self._showShipSelect();
    });

    el.querySelectorAll('.csk-type-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        self._classSkillType = this.dataset.type;
        self._renderClassSkills();
      });
    });

    // 切系：即时写存档（ClassSkills.setSelection），然后重渲染
    el.querySelectorAll('.csk-path-head-switch').forEach(function(head) {
      head.addEventListener('click', function() {
        ClassSkills.setSelection(self._classSkillType, parseInt(this.dataset.switch, 10));
        self._renderClassSkills();
      });
    });

    el.querySelectorAll('.csk-icon').forEach(function(icon) {
      icon.addEventListener('click', function() {
        self._showClassSkillPopup(parseInt(this.dataset.path, 10), parseInt(this.dataset.skill, 10));
      });
    });
  };

  /** 技能详情弹窗（HTML 渲染，不依赖 alert）。点遮罩或关闭按钮关闭。 */
  StartScreen.prototype._showClassSkillPopup = function(pathIndex, skillIndex) {
    var self = this;
    var paths = ClassSkills.getPaths(this._classSkillType);
    var path = paths ? paths[pathIndex] : null;
    var skill = (path && path.skills) ? path.skills[skillIndex] : null;
    if (!skill) return;

    this._closePopup();
    var popup = document.createElement('div');
    popup.className = 'csk-popup';
    popup.style.display = 'flex';
    popup.innerHTML = '<div class="csk-popup-box">'
      + ClassSkillsUI.buildSkillCardHtml(skill)
      + '<button class="enh-close-btn popup-close-x">关闭</button>'
      + '</div>';
    this._openPopup(popup);

    popup.addEventListener('click', function(e) { if (e.target === popup) self._closePopup(); });
    popup.querySelector('.popup-close-x').addEventListener('click', function() { self._closePopup(); });
  };
