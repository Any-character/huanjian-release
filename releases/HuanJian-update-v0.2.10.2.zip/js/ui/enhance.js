/**
 * ui/enhance.js — 选船强化页签渲染（StartScreen.prototype 扩展，2026-08-09 自 start-screen.js 拆出）
 *
 * _showEnhancement 入口 + 技能区/基础属性/武器槽/武器详情/武器更换弹窗。
 */

  StartScreen.prototype._showEnhancement = function() {
    this.state = 'enhancement';
    this._closePopup();
    var ship = SHIP_LIBRARY[this.selectedIndex];
    document.getElementById('ss-ship-select').style.display = 'none';
    document.getElementById('ss-commander').style.display = 'none';
    document.getElementById('ss-classskill').style.display = 'none';
    var el = document.getElementById('ss-enhancement');
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.gap = '12px';
    el.innerHTML = ''
      + '<div class="enh-top-bar">'
      + '  <button id="enh-back-btn">← 返回选船</button>'
      + '  <span class="enh-title">强化 — ' + ship.name + '</span>'
      + '</div>'
      + '<div class="enh-main">'
      + '  <div class="enh-left" id="enh-stats-panel"></div>'
      + '  <div class="enh-weapon-area" id="enh-weapon-area"></div>'
      + '  <div class="enh-skill-area" id="enh-skill-area"></div>'   // 战舰技能（2026-08-08，独立滚动列）
      + '</div>';
    this._renderEnhancedStats(ship);
    this._renderWeaponSlots(ship);
    this._renderShipSkills(ship);
    var self = this;
    document.getElementById('enh-back-btn').addEventListener('click', function() { self._showShipSelect(); });
  };

  /* ── 战舰技能（2026-08-08）：强化界面第三列，滚动查看 ──────────────
   * 注意：强化界面预留的「技能」tab 是舰种技能系统（未来另做），与本处战舰技能无关。 */
  StartScreen.prototype._renderShipSkills = function(ship) {
    var el = document.getElementById('enh-skill-area');
    var skills = (ship.config && ship.config.skills) || [];
    if (skills.length === 0) {
      el.innerHTML = '<div class="enh-skills-empty">该舰暂无技能</div>';
      return;
    }
    var h = '<div class="enh-skills-label">战舰技能</div>';
    for (var i = 0; i < skills.length; i++) {
      var sk = skills[i];
      h += '<div class="skill-card">'
        + '<div class="skill-name">' + sk.name + '</div>'
        + '<div class="skill-effects">';
      if (sk.desc) {
        // 完整描述优先（2026-08-09：沙皇等复杂技能照抄原文；多行 desc 用 \n 分段）
        var descLines = String(sk.desc).split('\n');
        for (var dl = 0; dl < descLines.length; dl++) {
          if (descLines[dl]) h += '<div class="skill-effect">'
            + '<span class="skill-eff-text">' + descLines[dl] + '</span></div>';
        }
      }
      var effs = sk.effects || [];
      for (var j = 0; j < effs.length; j++) {
        h += this._skillEffectHtml(effs[j]);
      }
      if (sk.aura) {
        h += this._skillAuraHtml(sk.aura);
      }
      h += '</div></div>';
    }
    el.innerHTML = h;
  };

  /* ── 技能效果 stat → 中文显示配置（2026-10-02 补全 7 个 + 开关型/单位支持）────
   * 为什么放在 StartScreen 上而不是裸 const：enhance.js 不在 tests/run_tests.js 的
   *   sourceFiles 里（它依赖 DOM），挂静态属性才能被第 83 节守卫直读。
   *
   * 背景：stat 是**功能性字段名**（systems/ship-skills.js APPLYERS 按名字消费舰船属性），
   *   不能改；旧表只覆盖 12 个而实际用了 19 个 → `|| e.stat` 兜底把英文原名漏到界面上，
   *   两个 flag 型（value:true）还拼成 `+true`，是纯 bug 而非文案问题。
   *
   * 每项 = { label: 中文名, kind: 'pct' | 'plain' | 'unit' | 'flag' }（unit 另带 unit 字段）：
   *   pct   — 0~1 小数 → `+X%`（对齐 ShipSkills.SCALES 的 pct）
   *   plain — 原始值/点数 → `+X`（血量/炮速/延缓燃烧等，保持既有显示不变）
   *   unit  — 原始值 + 显式单位（torpedoSpeed 单位是「节」，与炮速的内部单位不同）
   *   flag  — 布尔开关型，**只出文字不拼数字**；value 为假（未授予）则整行不出
   * ★ 新增 stat 必须同时在 ShipSkills.SCALES（尺度）与本表（显示）登记 ——
   *   tests 第 83 节遍历 ships/commanders 的 stat: 声明做全覆盖守卫。
   */
  StartScreen.SKILL_EFFECT_LABELS = {
    maxHp:               { label: '血量',         kind: 'plain' },
    armor:               { label: '装甲强度',     kind: 'plain' },
    critChance:          { label: '暴击几率',     kind: 'pct' },
    penetrationChance:   { label: '穿甲几率',     kind: 'pct' },
    burnChance:          { label: '燃烧几率',     kind: 'pct' },
    penDmg:              { label: '穿甲伤害',     kind: 'pct' },
    critDmg:             { label: '暴击伤害',     kind: 'pct' },
    shellEvasion:        { label: '炮弹规避',     kind: 'pct' },
    burnDelay:           { label: '延缓燃烧',     kind: 'unit', unit: '%' },
    floodDelay:          { label: '延缓漏水',     kind: 'unit', unit: '%' },
    // ⚠ 这四条的 value 是 points 尺度（15 = 15%），但玩家看到的必须是百分号
    //   → 用 kind:'unit' + unit:'%'，走渲染分支直接拼 %（不做 ×100，因为值是点数不是小数）。
    //   千万别写成 kind:'pct'：pct 分支会 ×100，15 → 显示 +1500%（错上加错）。
    //
    //   burnDelay/floodDelay 同为 points 尺度且**同样是百分比语义**
    //   （2026-10-02 字人指出「延缓燃烧也是百分比」，核实三处后修正 —— 此前注释误写
    //   「按惯例不带 %」，是照抄推断未查公式）：
    //     ① js/collision.js:177  tickInterval = BURN_INTERVAL / ((100 + burnSpeed − burnDelay) / 100)
    //     ② js/data/formulas.js   notes「跳伤间隔下限 2 秒、上限 8 秒（延缓燃烧至多 +100%）」
    //     ③ js/data/terms.js      desc「实际间隔 = 4 秒 ÷ (100 + 延缓燃烧 − 敌方燃烧加速) / 100」
    //
    //   反例（这些是**真点数**，加了 % 就是错的）：maxHp（raw，血量点数）、
    //   armor（词条 desc「每 1000 点装甲减伤 10%」，max 上限 100000）、
    //   mainGunShellSpeed/secondaryShellSpeed（游戏炮速单位，×0.057 = px/s）。
    reduceWeaponDmg:     { label: '减免武器伤害', kind: 'unit', unit: '%' },
    reduceTorpedoDmg:    { label: '减免鱼雷伤害', kind: 'unit', unit: '%' },
    reduceCritDmg:       { label: '减免暴击伤害', kind: 'pct' },
    shotAccuracy:        { label: '射击精度',     kind: 'pct' },
    mainGunShellSpeed:   { label: '主炮速度',     kind: 'plain' },
    secondaryShellSpeed: { label: '副炮速度',     kind: 'plain' },
    torpedoSpeed:        { label: '鱼雷速度',     kind: 'unit', unit: '节' },
    // 不屈（2026-11-08 威斯康星「威慑重击」）：raw 点数，直接显示「不屈 +200」
    unyielding:          { label: '不屈',         kind: 'plain' },
    // 开关型（消费链见 ship-skills.js APPLYERS → lock-system.js isSecondaryFollowing
    //   / ship-weapons.js getSecondaryRangePx）：
    //   secondaryAlwaysFollows   → 副炮不再各自自动选最近目标（autoFireSecondaries 直接 return），
    //                               改为主炮每次开火时按主炮的瞄准方向同步打一发
    //   secondaryRangeFollowsMain→ 副炮有效射程直接取主炮有效射程（动态，含主炮的各类加距）
    secondaryAlwaysFollows:    { label: '副炮恒跟随主炮瞄准（主炮开火时副炮同步射击）', kind: 'flag' },
    secondaryRangeFollowsMain: { label: '副炮射程始终等于主炮射程',                       kind: 'flag' },
  };

  /** 单个效果行：纯文本（无「战役/全模式」标签）。
   *  mode==='battle' 的行加文本前缀「战役」+ skill-effect-battle 竖条样式——
   *  这些效果在非战役模式会被 ship-skills.js 整条跳过，必须让玩家看得出有条件，
   *  否则会误以为全程生效（误导性 bug）。mode 字段本身不动（功能字段）。 */
  StartScreen.prototype._skillEffectHtml = function(e) {
    var txt = StartScreen._skillEffectText(e);
    if (!txt) return '';   // 开关型且 value 为假 = 该能力未授予，整行不出（别让玩家以为有）
    var isBattle = e.mode === 'battle';
    return '<div class="skill-effect' + (isBattle ? ' skill-effect-battle' : '') + '">'
      + '<span class="skill-eff-text">' + (isBattle ? '战役' : '') + txt + '</span></div>';
  };

  /** 效果行文本（纯函数，不碰 DOM；第 83 节守卫直接调它验真实渲染结果）。
   *  ⚠️ 缺映射时**不显示英文内部字段名**——对玩家毫无意义，且会静默到没人发现；
   *  改为控制台按 stat 名去重 warn（开发期立刻暴露）+ 界面占位文案（运行期不崩）。 */
  StartScreen._skillEffectText = function(e) {
    var meta = StartScreen.SKILL_EFFECT_LABELS[e.stat];
    if (!meta) {
      if (!StartScreen._warnedStats) StartScreen._warnedStats = {};
      if (!StartScreen._warnedStats[e.stat]) {
        StartScreen._warnedStats[e.stat] = true;
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('[enhance] 技能效果 stat「' + e.stat + '」缺中文映射：'
            + '请在 StartScreen.SKILL_EFFECT_LABELS（js/ui/enhance.js）登记');
        }
      }
      return '未命名效果';   // 占位：不猜单位（未知尺度拼 +数字 可能误导），但不崩
    }
    if (meta.kind === 'flag') return e.value ? meta.label : '';
    if (meta.kind === 'pct')  return meta.label + ' +' + Math.round(e.value * 100) + '%';
    // points 尺度的百分比字段（reduceWeaponDmg / reduceTorpedoDmg，value=15 表示 15%）：
    //   走 kind:'unit' + unit:'%' 表达「不做 ×100、直接拼 %」。这里的 % 与 pct 分支视觉一致
    //   （+15% 而非 +15 %），故渲染分支对 % 特判不加空格；其它 unit（如「节」）仍保留空格。
    if (meta.kind === 'unit') return meta.label + ' +' + e.value + (meta.unit ? (meta.unit === '%' ? meta.unit : ' ' + meta.unit) : '');
    return meta.label + ' +' + e.value;
  };

  /** 光环行（穿甲尖兵 12 公里友军） */
  StartScreen.prototype._skillAuraHtml = function(aura) {
    var modsText = '';
    if (aura.mods && aura.mods.penDmgAdd) modsText += '穿甲伤害+' + Math.round(aura.mods.penDmgAdd * 100) + '%';
    // 新光环 mod 在此追加描述
    return '<div class="skill-effect">'
      + '<span class="skill-eff-text">' + (aura.radiusKm || 12) + 'km 内本方战舰 ' + modsText
      + (aura.stack === 'unique' ? '（相同增益不叠加）' : '') + '</span></div>';
  };

  StartScreen.prototype._renderEnhancedStats = function(ship) {
    var el = document.getElementById('enh-stats-panel');
    var cfg = ship.config;
    var items = [
      ['舰名', cfg.name],
      ['血量', cfg.hp],
      ['装甲强度', cfg.armor],
      ['最大航速', cfg.maxSpeed + ' 节'],
      ['加速功率', cfg.accelPower],
      ['转向转速', (cfg.rotationSpeed * 180 / Math.PI).toFixed(1) + ' °/s'],
      ['暴击几率', (cfg.critChance * 100) + ' %'],
      ['碎甲几率', (cfg.shatterChance * 100) + ' %'],
      ['穿甲几率', (cfg.penetrationChance * 100) + ' %'],
    ];
    var h = '<div class="enh-stats-title">基础属性</div>';
    for (var i = 0; i < items.length; i++) {
      h += '<div class="ss-stat-row"><span class="ss-stat-key">' + items[i][0] + '</span><span class="ss-stat-val">' + items[i][1] + '</span></div>';
    }
    el.innerHTML = h;
  };

  StartScreen.prototype._renderWeaponSlots = function(ship) {
    var self = this;
    var loadout = loadLoadout(ship.id);
    var el = document.getElementById('enh-weapon-area');
    var h = '<div class="enh-weapons-label">武器槽位</div><div class="enh-slots">';
    // 主炮
    h += '<div class="enh-slot-group"><div class="enh-slot-type">主炮</div>';
    for (var i = 0; i < loadout.mainGun.length; i++) {
      var weapon = getWeaponById(loadout.mainGun[i]);
      h += '<div class="enh-slot" data-type="mainGun" data-slot="' + i + '">'
        + '<div class="enh-slot-icon" style="background:#FF6B35">' + weapon.barrelsPerMount + '联</div>'
        + '<div class="enh-slot-name">' + weapon.name + '</div>'
        + '<div class="enh-slot-level">等级 1</div>'
        + '</div>';
    }
    h += '</div>';
    // 鱼雷
    h += '<div class="enh-slot-group"><div class="enh-slot-type">鱼雷</div>';
    for (var j = 0; j < loadout.torpedo.length; j++) {
      var tw = getWeaponById(loadout.torpedo[j]);
      h += '<div class="enh-slot" data-type="torpedo" data-slot="' + j + '">'
        + '<div class="enh-slot-icon" style="background:#1E5FBF">' + tw.barrelsPerMount + '联</div>'
        + '<div class="enh-slot-name">' + tw.name + '</div>'
        + '<div class="enh-slot-level">等级 1</div>'
        + '</div>';
    }
    h += '</div>';
    // 副炮（AI 自动开火）
    if (loadout.secondary && loadout.secondary.length > 0) {
      h += '<div class="enh-slot-group"><div class="enh-slot-type">副炮（自动）</div>';
      for (var sc = 0; sc < loadout.secondary.length; sc++) {
        var sw = getWeaponById(loadout.secondary[sc]);
        h += '<div class="enh-slot" data-type="secondary" data-slot="' + sc + '">'
          + '<div class="enh-slot-icon" style="background:#CCCCCC">' + sw.barrelsPerMount + '联</div>'
          + '<div class="enh-slot-name">' + sw.name + '</div>'
          + '<div class="enh-slot-level">等级 1</div>'
          + '</div>';
      }
      h += '</div>';
    }
    // 水雷
    if (loadout.mine && loadout.mine.length > 0) {
      h += '<div class="enh-slot-group"><div class="enh-slot-type">水雷</div>';
      for (var k = 0; k < loadout.mine.length; k++) {
        var mw = getWeaponById(loadout.mine[k]);
        h += '<div class="enh-slot" data-type="mine" data-slot="' + k + '">'
          + '<div class="enh-slot-icon" style="background:#222222">' + mw.barrelsPerMount + '装</div>'
          + '<div class="enh-slot-name">' + mw.name + '</div>'
          + '<div class="enh-slot-level">等级 1</div>'
          + '</div>';
      }
      h += '</div>';
    }
    h += '</div></div>';
    el.innerHTML = h;

    el.querySelectorAll('.enh-slot').forEach(function(slot) {
      slot.addEventListener('click', function() {
        var type = this.dataset.type;
        var si = parseInt(this.dataset.slot);
        var wId = loadout[type][si];
        var w = getWeaponById(wId);
        self._showWeaponDetail(ship, type, si, w);
      });
    });
  };

  /* ── 武器详情弹窗 ──────────────────────────────────────────────── */

  StartScreen.prototype._showWeaponDetail = function(ship, type, slotIndex, weapon) {
    var self = this;

    // 先关闭旧弹窗
    this._closePopup();

    var popup = document.createElement('div');
    popup.className = 'ss-help-popup enh-popup';
    popup.style.display = 'flex';

    var typeLabel, speedLabel, speedVal;
    if (type === 'mainGun') {
      typeLabel = '主炮（' + weapon.barrelsPerMount + '联装）';
      speedLabel = '炮弹速度';
      speedVal = weapon.shellSpeed + ' 单位炮速';
    } else if (type === 'torpedo') {
      typeLabel = '鱼雷（' + weapon.barrelsPerMount + '联装）';
      speedLabel = '航速';
      speedVal = weapon.speed + ' 节';
    } else if (type === 'secondary') {
      typeLabel = '副炮（' + weapon.barrelsPerMount + '联装）·自动开火';
      speedLabel = '炮弹速度';
      speedVal = weapon.shellSpeed + ' 单位炮速';
    } else {
      typeLabel = '水雷';
      speedLabel = '引爆半径';
      // 单位统一 km / s（项目约定：不翻译成中文单位；第 83 节守卫）
      speedVal = weapon.detonationRadiusKM + ' km / 爆炸半径 ' + weapon.explosionRadiusKM + ' km / 存在 ' + weapon.lifetimeSec + ' s';
    }

    var html = ''
      + '<div class="enh-detail-card">'
      + '  <div class="enh-detail-name">' + weapon.name + '</div>'
      + '  <div class="enh-detail-info">'
      + '    <div class="ss-stat-row"><span class="ss-stat-key">类型</span><span class="ss-stat-val">' + typeLabel + '</span></div>'
      + '    <div class="ss-stat-row"><span class="ss-stat-key">总伤害</span><span class="ss-stat-val">' + weapon.damage + '</span></div>'
      + '    <div class="ss-stat-row"><span class="ss-stat-key">单发伤害</span><span class="ss-stat-val">' + Math.round(weapon.damage / weapon.barrelsPerMount) + '</span></div>'
      + '    <div class="ss-stat-row"><span class="ss-stat-key">' + speedLabel + '</span><span class="ss-stat-val">' + speedVal + '</span></div>';

    // 额外属性（绿字，与武器替换界面统一格式）
    if (weapon.bonuses) {
      var bonuses = weapon.bonuses;
      var parts = [];
      if (bonuses.critChance) parts.push('暴击几率+' + (bonuses.critChance * 100) + '%');
      if (bonuses.shatterChance) parts.push('碎甲几率+' + (bonuses.shatterChance * 100) + '%');
      if (bonuses.critDmg) parts.push('暴击伤害+' + (bonuses.critDmg * 100) + '%');
      if (bonuses.penetrationChance) parts.push('穿甲几率+' + (bonuses.penetrationChance * 100) + '%');
      if (bonuses.burnChance) parts.push('燃烧几率+' + (bonuses.burnChance * 100) + '%');
      if (bonuses.burnPower) parts.push('燃烧程度+' + (bonuses.burnPower * 100) + '%');
      if (bonuses.burnSpeed) parts.push('燃烧加速+' + (bonuses.burnSpeed * 100) + '%');
      if (bonuses.burnDuration) parts.push('燃烧时长+' + (bonuses.burnDuration * 100) + '%');
      if (bonuses.penDmg) parts.push('穿甲伤害+' + (bonuses.penDmg * 100) + '%');
      if (bonuses.bonusVsBurning) parts.push('对燃烧目标增伤+' + (bonuses.bonusVsBurning * 100) + '%');
      if (bonuses.floodChance) parts.push('漏水几率+' + (bonuses.floodChance * 100) + '%');
      if (bonuses.floodPower) parts.push('漏水程度+' + (bonuses.floodPower * 100) + '%');
      if (bonuses.floodSpeed) parts.push('漏水加速+' + (bonuses.floodSpeed * 100) + '%');
      if (bonuses.floodDuration) parts.push('漏水时长+' + (bonuses.floodDuration * 100) + '%');
      if (bonuses.finalDmg) parts.push('最终增伤+' + (bonuses.finalDmg * 100) + '%');
      if (bonuses.shatterPower) parts.push('碎甲程度+' + (bonuses.shatterPower * 100) + '%');
      if (parts.length) {
        html += '    <div class="ss-stat-row"><span class="ss-stat-val enh-bonus">' + parts.join('  ') + '</span></div>';
      }
    }

    html += ''
      + '  </div>'
      + '  <button class="enh-replace-btn popup-replace">替换</button>'
      + '  <button class="enh-close-btn popup-close-x">关闭</button>'
      + '</div>';

    popup.innerHTML = html;

    this._openPopup(popup);

    // 点击遮罩关闭
    popup.addEventListener('click', function(e) { if (e.target === popup) self._closePopup(); });

    // 按钮用 class 选择（不用 id，避免多弹窗冲突）
    popup.querySelector('.popup-close-x').addEventListener('click', function() { self._closePopup(); });
    popup.querySelector('.popup-replace').addEventListener('click', function() {
      self._closePopup();
      self._showWeaponReplace(ship, type, slotIndex, weapon);
    });
  };

  /* ── 武器替换 ──────────────────────────────────────────────────── */

  StartScreen.prototype._showWeaponReplace = function(ship, type, slotIndex, currentWeapon) {
    var self = this;
    var weapons = getAvailableWeapons(type, ship.shipType || 'cruiser');

    // 关旧弹窗
    this._closePopup();

    var popup = document.createElement('div');
    popup.className = 'ss-help-popup enh-popup';
    popup.style.display = 'flex';

    var h = ''
      + '<div class="enh-detail-card">'
      + '  <div class="enh-detail-name">选择' + (type === 'mainGun' ? '主炮' : type === 'torpedo' ? '鱼雷' : type === 'secondary' ? '副炮' : '水雷') + '</div>'
      + '  <div class="enh-replace-list">';
    for (var i = 0; i < weapons.length; i++) {
      var w = weapons[i];
      var isCur = w.id === currentWeapon.id;
      h += '<div class="enh-replace-item' + (isCur ? ' current' : '') + '">'
        + '<div class="enh-replace-top">'
        + '<div class="enh-replace-name">' + w.name + '</div>';
      if (isCur) {
        h += '<div class="enh-replace-current-label">当前装备</div>';
      } else {
        h += '<button class="enh-pick-btn popup-pick" data-wid="' + w.id + '">替换</button>';
      }
      h += '</div>'
        + '<div class="enh-replace-stats">'
        + (type === 'mainGun' ? '伤害 ' + w.damage + '  /  炮速 ' + w.shellSpeed
           : type === 'torpedo' ? '伤害 ' + w.damage + '  /  航速 ' + w.speed + ' 节'
           : type === 'secondary' ? '伤害 ' + w.damage + '  /  炮速 ' + w.shellSpeed
           : '伤害 ' + w.damage + '  /  引爆半径 ' + w.detonationRadiusKM + ' km')
        + '</div>';
      // 额外属性
      if (w.bonuses) {
        var parts = [];
        if (w.bonuses.critChance) parts.push('暴击几率+' + (w.bonuses.critChance * 100) + '%');
        if (w.bonuses.shatterChance) parts.push('碎甲几率+' + (w.bonuses.shatterChance * 100) + '%');
        if (w.bonuses.critDmg) parts.push('暴击伤害+' + (w.bonuses.critDmg * 100) + '%');
        if (w.bonuses.penetrationChance) parts.push('穿甲几率+' + (w.bonuses.penetrationChance * 100) + '%');
        if (w.bonuses.burnChance) parts.push('燃烧几率+' + (w.bonuses.burnChance * 100) + '%');
        if (w.bonuses.burnPower) parts.push('燃烧程度+' + (w.bonuses.burnPower * 100) + '%');
        if (w.bonuses.burnSpeed) parts.push('燃烧加速+' + (w.bonuses.burnSpeed * 100) + '%');
        if (w.bonuses.burnDuration) parts.push('燃烧时长+' + (w.bonuses.burnDuration * 100) + '%');
        if (w.bonuses.penDmg) parts.push('穿甲伤害+' + (w.bonuses.penDmg * 100) + '%');
        if (w.bonuses.bonusVsBurning) parts.push('对燃烧目标增伤+' + (w.bonuses.bonusVsBurning * 100) + '%');
        if (w.bonuses.floodChance) parts.push('漏水几率+' + (w.bonuses.floodChance * 100) + '%');
        if (w.bonuses.floodPower) parts.push('漏水程度+' + (w.bonuses.floodPower * 100) + '%');
        if (w.bonuses.floodSpeed) parts.push('漏水加速+' + (w.bonuses.floodSpeed * 100) + '%');
        if (w.bonuses.floodDuration) parts.push('漏水时长+' + (w.bonuses.floodDuration * 100) + '%');
        if (w.bonuses.finalDmg) parts.push('最终增伤+' + (w.bonuses.finalDmg * 100) + '%');
        if (w.bonuses.shatterPower) parts.push('碎甲程度+' + (w.bonuses.shatterPower * 100) + '%');
        if (parts.length) h += '<div class="enh-replace-bonus">' + parts.join('  ') + '</div>';
      }
      h += '</div>';
    }
    h += '  </div></div>';
    popup.innerHTML = h;
    this._openPopup(popup);

    popup.addEventListener('click', function(e) { if (e.target === popup) self._closePopup(); });

    popup.querySelectorAll('.popup-pick').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var newId = this.dataset.wid;
        var loadout = loadLoadout(ship.id);
        loadout[type][slotIndex] = newId;
        saveLoadout(ship.id, loadout);
        self._closePopup();
        self._showEnhancement();
      });
    });
  };
