﻿# =============================================================
# HuanJian updater (friend side) - called by update.bat
# Flow: read local version -> fetch manifest.json (jsDelivr, carries sha256)
#       -> download zip (GitHub direct + mirrors) -> SHA256 verify
#       -> backup current files -> apply update over css/ js/ index.html,
#       SKIPPING js/mods (your mods).
#
# 安全/健壮性约定（2026-10-01 修订）：
#   1) zip 里是可执行 JS/HTML/批处理，下载后**必须**校验 sha256，否则等于替别人执行代码。
#      校验和只来自官方 manifest.json（js/systems/updater.js 的 MANIFEST_URL 同源）。
#   2) 覆盖前把 css/ js/ index.html update.* 整份备份到 %TEMP%，中途失败可手动回滚。
#   3) 覆盖改用 robocopy /MIR：新版删掉/改名的文件不会残留在旧目录里（mods 除外，永不动）。
#   4) 控制台输出一律「中文在前 + 英文在括号里」双语：朋友机器是 Win7 + 默认中文
#      代码页（GBK），中文可能显示成乱码；括号里的英文仍然可读，所以不会有
#      "完全看不懂"的回归。输出前尽量把控制台切到 UTF-8（失败就退回原样）。
#      本文件注释用中文（UTF-8 BOM，PowerShell 5.1 才能正确读）。
# =============================================================
# Win7 PowerShell 5.1 默认 TLS 1.0，GitHub/jsDelivr/ghproxy 全要求 TLS 1.2+
# 不加这两行，Win7 上所有网络请求都会 TLS 握手失败 → 连 jsDelivr 兜底都白搭
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
try { [Net.ServicePointManager]::SecurityProtocol += [Net.SecurityProtocolType]::Tls12 } catch { }

# 尽量让控制台输出 UTF-8（Win7 默认 GBK 会把中文显示成乱码）。
# 失败不影响：下面所有玩家可见的输出都是「中文 + 英文」双语，乱码时英文仍可读。
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$repo = "Any-character/huanjian-release"
$asset = "HuanJian-update.zip"
$manifestUrl = "https://cdn.jsdelivr.net/gh/$repo@main/manifest.json"
$releasePage = "https://github.com/$repo/releases/latest"

Write-Host ""
Write-Host "======== 幻舰 更新器 (HuanJian Updater) ========"

# -------------------------------------------------------------
# 公共退出助手：出错要说人话 + 给下一步操作指引（AGENTS §12）
# -------------------------------------------------------------
function Stop-WithError([string]$msg, [string[]]$hints) {
    Write-Host ""
    Write-Host "出错了（下面是详细信息）："
    Write-Host ("ERROR: " + $msg)
    if ($hints) { foreach ($h in $hints) { Write-Host ("  " + $h) } }
    Write-Host ""
    Read-Host "按回车键退出 (Press Enter to exit)"
    exit 1
}

# -------------------------------------------------------------
# 版本比较：逐段取整比较（0.2.7 < 0.2.10，不能用字符串比较）
# 返回：第一个参数更大 → +1；更小 → -1；相等 → 0
#
# 段数：**最多 4 段、缺段按 0**（2026-10-02，由 3 段扩展）
#   0.2.9 == 0.2.9.0   0.2.9.1 > 0.2.9   0.2.10 > 0.2.9.1   0.2.9.1.2 截断为 0.2.9.1
#   防降级保护（下方第 3 节）走的也是这个函数，循环上限必须 ≥ 4：
#   本地 0.2.9.1、线上 0.2.9 时，第 4 段才能判出 1 > 0 从而拒绝降级。
#
# ⚠ 下面循环上限的 4 必须与下面两处保持一致（AGENTS §5.31 / 单测第 84 节守卫）：
#     (1) tools/release.py           → VER_SEG_MAX = 4 / ver_parts
#     (2) js/systems/updater.js      → Updater.compareVersions 的 i < 4
#   本项目历史上真实故障：这里的 return 1 / -1 写反 → 更新静默失效。
#   段数上限三处只改一处是同一类故障（只改本文件：线上 0.2.9.1 被当成与本地相等 → 不更新）。
#
# ⚠ 2026-10-02 修一个致命 bug：原来这里 return 1 / -1 写反了
#   （写成「第二个参数更大 → 1」）。三处调用点全都按「第一个更大 → 1」使用，
#   于是「线上有新版」时恒返回 -1 → 永远走「已经是最新版本」分支静默退出，
#   更新**从来没有真正发生过**，但控制台显示正常退出、用户以为成功了。
#   更危险的是本地版本比线上新时它返回 +1 → 会默默**降级**用户的游戏。
# -------------------------------------------------------------
function Parse-V([string]$s) {
    # (?i)：大小写不敏感地剥 v 前缀 —— 与 updater.js 的 /^v/i 和 release.py 的 flags=re.I 对齐
    # （否则 'V0.2.9' 在这里不被剥壳、三处语义就不一致了）
    return @($s -replace '(?i)^v', '' -split '\.') | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
}
function Compare-Ver([string]$x1, [string]$x2) {
    $a = Parse-V $x1; $b = Parse-V $x2
    for ($i = 0; $i -lt 4; $i++) {
        $x = 0; $y = 0
        if ($a.Count -gt $i) { $x = $a[$i] }
        if ($b.Count -gt $i) { $y = $b[$i] }
        if ($x -gt $y) { return 1 }
        if ($y -gt $x) { return -1 }
    }
    return 0
}

# -------------------------------------------------------------
# 1. 本地版本（js/version.js 的 GAME_VERSION，单一来源）
# -------------------------------------------------------------
$cur = "0.0.0"
$verFile = Join-Path $root "js\version.js"
if (Test-Path $verFile) {
    $m = Select-String -Path $verFile -Pattern "GAME_VERSION\s*=\s*'([^']+)'"
    if ($m) { $cur = $m.Matches[0].Groups[1].Value }
}
Write-Host ("当前版本：" + $cur + " (Current version: " + $cur + ")")

# -------------------------------------------------------------
# 2. 取 manifest.json：版本 / 公告 / zip 地址 / sha256 校验和
#    只认这一份：它是"这一版 zip 的 sha256"的唯一来源，其它端点给不出校验和，
#    拿不到校验和就不下载（宁可让朋友手动下，也不执行无法验明正文的包）。
# -------------------------------------------------------------
$mf = $null
try {
    $mf = Invoke-RestMethod -Uri $manifestUrl -TimeoutSec 25 -Headers @{ "User-Agent" = "huanjian-updater" }
    Write-Host "校验来源       : jsDelivr 官方 manifest (Checked via: jsDelivr manifest, official)"
} catch {
    Write-Host "连不上官方 manifest (jsDelivr)。 (Could not reach the official manifest via jsDelivr.)"
}

$latest = ""; $zipUrl = ""; $notes = ""; $sha = ""
if ($mf) {
    $latest = ([string]$mf.version).Trim()
    $notes = [string]$mf.notes
    $zipUrl = ([string]$mf.zip).Trim()
    if ($mf.sha256) { $sha = ([string]$mf.sha256).ToLower().Trim() }
}

# GitHub API 只作诊断用：拿不到 manifest 时，至少还能判断"是不是已经最新"
$ghLatest = ""
try {
    $r = Invoke-RestMethod -Uri ("https://api.github.com/repos/" + $repo + "/releases/latest") `
        -Headers @{ "User-Agent" = "huanjian-updater" } -TimeoutSec 20
    $ghLatest = ([string]$r.tag_name).Trim() -replace '^v', ''
} catch { }

if (-not $latest) {
    # manifest 读不到时用 GitHub 版本号兜底判断（但没有 sha256，仍拒绝下载）
    if ($ghLatest) {
        $cmpGh = Compare-Ver $ghLatest $cur
        if ($cmpGh -lt 0) {
            Write-Host ""
            Write-Host ("你的版本 v" + $cur + " 比线上最新的 v" + $ghLatest + " 还新，已停止更新。")
            Write-Host ("Your version v" + $cur + " is NEWER than v" + $ghLatest + "; update cancelled.")
            Stop-WithError "为避免把你的游戏降级成旧版本，这次没有下载任何东西。" @(
                "你的文件完全没有被改动。(your files were NOT changed)")
        }
        if ($cmpGh -eq 0) {
            Write-Host ""
            Write-Host ("已经是最新版本 v" + $cur + "，无需更新。")
            Write-Host ("Already up to date (v" + $cur + ").")
            Read-Host "按回车键退出 (Press Enter to exit)"
            exit 0
        }
    }
    Stop-WithError "读不到官方更新清单（manifest），无法确认下载文件的校验和。(cannot read the official update manifest, so the download cannot be verified)" @(
        "清单里有这个文件的 SHA256 校验和，必须拿到才敢下载。(this is needed to check the file's SHA256 signature)",
        "先检查一下网络，然后重新运行 update.bat。(check your network, then run update.bat again)",
        "或者手动下载： " + $releasePage + "  (or download manually from that page)")
}
Write-Host ("最新版本：" + $latest + " (Latest version: " + $latest + ")")

if ($sha) { Write-Host "校验和         : manifest 里有 SHA256，下载后会校验 (Checksum: SHA256 available, will verify)" }
else { Write-Host "校验和         : manifest 里没有 SHA256，将拒绝下载 (Checksum: MISSING in manifest, download will be refused)" }

if ($ghLatest -and (Compare-Ver $ghLatest $latest) -gt 0) {
    # 只是提示，不阻断：jsDelivr 有几分钟 CDN 缓存，manifest 可能比 Release 慢一拍
    Write-Host ("提示：GitHub 上已经有 v" + $ghLatest + "，但 manifest 还指向 v" + $latest + "。(Note: manifest is a bit behind, CDN cache)")
    Write-Host "      本次会更新到 v" + $latest + "。(this run will update to v" + $latest + ")"
}

# -------------------------------------------------------------
# 3. 版本关系判定
#    ★ 防降级保护（2026-10-02）：本地版本比线上还新时**拒绝更新并退出**。
#      这种情况正常不会发生（线上是最新发布），但万一发生（开发版 / 版本号被
#      改过 / manifest 缓存错乱），默默降级会把玩家的游戏弄旧 —— 必须挡住。
# -------------------------------------------------------------
$cmp = Compare-Ver $latest $cur
if ($cmp -lt 0) {
    # 线上版本 < 本地版本 → 拒绝降级
    Write-Host ""
    Write-Host ("你的版本 v" + $cur + " 比线上最新的 v" + $latest + " 还新，已停止更新。")
    Write-Host ("Your version v" + $cur + " is NEWER than the latest published v" + $latest + "; update cancelled.")
    Stop-WithError "为避免把你的游戏降级成旧版本，这次没有下载任何东西。" @(
        "你的文件完全没有被改动，游戏照常能玩。(your files were NOT changed)",
        "如果你确认想要 v" + $latest + " 这个旧版本，手动下载： " + $releasePage + "  (download manually)")
}
if ($cmp -eq 0) {
    Write-Host ""
    Write-Host ("已经是最新版本 v" + $cur + "，无需更新。")
    Write-Host ("Already up to date (v" + $cur + ").")
    Read-Host "按回车键退出 (Press Enter to exit)"
    exit 0
}
if ($notes) {
    Write-Host ""
    Write-Host "---- 更新说明 (Update notes) ----"
    Write-Host $notes
    Write-Host "------------------------------"
}

# -------------------------------------------------------------
# 4. 下载地址：优先用**版本化**地址，保证 zip 与 manifest.sha256 严格对应
#    manifest.zip 形如 .../releases/latest/download/xxx.zip（永远指向"最新"那版）。
#    若线上已有更新的 Release 而 manifest 尚未刷新（CDN 缓存），latest 会下到
#    另一个版本 → sha256 必然不匹配 → 误报"校验失败"。故改写成
#    .../releases/download/v<manifest.version>/<资产名>。
# -------------------------------------------------------------
$zipTry = @()
if ($zipUrl) {
    $am = $asset
    try { $leaf = Split-Path ([uri]$zipUrl).AbsolutePath -Leaf; if ($leaf) { $am = $leaf } } catch { }
    if ($zipUrl -match '^https?://github\.com/([^/]+)/([^/]+)/releases/(latest|download)') {
        $zipTry += ("https://github.com/" + $Matches[1] + "/" + $Matches[2] + "/releases/download/v" + $latest + "/" + $am)
        $zipTry += $zipUrl
    } else {
        $zipTry += $zipUrl
    }
}
if ($zipTry.Count -eq 0) { $zipTry += ("https://github.com/" + $repo + "/releases/download/v" + $latest + "/" + $asset) }

# 第三方反代（部分朋友网络需要），排在 GitHub 直连之后，且会在控制台明示
$hosts = @("", "https://ghproxy.net/", "https://mirror.ghproxy.com/")
$urls = @()
foreach ($h in $hosts) { foreach ($z in $zipTry) { $urls += ($h + $z) } }

$tmp = Join-Path $env:TEMP ("huanjian-update-" + [guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Path $tmp | Out-Null
$zipPath = Join-Path $tmp "update.zip"

Write-Host ""
Write-Host "正在下载更新包……"
Write-Host "Downloading update package..."
$ok = $false
foreach ($u in $urls) {
    $host2 = ""
    try { $host2 = ([uri]$u).Host } catch { }
    if ($host2 -and $host2 -notmatch '(^|\.)github\.com$') {
        Write-Host ("  注意：这次走的是第三方反代，不是 GitHub 直连：" + $host2)
        Write-Host "        (NOTE: third-party mirror, not GitHub direct.)"
        Write-Host "        下载后仍会用官方 manifest 的 SHA256 校验，文件内容不会被它改。"
        Write-Host "        (The file is still SHA256-verified against the official manifest.)"
    }
    try {
        Write-Host ("  trying: " + $u)
        Invoke-WebRequest -Uri $u -OutFile $zipPath -TimeoutSec 300 `
            -Headers @{ "User-Agent" = "huanjian-updater" }
        $ok = $true
        break
    } catch {
        Write-Host "    这个源失败，换下一个……"
        Write-Host "    failed, trying next source..."
    }
}
if (-not $ok) {
    Stop-WithError "所有下载地址都失败了。(all download sources failed)" @(
        "先检查一下网络，然后重新运行 update.bat。(check your network, then run update.bat again)",
        "或者手动下载： " + $releasePage + "  (or download manually from that page)")
}

# -------------------------------------------------------------
# 5. SHA256 校验（核心安全闸）：不过绝不进解压
# -------------------------------------------------------------
if (-not $sha) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Stop-WithError "官方 manifest 里没有 SHA256 校验和，这个更新包无法验证，已拒绝安装。(no SHA256 checksum in the manifest, so this package cannot be verified)" @(
        "你的文件没有被改动，游戏还能正常玩。(Your files were NOT changed.)",
        "可以手动下载： " + $releasePage + "  (download manually from that page)")
}
$got = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
if ($got -ne $sha) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Write-Host ("  expected SHA256 : " + $sha)
    Write-Host ("  downloaded      : " + $got)
    Stop-WithError "校验失败 —— 下载的文件已损坏，或被人动过手脚，已拒绝安装。(FILE VERIFICATION FAILED - corrupted or tampered with)" @(
        "你的文件没有被改动，游戏还能正常玩，什么都没动过。(Your files were NOT changed.)",
        "多半是网络不稳导致下了一半。换个网络或用下面的地址重新下载即可。(likely a truncated download; retry or download manually)",
        "手动下载地址： " + $releasePage + "  (manual download: that page)")
}
Write-Host "校验通过：SHA256 一致"
Write-Host ("Verified: SHA256 OK (" + $sha.Substring(0, 16) + "...)")

# -------------------------------------------------------------
# 6. 解压
# -------------------------------------------------------------
$ex = Join-Path $tmp "extracted"
try {
    Expand-Archive -Path $zipPath -DestinationPath $ex -Force
} catch {
    Stop-WithError "校验过的更新包解压失败了（多半是文件没下完整）。(the verified package could not be unpacked)" @(
        "你的文件没有被改动，游戏还能正常玩。(Your files were NOT changed.)",
        "重新运行 update.bat，或者手动下载： " + $releasePage + "  (run update.bat again, or download manually from that page)")
}

# -------------------------------------------------------------
# 7. 备份当前文件（覆盖前必做，中途失败可手动回滚）
#    连 js/mods 一起备份：备份只读不写，多几 MB 无所谓，回滚时才是完整状态
# -------------------------------------------------------------
$bak = Join-Path $env:TEMP ("huanjian-backup-v" + $cur + "-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
try {
    New-Item -ItemType Directory -Path $bak -Force | Out-Null
    foreach ($item in @("css", "js", "index.html", "update.bat", "update.ps1")) {
        $p = Join-Path $root $item
        if (Test-Path $p) { Copy-Item $p $bak -Recurse -Force }
    }
} catch {
    Stop-WithError ("备份失败，更新已取消。(backup failed: " + $_.Exception.Message + " - the update was cancelled)") @(
        "你的文件没有被改动，游戏还能正常玩。(Your files were NOT changed.)",
        "请清理 TEMP（临时文件夹）腾点空间，再重新运行 update.bat。(free up some space in TEMP, then run update.bat again)")
}
Write-Host ("已备份旧文件：" + $bak)
Write-Host ("Backup of v" + $cur + ": " + $bak)

# -------------------------------------------------------------
# 8. 覆盖：css/ + index.html + js/（除 mods）
#    robocopy /MIR = 镜像同步，会删掉目标端多余文件 → 新版删掉的文件不残留
#    （css 无用户数据，可 MIR；js 的 mods 是用户数据，故 mods 整个跳过，
#      js 下**每个子目录**单独 MIR，js 根目录散文件单独处理）
# -------------------------------------------------------------
Write-Host "正在覆盖文件（js\mods 里的 Mod 不会被动）……"
Write-Host "Applying update (js\mods is protected)..."
try {
    $srcCss = Join-Path $ex "css"
    if (Test-Path $srcCss) {
        robocopy $srcCss (Join-Path $root "css") /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { throw ("robocopy css failed with code " + $LASTEXITCODE) }
        $global:LASTEXITCODE = 0
    }
    $srcIndex = Join-Path $ex "index.html"
    if (Test-Path $srcIndex) { Copy-Item $srcIndex $root -Force }

    $srcJs = Join-Path $ex "js"
    $dstJs = Join-Path $root "js"
    if (Test-Path $srcJs) {
        # 子目录：逐个镜像（mods 跳过）
        Get-ChildItem -Path $srcJs -Directory | Where-Object { $_.Name -ne "mods" } | ForEach-Object {
            robocopy $_.FullName (Join-Path $dstJs $_.Name) /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) { throw ("robocopy js\" + $_.Name + " failed with code " + $LASTEXITCODE) }
            $global:LASTEXITCODE = 0
        }
        # 根目录散文件：先逐个覆盖，再删掉新版已移除的旧 .js
        $newFiles = @(Get-ChildItem -Path $srcJs -File | ForEach-Object { $_.Name })
        Get-ChildItem -Path $srcJs -File | ForEach-Object { Copy-Item $_.FullName $dstJs -Force }
        if (Test-Path $dstJs) {
            Get-ChildItem -Path $dstJs -File -Filter *.js | Where-Object { $newFiles -notcontains $_.Name } | ForEach-Object {
                Write-Host ("  removing stale js file: " + $_.Name)
                Remove-Item $_.FullName -Force
            }
        }
    }

    # 顺带自更新 update.* 本身（脚本已载入内存，不影响本次运行）
    foreach ($f in @("update.bat", "update.ps1")) {
        $src = Join-Path $ex $f
        if (Test-Path $src) { Copy-Item $src $root -Force }
    }
} catch {
    Write-Host ""
    Write-Host "出错了（下面是详细信息）："
    Write-Host ("ERROR: update failed halfway (" + $_.Exception.Message + ").")
    Write-Host ("更新只完成了一半，你的文件可能处于新旧混合状态。(the update stopped halfway, files may be a mix of old and new)")
    Write-Host ""
    Write-Host "怎么恢复（旧文件的完整备份在下面这个文件夹里）："
    Write-Host ("  " + $bak)
    Write-Host "  把这个文件夹里的 css、js、index.html 复制回游戏目录，覆盖掉现在的文件，"
    Write-Host "  然后重新打开游戏，就恢复到更新前的样子了。"
    Write-Host "(To roll back: copy css\, js\, index.html from that folder back into this folder,"
    Write-Host " overwriting the files there. Then start the game again.)"
    Write-Host ""
    Read-Host "按回车键退出 (Press Enter to exit)"
    exit 1
}

Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host ("更新完成：" + $cur + " → " + $latest)
Write-Host ("Update complete: v" + $cur + " -> v" + $latest)
Write-Host "你在 js\mods 里的 Mod 一个都没动。"
Write-Host "Your mods in js\mods are untouched."
Write-Host "（更新包里本来就不含 js\mods 目录，所以在 zip 里找不到 mods 是正常的。）"
Write-Host "(The update package never contains js/mods - normal not to see it in the zip.)"
Write-Host ("备份保留在：" + $bak + "（确认游戏能正常玩之后，可以自己删掉）")
Write-Host ("Backup kept at: " + $bak + " (delete once you confirm the game runs fine)")
Read-Host "按回车键退出 (Press Enter to exit)"
