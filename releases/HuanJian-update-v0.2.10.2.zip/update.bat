@echo off
REM ============================================================
REM  HuanJian updater (friend side)
REM  Put this file in the game folder (next to index.html),
REM  double-click to update. Your mods in js\mods are NEVER touched.
REM ============================================================
title HuanJian Updater
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
