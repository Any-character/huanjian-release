/**
 * class-skills.js — 舰种技能系统（2026-10-03）
 *
 * ⚠️ 与「战舰技能」（`js/systems/ship-skills.js`，单艘船独有）是两个不同系统 —— 叫法见 `docs/glossary.md`。
 *    数据源 `js/data/ship-class-skills.js` 的 CLASS_SKILLS；本文件负责「读存档 + 过滤 + 合并 + 生效」。
 *
 * 设计要点（docs/superpowers/plans/2026-10-03-ship-class-skills.md §8.1）：
 *   **单一入口** `getEffects(ship)` 返回已按舰种 + 选系过滤好的合并 effects，
 *   杜绝「多处各自判断该不该生效」导致的分叉。
 *
 * 生效范围（设计文档 §二.2，字人确认）：**只对玩家自己的船生效**。
 *   ⚠️ 本文件**不判玩家**（getEffects 只算效果）；isPlayer 判断放在调用方
 *      （战斗开始时对 player 舰调 applyTo 一次）。
 *
 * 通道分两类（§3.1）：
 *   ① BUFF 通道（6 条）—— 走 buff 系统常驻挂载（noIcon + noDuration），消费点 `getBuffMod(key)`。
 *      选 buff 而非 ship 字段的理由：`torpedoSpeedAdd` 的既有实现（ship-weapons.js:289 `_torpedoSpeedAdd`）
 *      = `ship.torpedoSpeedBonus`（战舰技能静态加成）+ `getBuffMod('torpedoSpeedAdd')`（限时层数）；
 *      舰种技能是「战斗中不可切换」的常驻加成，语义上属于后者（同族通道保持一致，
 *      且复用 buff 的「多来源求和」，天然满足 §4 的 Σ 口径）。
 *   ② 舰体字段通道（8 条）—— 直接加算到 ship 字段，与 `applyTermOverridesToShip`
 *      （js/systems/term-overrides.js）的「基础属性 + 额外加成」惯例完全一致。
 */

const ClassSkills = {
  /** localStorage key（设计文档 §七） */
  STORAGE_KEY: 'hj_classSkills',

  /** buff 通道：stat → getBuffMod 的 key（同名单射，便于静态守卫遍历） */
  BUFF_CHANNELS: {
    torpedoSpeedPct: 'torpedoSpeedPct',                 // 小数，鱼雷航速百分比
    torpedoSpeedAdd: 'torpedoSpeedAdd',                 // 节
    torpedoReloadPct: 'torpedoReloadPct',               // 小数，鱼雷装填缩减百分比
    mineReloadPct: 'mineReloadPct',                     // 小数，水雷装填缩减百分比
    reloadFlatReduce_torpedo: 'reloadFlatReduce_torpedo', // 秒
    reloadFlatReduce_mine: 'reloadFlatReduce_mine',       // 秒
  },

  /**
   * 舰体字段通道：stat → { field, scale?, after? }
   *   scale:'deg' — 存储层是「度」，应用到 ship（弧度）时 ×π/180（同 TERM_OVERRIDES rad:true）
   *   after      — 改完该字段后需调用的方法（如 maxSpeed → 重建速力档位）
   */
  FIELD_CHANNELS: {
    floodChance:       { field: 'floodChance' },        // 小数
    floodDuration:     { field: 'floodDuration' },      // 小数
    floodPower:        { field: 'floodPower' },         // 小数
    detonationRadius:  { field: 'detonationRadius' },   // km
    explosionRadius:   { field: 'explosionRadius' },    // km
    lifetimeSec:       { field: 'lifetimeSec' },        // 秒
    maxSpeed:          { field: 'maxSpeed', after: '_rebuildSpeedGears' },  // 节
    rotationSpeed:     { field: 'rotationSpeed', scale: 'deg' },             // 度/秒
  },

  /* ── 存档（localStorage['hj_classSkills'] = { destroyer: 0|1 }）──────────── */

  /** 读存档。**任何异常都吞掉回落 {}**（损坏 JSON / 非对象 / 无 localStorage 环境）。 */
  getSelection() {
    try {
      var raw = localStorage.getItem(this.STORAGE_KEY);
      if (!raw) return {};
      var obj = JSON.parse(raw);
      if (obj && typeof obj === 'object' && !Array.isArray(obj)) return obj;
      return {};
    } catch (e) { return {}; }
  },

  /** 写存档（UI 切系时调）。异常吞掉（隐私模式 / 配额满不应崩游戏）。 */
  setSelection(shipType, pathIndex) {
    var sel = this.getSelection();
    sel[shipType] = (pathIndex === 1 ? 1 : 0);
    try { localStorage.setItem(this.STORAGE_KEY, JSON.stringify(sel)); } catch (e) {}
  },

  /** 该舰种当前选中的系 index（0/1）。缺失/非法 → 0（一系「突击」）。 */
  getPathIndex(shipType) {
    var sel = this.getSelection();
    var v = sel[shipType];
    return (v === 1) ? 1 : 0;
  },

  /** 某舰种的舰种技能定义（无此舰种 → null）。 */
  getDef(shipType) {
    if (!shipType) return null;
    var def = CLASS_SKILLS[shipType];
    return (def && Array.isArray(def.paths)) ? def : null;
  },

  /** 某舰种的系列表（空壳舰种 → 空数组，**不抛异常**，设计文档 §9.3）。 */
  getPaths(shipType) {
    var def = this.getDef(shipType);
    return def ? def.paths : [];
  },

  /**
   * 取舰船的舰种。优先 `_shipConfig.shipType`（ShipSkills.applyStatic 会挂 _shipConfig），
   * 回落 `ship.shipType`（Ship 构造器从 cfg.shipType 存的），都没有 → null。
   */
  getShipType(ship) {
    if (!ship) return null;
    if (ship._shipConfig && ship._shipConfig.shipType) return ship._shipConfig.shipType;
    return ship.shipType || null;
  },

  /* ── 单一入口 ─────────────────────────────────────────────────────────── */

  /**
   * 当前生效的舰种技能效果（已按舰种 + 选系过滤 + 同 stat 多来源合并）。
   * @param {Ship} ship
   * @returns {Array<{stat:string, value:number}>} 空舰种 / 巡洋 / 战列 → []
   */
  getEffects(ship) {
    var type = this.getShipType(ship);
    var def = this.getDef(type);
    if (!def || def.paths.length === 0) return [];
    var path = def.paths[this.getPathIndex(type)];
    if (!path || !Array.isArray(path.skills)) return [];

    var out = [];
    var byStat = Object.create(null);   // stat → 合并后的 {stat,value} 引用
    for (var i = 0; i < path.skills.length; i++) {
      var sk = path.skills[i];
      // ⚠️ 只收「已开放的被动」：ready:false 的主动技能本轮不实现（设计文档 §5.1）
      if (!sk || sk.type !== 'passive' || sk.ready !== true) continue;
      var effs = sk.effects || [];
      for (var j = 0; j < effs.length; j++) {
        var e = effs[j];
        if (!e || !e.stat) continue;
        var v = (typeof e.value === 'number' && isFinite(e.value)) ? e.value : 0;
        if (byStat[e.stat] === undefined) {
          byStat[e.stat] = { stat: e.stat, value: 0 };
          out.push(byStat[e.stat]);
        }
        byStat[e.stat].value += v;   // 同 stat 多来源 → 相加（设计文档 §8.1.5）
      }
    }
    return out;
  },

  /** getEffects 的对象视图（测试/调试方便）。 */
  getEffectMap(ship) {
    var out = {};
    var effs = this.getEffects(ship);
    for (var i = 0; i < effs.length; i++) out[effs[i].stat] = effs[i].value;
    return out;
  },

  /* ── 生效 ─────────────────────────────────────────────────────────────── */

  /**
   * 把当前生效效果落到舰船上（战斗开始时对**玩家舰**调一次）。
   * 幂等：重复调用直接 return，防止叠加两次。
   * @param {Ship} ship
   * @returns {Array} 实际生效的 effects（便于测试/调试）
   */
  applyTo(ship) {
    if (!ship) return [];
    if (ship._classSkillsApplied) return [];
    ship._classSkillsApplied = true;

    var effs = this.getEffects(ship);
    var buffs = Object.create(null);   // BUFF 通道先合并，最后一次性挂（getBuffMod 本身也会跨 buff 求和）

    for (var i = 0; i < effs.length; i++) {
      var stat = effs[i].stat, v = effs[i].value;
      if (!v) continue;

      if (this.BUFF_CHANNELS[stat]) {
        buffs[stat] = (buffs[stat] || 0) + v;
        continue;
      }
      var fc = this.FIELD_CHANNELS[stat];
      if (!fc) continue;
      // scale:'deg' → 存储层「度」转弧度（与 systems/term-overrides.js:27 同惯例）
      var add = (fc.scale === 'deg') ? v * Math.PI / 180 : v;
      ship[fc.field] = (ship[fc.field] || 0) + add;
      if (fc.after && typeof ship[fc.after] === 'function') ship[fc.after]();
    }

    if (ship.addBuff) {
      for (var k in buffs) {
        var mods = { noIcon: true, noDuration: true };   // 常驻、无时间 → 不显示图标/时间（§5.29）
        mods[k] = buffs[k];
        ship.addBuff('classskill_' + k, '舰种技能', Infinity, mods);
      }
    }
    return effs;
  },
};
