/**
 * settings.js — 全局设置（持久化到 localStorage huanjian.settings）
 *
 * 结构：
 *   fx: { shake, flash, damagePopups, wakeParticles, hitStats } — 特效开关
 *   secondaryAuto: bool — 副炮自动开火
 *   cameraMidFollow: bool — 相机始终跟随准星与我舰连线中点
 *   cameraFollowSmooth: number — 相机跟随平滑度（0.05~1；1=立即跟随，越小越滑顺）
 *   zoomIndex: number — 初始缩放档（0..ZOOM_LEVELS.length-1）
 *   keys: { 10 个动作 → 绑定值 } — 绑定值：key:<code> | mouse:0|2 | wheel
 */
const DEFAULT_SETTINGS = Object.freeze({
  fx: Object.freeze({
    shake: true, flash: true, damagePopups: true,
    wakeParticles: true, hitStats: true,
    killToast: true,              // 击杀飞入特效"你击沉了 XXX"（2026-08-06）
  }),
  secondaryAuto: true,
  noDamageVariance: false,
  aimAssist: false,       // 辅助瞄准：鼠标在被发现敌舰船模附近时降低灵敏度（2026-08-08）
  zoomIndex: 3,           // 默认档 0.53（2026-10-01 等比 7 档后取 ≈旧 0.55 手感；须与 DEFAULT_ZOOM_INDEX 一致）
  cameraSensitivity: 1,   // 相机移动灵敏度（1~10，倍率；2026-08-07 相机偏移）
  cameraMidFollow: false,    // 相机始终跟随准星与我舰连线中点（2026-10-01；方向键临时接管，L/空格恢复）
  cameraFollowSmooth: 0.25,   // 相机跟随平滑度（1=立即跟随，越小越滑顺；仅跟随模式生效，2026-10-01 抗抖动）
  keys: Object.freeze({
    moveUp: 'key:KeyW',     moveDown: 'key:KeyS',
    turnLeft: 'key:KeyA',   turnRight: 'key:KeyD',
    zoomIn: 'key:KeyM',     zoomOut: 'key:KeyN',
    stats: 'key:Tab',
    mainGun: 'mouse:0',     torpedo: 'mouse:2',  mine: 'wheel',
    commanderMain: 'mouse:1', commanderSecondary: 'key:KeyG',   // 指挥官主主动默认鼠标中键（2026-08-06）
    shipActiveSkill: 'key:KeyC',   // 战舰主动技能（沙皇「红场之魂」/A-140A「炮火风暴」/阳炎-利刃「蜃光猎影」共用，2026-10-02 统一）
    //   一艘舰只开一个主动技能，友军由 AI 自行决策行动，玩家不存在同屏争用键位的情况，
    //   所以**所有舰的主动技能都复用这一个动作名**。不要按舰新建第二个动作名：
    //   ① 新建会与本键重复占用（两个动作抢同一个物理键，两边都不可靠）
    //   ② 新动作名若漏登记进本表，isActionJustPressed(新名) 恒 false
    //      → 技能按不出来且不报错（静默失效，2026-10-02 真实踩过）
    // 相机偏移（2026-08-07）：方向键移动相机、L 还原、空格移到准星与我舰连线中点（与开船 WASD 不冲突）
    cameraUp: 'key:ArrowUp',    cameraDown: 'key:ArrowDown',
    cameraLeft: 'key:ArrowLeft', cameraRight: 'key:ArrowRight',
    cameraReset: 'key:KeyL',    cameraFocus: 'key:Space',   // 空格：相机移到准星与我舰连线中点（2026-08-09 字人改）
  }),
});

const SETTINGS_KEY = 'huanjian.settings';

/** 动作显示名（settings-screen.js 键位区渲染引用） */
const ACTION_LABELS = {
  moveUp: '加速', moveDown: '减速', turnLeft: '左转', turnRight: '右转',
  zoomIn: '放大视野', zoomOut: '缩小视野', stats: '查看战绩',
  mainGun: '主炮开火', torpedo: '鱼雷发射', mine: '布放水雷',
  commanderMain: '指挥官主动', commanderSecondary: '指挥官副主动',
  shipActiveSkill: '战舰主动技能',   // 三舰共用：沙皇 / A-140A / 阳炎-利刃（勿按舰拆成两个动作名）
  cameraUp: '相机上移', cameraDown: '相机下移',
  cameraLeft: '相机左移', cameraRight: '相机右移', cameraReset: '相机还原',
  cameraFocus: '相机移到准星与我舰连线中点',
};

/** 严格校验绑定字符串（key:/mouse:/wheel 三种合法形态） */
function parseBindingStrict(b) {
  if (b === 'wheel') return true;
  if (/^key:.+$/.test(b)) return true;
  if (/^mouse:[012]$/.test(b)) return true;
  return false;
}

/** 深合并：src 为覆盖源，缺失字段用 defaults 补齐；非法绑定值回退默认 */
function mergeSettings(src) {
  if (!src || typeof src !== 'object') src = {};
  var result = {
    fx: {},
    secondaryAuto: DEFAULT_SETTINGS.secondaryAuto,
    noDamageVariance: DEFAULT_SETTINGS.noDamageVariance,
    aimAssist: DEFAULT_SETTINGS.aimAssist,
    zoomIndex: DEFAULT_SETTINGS.zoomIndex,
    cameraSensitivity: DEFAULT_SETTINGS.cameraSensitivity,
    cameraMidFollow: DEFAULT_SETTINGS.cameraMidFollow,
    cameraFollowSmooth: DEFAULT_SETTINGS.cameraFollowSmooth,
    keys: {},
  };
  for (var fk in DEFAULT_SETTINGS.fx) {
    result.fx[fk] = typeof src.fx === 'object' && typeof src.fx[fk] === 'boolean'
      ? src.fx[fk] : DEFAULT_SETTINGS.fx[fk];
  }
  if (typeof src.secondaryAuto === 'boolean') result.secondaryAuto = src.secondaryAuto;
  if (typeof src.noDamageVariance === 'boolean') result.noDamageVariance = src.noDamageVariance;
  if (typeof src.aimAssist === 'boolean') result.aimAssist = src.aimAssist;
  if (typeof src.cameraMidFollow === 'boolean') result.cameraMidFollow = src.cameraMidFollow;
  if (typeof src.zoomIndex === 'number' && src.zoomIndex >= 0) result.zoomIndex = src.zoomIndex;
  if (typeof src.cameraSensitivity === 'number' && src.cameraSensitivity >= 0.1 && src.cameraSensitivity <= 10) {
    result.cameraSensitivity = src.cameraSensitivity;
  }
  if (typeof src.cameraFollowSmooth === 'number' && src.cameraFollowSmooth >= 0.05 && src.cameraFollowSmooth <= 1) {
    result.cameraFollowSmooth = src.cameraFollowSmooth;
  }
  for (var ak in DEFAULT_SETTINGS.keys) {
    var b = src.keys && src.keys[ak];
    if (typeof b === 'string' && parseBindingStrict(b)) result.keys[ak] = b;
    else result.keys[ak] = DEFAULT_SETTINGS.keys[ak];
  }
  return result;
}

let SETTINGS = null;

function loadSettings() {
  var src = null;
  try { src = JSON.parse(localStorage.getItem(SETTINGS_KEY)); } catch (e) {}
  SETTINGS = mergeSettings(src);
  return SETTINGS;
}

function saveSettings(src) {
  if (src) SETTINGS = mergeSettings(src);
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); } catch (e) {}
}

function resetSettings() {
  SETTINGS = mergeSettings({});
  saveSettings();
  return SETTINGS;
}

/** 返回与 value 冲突的其它动作名；无冲突返回 null */
function findBindingConflict(keys, action, value) {
  for (var k in keys) {
    if (k === action) continue;
    if (keys[k] === value) return k;
  }
  return null;
}

/** 绑定值 → 显示文本 */
function bindingLabel(binding) {
  if (binding === 'wheel') return '滚轮';
  var m = /^mouse:([012])$/.exec(binding);
  if (m) return m[1] === '0' ? '鼠标左键' : (m[1] === '1' ? '鼠标中键' : '鼠标右键');
  m = /^key:(.+)$/.exec(binding);
  if (m) return /^Key([A-Z0-9])$/.test(m[1]) ? m[1].slice(3) : m[1];
  return binding;
}

// 顶层实例化一次（测试环境无 localStorage 时回退默认）
SETTINGS = loadSettings();
