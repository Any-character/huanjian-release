/**
 * battle-stats.js — 战绩统计（纯数据逻辑，无 DOM，可 node 单测）
 *
 * 每艘参战舰挂 _stats：{ kills, assists, damage, taken, lastAttacker, counted, ... }
 *   damage  输出伤害（含其造成的燃烧/漏水）
 *   taken   承伤（含 DOT）
 *   kills   击沉数（谁被它击沉记它的击杀）
 *   assists 助攻数（2026-10-02；只记玩家，见下方「助攻判定」）
 *   lastAttacker  最后伤害来源（击杀归属）
 *   counted 死亡是否已计（防同帧多弹重复计数）
 *   recentDamage  伤害来源历史 [{attacker, at}]，**每个 attacker 至多一条**（at = 最近一次造成伤害的时刻）
 *   assisters     死亡结算时算出的助攻者名单（不含击杀者；供 yanyin-pursuit 等技能消费）
 *
 * ── 助攻判定（2026-10-02，技能①「鱼雷追击」）──────────────────────────────────
 * 字人规格：「该敌舰被击沉前 20 秒内你对它造成过伤害，但最后一击不是你」。
 *   窗口 ASSIST_WINDOW_MS = 20000ms；判定时刻 = checkDeaths 的帧末时刻。
 *   前提：这次击沉必须是**敌对行为**（击杀者与目标不同阵营）—— 友军互沉不算「协助击沉」。
 *   排除：① 最后一击者（那是击杀不是助攻）② 目标自身 ③ 与目标**同阵营**的攻击者
 *         ④ 窗口外（at < now - 窗口，边界 at === now-20000 仍算）⑤ 未注册 _stats 的伤害来源
 *   同一攻击者打了 5 下也只算 1 次助攻（recentDamage 按 attacker 去重）。
 *   ⚠️ `assists` 计数器与播报**只给玩家**（字人只要求「你」的助攻）；
 *      `assisters` 名单则含全部助攻者，供技能层（AI 友军阳炎同样能拿 perm 层）。
 *
 * 时间来源：onHit / onDot / checkDeaths 的 `now` 形参**可选**，缺省 Date.now()。
 *   main.js 现有调用不传（不改动 main.js）；main.js gameLoop 的 now 本身就是 Date.now()（L585），
 *   故生产环境与显式传 now 的单测时间轴一致。
 *
 * 数据来源（main.js 调用）：
 *   onHit(ev[,now])        命中事件（含直接伤害 + 燃烧/漏水触发）
 *   onDot(d,t,att,type[,now]) 燃烧/漏水 tick 伤害
 *   checkDeaths(ships[,now])  帧末检测新死亡
 *
 * 阵营归属：按 hitEvent 的 attacker / target（船对象）归属，不再依赖
 * isPlayerProjectile 单边判定——玩家、友军、敌军伤害各自记账。
 */

/** 助攻判定窗口（ms）：被击沉前该窗口内对其造成过伤害即算助攻（2026-10-02） */
const ASSIST_WINDOW_MS = 20000;

class BattleStats {
  init(player, enemies, allies) {
    this._player = player;
    this._enemies = enemies || [];
    this._allies = allies || [];
    this._startTime = Date.now();   // 战斗开始时间（最终战绩显示战斗时长，2026-08-06）
    this._endTime = 0;              // 战斗结束时间（endBattle 冻结；0 = 战斗中）
    this._killToasts = [];          // 击杀飞入特效队列（player 击杀时 push，2026-08-06）
    this._ensureStats(player);
    for (var i = 0; i < this._enemies.length; i++) this._ensureStats(this._enemies[i]);
    for (var j = 0; j < this._allies.length; j++) this._ensureStats(this._allies[j]);
  }

  /** 暴露 killToasts（main.js 每帧 dt 更新 life + render 时传 renderer），2026-08-06 */
  getKillToasts() { return this._killToasts || (this._killToasts = []); }

  /**
   * 动态注册新船（运行时生成的敌舰/友军，2026-08-08）：注册 _stats + 按阵营加入对应战绩列表。
   * ⚠️ 重大修复（2026-08-09）：_enemies/_allies 是 main.js 数组的**引用**（init 时传入），
   * 若一律 push 到 _enemies，友军（如战役援助胡德）会被推入敌人数组 → 被当敌人更新/误伤。
   * 正确行为：按 ship.team 分流；已在对应数组（main.js 已 push）则幂等跳过。
   */
  track(ship) {
    if (!ship) return;
    this._ensureStats(ship);
    var list = (ship.team === 'enemy') ? this._enemies : this._allies;
    if (list && list.indexOf(ship) === -1) list.push(ship);
  }

  /** 战斗结束冻结时长（main.js gameOver 时调用；只冻结一次，防止点击查看战绩时把等待时间算进去，2026-08-06） */
  endBattle(now) {
    if (!this._endTime) this._endTime = now || Date.now();
  }

  _ensureStats(ship) {
    if (ship && !ship._stats) {
      ship._stats = {
        kills: 0, assists: 0, damage: 0, taken: 0, lastAttacker: null, counted: false,
        recentDamage: [],   // 伤害来源历史 [{attacker, at}]，按 attacker 去重（助攻判定，2026-10-02）
        assisters: null,    // 死亡结算时的助攻者名单（不含击杀者；技能消费）
        // 最终战绩（玩家详细统计，2026-08-05）
        healed: 0,  // 回复量（指挥官回血计入）
        dmgByType: { mainGun: 0, secondary: 0, torpedo: 0, mine: 0, burn: 0, flood: 0 },
        hitCounts: { mainGun: 0, secondary: 0, torpedo: 0, mine: 0, crit: 0, pen: 0, shatter: 0, burn: 0, flood: 0, execute: 0, accessoryDamage: 0, weaponDamage: 0 },
      };
    }
  }

  /**
   * 命中事件：按 attacker / target 归属（含敌我水雷、友军互打）；玩家输出追加分类统计。
   * @param {number} [now] — 伤害发生时刻（助攻判定用；缺省 Date.now()）
   */
  onHit(ev, now) {
    var dmg = ev.damage || 0;
    var attacker = ev.attacker || (ev.isPlayerProjectile ? this._player : null);
    var target = ev.target || ev.targetEnemy;
    if (!target && !ev.isPlayerProjectile && this._player) target = this._player;
    // 兜底注册（动态生成的船如增援首次承伤/输出时注册，2026-08-08）
    if (attacker && !attacker._stats) this._ensureStats(attacker);
    if (target && !target._stats) { this._ensureStats(target); this.track(target); }

    if (attacker && attacker._stats) attacker._stats.damage += dmg;
    if (target && target._stats) {
      target._stats.taken += dmg;
      if (attacker && attacker._stats) {
        target._stats.lastAttacker = attacker;
        this._recordDamage(target, attacker, now);   // 助攻判定的伤害历史（2026-10-02）
      }
    }
    // 最终战绩：仅玩家输出的详细统计（伤害分类 + 命中/效果次数）
    if (attacker && attacker === this._player && attacker._stats) {
      var st = attacker._stats;
      if (st.dmgByType[ev.type] !== undefined) st.dmgByType[ev.type] += dmg;
      if (st.hitCounts[ev.type] !== undefined) st.hitCounts[ev.type] += 1;
      if (ev.isCritical) st.hitCounts.crit += 1;
      if (ev.isPenetration) st.hitCounts.pen += 1;
      if (ev.isShatter) st.hitCounts.shatter += 1;
      if (ev.isBurn) st.hitCounts.burn += 1;
      if (ev.isFlood) st.hitCounts.flood += 1;
      if (ev.isExecute) st.hitCounts.execute += 1;
      if (ev.isAccessory) st.hitCounts.accessoryDamage += 1;   // 配件损毁次数（2026-09-05）
      if (ev.isWeaponDamage) st.hitCounts.weaponDamage += 1;   // 武器损毁次数（2026-09-13）
    }
  }

  /**
   * 燃烧/漏水 tick：target 承伤、attacker 输出；玩家造成的 DOT 按类型分类。
   * @param {string} [dotType] — 'burn' | 'flood'
   * @param {number} [now] — tick 时刻（助攻判定用；缺省 Date.now()）
   */
  onDot(damage, target, attacker, dotType, now) {
    if (!target) return;
    if (!target._stats) { this._ensureStats(target); this.track(target); }   // 兜底注册（2026-08-08）
    if (attacker && !attacker._stats) this._ensureStats(attacker);
    target._stats.taken += damage;
    if (attacker && attacker._stats) {
      attacker._stats.damage += damage;
      target._stats.lastAttacker = attacker;
      this._recordDamage(target, attacker, now);   // 燃烧/漏水同样算「造成过伤害」（2026-10-02）
      if (attacker === this._player && dotType && attacker._stats.dmgByType[dotType] !== undefined) {
        attacker._stats.dmgByType[dotType] += damage;
      }
    }
  }

  /**
   * 记录一次伤害到 target 的伤害来源历史（助攻判定数据源，2026-10-02）。
   *   · **每个 attacker 至多一条**：重复伤害只刷新 at，不追加
   *     → 数组长度上界 = 场上舰数（不会无限增长），且天然满足「打 5 下只算 1 次助攻」。
   *   · 顺手清掉窗口外（at < now - ASSIST_WINDOW_MS）的过期记录。边界 at === now-窗口 保留。
   *   · 自伤（attacker === target）与空 attacker 不入历史。
   */
  _recordDamage(target, attacker, now) {
    if (!attacker || !target || attacker === target) return;
    if (!(now > 0)) now = Date.now();     // 缺省时间（main.js 不传 now）
    var st = target._stats;
    if (!st) return;
    var list = st.recentDamage;
    if (!list) list = st.recentDamage = [];
    var cut = now - ASSIST_WINDOW_MS;
    var w = 0;
    for (var i = 0; i < list.length; i++) {
      if (list[i].at >= cut) { if (w !== i) list[w] = list[i]; w++; }
    }
    list.length = w;                       // 裁掉过期记录
    for (var j = 0; j < list.length; j++) {
      if (list[j].attacker === attacker) { list[j].at = now; return; }
    }
    list.push({ attacker: attacker, at: now });
  }

  /** 玩家回复量（指挥官回血计入最终战绩） */
  onHeal(amount) {
    if (this._player && this._player._stats) {
      this._player._stats.healed += (amount || 0);
    }
  }

  /**
   * 帧末检测新死亡并计击杀 + 助攻（同帧多弹只计一次）。
   * 支持两种调用：checkDeaths(ships数组) 或旧式 checkDeaths(player, enemies)。
   * @param {number} [now] — 结算时刻（助攻窗口的右端点；缺省 Date.now()）
   *
   * 击杀与助攻**互斥**（最后一击者是击杀者，不在 assisters 里），故两者不会重复记。
   * `s._stats.assisters` 落盘后由 yanyin-pursuit.scanKills 消费（帧末同一帧内可读）。
   */
  checkDeaths(player, enemies, now) {
    if (!(now > 0)) now = Date.now();
    var ships;
    if (Array.isArray(player)) ships = player;
    else {
      ships = [player];
      if (enemies) ships = ships.concat(enemies);
    }
    for (var i = 0; i < ships.length; i++) {
      var s = ships[i];
      if (!s || !s._stats || s._stats.counted || s.isAlive) continue;
      s._stats.counted = true;
      var k = s._stats.lastAttacker;
      if (k && k._stats) k._stats.kills++;
      else if (this._player && this._player._stats && s !== this._player) {
        this._player._stats.kills++;  // 兜底：当前唯一伤害源是玩家
      }
      // ── 助攻（2026-10-02）：窗口内有伤害、但不是最后一击、非同阵营 ──
      var assisters = this._collectAssisters(s, k, now);
      s._stats.assisters = assisters;
      var playerAssisted = false;
      for (var a = 0; a < assisters.length; a++) {
        if (assisters[a] !== this._player || !assisters[a]._stats) continue;
        assisters[a]._stats.assists++;   // 计数器只给玩家（字人只要求「你」的助攻）
        playerAssisted = true;
      }
      // 玩家击杀 → push 击杀飞入特效（"你击沉了 XXX"，2026-08-06）
      if (this._player && this._player._stats && this._killToasts && k === this._player) {
        this._pushKillToast(s, false);
      } else if (playerAssisted && this._killToasts) {
        this._pushKillToast(s, true);   // "你协助击沉了 XXX"
      }
    }
  }

  /**
   * 收集 target 的助攻者名单（不含击杀者 killer），2026-10-02。
   * 前置门槛：**这次击沉必须是敌对行为**（击杀者与目标不同阵营）—— 友军互相打沉时
   *   「协助击沉」在语义上不成立（否则玩家误伤友舰、友军补刀就会白拿一个助攻）。
   * 排除五类：① 目标自身 ② 最后一击者（是击杀不是助攻）③ 与目标同阵营 ④ 窗口外（at < now - 窗口）
   *        ⑤ 无 _stats 的伤害来源（未注册，不参与统计）
   * 窗口边界：at >= now - ASSIST_WINDOW_MS 才算数（恰好 20s 仍算「20 秒内」）。
   * 同阵营判定沿用 yanyin-pursuit 的既有口径：`a.team && t.team && a.team === t.team` 才算同阵营
   *   （team 缺失时不做排除，与旧 scanKills 行为一致）。
   */
  _collectAssisters(target, killer, now) {
    var out = [];
    var st = target && target._stats;
    if (!st || !st.recentDamage) return out;
    if (killer && killer.team && target.team && killer.team === target.team) return out;  // 同阵营击沉
    var cut = now - ASSIST_WINDOW_MS;
    for (var i = 0; i < st.recentDamage.length; i++) {
      var r = st.recentDamage[i];
      if (!r) continue;
      var a = r.attacker;
      if (!a || !a._stats) continue;
      if (a === target || a === killer) continue;
      if (r.at < cut) continue;
      if (a.team && target.team && a.team === target.team) continue;
      out.push(a);
    }
    return out;
  }

  /** push 一条击杀/助攻播报（assist 字段供 ui.js 区分文案，2026-10-02） */
  _pushKillToast(s, isAssist) {
    if (!this._killToasts) return;
    this._toastSeq = (this._toastSeq || 0) + 1;
    this._killToasts.push({
      id: this._toastSeq,
      name: s.displayName || s.name || '敌舰',
      life: 0,
      assist: !!isAssist,   // false = 你击沉了 XXX（2026-08-06 原行为）；true = 你协助击沉了 XXX
    });
  }

  /** 渲染快照：只含存活舰，数字取整。蓝方 = player + allies（BattleStatsScreen 左侧）；2026-08-08 增援实时显示 */
  snapshot() {
    var rows = [];
    for (var i = 0; i < this._enemies.length; i++) {
      var e = this._enemies[i];
      if (!e || !e.isAlive) continue;
      if (!e._stats) this._ensureStats(e);   // 兜底（动态船极端情况）
      rows.push({
        name: e.displayName || e.name || '敌舰',
        kills: e._stats.kills,
        damage: Math.round(e._stats.damage),
        taken: Math.round(e._stats.taken),
      });
    }
    var allyRows = [];
    for (var j = 0; j < (this._allies || []).length; j++) {
      var a = this._allies[j];
      if (!a.isAlive) continue;
      allyRows.push({
        name: a.displayName || a.name || '友军',
        kills: a._stats.kills,
        damage: Math.round(a._stats.damage),
        taken: Math.round(a._stats.taken),
      });
    }
    return {
      player: {
        name: this._player.name || '玩家',
        kills: this._player._stats.kills,
        assists: this._player._stats.assists || 0,   // 2026-10-02
        damage: Math.round(this._player._stats.damage),
        taken: Math.round(this._player._stats.taken),
      },
      allies: allyRows,
      enemies: rows,
    };
  }

  /** 最终战绩快照（玩家个人，战斗结束展示）：总览 + 伤害详情 6 类 + 效果次数 9 项 + 船名/战斗时长 */
  playerFinal() {
    if (!this._player || !this._player._stats) return null;
    var st = this._player._stats;
    return {
      name: this._player.name || '玩家',
      durationSec: Math.max(0, Math.floor(((this._endTime || Date.now()) - this._startTime) / 1000)),
      kills: st.kills,
      assists: st.assists || 0,   // 2026-10-02
      damage: Math.round(st.damage),
      taken: Math.round(st.taken),
      healed: Math.round(st.healed),
      dmgByType: {
        mainGun: Math.round(st.dmgByType.mainGun),
        secondary: Math.round(st.dmgByType.secondary),
        torpedo: Math.round(st.dmgByType.torpedo),
        mine: Math.round(st.dmgByType.mine),
        burn: Math.round(st.dmgByType.burn),
        flood: Math.round(st.dmgByType.flood),
      },
      hitCounts: {
        mainGun: st.hitCounts.mainGun,
        secondary: st.hitCounts.secondary,
        torpedo: st.hitCounts.torpedo,
        mine: st.hitCounts.mine,
        crit: st.hitCounts.crit,
        pen: st.hitCounts.pen,
        shatter: st.hitCounts.shatter,
        burn: st.hitCounts.burn,
        flood: st.hitCounts.flood,
        execute: st.hitCounts.execute,
        accessoryDamage: st.hitCounts.accessoryDamage,
        weaponDamage: st.hitCounts.weaponDamage,
      },
    };
  }
}
