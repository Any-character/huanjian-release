/**
 * accessory-debuffs.js — 配件损毁（配损）+ 武器损毁（武损）减益图标
 *                          （Renderer.prototype 扩展，2026-09-05 / 2026-09-13）
 *
 * 图标与碎甲/燃烧/漏水同排（顶部中央右侧），**延续 _drawDebuffs 的排布游标**避免重叠。
 * - 配损（引擎/舵机/雷达）：读 ship.buffs[key].endTime 显示 10s 倒计时
 * - 武损（武器损毁，2026-09-13）：per-mount 状态（非 buff），读
 *   ship.getWeaponDamageCount(now) / getWeaponDamageEndTime(now)；右上 ×N = 被损毁武器数
 * 必须后于 fire-effects.js 加载（复用 _drawDebuffIcon）。
 */

  /**
   * 绘制配损 + 武损减益图标（在 _drawDebuffs 尾部调用）。
   * @param {Ship}   player — 玩家舰（读 player.buffs / 武损 API）
   * @param {number} now
   * @param {{x:number,y:number,rowCount:number}} [cursor] — _drawDebuffs 的排布游标（2026-09-13 加；
   *        修复此前"配损图标重新从起点排布 → 与燃烧/漏水图标重叠"的隐患）
   */
Renderer.prototype._drawAccessoryDebuffs = function (player, now, cursor) {
  if (!player || !player.buffs) return;
  const ctx = this.ctx;
  const size = 28;
  const gap = 4;
  const perRow = 6;
  const centerX = this.width / 2;
  const rowStartX = centerX - gap / 2 - size;   // 减益区第 0 枚（紧贴中心左侧，2026-09-13）
  // 有游标 → 接在燃烧/漏水图标之后；无游标（单独调用）→ 从起点开始
  var x = cursor ? cursor.x : rowStartX;
  var y = cursor ? cursor.y : (34 + (this._bossBarVisible ? 36 : 0));
  var rowCount = cursor ? cursor.rowCount : 0;
  var self = this;
  var place = function (fn) {
    fn(x, y);                                   // 绘制（返回值忽略）
    x -= (size + gap);                          // ★向左生长（与 _drawDebuffs 同区同向）
    rowCount++;
    if (rowCount >= perRow) { rowCount = 0; x = rowStartX; y += size + gap; }
  };

  var ACCS = [
    { key: 'rudderDamage', name: '舵机损毁' },
    { key: 'engineDamage', name: '引擎损毁' },
    { key: 'radarDamage',  name: '雷达损毁' },
  ];
  for (var i = 0; i < ACCS.length; i++) {
    (function (acc) {
      var b = player.buffs[acc.key];
      if (!b || now >= b.endTime) return;
      place(function (cx, cy) {
        return self._drawDebuffIcon(ctx, cx, cy, size, now, b.endTime, '#CC3333', '#660000', function (cx2, cy2, r) {
          if (acc.key === 'rudderDamage') {
            // 舵轮：外圈 + 十字辐条 + 中心点
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(cx2, cy2, r * 0.75, 0, Math.PI * 2);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(cx2 - r * 0.75, cy2);
            ctx.lineTo(cx2 + r * 0.75, cy2);
            ctx.moveTo(cx2, cy2 - r * 0.75);
            ctx.lineTo(cx2, cy2 + r * 0.75);
            ctx.stroke();
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath();
            ctx.arc(cx2, cy2, r * 0.2, 0, Math.PI * 2);
            ctx.fill();
          } else if (acc.key === 'engineDamage') {
            // 齿轮：外圈 6 齿 + 中心孔（底色调）
            ctx.fillStyle = '#FFFFFF';
            var teeth = 6;
            ctx.beginPath();
            for (var ti = 0; ti < teeth * 2; ti++) {
              var ta = (ti * Math.PI) / teeth;
              var tr = (ti % 2 === 0) ? r * 0.85 : r * 0.55;
              var tx = cx2 + Math.cos(ta) * tr;
              var ty = cy2 + Math.sin(ta) * tr;
              if (ti === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
            }
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = '#CC3333';
            ctx.beginPath();
            ctx.arc(cx2, cy2, r * 0.3, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // 雷达盘：上半圆扫描 + 基线 + 交叉断裂线（损毁）
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(cx2, cy2, r * 0.72, Math.PI, Math.PI * 2);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(cx2 - r * 0.72, cy2);
            ctx.lineTo(cx2 + r * 0.72, cy2);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(cx2 - r * 0.45, cy2 - r * 0.45);
            ctx.lineTo(cx2 + r * 0.45, cy2 + r * 0.45);
            ctx.moveTo(cx2 + r * 0.45, cy2 - r * 0.45);
            ctx.lineTo(cx2 - r * 0.45, cy2 + r * 0.45);
            ctx.stroke();
          }
        }, acc.name);
      });
    })(ACCS[i]);
  }

  // ── 武器损毁（武损，2026-09-13）────────────────────────────────────────
  // 非 buff 状态：per-mount（可能多门炮同时被损毁）→ 图标右上 ×N = 被损毁武器数；
  // 倒计时取所有武损炮位中最晚的结束时间（全部修复后图标才消失）。
  var wedCount = player.getWeaponDamageCount ? player.getWeaponDamageCount(now) : 0;
  var wedEnd   = player.getWeaponDamageEndTime ? player.getWeaponDamageEndTime(now) : 0;
  if (wedCount > 0 && wedEnd > now) {
    place(function (cx, cy) {
      return self._drawDebuffIcon(ctx, cx, cy, size, now, wedEnd,
        '#CC3300', '#661100',   // 红系（与燃烧同族：字人"命中统计显示为红色，和燃烧一样"）
        function (cx2, cy2, r) {
          // 图标：断成两截的炮管（左右错位）+ 断裂处爆裂线 —— 一眼可读"武器被打断"
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(cx2 - r * 1.05, cy2 - r * 0.58, r * 0.85, r * 0.44);   // 左半炮管（上）
          ctx.fillRect(cx2 + r * 0.22, cy2 + r * 0.14, r * 0.85, r * 0.44);   // 右半炮管（下错位）
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 1.5;
          ctx.beginPath();                                                     // 断裂爆裂线
          ctx.moveTo(cx2 - r * 0.30, cy2 - r * 0.90);
          ctx.lineTo(cx2 + r * 0.12, cy2 - r * 0.28);
          ctx.moveTo(cx2 - r * 0.02, cy2 + r * 0.24);
          ctx.lineTo(cx2 + r * 0.40, cy2 + r * 0.92);
          ctx.stroke();
        },
        '武器损毁', false, wedCount   // layer = 被损毁武器数（复用图标层数角标）
      );
    });
  }
};
