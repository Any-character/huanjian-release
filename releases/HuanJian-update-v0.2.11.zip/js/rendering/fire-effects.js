/**
 * fire-effects.js — 火焰 + 减益图标（Renderer.prototype 扩展）
 *
 * 自 effects.js 拆分（2026-08-03）：燃烧火焰粒子、减益图标绘制。
 * 加载顺序：damage-popups.js 之后。
 */

/* ========================================================================== */
/*  Fire particles (from burn stacks on ships)                                  */
/* ========================================================================== */

/**
 * 获取燃烧层对应的世界坐标（舰首/舰中/舰尾）。
 * @param {Ship} ship
 * @param {number} firePos  — 0=舰首 1=舰中 2=舰尾
 * @param {number} [alongJitter] — 纵向抖动（沿舰体前后，px；2026-11-08：避免三点固定成一排）
 * @param {number} [sideJitter]  — 横向抖动（左右舷方向，px）
 * @returns {{x:number, y:number}}
 */
Renderer.prototype._getBurnWorldPos = function (ship, firePos, alongJitter, sideJitter) {
  var localY = [-ship.length * 0.35, 0, ship.length * 0.35][firePos] || 0;
  localY += alongJitter || 0;
  var localX = sideJitter || 0;
  var h = ship.heading;
  return {
    // 局部坐标：localY = 舰首方向，localX = 横向（右舷为正）
    x: ship.x - localY * Math.sin(h) + localX * Math.cos(h),
    y: ship.y + localY * Math.cos(h) + localX * Math.sin(h),
  };
};

/**
 * 每帧为所有存活的燃烧层生成火焰/浓烟粒子。
 * @param {Ship} player
 * @param {Array<Ship>} enemies
 */
Renderer.prototype.spawnFireParticles = function (player, enemies) {
  // 2026-08-06 修复：燃烧粒子只对「我方可见」的敌人生成——未被发现的敌人
  // 船体都不绘制（renderer 里 canSeeShipByAny / hasBuff('lit')），火焰却暴露位置，属 bug。
  // 观察者 = 玩家 + 友军（与 render() 里 obs 一致）；旁观视角 _observeAll 全部可见。
  var obs = [player].concat(this._allies || []);
  var ships = [];
  if (player && player.isAlive && player.burnStacks.length > 0) ships.push(player);
  for (var si = 0; si < enemies.length; si++) {
    var e = enemies[si];
    if (e && e.isAlive && e.burnStacks.length > 0 &&
        (this._observeAll || Detection.canSeeShipByAny(obs, e) || (e.hasBuff && e.hasBuff('lit')))) {
      ships.push(e);
    }
  }

  for (var si2 = 0; si2 < ships.length; si2++) {
    var ship = ships[si2];
    // 2026-11-08 字人反馈「三点太刻意」：仍分舰首/舰中/舰尾三个火场，
    //   但每颗粒子在**所属火场范围内随机散布**（沿舰体 ±14% 舰长、横向 ±30% 舰宽），
    //   于是读起来是一片火在烧，而不是三个整齐的点。
    var alongSpread = ship.length * 0.14;
    var sideSpread = Math.max(3, ship.width * 0.30);
    for (var bi = 0; bi < ship.burnStacks.length; bi++) {
      var stack = ship.burnStacks[bi];

      // 火床（2026-11-08 二次修订）：一颗大而暗的光斑贴着火场，短命高频生成。
      //   它是"连续性"的主要来源——火苗之间的空隙被它填住，看起来是一片火而不是一排亮点。
      if (Math.random() < 0.8) {
        var gpos = this._getBurnWorldPos(
          ship, stack.firePos,
          (Math.random() - 0.5) * 2 * alongSpread,
          (Math.random() - 0.5) * 2 * sideSpread
        );
        this.fireParticles.push({
          x: gpos.x, y: gpos.y, px: gpos.x, py: gpos.y,
          vx: 0, vy: 0,
          life: 0,
          maxLife: 0.18 + Math.random() * 0.18,
          radius: 7 + Math.random() * 6,
          type: 'fireGlow',
        });
      }

      // 火焰：每帧 3~4 颗（更密更小），尺寸/寿命/初速都随机 → 闪烁不重样
      var flameCount = 3 + Math.floor(Math.random() * 2);
      for (var fi = 0; fi < flameCount; fi++) {
        var pos = this._getBurnWorldPos(
          ship, stack.firePos,
          (Math.random() - 0.5) * 2 * alongSpread,
          (Math.random() - 0.5) * 2 * sideSpread
        );
        this.fireParticles.push({
          x: pos.x, y: pos.y, px: pos.x, py: pos.y,
          vx: (Math.random() - 0.5) * 12,
          vy: -(16 + Math.random() * 30),
          life: 0,
          maxLife: 0.30 + Math.random() * 0.32,
          radius: 1.4 + Math.random() * 2.0,
          type: 'flame',
        });
      }

      // 浓烟：每帧 55% 一颗，散布比火焰更大（火场上方飘起来就是烟柱）
      if (Math.random() < 0.55) {
        var spos = this._getBurnWorldPos(
          ship, stack.firePos,
          (Math.random() - 0.5) * 2 * alongSpread * 1.5,
          (Math.random() - 0.5) * 2 * sideSpread * 1.4
        );
        this.fireParticles.push({
          x: spos.x,
          y: spos.y,
          vx: (Math.random() - 0.5) * 8,
          vy: -(10 + Math.random() * 16),
          life: 0,
          maxLife: 0.55 + Math.random() * 0.5,
          radius: 2.5 + Math.random() * 3.5,
          type: 'smoke',
        });
      }
    }
  }

  // 上限防止内存泄漏
  if (this.fireParticles.length > 500) {
    this.fireParticles.splice(0, this.fireParticles.length - 400);
  }
};

/** 更新火焰/浓烟粒子 */
Renderer.prototype.updateFireParticles = function (dt) {
  for (var i = this.fireParticles.length - 1; i >= 0; i--) {
    var p = this.fireParticles[i];
    p.life += dt;
    if (p.life >= p.maxLife) { this.fireParticles.splice(i, 1); continue; }
    // 上一帧位置（拖尾用，2026-11-08）：把相邻两帧的位移连成短线 → 火焰有"火舌"的连续感
    if (p.type === 'flame') { p.px = p.x; p.py = p.y; }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.96;
    p.vy *= 0.96;
    if (p.type === 'smoke') {
      p.radius += dt * 8;   // 烟雾扩散
    }
  }
};

/**
 * 绘制持续燃烧粒子（flame + fireGlow + smoke，前景层：舰船之上，见 renderer.js 7.6）。
 *
 * 2026-11-08 二次修订「点状明显、连续感不够」的三个来源与对策：
 *   ① 每个粒子是**硬边实心圆** → 改画「柔光外圈 + 亮芯」两层，边缘自然衰减；
 *   ② 粒子之间**互不叠加** → 火焰层用 `globalCompositeOperation = 'lighter'`（加色混合），
 *      相邻粒子重叠处自然变亮成一整片，看不到一个个圆；
 *   ③ 相邻两帧的位移**没有连接** → 画一条从上一帧位置到当前帧的短线（拖尾/火舌）。
 * 另配 `fireGlow` 火床（大而暗的光斑）填住火苗之间的空隙。
 */
Renderer.prototype._drawFireParticles = function () {
  if (this.fireParticles.length === 0) return;
  var ctx = this.ctx;
  var i, p, phase, s, r;

  // ── ① 浓烟先画（普通混合）：烟是遮挡物，不该被火焰加色提亮 ──
  for (i = 0; i < this.fireParticles.length; i++) {
    p = this.fireParticles[i];
    if (p.type !== 'smoke') continue;
    phase = p.life / p.maxLife;
    if (phase >= 1) continue;
    s = this.worldToScreen(p.x, p.y);
    r = p.radius * this.zoom;
    var smAlpha = (1 - phase) * 0.30;
    if (smAlpha < 0.01) continue;
    ctx.fillStyle = 'rgba(36,36,40,' + (smAlpha * 0.5).toFixed(3) + ')';
    ctx.beginPath();
    ctx.arc(s.x, s.y, r * 1.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(42,42,46,' + smAlpha.toFixed(3) + ')';
    ctx.beginPath();
    ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // ── ② 火焰 + 火床：加色混合，重叠处自动融成连续火团 ──
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.lineCap = 'round';
  for (i = 0; i < this.fireParticles.length; i++) {
    p = this.fireParticles[i];
    if (p.type !== 'flame' && p.type !== 'fireGlow') continue;
    phase = p.life / p.maxLife;
    if (phase >= 1) continue;
    s = this.worldToScreen(p.x, p.y);
    r = Math.max(0.5, p.radius * this.zoom);

    // 火床：大、暗、短命 → 只负责"铺底"，不抢火焰的形状
    var alpha = (1 - phase) * (p.type === 'fireGlow' ? 0.20 : 0.85);
    if (alpha < 0.01) continue;

    // 黄→橙→红→暗红
    var rCol, gCol;
    if (phase < 0.3) {
      rCol = 255;
      gCol = Math.round(200 - phase / 0.3 * 80);
    } else if (phase < 0.6) {
      rCol = 255;
      gCol = Math.round(120 - (phase - 0.3) / 0.3 * 80);
    } else {
      rCol = Math.round(255 - (phase - 0.6) / 0.4 * 100);
      gCol = Math.round(40 - (phase - 0.6) / 0.4 * 30);
    }
    gCol = Math.max(0, gCol);

    // 拖尾：上一帧 → 当前帧拉一条短线，把孤立的点接成火舌
    if (p.type === 'flame' && p.px != null) {
      var sp = this.worldToScreen(p.px, p.py);
      var dx = s.x - sp.x, dy = s.y - sp.y;
      if (dx * dx + dy * dy > 0.3) {
        ctx.strokeStyle = 'rgba(' + rCol + ',' + gCol + ',0,' + (alpha * 0.5).toFixed(3) + ')';
        ctx.lineWidth = r * 1.3;
        ctx.beginPath();
        ctx.moveTo(sp.x, sp.y);
        ctx.lineTo(s.x, s.y);
        ctx.stroke();
      }
    }

    // 柔光外圈（宽、淡）
    ctx.fillStyle = 'rgba(' + rCol + ',' + gCol + ',0,' + (alpha * 0.26).toFixed(3) + ')';
    ctx.beginPath();
    ctx.arc(s.x, s.y, r * 1.45, 0, Math.PI * 2);
    ctx.fill();
    // 亮芯（窄、亮，偏黄）
    ctx.fillStyle = 'rgba(' + rCol + ',' + Math.min(255, gCol + 45) + ',0,' + alpha.toFixed(3) + ')';
    ctx.beginPath();
    ctx.arc(s.x, s.y, r * 0.75, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
};

/** 绘制命中烟火粒子（hitFire + hitSmoke，前景层：在舰船之上，2026-08-16 字人反馈 "被舰船遮挡"）
 *  与 ship 绘制顺序解耦：renderer.js 在 player ship 绘制完后调此函数，确保命中火星/烟盖在船体上。 */
Renderer.prototype._drawHitFireworkParticles = function () {
  if (this.fireParticles.length === 0) return;
  var ctx = this.ctx;
  for (var i = 0; i < this.fireParticles.length; i++) {
    var p = this.fireParticles[i];
    if (p.type !== 'hitFire' && p.type !== 'hitSmoke') continue;   // FG：只画命中烟火
    var phase = p.life / p.maxLife;
    if (phase >= 1) continue;

    var s = this.worldToScreen(p.x, p.y);
    var r = p.radius * this.zoom;

    if (p.type === 'hitFire') {
      // 2026-08-16 增强可见度：alpha 略提，phase < 0.15 时头部白闪（爆炸瞬间的过曝光感）
      var alpha = (1 - phase) * 1.0;
      if (alpha < 0.01) continue;
      var rCol, gCol, bCol;
      if (phase < 0.15) {
        // 头部白闪（接近白色）—— 命中瞬间最亮的过曝光感
        rCol = 255;
        gCol = 240;
        bCol = 180;
      } else if (phase < 0.4) {
        rCol = 255;
        gCol = Math.round(200 - (phase - 0.15) / 0.25 * 80);
        bCol = 0;
      } else if (phase < 0.7) {
        rCol = 255;
        gCol = Math.round(120 - (phase - 0.4) / 0.3 * 80);
        bCol = 0;
      } else {
        rCol = Math.round(255 - (phase - 0.7) / 0.3 * 100);
        gCol = Math.round(40 - (phase - 0.7) / 0.3 * 30);
        bCol = 0;
      }
      ctx.fillStyle = 'rgba(' + rCol + ',' + Math.max(0, gCol) + ',' + Math.max(0, bCol) + ',' + alpha.toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // 命中烟：深灰半透明（2026-08-16 增强：alpha 从 0.55 提到 0.75，烟更明显）
      var smAlpha = (1 - phase) * 0.75;
      if (smAlpha < 0.01) continue;
      ctx.fillStyle = 'rgba(50,50,55,' + smAlpha.toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(s.x, s.y, r * (1 + phase * 0.8), 0, Math.PI * 2);   // 缓慢扩散（vs 燃烧烟 8px/s）
      ctx.fill();
    }
  }
};

/**
 * 弹丸命中战舰时生成"命中烟火"粒子（P2-2 2026-08-16 字人"追求自然真实"）。
 * 区别于 P2-1 通用装饰粒子：仅命中舰船（且未被规避）时触发，是命中判定的物理核心反馈。
 * 真实海战中炮弹命中舰船 = 爆炸火焰 + 黑烟 + 火星飞溅，本质是物理过程而非装饰。
 *
 * 组成（5-7 粒子，自然随机分布）：
 *   - 命中火星 3-4 个（橙红，从命中点向四周飞溅，0.4s 内淡出）
 *   - 命中烟 2-3 个（深灰，向上飘升 + 扩散，0.7s 内淡出）
 *
 * @param {number} wx — 命中点世界坐标
 * @param {number} wy
 */
Renderer.prototype.spawnHitFirework = function (wx, wy) {
  // 命中火星 5-6 个（2026-08-16 字人"仍然不可见" → 增强可见度：原 3-4 个）
  var fireCount = 5 + Math.floor(Math.random() * 2);
  for (var i = 0; i < fireCount; i++) {
    var ang = Math.random() * Math.PI * 2;
    var spd = 50 + Math.random() * 30;               // 50-80 px/s（增强飞溅）
    this.fireParticles.push({
      x: wx + (Math.random() - 0.5) * 8,
      y: wy + (Math.random() - 0.5) * 8,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd - 8,                    // 上飞更明显（爆炸冲击）
      life: 0,
      maxLife: 0.5 + Math.random() * 0.2,             // 0.5-0.7s（增强：延长让用户看清）
      radius: 2.5 + Math.random() * 1.0,              // 2.5-3.5（增强：原 1.2-2.0 太小）
      type: 'hitFire',
    });
  }
  // 命中烟 3-4 个（增强：从 2-3 提到 3-4）
  var smokeCount = 3 + Math.floor(Math.random() * 2);
  for (var j = 0; j < smokeCount; j++) {
    this.fireParticles.push({
      x: wx + (Math.random() - 0.5) * 10,
      y: wy + (Math.random() - 0.5) * 5,
      vx: (Math.random() - 0.5) * 8,
      vy: -(16 + Math.random() * 8),                  // 16-24 px/s（增强：上升更明显）
      life: 0,
      maxLife: 0.9 + Math.random() * 0.3,             // 0.9-1.2s（增强：完整扩散过程可见）
      radius: 4 + Math.random() * 1.5,                // 4-5.5（增强：原 2-3.2 太小）
      type: 'hitSmoke',
    });
  }
  // 上限防止内存泄漏
  if (this.fireParticles.length > 500) {
    this.fireParticles.splice(0, this.fireParticles.length - 400);
  }
};

/* ── debuff icons (top-centre) — generic layout, add new debuffs here ── */

/**
 * 减益图标（屏幕中央上方**左侧**区，2026-09-13 字人要求左右分区）：
 *   以屏幕中心线为界 —— 减益占左半（从中心向左生长），增益占右半（见 _drawBuffs），两区几何上不重叠。
 *   每行 6 枚，超出换行（新行回到本区起点）。
 */
Renderer.prototype._drawDebuffs = function (player, now) {
  if (!player || !player.isAlive) return;
  const ctx = this.ctx;
  const size = 28;
  const gap = 4;
  const perRow = 6;
  const centerX = this.width / 2;
  const rowStartX = centerX - gap / 2 - size;   // 第 0 枚（紧贴中心左侧）
  const startY = 34 + (this._bossBarVisible ? 36 : 0);   // 下移避开战斗计时（top 10px）+ 战役 Boss 血条（top 42px~68px，2026-08-09）
  var x = rowStartX;
  var y = startY;
  var rowCount = 0;
  var self = this;
  var place = function (fn) {
    fn(x, y);                                   // 绘制（返回值忽略）
    x -= (size + gap);                          // ★向左生长（减益在中心左侧）
    rowCount++;
    if (rowCount >= perRow) { rowCount = 0; x = rowStartX; y += size + gap; }
  };

  // collect active debuffs left-to-right: [shatter, burn*]
  if (player.shattered && now < player.shatterEndTime) {
    place(function(cx, cy) {
      return self._drawDebuffIcon(ctx, cx, cy, size, now,
        player.shatterEndTime,
        '#CC3333', '#660000',
        function(cx2, cy2, r) {
          // cracked shield
          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.arc(cx2, cy2, r * 0.7, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#CC3333';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(cx2 - r * 0.5, cy2 - r * 0.5);
          ctx.lineTo(cx2, cy2);
          ctx.lineTo(cx2 + r * 0.4, cy2 + r * 0.6);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(cx2 + r * 0.1, cy2 - r * 0.3);
          ctx.lineTo(cx2 + r * 0.6, cy2 - r * 0.1);
          ctx.stroke();
        },
        '碎甲'
      );
    });
  }

  // burn stacks
  var burnStackCount = player.getBurnStackCount();
  for (var bi = 0; bi < burnStackCount; bi++) {
    (function(s) {
      place(function(cx, cy) {
        return self._drawDebuffIcon(ctx, cx, cy, size, now,
          s.endTime,
          '#CC3300', '#661100',
          function(cx2, cy2, r) {
            // 火焰轮廓：水滴底 + 左高右低两个不对称的火苗尖
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath();
            ctx.moveTo(cx2 - r * 0.70, cy2 + r * 0.50);
            ctx.quadraticCurveTo(cx2 - r * 1.10, cy2 + r * 0.10, cx2 - r * 0.35, cy2 - r * 1.00);
            ctx.quadraticCurveTo(cx2 - r * 0.15, cy2 - r * 0.95, cx2 + r * 0.05, cy2 - r * 0.30);
            ctx.quadraticCurveTo(cx2 + r * 0.25, cy2 - r * 0.85, cx2 + r * 0.55, cy2 - r * 0.50);
            ctx.quadraticCurveTo(cx2 + r * 1.00, cy2 + r * 0.20, cx2 + r * 0.60, cy2 + r * 0.50);
            ctx.quadraticCurveTo(cx2, cy2 + r * 0.75, cx2 - r * 0.70, cy2 + r * 0.50);
            ctx.closePath();
            ctx.fill();
          },
          '燃烧'
        );
      });
    })(player.burnStacks[bi]);
  }

  // flood state (single)
  if (player.floodState && now < player.floodState.endTime) {
    place(function(cx, cy) {
      return self._drawDebuffIcon(ctx, cx, cy, size, now,
        player.floodState.endTime,
        '#CC3333', '#660000',
        function(cx2, cy2, r) {
          // 三个水滴
          ctx.fillStyle = '#FFFFFF';
          var drops = [
            { dx: -r * 0.50, dy: 0 },
            { dx:  r * 0.00, dy: -r * 0.15 },
            { dx:  r * 0.50, dy: 0 },
          ];
          for (var di = 0; di < drops.length; di++) {
            var dcx = cx2 + drops[di].dx;
            var dcy = cy2 + drops[di].dy;
            ctx.beginPath();
            ctx.moveTo(dcx, dcy - r * 0.60);
            ctx.quadraticCurveTo(dcx + r * 0.45, dcy + r * 0.10, dcx + r * 0.20, dcy + r * 0.55);
            ctx.quadraticCurveTo(dcx, dcy + r * 0.65, dcx - r * 0.20, dcy + r * 0.55);
            ctx.quadraticCurveTo(dcx - r * 0.45, dcy + r * 0.10, dcx, dcy - r * 0.60);
            ctx.closePath();
            ctx.fill();
          }
        },
        '漏水'
      );
    });
  }

  // 配件损毁 + 武器损毁减益图标（2026-09-05 / 2026-09-13）：
  // 传本函数末尾的排布游标（x/y/rowCount），使配损/武损图标接在燃烧/漏水之后，避免重叠
  if (this._drawAccessoryDebuffs) this._drawAccessoryDebuffs(player, now, { x: x, y: y, rowCount: rowCount });
};

/* ── buff icons — 增益：屏幕中央上方**右侧**区（蓝底），与减益左右分居中心线两侧 ── */
Renderer.prototype._drawBuffs = function (player, now, buffs) {
  if (!player || !player.isAlive) return;
  if (!buffs || !buffs.length) return;
  const ctx = this.ctx;
  const size = 28;
  const gap = 4;
  const perRow = 6;
  const centerX = this.width / 2;
  const rowStartX = centerX + gap / 2;                  // 第 0 枚（紧贴中心右侧）
  const startY = 34 + (this._bossBarVisible ? 36 : 0);   // 下移避开战斗计时 + 战役 Boss 血条（2026-08-09）
  var x = rowStartX;
  var y = startY;
  var rowCount = 0;
  var self = this;
  var place = function (fn) {
    fn(x, y);                                   // 绘制（返回值忽略）
    x += (size + gap);                          // ★向右生长（增益在中心右侧）
    rowCount++;
    if (rowCount >= perRow) { rowCount = 0; x = rowStartX; y += size + gap; }
  };

  for (var bi = 0; bi < buffs.length; bi++) {
    (function(b) {
      if (now >= b.endTime) return;
      place(function(cx, cy) {
        return self._drawDebuffIcon(ctx, cx, cy, size, now,
          b.endTime,
          '#4488FF', '#88CCFF',
          function(cx2, cy2, r) {
            // 增益：向上的箭头
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath();
            ctx.moveTo(cx2, cy2 - r * 0.7);
            ctx.lineTo(cx2 - r * 0.55, cy2 + r * 0.05);
            ctx.lineTo(cx2 - r * 0.2, cy2 + r * 0.05);
            ctx.lineTo(cx2 - r * 0.2, cy2 + r * 0.65);
            ctx.lineTo(cx2 + r * 0.2, cy2 + r * 0.65);
            ctx.lineTo(cx2 + r * 0.2, cy2 + r * 0.05);
            ctx.lineTo(cx2 + r * 0.55, cy2 + r * 0.05);
            ctx.closePath();
            ctx.fill();
          },
          b.name,
          b.noTimer,
          b.layer,
          b.noDuration
        );
      });
    })(buffs[bi]);
  }
};

/**
 * Draw a single debuff icon at position (x, y). Advances x by size + gap.
 * @param {number} layer — 可选：层数（多层增减益时右上角显示，如防御矩阵 20 层盾，2026-08-06）
 * @param {boolean} noDuration — 可选：**无持续时间的增益**（条件性光环，每帧刷新）→ 不显示任何时间文本
 *   （noTimer 的 ∞ 也不画；2026-09-19 字人要求"无持续时间的增益不显示持续时间"）
 * @returns {number} new x position after the icon
 */
Renderer.prototype._drawDebuffIcon = function (ctx, x, y, size, now, endTime, fillColor, strokeColor, drawSymbol, tooltipText, noTimer, layer, noDuration) {
  // ⚠ 本函数会改 textBaseline('bottom'→'top'→'middle')/textAlign/font/fillStyle/strokeStyle/lineWidth，
  //   而 canvas 状态是**全局且跨帧**的。它由 _drawDebuffs / _drawBuffs / _drawAccessoryDebuffs
  //   在**舰船循环之后**调用（renderer.js L172/L206），残留值会跨帧渗到下一帧的
  //   _drawFloatingHP → 敌舰名字压血条（2026-10-03 截击俾斯麦战役复现）。
  //   → 整体 save/restore 封住。安全：save/restore 只回滚 ctx 状态，
  //     调用方的流式布局（_drawDebuffs 的 x/y 游标）和本函数的返回值 x+size+4 都是 JS 变量，不受影响。
  ctx.save();
  const remaining = Math.max(0, (endTime - now) / 1000).toFixed(1);

  ctx.fillStyle = fillColor;
  ctx.fillRect(x, y, size, size);
  ctx.strokeStyle = strokeColor;
  ctx.lineWidth = 1.5;
  ctx.strokeRect(x, y, size, size);

  const iconCx = x + size / 2;
  const iconCy = y + 11;
  const iconR = 7;
  drawSymbol(iconCx, iconCy, iconR);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 10px "Microsoft YaHei", Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  // 时间文本（2026-09-19）：noDuration = 无持续时间的增益 → 完全不画（既不是秒数也不是 ∞）
  if (!noDuration) ctx.fillText(noTimer ? '\u221E' : remaining + 's', x + size / 2, y + size - 2);

  // 多层增减益：右上角显示层数角标（2026-08-06）
  if (layer && layer > 1) {
    const layerTxt = String(layer);
    ctx.font = 'bold 11px "Microsoft YaHei", Arial, sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'top';
    // 深色底衬保证可读
    const tw = ctx.measureText(layerTxt).width;
    ctx.fillStyle = 'rgba(0,0,0,0.65)';
    ctx.fillRect(x + size - 2 - tw - 4, y + 1, tw + 4, 13);
    ctx.fillStyle = '#FFCC00';
    ctx.fillText(layerTxt, x + size - 2, y + 3);
  }

  // tooltip on hover
  if (this._mx != null && this._my != null &&
      this._mx >= x && this._mx <= x + size &&
      this._my >= y && this._my <= y + size) {
    ctx.font = 'bold 12px "Microsoft YaHei", Arial, sans-serif';
    // 自适应宽度：中文 6 字以上会溢出 48px（2026-08-09 字人报"增益名称显示为英文"）
    var tipW = Math.max(48, ctx.measureText(tooltipText).width + 12);
    const tipH = 20;
    const tipX = x + size / 2 - tipW / 2;
    const tipY = y + size + 6;
    ctx.fillStyle = 'rgba(0,0,0,0.75)';
    ctx.fillRect(tipX, tipY, tipW, tipH);
    ctx.fillStyle = '#FFCC00';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(tooltipText, tipX + tipW / 2, tipY + tipH / 2);
  }

  ctx.restore();   // ★ 必须在 return 之前（return 是 JS 值，不受 ctx 状态影响）
  return x + size + 4;
};

