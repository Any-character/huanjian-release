/**
 * version.js — 游戏版本号（单一来源）
 *
 * 发版时由 tools/release.py 自动改写本文件（不要手改，避免与 Release 不一致）。
 * Updater（js/systems/updater.js）读 GAME_VERSION 与线上最新版本比较。
 */
const GAME_VERSION = '0.2.11';
