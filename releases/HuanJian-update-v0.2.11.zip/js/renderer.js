/**
 * renderer.js — All Canvas rendering: game world, minimap, compass.
 *
 * Camera is always centred on the player (unless player is dead).
 * World→Screen transform:  sx = wx - camX + canvasW/2,  sy = wy - camY + canvasH/2
 */

class Renderer {
  /**
   * @param {HTMLCanvasElement} gameCanvas    — main game canvas
   * @param {HTMLCanvasElement} minimapCanvas — 200×200 minimap canvas
   * @param {HTMLCanvasElement} compassCanvas — 80×80 compass canvas
   */
  constructor(gameCanvas, minimapCanvas, compassCanvas) {
    this.canvas   = gameCanvas;
    this.ctx      = gameCanvas.getContext('2d');
    this.mmCanvas = minimapCanvas;
    this.mmCtx    = minimapCanvas.getContext('2d');
    this.cpCanvas = compassCanvas;
    this.cpCtx    = compassCanvas.getContext('2d');
    this.zoom     = ZOOM_LEVELS[DEFAULT_ZOOM_INDEX]; // default zoom

    this.camX = 0;
    this.camY = 0;

    // wake particles (ship + torpedo)
    this.wakeParticles = [];       // [{x, y, vx, vy, life, maxLife, radius}] in world coords (ship wake)
    this.torpedoParticles = [];    // same structure, for torpedo wake particles

    // fire particles (burn stacks on ships)
    this.fireParticles = [];       // [{x, y, vx, vy, life, maxLife, radius, type}]
                                   // type: 'flame' | 'smoke'

    // size the main canvas to fill the window
    this._resize();
    window.addEventListener('resize', () => this._resize());

    // 受击反馈状态（逻辑在 rendering/hit-feedback.js）
    this.initHitFeedback();
    // 开火震动已删除（2026-08-30 字人反馈）：fireRecoilOffX/Y + fireShockwave 字段与
    // triggerFireRecoil/updateFireRecoil 方法全部移除，历史实现见 commit cec72b7。
  }

  /** Resize main canvas to match window. */
  _resize() {
    this.canvas.width  = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  /** Update render zoom level. */
  setZoom(z) { this.zoom = z; }

  get width()  { return this.canvas.width; }
  get height() { return this.canvas.height; }

  /* ── camera ──────────────────────────────────────────────────────────── */

  /** Centre camera on (wx, wy). */
  setCamera(wx, wy) {
    this.camX = wx;
    this.camY = wy;
  }

  /**
   * Convert world → screen.
   * 含受击摇晃（shakeOffX/Y，纯平移；不旋转——见 constants.js 调参经验）。
   */
  worldToScreen(wx, wy) {
    return {
      x: (wx - this.camX) * this.zoom + this.width / 2 + (this.shakeOffX || 0),
      y: (wy - this.camY) * this.zoom + this.height / 2 + (this.shakeOffY || 0),
    };
  }

  /* ====================================================================== */
  /*  MAIN FRAME RENDER                                                     */
  /* ====================================================================== */

  /**
   * @param {PlayerShip} player
   * @param {EnemyShip}  enemy
   * @param {Array}      projectiles
   * @param {{x:number,y:number}|null} mouseWorld — cursor world pos for aim line
   * @param {Array}      [damagePopups]  — active floating "-XXX" popups
   * @param {{mainGun:{count:number,expireTime:number},
   *          torpedo:{count:number,expireTime:number}}} [hitStats]
   * @param {number}     [now]  — current timestamp (ms, e.g. Date.now()) used
   *                              for hit-stat expiration check
   */
  render(player, enemies, projectiles, mouseWorld, damagePopups, hitStats, now) {
    const ctx = this.ctx;
    const w = this.width;
    const h = this.height;
    damagePopups = damagePopups || [];
    hitStats = hitStats || null;
    now = now || 0;
    enemies = enemies || [];

    // 蓝方共享视野观察者（main.js 每帧设 this._allies；快速战斗 allies 空 = 仅玩家）
    var obs = [player].concat(this._allies || []);

    // ── 1. clear ────────────────────────────────────────────────────────
    ctx.clearRect(0, 0, w, h);

    // ── 2. sea background ───────────────────────────────────────────────
    this._drawSea(w, h, now);

    // ── 3. subtle grid ──────────────────────────────────────────────────
    this._drawGrid(w, h);

    // ── 4. map border (red) ─────────────────────────────────────────────
    this._drawMapBorder();

    // ── 4.5 main-gun range circle ────────────────────────────────────────
    if (player && player.isAlive) {
      this._drawRangeCircle(player);
    }

    // ── 4.5 ship wakes (under ships) ────────────────────────────────────
    for (var ei = 0; ei < enemies.length; ei++) {
      var e = enemies[ei];
      if (e && e.isAlive && (this._observeAll || Detection.canSeeShipByAny(obs, e) || (e.hasBuff && e.hasBuff('lit')))) this._drawShipWake(e);
    }
    if (player && player.isAlive) this._drawShipWake(player);

    // ── 4.6 wake particles (ship + torpedo) ──────────────────────────────
    this._drawWakeParticles();
    this._drawTorpedoParticles();

    // ── 4.7 燃烧火焰：**不能**画在这里（2026-11-08 修复）
    //   火焰生成点固定在舰体中轴（舰首/中/尾），画在舰船之前 = 全部被舰体盖住 → 看起来"燃烧没有特效"。
    //   现已挪到第 7.6 步（舰船之后），见本文件 _drawFireParticles 的调用点。

    // ── 5. projectiles (stealth-filtered) ───────────────────────────────
    for (const p of projectiles) {
      if (p.alive && (this._observeAll || Detection.canSeeProjectileByAny(obs, p))) this._drawProjectile(p);
    }

    // ── 6. enemies (detection-gated; 含友军——main.js 以 enemies.concat(allies) 传入) ──
    for (var ei2 = 0; ei2 < enemies.length; ei2++) {
      var e2 = enemies[ei2];
      if (e2 && e2.isAlive && (this._observeAll || Detection.canSeeShipByAny(obs, e2) || (e2.hasBuff && e2.hasBuff('lit')))) {
        this._drawShip(e2);
        this._drawFloatingHP(e2, player);
        // 辅助瞄准锁定标记（软锁定，2026-08-08）：黄色圆环提示已锁定
        if (this._aimLock === e2) this._drawAimLock(e2);
      }
    }

    // ── 7. player ───────────────────────────────────────────────────────
    if (player && player.isAlive) {
      this._drawShip(player);
    }

    // ── 7.5 hit firework particles (前景层：在舰船之上，2026-08-16 字人反馈"被舰船遮挡") ──
    this._drawHitFireworkParticles();
    // ── 7.6 持续燃烧火焰/浓烟（前景层，2026-11-08 修复）──
    //   与命中烟火同理：生成点在舰体中轴上，画在舰船之前会被舰体完全遮住（大舰尤其明显，
    //   字人报"威斯康星被燃烧没看到燃烧特效"）。所有船型统一受益。
    this._drawFireParticles();

    // ── 8. aim line ─────────────────────────────────────────────────────
    if (player && player.isAlive && mouseWorld) {
      this._drawAimLine(player, mouseWorld);
    }

    // ── 9. damage popups (top layer) ───────────────────────────────────
    this._drawDamagePopups(damagePopups);

    // ── 10. hit-stat pills (top-right HUD) ─────────────────────────────
    if (hitStats) {
      // 2026-08-06 修复：补传鱼雷/水雷规避胶囊（此前漏传 2 参 → 两胶囊永不显示）
      this._drawHitStats(hitStats.mainGun, hitStats.torpedo, hitStats.shatter, hitStats.burn, hitStats.flood, hitStats.mine, now, hitStats.ricochet, hitStats.torpedoRicochet, hitStats.mineRicochet, hitStats.accessory, hitStats.weaponDamage);
    }

    // ── 11. player debuff icons (top-centre) ────────────────────────────
    this._drawDebuffs(player, now);
    // 增益图标（中心左侧，蓝底）：舰船增益 buff（光环/技能/军魂，2026-08-09 修：原只画指挥官 buffs → 胡德/穿甲尖兵等光环不显示）
    // + 指挥官主动 buff（去重：同一 key 两处都有时只显示一次）
    // 增益图标收集（屏幕中央上方**右侧**区，2026-09-13 左右分区）
    // ⚠️ 排除走 buff 体系的**减益**（它们由减益图标区 _drawDebuffs / _drawAccessoryDebuffs 绘制）：
    //    配损（引擎/舵机/雷达损毁）、疲弱、畏惧光环、红场敌方减速、被点亮标记。
    //    此前未排除 → 同一状态被画两次（减益区红图标 + 增益区蓝图标），
    //    字人 2026-09-13 反馈「图标被覆盖」即此（左右分区后更明显：蓝底「引擎损毁」出现在增益区）。
    //    ★新增任何"走 buff 体系的减益"都要加进这个名单（AGENTS §5.26）
    var DEBUFF_BUFF_KEYS = {
      engineDamage: 1, rudderDamage: 1, radarDamage: 1,   // 配损（accessory-debuffs.js）
      weary: 1,        // 疲弱（水镜盾被打爆）
      fearAura: 1,     // 畏惧光环（华晟，作用于敌舰）
      redsquareEnemy: 1,  // 红场之魂对敌军减速
      lit: 1,          // 被点亮（标记型，不显示图标）
    };
    var buffIcons = [];
    var seenBuffs = {};
    if (player.buffs) {
      for (var bk in player.buffs) {
        var b = player.buffs[bk];
        if (!b || b.endTime <= now) continue;
        if (DEBUFF_BUFF_KEYS[bk]) continue;   // 减益不在增益区显示
        if (b.noIcon) continue;               // 纯机制 buff（noIcon）不显示图标（2026-09-19）
        buffIcons.push(b);
        seenBuffs[bk] = true;
      }
    }
    if (this.commander && this.commander.getBuffs) {
      var cb = this.commander.getBuffs();
      for (var ci = 0; ci < cb.length; ci++) {
        if (cb[ci] && !seenBuffs[cb[ci].key]) buffIcons.push(cb[ci]);
      }
    }
    this._drawBuffs(player, now, buffIcons);

    // ── 12. hit feedback: 受击摇晃 + 边缘泛红（覆盖整个世界）──────────
    this.drawHitVignette();
  }

  /* ── helpers ─────────────────────────────────────────────────────────── */

  _drawSea(w, h, time) {
    const ctx = this.ctx;
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#0D2B45');
    grad.addColorStop(0.5, '#123A5C');
    grad.addColorStop(1, '#0D2B45');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  }

  _drawGrid(w, h) {
    const ctx = this.ctx;
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 0.5;

    const gridSpacing = 100; // px in world space (1 km)
    const invZoom = 1 / this.zoom;

    // Find the first visible world-grid-line (visible world range is larger when zoomed out)
    const worldLeft = this.camX - (w * invZoom) / 2;
    const worldTop  = this.camY - (h * invZoom) / 2;
    const worldW    = w * invZoom;
    const worldH    = h * invZoom;

    const firstGridX = Math.ceil(worldLeft / gridSpacing) * gridSpacing;
    const firstGridY = Math.ceil(worldTop  / gridSpacing) * gridSpacing;

    // 端点经 worldToScreen：受击摇晃时网格一起平移（纯平移，不旋转）
    for (let wx = firstGridX; wx < worldLeft + worldW + gridSpacing; wx += gridSpacing) {
      const p0 = this.worldToScreen(wx, worldTop);
      const p1 = this.worldToScreen(wx, worldTop + worldH);
      ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.lineTo(p1.x, p1.y); ctx.stroke();
    }
    for (let wy = firstGridY; wy < worldTop + worldH + gridSpacing; wy += gridSpacing) {
      const p0 = this.worldToScreen(worldLeft, wy);
      const p1 = this.worldToScreen(worldLeft + worldW, wy);
      ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.lineTo(p1.x, p1.y); ctx.stroke();
    }
  }

  _drawMapBorder() {
    const tl = this.worldToScreen(0, 0);
    const br = this.worldToScreen(MAP_SIZE_PX, MAP_SIZE_PX);
    const ctx = this.ctx;
    ctx.strokeStyle = '#FF4444';
    ctx.lineWidth = 3;
    ctx.setLineDash([]);
    ctx.strokeRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);
  }

  /** Main-gun range circle (subtle, world-relative). */
  _drawRangeCircle(player) {
    const ctx = this.ctx;
    const center = this.worldToScreen(player.x, player.y);
    const radius = player.weaponCfg.mainGun.range * this.zoom;
    ctx.strokeStyle = 'rgba(255,255,255,0.10)';
    ctx.lineWidth = 1;
    ctx.setLineDash([8, 12]);
    ctx.beginPath();
    ctx.arc(center.x, center.y, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  /* ── aim line ───────────────────────────────────────────────────────── */

  /** 辅助瞄准锁定标记（2026-08-08）：黄色圆环套在锁定敌舰上 */
  _drawAimLock(ship) {
    const ctx = this.ctx;
    const p = this.worldToScreen(ship.x, ship.y);
    const r = (ship.width || 20) * 0.75 + 14;
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 215, 94, 0.95)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.stroke();
    // 四角短标记（游戏框选样式）
    for (var i = 0; i < 4; i++) {
      var a = Math.PI / 4 + i * Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(p.x + Math.cos(a - 0.35) * r, p.y + Math.sin(a - 0.35) * r);
      ctx.lineTo(p.x + Math.cos(a) * (r + 7), p.y + Math.sin(a) * (r + 7));
      ctx.lineTo(p.x + Math.cos(a + 0.35) * r, p.y + Math.sin(a + 0.35) * r);
      ctx.stroke();
    }
    ctx.restore();
  }

  _drawAimLine(player, mouseWorld) {
    const ctx = this.ctx;
    const p = this.worldToScreen(player.x, player.y);
    // 瞄准线方向 = aimHeading，距离使用光标到舰的距离
    const dx = mouseWorld.x - player.x;
    const dy = mouseWorld.y - player.y;
    const dist = Math.hypot(dx, dy);
    const aimX = player.x + Math.sin(player.aimHeading) * dist;
    const aimY = player.y - Math.cos(player.aimHeading) * dist;
    const m = this.worldToScreen(aimX, aimY);

    ctx.save();
    ctx.strokeStyle = 'rgba(144, 238, 144, 0.55)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([10, 6]);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(m.x, m.y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }


}
