/**
 * ship-status.js — Ship 状态/伤害 mixin
 *
 * 自 ship.js 拆分（2026-08-03）：受伤、燃烧、进水、碎甲。
 * 必须后于 ship.js 加载。
 */

  /**
   * Subtract HP, clamped to 0.
   * 护盾优先：有护盾时任何伤害先扣护盾（2026-08-05）。
   * @param {number} amount — 伤害值
   * @param {string} type   — 伤害类型：'gun'（主/副炮=火炮）| 'torp' | 'mine' | 'dot' | 'skill'（2026-08-06 杜尔曼）
   *   层盾（杜尔曼防御矩阵）仅免疫 'gun'；水镜盾被打爆/减600 仅火炮语境
   */
  Ship.prototype.takeDamage = function(amount, type) {
    // 无敌（华晟战神护盾破）：完全免疫（2026-08-06）
    if (this.hasBuff('invincible')) return 0;   // 返回 0（无伤害，2026-08-09 承伤含护盾改造）
    type = type || 'gun';
    var cm = this.commander;
    var dm = cm && cm.durman;
    // 层盾（杜尔曼防御矩阵 2026-08-06）：仅火炮伤害被每层免疫一次（扣层不扣血/盾）——优先于一切护盾
    if (type === 'gun' && dm && dm.layerShield > 0 && this.hasBuff('layerShield')) {
      dm.layerShield--;
      if (cm._applyLayerMods) cm._applyLayerMods(Date.now());
      return 0;
    }
    var absorbedTotal = 0;   // 护盾吸收合计（血池储入 X 的一部分，2026-08-09）
    // 限时护盾（红场之魂 2026-08-09）：剩余时间短的优先消耗；不影响普通护盾/血量
    if (this.timedShields && this.timedShields.length > 0 && amount > 0) {
      this.timedShields.sort(function(a, b) { return a.expireAt - b.expireAt; });
      while (amount > 0 && this.timedShields.length > 0) {
        var ts = this.timedShields[0];
        var absorb = Math.min(ts.amount, amount);
        ts.amount -= absorb;
        amount -= absorb;
        absorbedTotal += absorb;
        if (ts.amount <= 0) {
          this.timedShields.shift();
        } else {
          break;   // 当前这份未扣完，更晚到期的后面才扣
        }
      }
    }
    if (this.shield > 0) {
      const absorbed = Math.min(this.shield, amount);
      this.shield -= absorbed;
      amount -= absorbed;
      absorbedTotal += absorbed;
      // 战神护盾被打破（shield 从 >0 变 0 且战神模式中）→ 无敌 + 被点亮（2026-08-06）
      if (this.shield === 0 && cm && cm.isWarGod && cm.isWarGod()) {
        cm.onShieldBreak(Date.now());
      }
    }
    // 水镜盾（杜尔曼 2026-08-06）：普通护盾之后扣减；归零 → 爆炸（被打爆）
    if (amount > 0 && dm && dm.mirrorShield > 0) {
      const mAbs = Math.min(dm.mirrorShield, amount);
      dm.mirrorShield -= mAbs;
      amount -= mAbs;
      absorbedTotal += mAbs;
      if (dm.mirrorShield === 0 && cm && cm.onMirrorBurst) {
        cm.onMirrorBurst(true, Date.now());
      }
    }
    // 水镜盾被打爆后剩余技能时间：火炮伤害固定降低 600 点（钳 0）
    if (type === 'gun' && dm && dm.mirrorBurstBroken && Date.now() < dm.mirrorEnd) {
      amount = Math.max(0, amount - 600);
    }
    // 进攻转化·涅槃（杜尔曼 2026-08-06）：致死伤害免疫一次 + 回20% + 免费水镜盾 + 永久30%非武器伤害减免
    if (amount >= this.hp && this.hp > 0 && cm && cm.durman && cm._triggerTransform) {
      if (cm._triggerTransform(Date.now())) {
        amount = 0;   // 免疫此次伤害
      }
    }
    // 血池濒死保护（沙皇 2026-08-09）：池 ≥ 25% 且 致死伤害 → 免疫 + 无敌 + 清池回复
    if (amount >= this.hp && this.hp > 0 && this._bloodPool) {
      if (this._bloodPool.tryRevive(Date.now())) amount = 0;
    }
    // 威斯康星「威慑重击·濒死」（2026-11-08）：受到致死伤害 → 免疫并保留 1 血，每场限 1 次；
    //   触发后无敌 5s + [重击炮弹] 装填无冷却 10s（重击弹计时由 WisconsinHeavy.update 读 noCdUntil）
    if (amount >= this.hp && this.hp > 0 && this._wi && !this._wi.deathSaved) {
      this._wi.deathSaved = true;
      this._wi.noCdUntil = Date.now() + 10000;
      this.hp = 1;
      amount = 0;
      this.addBuff('invincible', '濒死无敌', Date.now() + 5000);
    }
    // 永久固定伤害减免 +30%（仅非武器伤害：燃烧/漏水/技能伤害，2026-08-06 进攻转化涅槃后）
    if (amount > 0 && (type === 'dot' || type === 'skill') && this.flatDamageReduce) {
      amount = Math.round(amount * Math.max(0, 1 - this.flatDamageReduce));
    }
    var hpBefore = this.hp;
    this.hp = Math.max(0, this.hp - amount);
    // 总伤害 = 护盾吸收 + 实际扣血（2026-08-09：承伤统计含护盾；血池 X 同源）
    var totalDmg = absorbedTotal + Math.max(0, hpBefore - this.hp);
    // 血条损伤条（P2-2 2026-08-16）：每帧被命中推一条白色短条，1s 内淡掉
    if (totalDmg > 0) {
      if (!this.damageTicks) this.damageTicks = [];
      this.damageTicks.push({ delta: totalDmg, expireAt: Date.now() + 1000 });
      // 上限防止长时间战斗堆积
      if (this.damageTicks.length > 10) this.damageTicks.splice(0, this.damageTicks.length - 10);
    }
    // 血池储入（沙皇 2026-08-09）：X = 护盾吸收 + 实际扣血；大伤害规则仅武器伤害（2026-08-09 字人更正）
    if (this._bloodPool) {
      var refundPct = this._bloodPool.onDamage(totalDmg, Date.now(), type === 'gun' || type === 'torp' || type === 'mine');
      if (refundPct > 0 && this.hp < this.maxHp) {
        this.gainHp(Math.max(0, hpBefore - this.hp) * refundPct);   // 统一回血入口（自带飘字日志）
      }
    }
    // 威斯康星「不屈」（2026-11-08）：每次受到主炮/鱼雷/水雷伤害 → 回复固定点数血量
    //   与伤害数值无关（字人 A6）；受维修效率加成；武器减伤已在公式里算完，这里只补血
    if (totalDmg > 0 && (type === 'gun' || type === 'torp' || type === 'mine')) {
      var uny = this.unyielding || 0;
      // 满血也照样调用：溢出的部分按理论值飘字（2026-11-08），否则"回了但看不见"更迷惑
      if (uny > 0 && this.hp > 0) {
        var repairMult = (this.getRepairMult && this.getRepairMult()) || 1;
        this.gainHp(uny * repairMult);
      }
    }
    return totalDmg;   // 调用方（collision）用于承伤/输出统计（含护盾吸收，2026-08-09）
  }

  /* ── 限时护盾（红场之魂 2026-08-09）：到期自动消失、受击时剩余时间短的优先 ── */

  /**
   * 加一份限时护盾（amount 值、expireAt 到期时间戳、source 来源标记）。
   * @param {string} [source] — 来源标记（如 'yanyinHunt'）；缺省 null（兼容既有调用）。
   *   阳炎「猎影」被动用 addTimedShield(500, Infinity, 'yanyinHunt') 记账，
   *   再用 getSourceShieldTotal('yanyinHunt') 做「此来源不超过最大血量 50%」的门槛。
   *   expireAt 支持 Infinity（无持续时间）——cleanupTimedShields 的 `expireAt <= now` 恒 false，不清。
   */
  Ship.prototype.addTimedShield = function(amount, expireAt, source) {
    if (!this.timedShields) this.timedShields = [];
    // ⚠️ 护盾一律取整（2026-11-08 字人要求：护盾要能自动取整，阳炎同款）：
    //   5% 最大血量这类比例护盾必然出小数（65268×5% = 3263.4）→ HUD 会出现 3263.4 的护盾条。
    //   取整放在**加盾入口**，所有来源（威斯康星重击 / 阳炎猎影 / 红场庇护）自动受益。
    var amt = Math.round(amount || 0);
    if (amt > 0) this.timedShields.push({ amount: amt, expireAt: expireAt || 0, source: source || null });
  };

  /**
   * 统一回血入口（2026-11-08 字人要求「玩家所有回血都要飘字」）。
   * 所有回血走这里 → 记进 `_healLog` → main.js 每帧 drain 出绿字。
   * 之前各系统各自 `this.hp = Math.min(...)`，谁忘了加飘字就永远没人发现（不屈/红场返还都漏过）。
   * @returns {number} 实际回复量（已取整；血量满时返回 0，不记录）
   */
  Ship.prototype.gainHp = function(amount) {
    var amt = Math.round(amount || 0);
    if (amt <= 0 || !this.isAlive) return 0;
    var before = this.hp;
    this.hp = Math.min(this.maxHp, this.hp + amt);
    var healed = Math.round(this.hp - before);
    // 2026-11-08 字人要求：**溢出也按理论回复量飘字**。
    //   display = 本次治疗的理论值（含溢出部分），amount = 实际回血（战绩统计用）。
    //   所以即使 healed === 0（满血时触发回血）也要记一条 → 玩家能看到"这次回了多少但浪费了"。
    if (!this._healLog) this._healLog = [];
    this._healLog.push({ display: amt, amount: healed });
    return healed;
  };

  /** 清理到期限时护盾（只减限时部分，不影响普通护盾），返回当前限时盾总量 */
  Ship.prototype.cleanupTimedShields = function(now) {
    if (!this.timedShields || this.timedShields.length === 0) return 0;
    now = now != null ? now : Date.now();
    var total = 0;
    for (var i = this.timedShields.length - 1; i >= 0; i--) {
      if (this.timedShields[i].expireAt <= now) {
        this.timedShields.splice(i, 1);   // 到期消失（仅限时部分）
      } else {
        total += this.timedShields[i].amount;
      }
    }
    return total;
  };

  /** 当前限时盾总量（不清理） */
  Ship.prototype.getTimedShieldTotal = function() {
    if (!this.timedShields) return 0;
    var t = 0;
    for (var i = 0; i < this.timedShields.length; i++) t += this.timedShields[i].amount;
    return t;
  };

  /**
   * 按来源求和限时护盾（不清理）。阳炎「猎影」门槛：`getSourceShieldTotal('yanyinHunt') < maxHp * 0.5`。
   * @param {string|null} source — 来源标记；null 匹配 addTimedShield 未传第 3 参（缺省 null）的项。
   * @param {number} [now] — 未用（保留签名，方便未来加过期过滤），当前只按 source 求和。
   */
  Ship.prototype.getSourceShieldTotal = function(source, now) {
    if (!this.timedShields) return 0;
    var t = 0;
    for (var i = 0; i < this.timedShields.length; i++) {
      if (this.timedShields[i].source === source) t += this.timedShields[i].amount;
    }
    return t;
  };

  /* ── 增益/减益系统（2026-08-06，字人要求统一存储/聚合/过期） ────────── */
  // buff 结构：this.buffs = { key: { name, endTime, mods: { modKey: value } } }
  // mods 约定三类：
  //   乘法型   shellSpeedMul: 0.9      （弹丸速度 ×0.9）
  //   数值型   shotAccuracyPen: 0.1    （射击精度 -0.1，百分比点）
  //            critDmgPen: 0.2         （暴击伤害 -0.2）
  //   标记型   visibleToBlue: true     （"被点亮"：我方全体可见）

  /**
   * 施加/刷新 buff（同 key 覆盖 endTime + mods）
   * @param {number} [layer] — 图标层数角标（右上角 ×N；2026-09-19 新增，如「锁定」多层标记）。
   *   缺省 1（不显示角标）。也可通过 mods.layer 传入。
   */
Ship.prototype.addBuff = function(key, name, endTime, mods, layer) {
    mods = mods || {};
    // 常驻 buff（endTime=Infinity）自动 noTimer → 图标 ∞（2026-08-09 修：漏设显示 "Infinitys"）
    // noIcon（2026-09-19）：纯机制 buff（如炮火风暴主动内部状态）不参与增益图标渲染 —— renderer 跳过
    // noDuration（2026-09-19 字人要求）：**无持续时间的增益不显示持续时间**——条件性光环（每帧刷新、
    //   出圈即消失，如舰船技能光环 / 国度的雄心扇形增益 / 红场庇护）不显示任何时间文本（连「∞」也不显示）
    this.buffs[key] = {
      name: name || key,
      endTime: endTime || 0,
      mods: mods,
      noTimer: endTime === Infinity || !!mods.noTimer,
      noIcon: !!mods.noIcon,
      noDuration: !!mods.noDuration,
      layer: layer != null ? layer : (mods.layer != null ? mods.layer : 1),
    };
  }

  /** 手动移除 buff */
Ship.prototype.removeBuff = function(key) {
    delete this.buffs[key];
  }

  /** 是否激活中（未过期）。now 缺省用 Date.now()（测试可传固定值） */
Ship.prototype.hasBuff = function(key, now) {
    var b = this.buffs[key];
    return !!b && b.endTime > (now !== undefined ? now : Date.now());
  }

  /** 聚合所有激活 buff 的指定 mod（求和）。now 缺省 Date.now() */
Ship.prototype.getBuffMod = function(modKey, now) {
    now = now !== undefined ? now : Date.now();
    var sum = 0;
    for (var k in this.buffs) {
      var b = this.buffs[k];
      if (b.endTime > now && b.mods && b.mods[modKey] !== undefined) sum += b.mods[modKey];
    }
    return sum;
  }

  /** 清理过期 buff（每帧调用） */
Ship.prototype.cleanBuffs = function(now) {
    now = now !== undefined ? now : Date.now();
    for (var k in this.buffs) {
      if (this.buffs[k].endTime <= now) delete this.buffs[k];
    }
  }

Object.defineProperty(Ship.prototype, 'isAlive', {
    get: function() { return this.hp > 0; },
    configurable: true,
  });

Object.defineProperty(Ship.prototype, 'speed', {
    get: function() { return this.currentSpeed; },
    configurable: true,
  });

Object.defineProperty(Ship.prototype, 'gearName', {
    get: function() { return this.speedGears[this.gearIndex].name; },
    configurable: true,
  });

Object.defineProperty(Ship.prototype, 'isFlooded', {
    get: function() { return this.floodState !== null; },
    configurable: true,
  });

  /** @returns {number} 当前燃烧层数 */
Ship.prototype.getBurnStackCount = function() {
    return this.burnStacks.length;
  }

  /** @returns {boolean} 是否已达到最大层数 */
Ship.prototype.isBurnFull = function() {
    return this.burnStacks.length >= BURN_MAX_STACKS;
  }

  /** 获取当前已占用的舰上火效位置索引 (0=舰首, 1=舰中, 2=舰尾) */
Ship.prototype._getUsedFirePositions = function() {
    var used = [];
    for (var i = 0; i < this.burnStacks.length; i++) {
      used.push(this.burnStacks[i].firePos);
    }
    return used;
  }

  /**
   * 施加一层燃烧。
   * @param {number} damagePerTick — 每跳伤害
   * @param {number} tickInterval  — 跳伤间隔 秒
   * @param {number} duration      — 持续时间 秒
   * @param {number} now           — Date.now()
   */
Ship.prototype.applyBurn = function(damagePerTick, tickInterval, duration, now, attacker) {
    if (this.isBurnFull()) return;
    // 选取未被占用的火效位置
    var used = this._getUsedFirePositions();
    var available = [];
    for (var pi = 0; pi < 3; pi++) {
      if (used.indexOf(pi) === -1) available.push(pi);
    }
    if (available.length === 0) return;
    var firePos = available[Math.floor(Math.random() * available.length)];
    this.burnStacks.push({
      endTime: now + duration * 1000,
      nextTickTime: now + tickInterval * 1000,
      damagePerTick: damagePerTick,
      tickInterval: tickInterval,
      firePos: firePos,
      attacker: attacker || null,
    });
  }

  /**
   * 施加漏水（至多一层，满后不可再触发）。
   * @param {number} damagePerTick — 每跳伤害
   * @param {number} tickInterval  — 跳伤间隔 秒
   * @param {number} duration      — 持续时间 秒
   * @param {number} now           — Date.now()
   * @returns {boolean} true=成功施加, false=已在漏水状态
   */
Ship.prototype.applyFlood = function(damagePerTick, tickInterval, duration, now, attacker) {
    if (this.floodState) return false;
    this.floodState = {
      endTime: now + duration * 1000,
      nextTickTime: now + tickInterval * 1000,
      damagePerTick: damagePerTick,
      tickInterval: tickInterval,
      attacker: attacker || null,
    };
    return true;
  }

  /**
   * 施加配件损毁（2026-09-05）：引擎/舵机/雷达损毁之一，持续 10s，走增减益系统（buff 自动过期）。
   * 三种可并存，各自独立计时/图标。已拥有的类型不刷新时间（触发逻辑保证不重复选已有）。
   * @param {'engineDamage'|'rudderDamage'|'radarDamage'} key — 配损类型
   * @param {number} [now]
   * @returns {boolean} true=成功施加
   */
Ship.prototype.applyAccessoryDamage = function(key, now) {
    var MODS = {
      engineDamage: { noTurn: 1, noGear: 1 },   // 引擎损毁：不可转向 + 档位归零
      rudderDamage: { noTurn: 1 },              // 舵机损毁：不可转向
      radarDamage:  { radarOff: 1 },            // 雷达损毁：探测归零
    };
    var NAMES = { engineDamage: '引擎损毁', rudderDamage: '舵机损毁', radarDamage: '雷达损毁' };
    var mods = MODS[key];
    if (!mods) return false;
    this.addBuff(key, NAMES[key] || key, (now != null ? now : Date.now()) + 10000, mods);
    return true;
  }

  /**
   * **百分比扣血基数 —— 唯一入口**（2026-09-19 字人规范，AGENTS §5.30）。
   * 凡"按最大血量百分比"的伤害/效果（燃烧、漏水、以及以后新增的百分比扣血技能），
   * 基数由战役环境决定，**禁止各处自行选择基数**：
   *   非战役                        → 被作用者**自身**的 maxHp（烧敌舰按敌舰血量扣）
   *   战役（含自定义战斗「视同战役」） → **玩家舰** maxHp（战役敌舰血量高，读自身会破坏平衡）
   * @param {number} [playerMaxHp] — 玩家舰最大血量（调用链已带，缺省时退回自身）
   * @returns {number} 用于百分比计算的 maxHp 基数
   */
Ship.prototype.getPercentDamageBase = function(playerMaxHp) {
    if (typeof BattleRules !== 'undefined' && BattleRules.isCampaign) {
      return playerMaxHp != null ? playerMaxHp : this.maxHp;
    }
    return this.maxHp;
  }

  /**
   * **回血加成乘子 —— 唯一入口**（2026-10-01，仿 §5.30 getPercentDamageBase 模式）。
   * 凡"给本舰回血"的效果（指挥官技能 _healPlayer、血池回复 _startRecover、
   * 以及以后新增的一切回血来源），实际回血量 = 基础回血量 × 本函数返回值。
   * 禁止各处自行读取 repairEff。乘子 = 1 + 维修效率（基础值 + buff 加成 repairEffAdd，自动相加）。
   * @returns {number} 回血乘子（≥1）
   */
  Ship.prototype.getRepairMult = function() {
  var eff = (this.repairEff || 0);
  if (this.getBuffMod) eff += this.getBuffMod('repairEffAdd');
  return 1 + eff;
}

  /**
   * 处理漏水跳伤，返回本帧需要造成的伤害事件。
   * @param {number} now — Date.now()
   * @returns {Array<{damage:number}>}
   */
Ship.prototype.updateFlood = function(now) {
    if (!this.floodState) return [];
    var events = [];
    var s = this.floodState;
    while (now >= s.nextTickTime) {
      var dmg = s.damagePerTick;
      this.takeDamage(dmg, 'dot');  // dot（燃烧/漏水跳伤），非火炮不触发层盾/减600
      events.push({ damage: dmg, attacker: s.attacker });
      s.nextTickTime += s.tickInterval * 1000;
      if (s.nextTickTime >= s.endTime) break;
    }
    if (now >= s.endTime) {
      this.floodState = null;
    }
    return events;
  }

  /**
   * 处理燃烧跳伤，返回本帧需要造成的伤害事件。
   * @param {number} now — Date.now()
   * @returns {Array<{damage:number}>}
   */
Ship.prototype.updateBurn = function(now) {
    var events = [];
    for (var i = this.burnStacks.length - 1; i >= 0; i--) {
      var s = this.burnStacks[i];
      // 跳伤（先处理，确保终点时刻的最后一跳）
      while (now >= s.nextTickTime) {
        var dmg = s.damagePerTick;
        this.takeDamage(dmg, 'dot');  // dot（燃烧/漏水跳伤），非火炮不触发层盾/减600
        events.push({ damage: dmg, attacker: s.attacker });
        s.nextTickTime += s.tickInterval * 1000;
        if (s.nextTickTime >= s.endTime) break;
      }
      // 过期移除（后检查，给最后一跳机会）
      if (now >= s.endTime) {
        this.burnStacks.splice(i, 1);
      }
    }
    return events;
  }

