/**
 * ship-class-skills.js — 舰种技能数据（2026-10-03）
 *
 * ⚠️ 本文件是「舰种技能」（整个舰种共有，玩家在选船界面选一系/二系）；与「战舰技能」
 *    （js/systems/ship-skills.js，单艘船独有）的区分见 `docs/glossary.md`。
 *
 * 数据结构（设计文档 §3）：
 *   CLASS_SKILLS[shipType] = { label, paths: [ { id, name, enabled, skills: [...] } ] }
 *   单条技能 = { id, name, type:'passive'|'active', ready:boolean, effects:[{stat,value}], desc }
 *   - ready:false = 未开放（弹窗显示「敬请期待」），**不产生任何战斗效果**
 *   - effects 按 stat 分通道：百分比通道与固定值通道**独立**（设计文档 §3.1）
 *
 * ── 单位约定（⚠️ 已逐条核对消费端代码，改数值前先看这里）────────────────────
 *   torpedoSpeedPct            小数（0.05 = +5%）
 *   torpedoSpeedAdd            节（固定值；不做 ×0.057 换算，鱼雷 speed 本就以节计）
 *   torpedoReloadPct           小数（0.10 = 冷却 -10%，**加进** getWeaponReloadSec 的 pct 池）
 *   mineReloadPct             同上（水雷）
 *   reloadFlatReduce_torpedo  秒（固定减，与 reloadPctReduce 类不同量纲）
 *   reloadFlatReduce_mine     秒
 *   floodChance               小数（0.05 = +5%，collision.js 与 resistFloodChance 相减）
 *   floodPower                小数（0.15 = +15%，collision.js `1 + floodPower - resist`）
 *   floodDuration             小数（0.60 = +60%；collision.js `FLOOD_DURATION × (1 + 和)`，
 *                             多来源**先求和再乘一次**，故 0.6+0.6 = ×2.2 而非 ×1.6×1.6）
 *   detonationRadius          **km**（ship.js 存 km；weapon-config.js 开火时才 ×PX_PER_KM）
 *   explosionRadius           **km**（同上）
 *   lifetimeSec               **秒**（SeaMine.lifeLeft = lifetimeSec，直接秒）
 *   maxSpeed                  **节**（= px/s；改后必须 _rebuildSpeedGears 重建档位）
 *   rotationSpeed             **度/秒**（⚠️ 存储层是「度」，应用到 ship 实例时 ×π/180 转弧度
 *                             —— 与 TERM_OVERRIDES 的 `rad:true` 同惯例，见 systems/term-overrides.js:27）
 */

const CLASS_SKILLS = Object.freeze({
  destroyer: {
    label: '驱逐舰',
    paths: [
      {
        id: 'assault',
        name: '突击',
        enabled: true,          // 一系默认启用
        skills: [
          {
            id: 'assault-torpedo-improve',
            name: '鱼雷改进',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'torpedoSpeedPct', value: 0.05 },
              { stat: 'torpedoSpeedAdd', value: 5 },
            ],
            desc: '鱼雷航速+5%，鱼雷航速+5节',
          },
          {
            id: 'assault-torpedo-service',
            name: '鱼雷整备',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'torpedoReloadPct', value: 0.10 },
              { stat: 'reloadFlatReduce_torpedo', value: 1 },
            ],
            desc: '鱼雷冷却-10%，鱼雷冷却-1秒',
          },
          {
            id: 'assault-horsepower-1',
            name: '马力全开Ⅰ',
            type: 'active',
            ready: false,          // ⏸ 敬请期待（本轮不实现，无 effects）
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'assault-armor-pierce',
            name: '装甲击穿',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'floodChance', value: 0.05 },
              { stat: 'floodDuration', value: 0.60 },
            ],
            desc: '鱼雷漏水几率+5%，漏水延长+60%',
          },
          {
            id: 'assault-battleship-cover',
            name: '战舰遮蔽',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'assault-precision-lock',
            name: '精准锁定',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'floodPower', value: 0.15 },
            ],
            desc: '漏水程度+15%',
          },
          {
            id: 'assault-pure-oxygen',
            name: '纯氧助燃',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
        ],
      },
      {
        id: 'blockade',
        name: '封锁',
        enabled: false,         // 二系默认未启用（UI 里点此切换）
        skills: [
          {
            id: 'blockade-mine-enhance',
            name: '水雷强化',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'detonationRadius', value: 0.255 },   // km
              { stat: 'explosionRadius', value: 1.25 },     // km
            ],
            desc: '水雷引爆半径+0.255km，水雷爆炸半径+1.25km',
          },
          {
            id: 'blockade-power-boost',
            name: '动力强化',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'maxSpeed', value: 2.5 },             // 节
              { stat: 'rotationSpeed', value: 2 },          // 度/秒（应用时转弧度）
            ],
            desc: '最大航速+2.5节，转向转速+2度每秒',
          },
          {
            id: 'blockade-horsepower-2',
            name: '马力全开Ⅱ',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'blockade-mine-service',
            name: '水雷整备',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'mineReloadPct', value: 0.10 },
              { stat: 'reloadFlatReduce_mine', value: 1 },
            ],
            desc: '水雷冷却-10%，水雷冷却-1秒',
          },
          {
            id: 'blockade-recon-mine',
            name: '侦察水雷',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'blockade-mine-improve',
            name: '水雷改进',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'lifetimeSec', value: 60 },           // 秒
            ],
            desc: '水雷存在时间+60秒',
          },
          {
            id: 'blockade-chain-mine',
            name: '连锁水雷',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
        ],
      },
    ],
  },
  cruiser:   { label: '巡洋舰', paths: [] },   // 空壳 → UI 显示「敬请期待」（查询不得抛异常）
  battleship: { label: '战列舰', paths: [] },
});
