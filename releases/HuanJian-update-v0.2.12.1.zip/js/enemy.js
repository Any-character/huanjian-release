/**
 * enemy.js — EnemyShip subclass with simple tracking AI.
 *
 * Behaviour:
 *   1. Rotate toward player at max rotationSpeed.
 *   2. Always stay at 全速 (gear 3).
 *   3. When within engagementRange → fire main guns & torpedoes via mount system
 *      （每炮独立冷却，2026-08-08 人机武器改革；无射界限制 arcKey='all'）。
 */

class EnemyShip extends Ship {
  constructor(x, y) {
    super(ENEMY_CONFIG, x, y, 0, false, 'enemy');

    // ── 挂载人机武器（2026-08-08：巡-人机A 主炮 + 巡洋鱼雷兜底）──
    const mgW = getEnemyDefaultWeapon('mainGun', 'cruiser');
    const tpW = getEnemyDefaultWeapon('torpedo', 'cruiser');
    for (var i = 0; i < this.mainGunMounts.length; i++) {
      this.mainGunMounts[i].weaponId = mgW ? mgW.id : null;
    }
    for (var t = 0; t < this.torpedoMounts.length; t++) {
      this.torpedoMounts[t].weaponId = tpW ? tpW.id : null;
    }
  }

  /* ── per-frame update ────────────────────────────────────────────────── */

  /**
   * @param {number}       dt           — delta-time (seconds)
   * @param {PlayerShip}   player       — reference to player
   * @param {Array}        projectiles  — shared projectiles array (push into)
   * @param {number}       now          — Date.now()
   * @param {Array}        [teamShips]  — 己方阵营船数组（红方共享；缺省 [this]）；玩家须被己方探测到才开火
   */
  update(dt, player, projectiles, now, teamShips) {
    if (!this.isAlive || !player || !player.isAlive) return;

    // ── rudder toward player ────────────────────────────────────────────
    const dx = player.x - this.x;
    const dy = player.y - this.y;
    const targetAngle = Math.atan2(dx, -dy); // 0 = north
    let diff = targetAngle - this.heading;
    while (diff >  Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;
    this.rudderInput = Math.sign(diff); // -1, 0, or 1

    // ── always full speed ───────────────────────────────────────────────
    this.gearIndex = 3; // 全速

    // ── smoothing ────────────────────────────────────────────────────────
    this.smoothSpeed(dt);
    this.smoothTurn(dt);

    // ── move & clamp ────────────────────────────────────────────────────
    this.move(dt);
    this.clampToMap();

    // ── attack if in range（mount 系统内部每炮独立冷却；2026-08-08 取消随机间隔）──
    const dist = Math.hypot(dx, dy);
    // 探测限制：玩家必须被己方阵营共享水上探测到才开火（寻路不受影响）
    if (dist <= ENEMY_CONFIG.engagementRange && Detection.canSeeShipByAny(teamShips || [this], player)) {
      // main gun（提前量预判 2026-08-06：读玩家航速含倒车/航向，直线假定，迭代 2 次）
      //   2026-10-25：弹速从**武器库**取（getMainGunShellSpeedPx，与真实开火同一口径）。
      //   原来读 ship.weaponCfg.mainGun.shellSpeed —— 那是船里手抄的重复数字，
      //   武器库改炮速后不会跟着变 → AI 按旧弹速算提前量，越改越打不准。
      const apMg = aimAhead(player, this.x, this.y, this.getMainGunShellSpeedPx());
      const shells = this.fireMainGun(apMg.x, apMg.y, now);
      if (shells.length > 0) {
        projectiles.push(...shells);
        // 敌方开火震动已删（2026-08-30 字人反馈；历史实现见 commit cec72b7）
      }

      // torpedoes（慢速，提前量更大）
      const apTp = aimAhead(player, this.x, this.y, this.getTorpedoSpeedKn());
      const torps = this.fireTorpedo(apTp.x, apTp.y, now);
      if (torps.length > 0) projectiles.push(...torps);
    }
  }
}
