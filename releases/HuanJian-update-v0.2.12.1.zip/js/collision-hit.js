/**
 * collision-hit.js — 命中伤害公式（Collision 静态方法扩展，2026-08-09 自 collision.js 拆出）
 *
 * _computeHitDamage：三处命中（主炮/鱼雷/水雷）公共的伤害公式（暴击/穿甲/碎甲/处决/对冲减伤）。
 *
 * ⚠️ 改动前必读（AGENTS.md §0 索引 / §5.28 武器真伤 / 公式库 js/data/formulas.js）：
 *   - 本文件是伤害公式的**唯一出口**，改公式必须同步刷新 formulas.js 的公式说明（词条 desc 亦对应）
 *   - 末尾加法段（战神附加 / 武器真伤）均为「不吃减伤」语义；真伤基数 = proj.panelDamage（武器总面板），
 *     **不是** proj.damage（单管）；抵抗对冲写法 = max(0, 敌方真伤 − 目标 resistTrueDmg)
 */

  /**
   * 配件损毁触发（2026-09-05）：主炮（非副炮）/鱼雷/水雷命中可能触发配损。
   * 触发率 = max(0, 配损几率 − 抵抗配损)；随机一个当前未拥有的配损；三种全有 → 不触发（不刷新已有）。
   * @param {Object} proj  — 弹丸（accessoryChance / isSecondary）
   * @param {Ship}   target
   * @param {number} now
   * @returns {string|null} 触发的配损类型（engineDamage/rudderDamage/radarDamage）或 null
   */
  Collision._tryApplyAccessoryDamage = function(proj, target, now) {
    if (proj.isSecondary) return null;   // 副炮不触发配损
    var chance = Math.max(0, (proj.accessoryChance || 0) - (target.resistAccessoryChance || 0));  // 抵抗配损（对冲）
    if (Math.random() >= chance) return null;
    var candidates = [];
    if (!target.hasBuff('engineDamage', now)) candidates.push('engineDamage');
    if (!target.hasBuff('rudderDamage', now)) candidates.push('rudderDamage');
    if (!target.hasBuff('radarDamage', now))  candidates.push('radarDamage');
    if (candidates.length === 0) return null;   // 三损全有 → 不触发
    var pick = candidates[Math.floor(Math.random() * candidates.length)];
    if (target.applyAccessoryDamage) target.applyAccessoryDamage(pick, now);
    return pick;
  };

  /**
   * 武器损毁（武损）触发（2026-09-13 字人需求）：主炮（非副炮）/鱼雷/水雷命中可能触发武损。
   * 触发率 = max(0, 武损几率 − 抵抗武损)；在**未被损毁**的武器中随机一个（含副炮）；
   * 全部武器已损毁 → 不触发（applyWeaponDamage 返回 null）。
   * @param {Object} proj  — 弹丸（weaponDamageChance / isSecondary）
   * @param {Ship}   target
   * @param {number} now
   * @returns {{type:string,index:number}|null} 被损毁武器（type/index）或 null
   */
  Collision._tryApplyWeaponDamage = function(proj, target, now) {
    if (proj.isSecondary) return null;   // 副炮不触发武损
    var chance = Math.max(0, (proj.weaponDamageChance || 0) - (target.resistWeaponDamageChance || 0));  // 抵抗武损（对冲）
    if (Math.random() >= chance) return null;
    if (!target.applyWeaponDamage) return null;
    return target.applyWeaponDamage(now);   // 全部武器已损毁 → 返回 null（本次不触发）
  };

  /**
   * 伤害公式公共段（主炮/鱼雷/水雷三处命中复用，2026-08-07 去重）。
   * 语义与拆分前逐行一致：①武器伤害 ②装甲(可穿甲) ③暴击 ④穿甲伤害 ⑤收割 ⑥最终增伤
   * ⑦其它加成 ⑧武器减伤(字段由 opts 传) ⑨最终减伤 ⑩浮动+真伤+变1 + 碎甲。
   * @param {Object} proj, target
   * @param {number} now, playerMaxHp
   * @param {Object} opts — { enablePen: bool(仅主炮), reduceKey: 目标减伤字段名, penKey: 弹丸穿透字段名 }
   * @returns {{finalDamage:number, isCrit:boolean, isExecute:boolean, isPen:boolean, isShatter:boolean}}
   */
Collision._computeHitDamage = function(proj, target, now, playerMaxHp, opts) {
    var variance = this._noDamageVariance ? 1 : (1 + (Math.random() - 0.5) * 2 * DAMAGE_VARIANCE);
    var finalDamage = proj.damage;   // 单管面板伤害

    // ① 武器伤害加成/减少（2026-08-06 改：直接相减类似逆属性——武器伤害-x% 与武器伤害+y% 抵消成净加成，非独立乘区；疲弱/防御矩阵光环走 weaponDmgPen）
    //   「受到武器伤害」（target.takeWeaponDmgAdd，2026-11-08 威斯康星不动堡垒 -90%）与上两项**同类相加**
    finalDamage *= Math.max(0, 1 + (proj.flatDmgPct || 0) - (proj.weaponDmgPen || 0) + (target.takeWeaponDmgAdd || 0));

    // ② 装甲减伤（无视装甲；碎甲状态已体现于 target.armor 降低）；仅主炮可穿甲
    var isPen = false;
    var effectiveArmor = target.armor + (target.getBuffMod ? target.getBuffMod('armorAdd') : 0);  // 学有所成：装甲强化 buff
    if (opts.enablePen && Math.random() < Math.max(0, (proj.penetrationChance || 0) - (target.resistPenetration || 0) - (target.getBuffMod ? target.getBuffMod('resistPenetrationAdd') : 0))) {  // 抵抗穿甲（对冲 + 光环 buff，2026-09-19）
      effectiveArmor = Math.round(target.armor * 0.8);  // 穿甲：无视20%装甲
      isPen = true;
      // 学有所成（杜尔曼）：被打出穿甲 → 10s 全口径规避+5%（60s 冷却）
      if (target.commander && target.commander.tryLearnTrigger) target.commander.tryLearnTrigger(target, 'pen', now);
    }
    finalDamage *= Armor.getMultiplier(Math.max(0, effectiveArmor - (proj.ignoreArmor || 0)));  // 无视装甲（对冲装甲强度，有效装甲下限 0）

    // ②b A-140A「国度的雄心」锁定加成（2026-09-19）：副炮命中**被锁定**敌舰 → 暴击几率 +1%×锁定层数
    var _ambitionL = (proj.isSecondary && proj.owner && proj.owner.getLockLayersOn)
      ? (proj.owner.getLockLayersOn(target) || 0) : 0;

    // ③ 暴击（考虑抵抗暴击 + 无邪气场豁免）
    //   「免疫暴击」（buff immuneCrit，2026-11-08 威斯康星不动堡垒）：**完全免疫**，直接不进暴击分支。
    //   ⚠️ 与「抵抗暴击」不同：抵抗是减法，敌方暴击几率可能 >100%（冗余暴击几率对冲抵抗），免疫才是绝对。
    var isCrit = false;
    var _critImmune = !!(target.getBuffMod && target.getBuffMod('immuneCrit') > 0);
    // 致命弹（2026-11-15 战列舰「毁灭」）：必定暴击 —— 无视免疫暴击 / 抵抗暴击，强制进暴击分支；
    //   暴击伤害仍吃目标「减免暴击伤害」（与碎甲弹吃「抵抗碎甲程度」同口径：只保证触发，不保证数值）。
    var _forceCrit = !!proj.isFatalShell;
    if (_forceCrit || (!_critImmune && Math.random() < Math.max(0, (proj.critChance != null ? proj.critChance : CRIT_CHANCE) - (target.resistCritChance || 0) - (target.getBuffMod ? target.getBuffMod('resistCritChanceAdd') : 0) + 0.01 * _ambitionL))) {   // 抵抗暴击（光环 buff，2026-09-19）
      var reduceCrit = (target.reduceCritDmg || 0) + (target.getBuffMod ? target.getBuffMod('reduceCritDmgAdd') : 0);  // 沙皇血池暴击伤害减免（2026-08-09）
      var critMult = 2 * Math.max(0, 1 + (proj.critDmg || 0) - reduceCrit);  // 基础×2.0 × (1+暴击伤害加成−目标减免暴击伤害)
      if (!_forceCrit && Math.random() < (target.negateCritChance || 0)) {
        // 无邪气场（华晟被动 2026-08-06）：被普通暴击有概率不触发（取消暴击，不乘暴击倍率）
      } else {
        finalDamage *= critMult;
        isCrit = true;
        // 学有所成（杜尔曼）：被打出暴击 → 10s 装甲+500（60s 冷却）
        if (target.commander && target.commander.tryLearnTrigger) target.commander.tryLearnTrigger(target, 'crit', now);
      }
    }

    // ④ 穿甲伤害加成（穿甲触发时；目标减免穿甲伤害）
    //   「受到穿甲伤害」（target.takePenDmgAdd，2026-11-08 威斯康星不动堡垒 +100%）与攻击方穿甲伤害**同类相加**；
    //   敌方未触发穿甲（isPen=false）时整段不生效。
    var _takePen = target.takePenDmgAdd || 0;
    if (isPen && ((proj.penDmg || 0) > 0 || _takePen > 0)) {
      var reducePen = (target.reducePenDmg || 0) + (target.getBuffMod ? target.getBuffMod('reducePenDmgAdd') : 0);  // 沙皇血池穿甲伤害减免（2026-08-09）
      finalDamage *= Math.max(0, 1 + (proj.penDmg || 0) + _takePen - reducePen);
    }

    // ⑤ 收割（目标低血；基础 10% + 收割伤害加成）
    var isExecute = false;
    if (target.maxHp > 0 && target.hp / target.maxHp <= (0.25 + (proj.executeThreshold || 0))
        && Math.random() < (proj.executeChance || 0)) {
      finalDamage *= (1 + 0.10 + (proj.executeDmg || 0));
      isExecute = true;
    }

    // ⑥ 最终增伤（独立因子，2026-08-06 与最终减伤取消逆属性关系，不再相减）
    if (proj.finalDmg) {
      finalDamage *= (1 + proj.finalDmg);
    }

    // ⑦ 其它伤害加成（护盾撕裂、对燃烧目标增伤等独立增伤）
    if ((proj.bonusVsBurning || 0) > 0 && target.burnStacks && target.burnStacks.length > 0) {
      finalDamage *= (1 + (proj.bonusVsBurning || 0));
    }
    if (target.shield > 0 && proj.shieldShred) {
      finalDamage *= (1 + proj.shieldShred);
    }
    // ⑦b A-140A 副炮锁定伤害加成（2026-09-19）：+10% × 锁定层数
    if (_ambitionL > 0) finalDamage *= (1 + 0.10 * _ambitionL);

    // ⑧ 武器减伤（考虑穿透）：减伤因子 = min(100 − y + x, 100)%，不能增伤（字段名由 opts 传：mainPen/reduceMainDmg 等）
    //    y = 舰体减免字段 + 光环「减免武器伤害」buff（reduceWeaponDmgAdd，点数；A-140A 炮火风暴 2026-09-19）
    var _buffReduce = (target.getBuffMod && target.getBuffMod('reduceWeaponDmgAdd')) || 0;
    var penEff = Math.min(100 - (target[opts.reduceKey] || 0) - _buffReduce + (proj[opts.penKey] || 0), 100);
    if (penEff < 100) {
      finalDamage *= penEff / 100;
    }

    // ⑨ 最终减伤（独立因子，2026-08-06 与最终增伤取消逆属性关系）
    // 最终减伤链式（2026-08-06 杜尔曼）：实际无视减伤=max(0,无视减伤−舰体保护)；实际最终减伤=max(0,最终减伤−实际无视减伤)；因子=1−实际最终减伤（不增伤）
    // 威尔士亲王光环 finalReduceAdd（2026-08-08）：与舰体 resistFinalDmg 相加后再链式
    var buffResist = (target.getBuffMod && target.getBuffMod('finalReduceAdd')) || 0;
    if (target.resistFinalDmg || proj.ignoreFinalReduce || buffResist) {
      var actualIgnore = Math.max(0, (proj.ignoreFinalReduce || 0) - (target.hullProtect || 0));
      var actualResist = Math.max(0, (target.resistFinalDmg || 0) + buffResist - actualIgnore);
      finalDamage *= Math.max(0, 1 - actualResist);
    }

    // ⑩ 默认伤害浮动（2026-08-06 从公式开头挪至末尾乘算）
    finalDamage = Math.round(finalDamage * variance);
    if (finalDamage <= 0) finalDamage = 1;
    // 特殊：战神模式附加伤害（命中额外造成自身 maxHp×0.6%，附加不受减伤影响）
    if (proj.execFlatDmg) finalDamage += proj.execFlatDmg;
    // 武器真伤（2026-09-19 字人规格重构）：
    //   ① 基数 = **武器总面板伤害**（proj.panelDamage，联装总伤害；旧实现误用单管 damage → 少算联装数倍）
    //      例：四联装面板 20000（每发 5000），真伤 10% → 每发 +2000 = 7000，四发 28000。
    //   ② 抵抗武器真伤（对冲）：有效真伤 = max(0, 攻击方真伤 − 抵抗真伤)，抵抗只能抵消不能增伤。
    var effTrueDmg = Math.max(0, (proj.trueDmg || 0) - (target.resistTrueDmg || 0));
    if (effTrueDmg > 0) {
      finalDamage += Math.round((proj.panelDamage != null ? proj.panelDamage : proj.damage) * effTrueDmg);
    }
    // 数值真伤（2026-11-08 威斯康星「威慑重击」叠层）：**固定数值**，排在百分比真伤**之后**加，
    //   不乘面板、不吃任何减伤（字人 A3 口径）；与百分比真伤是两条独立通道。
    if (proj.trueDmgFlat > 0) finalDamage += Math.round(proj.trueDmgFlat);
    // A-140A「国度的雄心」：主炮命中**被锁定**敌舰 → 附加固定伤害 = 10% × 基础副炮伤害 × 层数
    //   （末尾加法、不吃减伤；基数取该舰副炮武器面板的最高值，2026-09-19 字人 B6）
    if (!proj.isSecondary && proj.owner && proj.owner.getLockLayersOn && proj.owner.getSecondaryPanelDamageMax) {
      var _ambMainL = proj.owner.getLockLayersOn(target) || 0;
      if (_ambMainL > 0) {
        finalDamage += Math.round(proj.owner.getSecondaryPanelDamageMax() * 0.10 * _ambMainL);
      }
    }
    // 特殊：受到武器伤害为1几率（按概率强制本次武器伤害为 1，护盾优先扣减逻辑不变）
    if (target.dmgToOneChance && Math.random() < target.dmgToOneChance) {
      finalDamage = 1;
    }

    // 学有所成（杜尔曼）：被打出碎甲 → 5s 免疫碎甲 + 60s 冷却（tryShatter 因 shatterImmune 返回 false → 本次碎甲取消）
    if (target.commander && target.commander.tryLearnTrigger) target.commander.tryLearnTrigger(target, 'shatter', now);
    // 碎甲弹（2026-11-15 战列舰「毁灭」）：必定碎甲 —— 绕过概率判定与「抵抗碎甲」；
    //   与「必定暴击无视免疫暴击」一致，也绕过「免疫碎甲」buff（shatterImmune）。
    //   碎甲程度仍用弹丸上的 shatterPower，目标「抵抗碎甲程度」照常对冲。
    var _forceShatter = !!proj.isShatterShell;
    var isShatter = Armor.tryShatter(target,
      _forceShatter ? 1 : Math.max(0, (proj.shatterChance != null ? proj.shatterChance : SHATTER_CHANCE) - (target.resistShatterChance || 0)),
      now, proj.shatterPower, _forceShatter);  // 抵抗碎甲（对冲）

    return { finalDamage: finalDamage, isCrit: isCrit, isExecute: isExecute, isPen: isPen, isShatter: isShatter };
  };
