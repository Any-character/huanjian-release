/**
 * player.js — PlayerShip subclass with keyboard-driven control.
 *
 * W / S   : single-press gear change (handled via just-pressed flags).
 * A / D   : continuous-hold rotation.
 */

class PlayerShip extends Ship {
  /**
   * @param {number} x
   * @param {number} y
   * @param {Object} [cfg] — 可选，默认 PLAYER_CONFIG
   */
  constructor(x, y, cfg) {
    super(cfg || PLAYER_CONFIG, x, y, 0, true, 'player');
  }

  /**
   * @param {number} dt          — delta-time (seconds)
   * @param {object} inputState  — { isActionHeld(action), isActionJustPressed(action) }
   */
  update(dt, inputState) {
    // ── 配件损毁（2026-09-05）：引擎损毁 → W/S 无效 + 档位强制停止；舵机/引擎损毁 → 转向键无效 ──
    var noTurn = this.getBuffMod('noTurn') > 0;
    var noGear = this.getBuffMod('noGear') > 0;

    // ── gear change (single-press) ──────────────────────────────────────
    if (noGear) {
      this.gearIndex = INITIAL_GEAR_INDEX;   // 档位强制归零（停止），航速由 smoothSpeed 自然衰减到 0
    } else {
      if (inputState.isActionJustPressed('moveUp')) this.increaseGear();
      if (inputState.isActionJustPressed('moveDown')) this.decreaseGear();
    }

    // ── rudder input (replaces direct rotation) ────────────────────────
    this.rudderInput = 0;
    if (!noTurn) {
      if (inputState.isActionHeld('turnLeft')) this.rudderInput = -1;
      if (inputState.isActionHeld('turnRight')) this.rudderInput =  1;
    }

    // ── smoothing ──────────────────────────────────────────────────────
    this.smoothSpeed(dt);
    this.smoothTurn(dt);

    // ── movement & boundary ─────────────────────────────────────────────
    this.move(dt);
    this.clampToMap();
  }
}
