/**
 * ui.js — HTML-overlay HUD manager.
 *
 * Updates: ship info (name, HP bar), speed / gear text,
 *          weapon-cooldown icons (arc-aware), game-over overlay.
 */

class UIManager {
  constructor() {
    this.elShipName = document.getElementById('ship-name');
    this.elHpBar     = document.getElementById('hp-bar');
    this.elHpText    = document.getElementById('hp-text');
    this.elShieldWrap = document.getElementById('shield-wrap');   // 护盾条容器（无护盾隐藏）
    this.elShieldBar  = document.getElementById('shield-bar');
    this.elShieldText = document.getElementById('shield-text');

    this.elSpeedVal  = document.getElementById('speed-value');
    this.elGearName  = document.getElementById('gear-name');

    this.elGunIcons  = document.getElementById('main-gun-icons');
    this.elTorpIcons = document.getElementById('torpedo-icons');
    this.elMineIcons = document.getElementById('mine-icons');
    this.elSecIcons  = document.getElementById('secondary-icons');   // 副炮图标行（卢金斯 2026-09-13）

    this.elCommanderSkills = document.getElementById('commander-skills');
    this.elKillToasts = document.getElementById('kill-toasts');   // 击杀飞入特效容器（2026-08-06）
    this._killToastIds = {};    // 已渲染的 toast id → DOM 节点（去重）

    this.elGameOver  = document.getElementById('game-over');
    this.elGameOverText = document.getElementById('game-over-text');

    // 战役 Boss 血条（2026-08-07）：有 phases 的敌舰视为 Boss
    this.elBossWrap  = document.getElementById('boss-bar-wrap');
    this.elBossName  = document.getElementById('boss-bar-name');
    this.elBossFill  = document.getElementById('boss-bar-fill');
    this.elBossText  = document.getElementById('boss-bar-text');

    // 开火闪烁状态已删除（2026-08-16 字人反馈）：
    // 字段占位保留，未来如需重做可查阅 P2-2 a8bfc14 commit。
    this._firingFlash = null;
  }

  /**
   * Full HUD refresh (called every frame).
   * @param {PlayerShip} player
   * @param {number}     now      — Date.now()
   * @param {number}     aimX, aimY — mouse world coordinates (for arc check)
   */
  update(player, now, aimX, aimY) {
    if (!player) return;

    // ship info
    this.elShipName.textContent = player.name;
    var hpRatio = player.hp / player.maxHp;
    this.elHpBar.style.width = (hpRatio * 100).toFixed(1) + '%';
    // 健康/受损/濒死三态：低饱和的铜绿 → 黄铜 → 铁锈红（2026-11-15 界面统一）
    var hpColor = hpRatio > 0.5 ? '#5C8C74' : hpRatio > 0.25 ? '#C0934E' : '#B4462F';
    this.elHpBar.style.backgroundColor = hpColor;
    this.elHpText.textContent = Math.round(player.hp) + ' / ' + player.maxHp;   // 取整防浮点（2026-08-09 血池返还/回复）

    // 护盾条（血条下方，浅蓝；无护盾隐藏）——普通护盾 + 水镜盾（杜尔曼）合并显示（2026-08-06）
    var dmShield = (player.commander && player.commander.durman) ? (player.commander.durman.mirrorShield || 0) : 0;
    var totalShield = (player.shield || 0) + dmShield + (player.getTimedShieldTotal ? player.getTimedShieldTotal() : 0);   // 含限时护盾（红场，2026-08-09）
    if (totalShield > 0) {
      this.elShieldWrap.style.display = 'block';
      var shBase = player.maxShield > 0 ? player.maxShield : totalShield;   // 无基础护盾（古鹰）时以当前盾为满条基准
      var shRatio = Math.min(totalShield / shBase * 100, 100);              // 水镜盾可超额，条钳 100%
      this.elShieldBar.style.width = shRatio.toFixed(1) + '%';
      this.elShieldText.textContent = totalShield;
    } else {
      this.elShieldWrap.style.display = 'none';
    }

    // speed（数字与单位分开显示：数字走等宽字体，单位是独立的注记）
    this.elSpeedVal.textContent = Math.abs(player.speed).toFixed(1);
    this.elGearName.textContent = player.gearName;

    // weapon cooldown icons (with arc state)
    var mgArcStates = player.getMainGunArcStates(aimX, aimY);
    var tpArcStates = player.getTorpedoArcStates(aimX, aimY);
    var mnArcStates = player.getMineArcStates();
    // 副炮图标行（2026-09-13 修订）：仅"副炮跟随主炮瞄准"状态显示（ship.secondaryFollowsMain，
    // 当前唯一入口 = 卢金斯齐射模式；未来其它来源设置该字段即自动显示）。
    // 不跟随 → 隐藏（与未加该功能前一致）；跟随 → 显示 + can-fire 射界高亮（同主炮，2026-09-13 字人反馈）
    if (this.elSecIcons && player.secondaryMounts && player.getSecondaryCooldowns && player.getSecondaryArcStates) {
      if (player.isSecondaryFollowing ? player.isSecondaryFollowing() : player.secondaryFollowsMain) {
        this.elSecIcons.style.display = '';
        var secArcStates = player.getSecondaryArcStates(aimX, aimY);
        this._updateCooldownIcons(this.elSecIcons, player.getSecondaryCooldowns(now), 'secondary', player.secondaryMounts.length, secArcStates);
      } else {
        this.elSecIcons.style.display = 'none';
      }
    }
    this._updateCooldownIcons(this.elGunIcons, player.getMainGunCooldowns(now), 'main-gun', player.weaponCfg.mainGun.mountCount, mgArcStates);
    // 威斯康星 [重击炮弹]（2026-11-08）：装填了重击弹的那门主炮图标加粒子特效
    //   （参考图待字人提供；当前是占位实现：暖金光晕 + 绕圈虚线）
    // 战列舰「毁灭」主动弹种（2026-11-15）：碎甲弹 → 青绿标记、致命弹 → 金黄标记。
    //   三者相互独立（碎甲/致命互斥，但都与重击弹共存），故各自增删类。
    if (this.elGunIcons && player.mainGunMounts) {
      var gunIcons = this.elGunIcons.children;
      for (var gi = 0; gi < gunIcons.length && gi < player.mainGunMounts.length; gi++) {
        var _mnt = player.mainGunMounts[gi];
        if (_mnt._heavy) gunIcons[gi].classList.add('heavy-shell');
        else gunIcons[gi].classList.remove('heavy-shell');
        if (_mnt._shatterShell) gunIcons[gi].classList.add('shatter-shell');
        else gunIcons[gi].classList.remove('shatter-shell');
        if (_mnt._fatalShell) gunIcons[gi].classList.add('fatal-shell');
        else gunIcons[gi].classList.remove('fatal-shell');
      }
    }
    this._updateCooldownIcons(this.elTorpIcons, player.getTorpedoCooldowns(now), 'torpedo', player.weaponCfg.torpedo.mountCount, tpArcStates);
    this._updateCooldownIcons(this.elMineIcons, player.getMineCooldowns(now), 'mine', player.weaponCfg.mine.mountCount, mnArcStates);

    // commander active skill icons
    this._updateCommanderSkills(now, player);
  }

  // 技能图形在 js/ui/skill-glyphs.js（2026-11-15 拆出：本文件已超 400 行）

  /**
   * 指挥官主动技能图标（右下角，武器图标旁）。
   * 每技能一个：圆形冷却图标（填充 + 秒数文本）、下方技能名、右下角键位标签；
   * Z计划 额外画一圈进度点（st.dotsTotal/dotsLit，每命中 1 次亮 1 点，点满升级）。
   * 无指挥官/无主动技能 → 隐藏容器。
   */
  _updateCommanderSkills(now, player) {
    if (!this.commander || !this.commander.active || !this.elCommanderSkills) {
      if (this.elCommanderSkills) {
        this.elCommanderSkills.innerHTML = '';
        this.elCommanderSkills.style.display = 'none';
      }
      this._updateShipActiveSkills(now, player);   // 指挥官不在场也画战舰主动技能（2026-08-09）
      return;
    }
    var states = this.commander.getActiveSkillStates(now);
    if (!states.length) {
      this.elCommanderSkills.innerHTML = '';
      this.elCommanderSkills.style.display = 'none';
      this._updateShipActiveSkills(now, player);
      return;
    }
    this.elCommanderSkills.style.display = 'flex';
    var el = this.elCommanderSkills;
    // 重建图标（技能数极少，重建开销可忽略）
    el.innerHTML = '';
    var keyBinds = [
      SETTINGS.keys.commanderMain,
      SETTINGS.keys.commanderSecondary,
    ];
    // 华晟军魂统一图标：单个外圈 + 6 个点镶在外圈上（黄点=军魂数量）+ 上方键位 + 冷却秒数，无等级角标
    // （2026-08-06 统一删方形图标；2026-11-08 去内圈、六点移到外圈——内圈是多余的第二个圈）
    var wsIndex = -1;
    var wsState = null;
    for (var ws = 0; ws < states.length; ws++) {
      if (states[ws].name === '军魂') { wsIndex = ws; wsState = states[ws]; break; }
    }
    if (wsState) {
      var soulSlot = document.createElement('div');
      soulSlot.className = 'soul-slot' + (wsState.ready ? ' ready' : ' cooling');
      var soulDots = '';
      for (var sd = 0; sd < 6; sd++) {
        // 半径 23px = 外圈上（46px 图标）；从 30° 起排，给上方键位角标让出正中位置
        soulDots += '<span class="soul-dot' + (sd < wsState.level ? ' on' : '') + '" style="transform: rotate(' + (30 + sd * 60) + 'deg) translateY(-23px)"></span>';
      }
      soulSlot.innerHTML = this._skillGlyphSvg('军魂')
        + soulDots
        + '<span class="soul-cd"></span>'
        + '<span class="soul-key">' + (keyBinds[wsIndex] ? bindingLabel(keyBinds[wsIndex]) : '') + '</span>'
        + '<span class="soul-name">军魂</span>';
      el.appendChild(soulSlot);
      var cdEl = soulSlot.querySelector('.soul-cd');
      if (!wsState.ready && wsState.remaining > 0) {
        cdEl.textContent = wsState.remaining.toFixed(1);
      }
    }
    // 杜尔曼水镜之盾充能图标：46x46 单圆 + 2 充能点 + 冷却 + 名称 + 右下键位（2026-08-06 改）
    var msIndex = -1;
    var msState = null;
    for (var ms = 0; ms < states.length; ms++) {
      if (states[ms].name === '水镜之盾') { msIndex = ms; msState = states[ms]; break; }
    }
    if (msState) {
      var mirrorSlot = document.createElement('div');
      var maxC = msState.chargeMax || 1;
      mirrorSlot.className = 'mirror-slot' + (msState.level === 0 ? ' cooling' : '');
      var charges = '';
      for (var cb = 0; cb < maxC; cb++) {
        var on = cb < msState.level;
        charges += '<span class="mirror-charge' + (on ? ' on' : '') + '"></span>';
      }
      mirrorSlot.innerHTML = this._skillGlyphSvg('水镜之盾')
        + charges
        + '<span class="mirror-cd"></span>'
        + '<span class="mirror-key">' + (keyBinds[msIndex] ? bindingLabel(keyBinds[msIndex]) : '') + '</span>'
        + '<span class="mirror-name">水镜之盾</span>';
      el.appendChild(mirrorSlot);
      // 冷却数字：level < max 时显示下一层充能剩余秒数
      var cdEl2 = mirrorSlot.querySelector('.mirror-cd');
      if (msState.level < maxC && msState.remaining > 0) {
        cdEl2.textContent = msState.remaining.toFixed(1);
      }
    }
    for (var i = 0; i < states.length; i++) {
      if (i === wsIndex || i === msIndex) continue;   // 军魂/水镜盾已用特殊图标渲染，不重复方形
      var st = states[i];
      var icon = document.createElement('div');
      // 带进度点的图标（Z计划）多一个 has-dots：键位标签要挪到图标上方，否则 48px 标签压住下半圈的点
      var dotTotal = st.dotsTotal || 0;
      icon.className = 'cooldown-icon commander-icon'
        + (dotTotal > 0 ? ' has-dots' : '')
        + (st.activeMode ? ' mode-active' : '');
      // 激活特效（2026-09-13 字人需求，参考巅峰战舰）：模式切换类技能激活时，
      //   图标内贴边绕中心转的云雾粒子（两层错速反向 → 云雾感，暖金色系，CSS 实现）。
      //   注：本循环每帧重建 DOM → CSS 旋转动画从 0deg 重启，相位固定无跳变
      var mistHtml = st.activeMode
        ? '<span class="cs-mist"></span><span class="cs-mist b"></span>'
        : '';
      // 进度点（2026-11-08 字人要求，同华晟军魂）：半径 23px = 46px 圆边线上；
      //   从 22.5° 起等分，避开正上方（键位标签所在）与正下方（技能名所在）
      var dotsHtml = '';
      for (var dp = 0; dp < dotTotal; dp++) {
        dotsHtml += '<span class="cs-dot' + (dp < st.dotsLit ? ' on' : '') + '" style="transform: rotate('
          + (22.5 + dp * (360 / dotTotal)) + 'deg) translateY(-23px)"></span>';
      }
      icon.innerHTML = mistHtml
        + this._skillGlyphSvg(st.name)
        + '<div class="cs-wrap"><div class="cooldown-fill"></div></div>'
        + '<span class="cooldown-text"></span>'
        + '<span class="cs-name"></span>'
        + '<span class="cs-key"></span>'
        + dotsHtml;
      el.appendChild(icon);
      var fill = icon.querySelector('.cooldown-fill');
      var text = icon.querySelector('.cooldown-text');
      var fillColor = '#B4863F';
      var readyColor = '#C0934E';
      if (!st.ready) {
        var pct = ((st.total - st.remaining) / st.total) * 100;
        fill.style.height = pct + '%';
        fill.style.backgroundColor = fillColor;
        fill.style.opacity = '0.22';   // 冷却进度是底纹，不是一块金砖（2026-11-15）
        text.textContent = st.remaining.toFixed(1);
        text.style.bottom = '1px';
        text.style.fontSize = '9px';
        icon.classList.add('cooling');
        icon.classList.remove('ready');
      } else {
        fill.style.height = '100%';
        fill.style.backgroundColor = readyColor;
        fill.style.opacity = '0.14';   // 就绪只提亮一档，靠外圈黄铜表示可用
        text.textContent = '';
        icon.classList.add('ready');
        icon.classList.remove('cooling');
      }
      var nameEl = icon.querySelector('.cs-name');
      nameEl.textContent = st.name;
      var keyEl = icon.querySelector('.cs-key');
      keyEl.textContent = keyBinds[i] ? bindingLabel(keyBinds[i]) : '';
    }
    this._updateShipActiveSkills(now, player);
  }

  /**
   * 战舰主动技能图标（2026-08-09 沙皇「红场之魂」）：追加到指挥官技能栏。
   * 红场之魂特殊：圈内显示血池储量/上限（xxxxx/xxxxx）。
   */
  _updateShipActiveSkills(now, player) {
    if (!player || !this.elCommanderSkills) return;
    var st = ShipSkills.getActiveSkillStates(player, now);
    var el = this.elCommanderSkills;
    // 清掉上次画的战舰主动图标（_updateCommanderSkills 全量重建时也会被 innerHTML 清掉，双保险）
    var olds = el.querySelectorAll('.redsquare-slot, .ship-active-icon');
    for (var o = olds.length - 1; o >= 0; o--) {
      if (olds[o].parentNode) olds[o].parentNode.removeChild(olds[o]);
    }
    // 舰种主动技能（2026-11-15）：与战舰主动技能同一个技能栏，画在 js/ui/class-skill-icons.js。
    //   放在 !st.length 提前 return 之前 —— 没有战舰技能时也要显示舰种技能。
    this._updateClassActiveSkills(now, player);
    if (!st.length) return;
    el.style.display = 'flex';   // 指挥官不在场时也显示战舰主动技能
    for (var i = 0; i < st.length; i++) {
      var s = st[i];
      var keyLabel = SETTINGS.keys[s.key] ? bindingLabel(SETTINGS.keys[s.key]) : '';
      if (s.id === 'tsar-redsquare') {
        // 红场之魂特殊图标：圈内显示血池储量/上限
        var rs = document.createElement('div');
        rs.className = 'redsquare-slot' + (s.active ? ' active' : '') + (s.ready ? ' ready' : ' cooling');
        var bp = s.bloodPool;
        var storedTxt = bp ? Math.round(bp.stored).toLocaleString() : '0';
        var maxTxt = bp ? Math.round(bp.getMaxStored()).toLocaleString() : '0';
        rs.innerHTML = '<span class="redsquare-pool">' + storedTxt + '/' + maxTxt + '</span>'
          + '<span class="redsquare-cd"></span>'
          + '<span class="redsquare-key">' + keyLabel + '</span>'
          + '<span class="redsquare-name">红场之魂</span>';
        el.appendChild(rs);
        var cdEl = rs.querySelector('.redsquare-cd');
        if (!s.ready && s.remaining > 0) cdEl.textContent = s.remaining.toFixed(1);
      } else {
        // 通用战舰主动技能图标（未来扩展）；激活中 → 同指挥官模式技能特效（云雾粒子，2026-09-19）
        var icon = document.createElement('div');
        icon.className = 'cooldown-icon commander-icon ship-active-icon' + (s.active ? ' mode-active' : '');
        var mistHtml = s.active ? '<span class="cs-mist"></span><span class="cs-mist b"></span>' : '';
        icon.innerHTML = mistHtml
          + this._skillGlyphSvg(s.name)
          + '<div class="cs-wrap"><div class="cooldown-fill"></div></div>'
          + '<span class="cooldown-text"></span>'
          + '<span class="cs-name"></span>'
          + '<span class="cs-key"></span>';
        el.appendChild(icon);
        var fill = icon.querySelector('.cooldown-fill');
        var text = icon.querySelector('.cooldown-text');
        if (!s.ready) {
          var pct2 = ((s.cooldownSec - s.remaining) / s.cooldownSec) * 100;
          fill.style.height = pct2 + '%';
          fill.style.backgroundColor = '#C9A227';
          fill.style.opacity = '0.22';
          text.textContent = s.remaining.toFixed(1);
          icon.classList.add('cooling');
        } else {
          fill.style.height = '100%';
          fill.style.backgroundColor = '#C0934E';
          fill.style.opacity = '0.14';
          icon.classList.add('ready');
        }
        icon.querySelector('.cs-name').textContent = s.name;
        icon.querySelector('.cs-key').textContent = keyLabel;
      }
    }
  }

  /**
   * Rebuild / update cooldown icon DOM.
   * Three visual states:
   *   1. Cooling → orange-red fills bottom-up as cooldown nears completion, time text
   *   2. Ready + can fire → full light-blue fill
   *   3. Ready + cannot fire → full orange-red fill
   *
   * @param {HTMLElement} container
   * @param {Array}       cooldowns  — [{remaining, total, ready}]
   * @param {string}      type       — 'main-gun' | 'torpedo'
   * @param {number}      count
   * @param {Array}       arcStates  — [bool] can fire at aim direction
   */
  _updateCooldownIcons(container, cooldowns, type, count, arcStates) {
    arcStates = arcStates || [];
    // create icons once
    if (container.children.length === 0) {
      for (var i = 0; i < count; i++) {
        var icon = document.createElement('div');
        icon.className = 'cooldown-icon ' + type + '-icon';
        icon.innerHTML = '<div class="cooldown-fill"></div>'
          + '<span class="cooldown-text"></span>';
        container.appendChild(icon);
      }
    }

    var children = container.children;
    var fillColor = '#B4462F';   // 装填中 = 铁锈红
    var readyColor = '#C0934E';  // 可开火 = 黄铜（唯一强调色）

    for (var i = 0; i < count; i++) {
      var cd = cooldowns[i];
      var el = children[i];
      var fill = el.querySelector('.cooldown-fill');
      var text = el.querySelector('.cooldown-text');

      // 武器损毁（武损，2026-09-13）：被损毁武器标红 + 斜杠损坏标记；
      //   冷却条数值取冻结值（getXxxCooldowns 已按 damaged 分支处理，装填进度冻结）
      if (cd.damaged) {
        el.classList.add('damaged');
      } else {
        el.classList.remove('damaged');
      }

      if (!cd.ready) {
        // cooling — orange-red fills bottom-up as cooldown nears completion
        // ★2026-09-13 字人 BUG 修复（"齐射时数字动、橙条不动"）：
        //   pct 若为负（remaining > total，异常数据）/ NaN / Infinity → style.height 赋值被浏览器拒绝
        //   → fill 停留在上一次有效值 → **条永久冻结而数字（textContent）照常更新**。
        //   钳制到 [0,100] 后 height 每帧必有有效值 → 条必然跟随（最坏显示 0%，数据恢复即恢复）。
        var pct = ((cd.total - cd.remaining) / cd.total) * 100;
        if (!isFinite(pct)) pct = 0;
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;
        fill.style.height = pct + '%';
        fill.style.backgroundColor = fillColor;
        fill.style.opacity = '0.85';
        text.textContent = cd.remaining.toFixed(1);
        text.style.bottom = '1px';
        text.style.fontSize = '9px';
        el.classList.add('cooling');
        el.classList.remove('ready', 'can-fire', 'no-fire');
      } else if (arcStates[i]) {
        // ready + can fire → 黄铜底色（低不透明度：一排图标全亮时不能变成金砖）
        fill.style.height = '100%';
        fill.style.backgroundColor = readyColor;
        fill.style.opacity = '0.20';
        text.textContent = '';
        el.classList.add('ready', 'can-fire');
        el.classList.remove('cooling', 'no-fire');
      } else {
        // ready + cannot fire → full orange-red
        fill.style.height = '100%';
        fill.style.backgroundColor = fillColor;
        fill.style.opacity = '0.18';
        text.textContent = '';
        el.classList.add('ready', 'no-fire');
        el.classList.remove('cooling', 'can-fire');
      }
    }
    // 底炮图标闪烁已删除（2026-08-16 字人反馈）：不再有 flashAlive 清理
  }

  showGameOver(isWin) {
    this.elGameOver.style.display = 'flex';
    this.elGameOverText.textContent = isWin ? '胜利！' : '失败！';
    // 2026-11-15：跟着设计口令走——胜利用黄铜（全场唯一强调色），失败用警报红
    this.elGameOverText.style.color = isWin ? '#C0934E' : '#B4462F';
  }

  /**
   * 击杀飞入特效（"你击沉了 XXX"，2026-08-06）。
   * DOM 层渲染（z-index 200 盖过 game-over 遮罩 100）：
   *   每帧传入 battleStats 的 killToasts 数组（含 id/name/life），
   *   按 id 去重创建节点（CSS 动画自动播放），数组 splice 过期后下一帧移除节点+记录。
   *   ⚠️ 生命周期完全由数组驱动（不再依赖 animationend 删记录）——修复 2026-08-06 反复弹出竞态：
   *      animationend 先删记录、数组 toast 还在 → 下一帧重建节点 → 反复弹出。
   * @param {Array<{id:number,name:string}>} toasts
   */
  updateKillToasts(toasts) {
    if (!this.elKillToasts) return;
    // 击杀播报开关（2026-08-07 起生效；设置 → 特效 → 击杀飘字）：
    // 关闭时清空已有节点（残留 DOM 直接移除），不创建新节点；数组仍由 main.js 生命周期管理
    if (SETTINGS && SETTINGS.fx && SETTINGS.fx.killToast === false) {
      for (var offId in this._killToastIds) {
        var offEl = this._killToastIds[offId];
        if (offEl && offEl.parentNode) offEl.parentNode.removeChild(offEl);
        delete this._killToastIds[offId];
      }
      return;
    }
    toasts = toasts || [];
    var active = {};
    for (var i = 0; i < toasts.length; i++) {
      var t = toasts[i];
      if (t.id == null) continue;
      active[t.id] = true;
      if (this._killToastIds[t.id]) continue;    // 已渲染过，跳过
      var div = document.createElement('div');
      div.className = 'kill-toast';
      // 助攻播报（2026-10-02）：battle-stats 的 toast 带 assist 布尔，击杀沿用原文案
      div.textContent = (t.assist ? '你协助击沉了 ' : '你击沉了 ') + (t.name || '敌舰');
      this.elKillToasts.appendChild(div);
      this._killToastIds[t.id] = div;
    }
    // 数组已 splice（toast 过期）→ 移除对应 DOM 节点 + 记录（只弹一次）
    for (var id in this._killToastIds) {
      if (!active[id]) {
        var el = this._killToastIds[id];
        if (el && el.parentNode) el.parentNode.removeChild(el);
        delete this._killToastIds[id];
      }
    }
  }

  hideGameOver() {
    this.elGameOver.style.display = 'none';
  }

  /**
   * 战役 Boss 血条（2026-08-07）：找到第一艘带 phases 的活敌舰显示血量。
   * @param {Array} enemies — 敌方数组（含存活判定）
   */
  updateBossBar(enemies) {
    if (!this.elBossWrap) return;
    var boss = null;
    for (var i = 0; i < (enemies || []).length; i++) {
      var e = enemies[i];
      if (e && e.isAlive && e._phases && e._phases.length > 0) { boss = e; break; }
    }
    if (!boss) {
      this.elBossWrap.style.display = 'none';
      return;
    }
    this.elBossWrap.style.display = 'block';
    this.elBossName.textContent = boss.displayName || boss.name || 'BOSS';
    var ratio = Math.max(0, Math.min(1, boss.hp / boss.maxHp));
    this.elBossFill.style.width = (ratio * 100).toFixed(1) + '%';
    this.elBossText.textContent = boss.hp + ' / ' + boss.maxHp;
  }
}
