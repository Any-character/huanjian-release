/**
 * enemy-weapons.js — 人机武器库（2026-08-08 改革）
 *
 * 与玩家武器库（MAIN_GUN_WEAPONS 等）**独立管理**：复制数据、独立 id、独立查询函数，
 * 不从玩家武器库读取（字人明确要求）。
 *
 * 规则：
 * - 舰种隔离：getAvailableEnemyWeapons(type, shipType) 按 shipType 过滤
 * - 人机武器不带冷却（和玩家一致）：冷却来自舰种默认 reload（SHIP_TYPE_DEFAULTS）或配置覆盖
 * - 伤害/炮速 = 面板值（联装数 barrelsPerMount 决定每发均摊，与玩家武器语义一致）
 * - 默认装备：人机A 系列（enemy-cruiser-mgA / enemy-bb-*）；缺的类型用复制过来的玩家武器兜底
 */

var ENEMY_WEAPONS = Object.freeze([
  /* ── 人机A 系列（默认，2026-08-08）── */
  Object.freeze({
    id: 'enemy-cruiser-mgA',
    name: '巡-人机A',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,      // 二联装
    damage: 1000,
    shellSpeed: 10000,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-bb-mgA',
    name: '战-人机A',
    type: 'mainGun',
    shipType: 'battleship',
    barrelsPerMount: 3,      // 三联装
    damage: 2000,
    shellSpeed: 7000,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-bb-tpA',
    name: '战-人机A',
    type: 'torpedo',
    shipType: 'battleship',
    barrelsPerMount: 4,      // 四联装
    damage: 4000,
    speed: 35,               // 35 节
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    color: '#AA1111',
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-bb-scA',
    name: '战-人机A',
    type: 'secondary',
    shipType: 'battleship',
    barrelsPerMount: 2,      // 二联装
    damage: 600,
    shellSpeed: 12000,
    color: '#FFFFFF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    alpha: 0.7,
    bonuses: Object.freeze({}),
  }),

  /* ── 复制自玩家武器库（2026-08-08 独立管理；巡洋测试武器已删不入库）── */
  Object.freeze({
    id: 'enemy-cruiser-burst',
    name: '巡-速爆冲击',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2188,
    shellSpeed: 10455,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ critChance: 0.12, penDmg: 0.05, burnPower: 0.10 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-swift',
    name: '巡-急速领域',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2190,
    shellSpeed: 11443,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ penDmg: 0.05, burnPower: 0.10 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-phoenix',
    name: '巡-鸾凤追风',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2251,
    shellSpeed: 11386,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ burnChance: 0.04, bonusVsBurning: 0.09, burnSpeed: 0.15 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-flash',
    name: '巡-闪跃爆裂',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2250,
    shellSpeed: 10552,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ critChance: 0.12, burnChance: 0.04, burnPower: 0.12, penDmg: 0.06 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-snowpeak',
    name: '巡-雪顶之花',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2301,
    shellSpeed: 11392,
    color: '#E8F0FF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ critChance: 0.09, critDmg: 0.1 }),
  }),
  Object.freeze({
    id: 'enemy-destroyer-mg',
    name: '驱-127mm-契约',
    type: 'mainGun',
    shipType: 'destroyer',
    barrelsPerMount: 2,
    damage: 908,
    shellSpeed: 8862,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ critDmg: 0.1 }),
  }),
  Object.freeze({
    id: 'enemy-battleship-mg',
    name: '战-460mm-契约',
    type: 'mainGun',
    shipType: 'battleship',
    barrelsPerMount: 3,
    damage: 4948,
    shellSpeed: 12153,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: Object.freeze({ critDmg: 0.1 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-tp610',
    name: '巡-610mm-S',
    type: 'torpedo',
    shipType: 'cruiser',
    barrelsPerMount: 4,
    damage: 27342,
    speed: 51.6,
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    color: '#AA1111',
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-cruiser-tpBull',
    name: '巡-突袭蛮牛',
    type: 'torpedo',
    shipType: 'cruiser',
    barrelsPerMount: 4,
    damage: 21874,
    speed: 69.7,
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    color: '#AA1111',
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-destroyer-tp',
    name: '驱-610mm-契约',
    type: 'torpedo',
    shipType: 'destroyer',
    barrelsPerMount: 4,
    damage: 19593,
    speed: 63.9,
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    color: '#AA1111',
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-destroyer-mine',
    name: '驱-水压水雷4-1A',
    type: 'mine',
    shipType: 'destroyer',
    barrelsPerMount: 1,
    damage: 8799,
    detonationRadiusKM: 0.75,
    explosionRadiusKM: 2.45,
    lifetimeSec: 135,
    color: '#000000',
    bonuses: Object.freeze({ floodChance: 0.10 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-mine',
    name: '巡-强袭者',
    type: 'mine',
    shipType: 'cruiser',
    barrelsPerMount: 1,
    damage: 10679,
    detonationRadiusKM: 0.75,
    explosionRadiusKM: 2.45,
    lifetimeSec: 131,
    color: '#000000',
    bonuses: Object.freeze({ floodChance: 0.10, floodDuration: 0.40, floodPower: 0.12, critDmg: 0.06 }),
  }),
  Object.freeze({
    id: 'enemy-battleship-mine',
    name: '战-炎中盘龙',
    type: 'mine',
    shipType: 'battleship',
    barrelsPerMount: 1,
    damage: 10740,
    detonationRadiusKM: 0.75,
    explosionRadiusKM: 2.5,
    lifetimeSec: 120,
    color: '#000000',
    bonuses: Object.freeze({ critChance: 0.06, critDmg: 0.08, floodChance: 0.05, floodPower: 0.10 }),
  }),
  Object.freeze({
    id: 'enemy-destroyer-scA',
    name: '驱-人机A',
    type: 'secondary',
    shipType: 'destroyer',
    barrelsPerMount: 2,      // 二联装
    damage: 400,
    shellSpeed: 7000,
    color: '#FFFFFF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    alpha: 0.7,
    bonuses: Object.freeze({}),
  }),
  Object.freeze({
    id: 'enemy-battleship-sc',
    name: '战-152mm12型',
    type: 'secondary',
    shipType: 'battleship',
    barrelsPerMount: 2,
    damage: 1393,
    shellSpeed: 12635,
    color: '#FFFFFF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    alpha: 0.7,
    bonuses: Object.freeze({ critChance: 0.08 }),
  }),
  Object.freeze({
    id: 'enemy-cruiser-sc130',
    name: '巡-130mm原型',
    type: 'secondary',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 1247,
    shellSpeed: 12285,
    color: '#FFFFFF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    alpha: 0.7,
    bonuses: Object.freeze({}),
  }),
]);

/** 按 id 查人机武器（独立查询，不碰玩家库） */
function getEnemyWeaponById(id) {
  if (!id) return null;
  for (var i = 0; i < ENEMY_WEAPONS.length; i++) {
    if (ENEMY_WEAPONS[i].id === id) return ENEMY_WEAPONS[i];
  }
  return null;
}

/** 按类型+舰种过滤人机武器（舰种隔离） */
function getAvailableEnemyWeapons(type, shipType) {
  var out = [];
  for (var i = 0; i < ENEMY_WEAPONS.length; i++) {
    var w = ENEMY_WEAPONS[i];
    if (w.type === type && w.shipType === shipType) out.push(w);
  }
  return out;
}

/** 人机默认武器：人机A 系列优先，缺的类型用该舰种复制武器兜底（2026-08-08） */
function getEnemyDefaultWeapon(type, shipType) {
  var list = getAvailableEnemyWeapons(type, shipType);
  if (list.length === 0) return null;
  // 人机A 优先（id 含 '-A' 结尾的人机A 系列，或名字含 人机A）
  for (var i = 0; i < list.length; i++) {
    if (list[i].name && list[i].name.indexOf('人机A') !== -1) return list[i];
  }
  return list[0];   // 兜底：复制武器第一把
}
