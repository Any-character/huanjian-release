/**
 * main-guns.js — 主炮武器库（独立文件，未来可扩展）
 * 2026-08-08：删除巡洋测试主炮（testA/testC/testD）——玩家主炮换正式武器
 */
var MAIN_GUN_WEAPONS = Object.freeze([
  Object.freeze({
    id: 'cruiser-burst-impact',
    name: '巡-速爆冲击',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2188,
    shellSpeed: 10455,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      critChance: 0.12,  // +12% 暴击几率
      penDmg: 0.05,      // +5% 穿甲伤害
      burnPower: 0.10,   // +10% 燃烧程度
    },
  }),
  Object.freeze({
    id: 'cruiser-swift-domain',
    name: '巡-急速领域',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2190,
    shellSpeed: 11443,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      penDmg: 0.05,      // +5% 穿甲伤害
      burnPower: 0.10,   // +10% 燃烧程度
    },
  }),
  Object.freeze({
    id: 'cruiser-phoenix-chase',
    name: '巡-鸾凤追风',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2251,
    shellSpeed: 11386,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      burnChance: 0.04,      // +4% 燃烧几率
      bonusVsBurning: 0.09,  // +9% 对燃烧目标增伤
      burnSpeed: 0.15,       // +15% 燃烧加速
    },
  }),
  Object.freeze({
    id: 'cruiser-flash-burst',
    name: '巡-闪跃爆裂',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2250,
    shellSpeed: 10552,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      critChance: 0.12,  // +12% 暴击几率
      burnChance: 0.04,  // +4% 燃烧几率
      burnPower: 0.12,   // +12% 燃烧程度
      penDmg: 0.06,      // +6% 穿甲伤害
    },
  }),
  Object.freeze({
    id: 'cruiser-140mm-snowpeak',
    name: '巡-雪顶之花',
    type: 'mainGun',
    shipType: 'cruiser',
    barrelsPerMount: 2,
    damage: 2301,
    shellSpeed: 11392,
    color: '#E8F0FF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      critChance: 0.09,     // +9% 暴击率
      critDmg:    0.1,      // +10% 暴击伤害（暴击时伤害 ×2.0×1.1=×2.2）
    },
  }),
  Object.freeze({
    id: 'destroyer-127mm-contract',
    name: '驱-127mm-契约',
    type: 'mainGun',
    shipType: 'destroyer',
    barrelsPerMount: 2,
    damage: 908,
    shellSpeed: 8862,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      critDmg: 0.1,      // +10% 暴击伤害（暴击时 ×2.2）
    },
  }),
  Object.freeze({
    id: 'battleship-460mm-contract',
    name: '战-460mm-契约',
    type: 'mainGun',
    shipType: 'battleship',
    barrelsPerMount: 3,
    damage: 4948,
    shellSpeed: 12153,
    color: '#FF2222',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      critDmg: 0.1,   // +10% 暴击伤害（暴击时 ×2.2）
    },
  }),
  // 赤色霞光（2026-11-08 字人需求）：战列舰四联装主炮。
  //   damage 是**联装总面板**（weapon-config 按 barrelsPerMount 均摊到每发：6139/4 = 1535），
  //   不要按「单发伤害」填——填单发会变成 4 倍总伤。
  Object.freeze({
    id: 'battleship-crimson-glow',
    name: '战-赤色霞光',
    type: 'mainGun',
    shipType: 'battleship',
    barrelsPerMount: 4,
    damage: 6139,
    shellSpeed: 12578,
    color: '#FF3B2F',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    bonuses: {
      critChance: 0.10,  // +10% 暴击几率
      critDmg:    0.10,  // +10% 暴击伤害（暴击时 ×2.0×1.1 = ×2.2）
      penDmg:     0.05,  // +5% 穿甲伤害
    },
  }),
]);
