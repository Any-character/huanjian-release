/**
 * secondary-guns.js — 副炮武器库
 *
 * 副炮为 AI 自动开火武器：冷却好且射程+射界内有敌人时自动向最近目标开火。
 * 可暴击/碎甲，不能穿甲/燃烧/漏水；炮弹与尾迹为半透明白色（alpha 字段）。
 */
var SECONDARY_WEAPONS = Object.freeze([
  Object.freeze({
    id: 'battleship-152mm-12',
    name: '战-152mm12型',
    type: 'secondary',
    shipType: 'battleship',
    barrelsPerMount: 2,
    damage: 1393,
    shellSpeed: 12635,
    color: '#FFFFFF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    alpha: 0.7,        // 炮弹/尾迹透明度（半透明白）
    bonuses: {
      critChance: 0.08,  // +8% 暴击几率
    },
  }),
  // 巡洋二联装副炮「巡-130mm原型」（2026-08-08）：伤害高、弹速快
  Object.freeze({
    id: 'cruiser-130mm-proto',
    name: '巡-130mm原型',
    type: 'secondary',
    shipType: 'cruiser',
    barrelsPerMount: 2,   // 二联装
    damage: 1247,
    shellSpeed: 12285,    // ×0.057 ≈ 700 px/s
    color: '#FFFFFF',
    shellRadius: 3,
    trailFrames: 8,
    spreadAngle: 1 * Math.PI / 180,
    landingDeviation: 15,
    alpha: 0.7,
    bonuses: {},
  }),
]);
