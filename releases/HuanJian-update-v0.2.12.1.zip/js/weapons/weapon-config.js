/**
 * weapon-config.js — 武器查找 + 武器→战场config转换工具
 *
 * ⚠️ 改动前必读（AGENTS.md §8.6 攻击侧属性清单）：
 *   - 本文件是「武器定义 → 每炮位配置」的**唯一转换点**（4 类武器共用），弹丸字段在此汇总
 *   - 攻击侧属性的「舰体值 + 武器 bonuses」相加由本文件统一做；**字段清单来自
 *     js/data/attack-stats.js 的表**（`fillAttackFields` 兜底，新属性不必在此再加一行）
 *   - panelDamage = weapon.damage（武器总面板，联装总伤害）——真伤基数专用，勿与 damage（单管）混用
 *   - 敌人走 custom-enemy.js 的 _weaponWcfg（不经本文件）；它复用同一张表，勿在那边重抄
 */

/** 根据 weapon id 查找武器定义 */
function getWeaponById(id) {
  return MAIN_GUN_WEAPONS.find(function(w) { return w.id === id; })
      || TORPEDO_WEAPONS.find(function(w) { return w.id === id; })
      || MINE_WEAPONS.find(function(w) { return w.id === id; })
      || SECONDARY_WEAPONS.find(function(w) { return w.id === id; });
}

/** 获取某舰种可用的某类型武器列表 */
function getAvailableWeapons(type, shipType) {
  var list = type === 'mainGun' ? MAIN_GUN_WEAPONS
    : (type === 'torpedo' ? TORPEDO_WEAPONS
      : (type === 'secondary' ? SECONDARY_WEAPONS : MINE_WEAPONS));
  return list.filter(function(w) { return w.shipType === shipType; });
}

/**
 * 将武器定义转为战斗用的 per-mount weaponCfg 子对象。
 * @param {Object} weapon       — 武器定义
 * @param {Object} shipWeaponCfg — ship.weaponCfg.mainGun 或 ship.weaponCfg.torpedo
 * @param {Object} [baseStats]  — { critChance, shatterChance, critDmg } 战舰基础值
 */
function weaponToMountConfig(weapon, shipWeaponCfg, baseStats) {
  // 2026-10-25 重构：外层包装。先走原分支逻辑，再由 data/attack-stats.js 的表补齐
  //   表里新增、但分支还没显式写的攻击属性（以后加字段不必再改下面 4 个分支）。
  //   今天所有分支都已显式写全 → 这一步是 no-op，行为零变化。
  return fillAttackFields(
    _weaponToMountConfigRaw(weapon, shipWeaponCfg, baseStats),
    baseStats, weapon.bonuses, weapon.type
  );
}

/** 原 4 分支实现（主炮 / 副炮 / 水雷 / 鱼雷），字段显式白名单见各分支 */
function _weaponToMountConfigRaw(weapon, shipWeaponCfg, baseStats) {
  var bonuses = weapon.bonuses || {};
  baseStats = baseStats || {};

  // 计算叠加后的有效属性：战舰基础 + 武器加成
  var effCrit        = (baseStats.critChance        || 0) + (bonuses.critChance        || 0);
  var effShatter     = (baseStats.shatterChance     || 0) + (bonuses.shatterChance     || 0);
  var effCritDmg     = (baseStats.critDmg           || 0) + (bonuses.critDmg           || 0);
  var effPenetration = (baseStats.penetrationChance || 0) + (bonuses.penetrationChance || 0);
  var effBurnChance  = (baseStats.burnChance        || 0) + (bonuses.burnChance        || 0);
  var effBurnPower   = (baseStats.burnPower         || 0) + (bonuses.burnPower         || 0);
  var effBurnSpeed   = (baseStats.burnSpeed         || 0) + (bonuses.burnSpeed         || 0);
  var effBurnDur     = (baseStats.burnDuration      || 0) + (bonuses.burnDuration      || 0);
  var effPenDmg      = (baseStats.penDmg            || 0) + (bonuses.penDmg            || 0);
  var effBonusVsBurn = (baseStats.bonusVsBurning    || 0) + (bonuses.bonusVsBurning    || 0);
  var effFloodChance = (baseStats.floodChance       || 0) + (bonuses.floodChance       || 0);
  var effAccessoryChance = (baseStats.accessoryChance || 0) + (bonuses.accessoryChance || 0);  // 配损几率（2026-09-05，主炮/鱼雷/水雷）
  var effWeaponDamageChance = (baseStats.weaponDamageChance || 0) + (bonuses.weaponDamageChance || 0);  // 武损几率（2026-09-13，主炮/鱼雷/水雷）
  var effFloodPower  = (baseStats.floodPower        || 0) + (bonuses.floodPower        || 0);
  var effFloodSpeed  = (baseStats.floodSpeed        || 0) + (bonuses.floodSpeed        || 0);
  var effFloodDur    = (baseStats.floodDuration     || 0) + (bonuses.floodDuration     || 0);
  var effFinalDmg    = (baseStats.finalDmg          || 0) + (bonuses.finalDmg          || 0);
  var effShatterPwr  = (baseStats.shatterPower      || 0) + (bonuses.shatterPower      || 0);
  var effMainPen     = (baseStats.mainPen            || 0) + (bonuses.mainPen            || 0);
  var effTorpPen     = (baseStats.torpPen            || 0) + (bonuses.torpPen            || 0);
  var effExeChance    = (baseStats.executeChance    || 0) + (bonuses.executeChance    || 0);
  var effShieldShred = (baseStats.shieldShred || 0) + (bonuses.shieldShred || 0);
  var effIgnoreFinalReduce = (baseStats.ignoreFinalReduce || 0) + (bonuses.ignoreFinalReduce || 0);
  var effExeDmg       = (baseStats.executeDmg       || 0) + (bonuses.executeDmg       || 0);
  var effExeThreshold = (baseStats.executeThreshold || 0) + (bonuses.executeThreshold || 0);

  // 武器真伤汇总（2026-09-19 字人规格）：「武器真伤」（通用）与对应武器的专属真伤
  //   属同类词条 → 数值简单相加；面板伤害基数为「武器总面板」（weapon.damage = 联装总伤害）。
  //   例：四联装面板 20000（每发 5000），武器真伤 10% → 每发 +2000 = 7000，四发 28000。
  var _trueDmgKey = weapon.type === 'mainGun' ? 'mainTrueDmg'
    : weapon.type === 'torpedo' ? 'torpTrueDmg'
      : weapon.type === 'mine' ? 'mineTrueDmg' : 'secTrueDmg';
  var effTrueDmg = (baseStats.trueDmg || 0) + (bonuses.trueDmg || 0)
    + (baseStats[_trueDmgKey] || 0) + (bonuses[_trueDmgKey] || 0);

  if (weapon.type === 'mainGun') {
    return {
      mountCount: 1,
      barrelsPerMount: weapon.barrelsPerMount,
      cooldownSec: shipWeaponCfg.cooldownSec,
      damage: Math.round(weapon.damage / weapon.barrelsPerMount),
      shellSpeed: weapon.shellSpeed * 0.057,
      spreadAngle: weapon.spreadAngle,
      landingDeviation: weapon.landingDeviation,
      shellRadius: weapon.shellRadius,
      trailFrames: weapon.trailFrames,
      playerColor: weapon.color,
      enemyColor: shipWeaponCfg.enemyColor || '#DD1111',
      range: shipWeaponCfg.range,
      holdInterval: shipWeaponCfg.holdInterval,
      critChance: effCrit,
      shatterChance: effShatter,
      critDmg: effCritDmg,
      penetrationChance: effPenetration,
      burnChance: effBurnChance,
      burnPower: effBurnPower,
      burnSpeed: effBurnSpeed,
      burnDuration: effBurnDur,
      accessoryChance: effAccessoryChance,
      weaponDamageChance: effWeaponDamageChance,
      penDmg: effPenDmg,
      bonusVsBurning: effBonusVsBurn,
      finalDmg: effFinalDmg,
      shatterPower: effShatterPwr,
      mainPen: effMainPen,
      executeChance: effExeChance,
      executeDmg: effExeDmg,
      executeThreshold: effExeThreshold,
      shieldShred: effShieldShred,
      ignoreFinalReduce: effIgnoreFinalReduce,
      trueDmg: effTrueDmg,             // 武器真伤（通用 + 主炮真伤，2026-09-19）
      panelDamage: weapon.damage,      // 真伤基数 = 武器总面板（联装总伤害）
      shellCaliber: baseStats.shellCaliber || 'medium',
      shotAccuracy: baseStats.shotAccuracy != null ? baseStats.shotAccuracy : 1,
    };
  }
  if (weapon.type === 'secondary') {
    // 副炮：只保留 暴击/碎甲 系加成；无穿甲/燃烧/漏水/最终增伤
    return {
      mountCount: 1,
      barrelsPerMount: weapon.barrelsPerMount,
      cooldownSec: shipWeaponCfg.cooldownSec,
      damage: Math.round(weapon.damage / weapon.barrelsPerMount),
      shellSpeed: weapon.shellSpeed * 0.057,
      spreadAngle: weapon.spreadAngle,
      landingDeviation: weapon.landingDeviation,
      shellRadius: weapon.shellRadius,
      trailFrames: weapon.trailFrames,
      playerColor: weapon.color,
      enemyColor: shipWeaponCfg.enemyColor || '#DD1111',
      range: shipWeaponCfg.range,
      holdInterval: shipWeaponCfg.holdInterval,
      critChance: effCrit,
      shatterChance: effShatter,
      critDmg: effCritDmg,
      shatterPower: effShatterPwr,
      executeChance: effExeChance,
      executeDmg: effExeDmg,
      executeThreshold: effExeThreshold,
      shieldShred: effShieldShred,
      ignoreFinalReduce: effIgnoreFinalReduce,
      trueDmg: effTrueDmg,             // 武器真伤（通用 + 副炮真伤，2026-09-19）
      panelDamage: weapon.damage,      // 真伤基数 = 武器总面板
      shellCaliber: 'small',   // 副炮恒小口径
      shotAccuracy: baseStats.shotAccuracy != null ? baseStats.shotAccuracy : 1,
      alpha: weapon.alpha || 1,
      isSecondary: true,
    };
  }
  // mine
  if (weapon.type === 'mine') {
    // 水雷半径/存在时间优先级（2026-08-07 修复）：
    //   ① 武器数据优先（weapon.detonationRadiusKM 等）——修 bug：船默认值 0.75/2.45/135 永远非 null，
    //      导致自建大半径水雷的 detonationRadiusKM 被忽略（生成弹丸恒用船默认值）
    //   ② 船字段仅在"词条调节过"（≠ 默认常量）时覆盖武器数据
    var mineDetRad = (baseStats.detonationRadius != null && baseStats.detonationRadius !== MINE_DETONATION_KM)
      ? baseStats.detonationRadius : weapon.detonationRadiusKM;
    var mineExpRad = (baseStats.explosionRadius != null && baseStats.explosionRadius !== MINE_EXPLOSION_KM)
      ? baseStats.explosionRadius : weapon.explosionRadiusKM;
    var mineLife = (baseStats.lifetimeSec != null && baseStats.lifetimeSec !== MINE_LIFETIME_SEC)
      ? baseStats.lifetimeSec : (weapon.lifetimeSec != null ? weapon.lifetimeSec : MINE_LIFETIME_SEC);
    return {
      mountCount: 1,
      barrelsPerMount: 1,
      cooldownSec: shipWeaponCfg.cooldownSec,
      damage: Math.round(weapon.damage),
      detonationRadius: mineDetRad * PX_PER_KM,
      explosionRadius:  mineExpRad  * PX_PER_KM,
      lifetimeSec:       mineLife,
      trueDmg: effTrueDmg,             // 武器真伤（通用 + 水雷真伤，2026-09-19）
      panelDamage: weapon.damage,      // 真伤基数 = 武器总面板（水雷联装恒 1，即 damage）
      color: weapon.color || '#000000',
      holdInterval: shipWeaponCfg.holdInterval,
      critChance: effCrit,
      shatterChance: effShatter,
      critDmg: effCritDmg,
      floodChance: effFloodChance,
      floodPower: effFloodPower,
      floodSpeed: effFloodSpeed,
      floodDuration: effFloodDur,
      accessoryChance: effAccessoryChance,
      weaponDamageChance: effWeaponDamageChance,
      finalDmg: effFinalDmg,
      shatterPower: effShatterPwr,
      bonusVsBurning: effBonusVsBurn,
      executeChance: effExeChance,
      executeDmg: effExeDmg,
      executeThreshold: effExeThreshold,
      shieldShred: effShieldShred,
      ignoreFinalReduce: effIgnoreFinalReduce,
    };
  }
  // torpedo
  // 鱼雷专属通道（2026-10-01 阳炎-利刃基础设施）：
  //   torpPanelDmgPct —— 每管伤害 += 武器总面板 × pct（**不分摊**，每管都加整笔；吃一切减伤）
  //     例：四联装面板 20000（每管 5000）+ 5% → 每管 = 5000 + 20000×5% = 6000（不是 5250）
  //     ★与真伤的本质区别：真伤在 collision-hit 末尾加法（绕过全部减伤），本项在**基础伤害**里，
  //       所以走正常减伤链路，且不需要弹丸携带 proj.torpPanelDmgPct 字段。
  //   torpedoSpeedAdd  —— 直接加到 weapon.speed（单位「节」，**不是**炮速的 ×0.057）；弹丸构造时快照。
  //   torpedoSpeedPct  —— 鱼雷航速百分比（2026-10-03 舰种技能「鱼雷改进」）。⚠️ 加法口径 B 方案
  //     （设计文档 §4，字人确认）：`实际航速 = 面板基础 × (1 + Σ百分比) + Σ固定值`。
  //     **百分比只乘武器面板 speed，不吃其他来源的固定值**（阳炎自带 +30 节不会被 +5% 再乘一次）。
  //     例：面板 60 节，+5% +10% +5节 → 60×1.15 + 5 = 74；面板 60 + 5% + 固定 30 → 60×1.05 + 30 = 93。
  //     ⚠️ 无百分比时 `weapon.speed * (1 + 0) + 0` 与原 `weapon.speed + 0` 逐字节等价，不破坏存量鱼雷。
  //   ★这三个键只服务鱼雷，故不进 effXxx 汇总池；主炮/副炮/水雷分支不受影响（属性专属隔离）。
  var effTorpPanelDmgPct = (baseStats.torpPanelDmgPct || 0) + (bonuses.torpPanelDmgPct || 0);
  var effTorpedoSpeedAdd = (baseStats.torpedoSpeedAdd || 0) + (bonuses.torpedoSpeedAdd || 0);
  var effTorpedoSpeedPct = (baseStats.torpedoSpeedPct || 0) + (bonuses.torpedoSpeedPct || 0);
  return {
    mountCount: 1,
    barrelsPerMount: weapon.barrelsPerMount,
    cooldownSec: shipWeaponCfg.cooldownSec,
    damage: Math.round(weapon.damage / weapon.barrelsPerMount)
           + Math.round(weapon.damage * effTorpPanelDmgPct),
    trueDmg: effTrueDmg,             // 武器真伤（通用 + 鱼雷真伤，2026-09-19）
    panelDamage: weapon.damage,      // 真伤基数 = 武器总面板（联装总伤害）
    speed: weapon.speed * (1 + effTorpedoSpeedPct) + effTorpedoSpeedAdd,
    scatterAngle: weapon.scatterAngle,
    torpedoRadius: weapon.torpedoRadius,
    trailFrames: weapon.trailFrames,
    playerColor: '#FFFFFF',
    enemyColor: shipWeaponCfg.enemyColor || '#AA1111',
    range: shipWeaponCfg.range,
    holdInterval: shipWeaponCfg.holdInterval,
    critChance: effCrit,
    shatterChance: effShatter,
    critDmg: effCritDmg,
    penetrationChance: effPenetration,
    floodChance: effFloodChance,
    floodPower: effFloodPower,
    floodSpeed: effFloodSpeed,
    floodDuration: effFloodDur,
    accessoryChance: effAccessoryChance,
    weaponDamageChance: effWeaponDamageChance,
    finalDmg: effFinalDmg,
    shatterPower: effShatterPwr,
    bonusVsBurning: effBonusVsBurn,
    torpPen: effTorpPen,
    executeChance: effExeChance,
    executeDmg: effExeDmg,
    executeThreshold: effExeThreshold,
    shieldShred: effShieldShred,
    ignoreFinalReduce: effIgnoreFinalReduce,
    // 鱼雷精度（2026-10-02 阳炎-利刃数据表「鱼雷精度 20%」）：
    //   与主炮/副炮的 shotAccuracy 共享同一弹丸字段 proj.shotAccuracy，
    //   collision.js 鱼雷跳弹分支统一读 proj.shotAccuracy（!= null ? : 1 兜底为 1）。
    //   公式：精度 = (baseStats.shotAccuracy ?? 1) + (baseStats.torpedoAccuracy ?? 0)
    //   → 阳炎「鱼雷精度 20%」（torpAcc=0.2，无 shotAccuracy）= 1.20。
    shotAccuracy: (baseStats.shotAccuracy != null ? baseStats.shotAccuracy : 1)
                + (baseStats.torpedoAccuracy != null ? baseStats.torpedoAccuracy : 0),
  };
}
