/**
 * mines.js — 水雷武器库（独立文件，未来可扩展）
 */
var MINE_WEAPONS = Object.freeze([
  Object.freeze({
    id: 'destroyer-sea-mine-4-1A',
    name: '驱-水压水雷4-1A',
    type: 'mine',
    shipType: 'destroyer',
    barrelsPerMount: 1,
    damage: 8799,
    detonationRadiusKM: MINE_DETONATION_KM,   // 0.75 km
    explosionRadiusKM:  MINE_EXPLOSION_KM,    // 2.45 km
    lifetimeSec: MINE_LIFETIME_SEC,            // 135 s
    color: '#000000',
    bonuses: Object.freeze({
      floodChance: 0.10,   // +10% 漏水几率
    }),
  }),
  // 巡洋水雷「巡-强袭者」（2026-08-08）：伤害高、爆炸半径大、带漏水+暴击伤害
  Object.freeze({
    id: 'cruiser-assaulter',
    name: '巡-强袭者',
    type: 'mine',
    shipType: 'cruiser',
    barrelsPerMount: 1,
    damage: 10679,
    detonationRadiusKM: 0.75,   // 引爆半径 0.75 km
    explosionRadiusKM:  2.45,   // 爆炸半径 2.45 km
    lifetimeSec: 131,           // 存在时间 131 s
    color: '#000000',
    bonuses: Object.freeze({
      floodChance: 0.10,   // +10% 漏水几率
      floodDuration: 0.40, // +40% 漏水延长（持续时间）
      floodPower: 0.12,    // +12% 漏水程度（每跳伤害）
      critDmg: 0.06,       // +6% 暴击伤害
    }),
  }),
  // 战列水雷「战-炎中盘龙」（2026-08-08）：暴击+漏水双词条
  Object.freeze({
    id: 'battleship-flame-dragon',
    name: '战-炎中盘龙',
    type: 'mine',
    shipType: 'battleship',
    barrelsPerMount: 1,
    damage: 10740,
    detonationRadiusKM: 0.75,   // 引爆半径 0.75 km
    explosionRadiusKM:  2.5,    // 爆炸半径 2.5 km
    lifetimeSec: 120,           // 存在时间 120 s
    color: '#000000',
    bonuses: Object.freeze({
      critChance: 0.06,   // +6% 暴击几率
      critDmg:    0.08,   // +8% 暴击伤害
      floodChance: 0.05,  // +5% 漏水几率
      floodPower:  0.10,  // +10% 漏水程度
    }),
  }),
]);
