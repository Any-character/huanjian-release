/**
 * torpedoes.js — 鱼雷武器库（独立文件，未来可扩展）
 * 2026-08-08：删除巡洋测试鱼雷（testA/testB）——玩家鱼雷换正式武器
 */
var TORPEDO_WEAPONS = Object.freeze([
  Object.freeze({
    id: 'cruiser-610mm-S',
    name: '巡-610mm-S',
    type: 'torpedo',
    shipType: 'cruiser',
    barrelsPerMount: 4,
    damage: 27342,
    speed: 51.6,
    color: '#AABBCC',
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    bonuses: Object.freeze({
      finalDmg: 0.05,
      shatterChance: 0.05,
      shatterPower: 0.10,
    }),
  }),
  Object.freeze({
    id: 'cruiser-assault-bull',
    name: '巡-突袭蛮牛',
    type: 'torpedo',
    shipType: 'cruiser',
    barrelsPerMount: 4,
    damage: 21874,
    speed: 69.7,
    color: '#FF9966',
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    bonuses: Object.freeze({
      floodChance: 0.05,
      critDmg: 0.06,
      floodPower: 0.12,
    }),
  }),
  Object.freeze({
    id: 'destroyer-610mm-contract',
    name: '驱-610mm-契约',
    type: 'torpedo',
    shipType: 'destroyer',
    barrelsPerMount: 4,
    damage: 19593,
    speed: 63.9,
    color: '#FFFFFF',
    torpedoRadius: 4,
    trailFrames: 8,
    scatterAngle: 5 * Math.PI / 180,
    bonuses: Object.freeze({
      critDmg: 0.1,      // +10% 暴击伤害（暴击时伤害 ×2.2）
    }),
  }),
]);
