/**
 * ship-loadout.js — 每艘船默认武器负载 + localStorage 持久化
 */
var DEFAULT_LOADOUT = {
  guying: {
    mainGun: ['cruiser-burst-impact', 'cruiser-burst-impact', 'cruiser-burst-impact'],   // 2026-08-08 测试主炮删除 → 速爆冲击
    torpedo: ['cruiser-610mm-S', 'cruiser-610mm-S'],                                      // 测试鱼雷删除 → 610-S
    secondary: ['cruiser-130mm-proto', 'cruiser-130mm-proto', 'cruiser-130mm-proto', 'cruiser-130mm-proto'],  // 巡-130mm原型 ×4（2026-08-08）
    mine: ['cruiser-assaulter', 'cruiser-assaulter'],  // 巡-强袭者 ×2（2026-08-08）
  },
  cleveland: {
    mainGun: ['cruiser-burst-impact','cruiser-burst-impact','cruiser-burst-impact','cruiser-burst-impact','cruiser-burst-impact','cruiser-burst-impact'],  // 2026-08-08
    torpedo: ['cruiser-610mm-S','cruiser-610mm-S','cruiser-610mm-S','cruiser-610mm-S'],   // 2026-08-08
    mine: [],
  },
  fantasque: {
    mainGun: ['destroyer-127mm-contract', 'destroyer-127mm-contract', 'destroyer-127mm-contract', 'destroyer-127mm-contract', 'destroyer-127mm-contract'],
    torpedo: ['destroyer-610mm-contract', 'destroyer-610mm-contract', 'destroyer-610mm-contract'],
    mine: ['destroyer-sea-mine-4-1A', 'destroyer-sea-mine-4-1A', 'destroyer-sea-mine-4-1A'],
  },
  vanguard: {
    mainGun: ['battleship-460mm-contract', 'battleship-460mm-contract', 'battleship-460mm-contract', 'battleship-460mm-contract'],
    secondary: ['battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12'],
    torpedo: [],
    mine: [],
  },
  yanyin: {
    // 阳炎-利刃：3 主炮（前1后2）+ 2 鱼雷（舰中）+ 5 水雷；武器沿用驱-系列（2026-10-01）
    mainGun: ['destroyer-127mm-contract', 'destroyer-127mm-contract', 'destroyer-127mm-contract'],
    torpedo: ['destroyer-610mm-contract', 'destroyer-610mm-contract'],
    mine: ['destroyer-sea-mine-4-1A', 'destroyer-sea-mine-4-1A', 'destroyer-sea-mine-4-1A', 'destroyer-sea-mine-4-1A', 'destroyer-sea-mine-4-1A'],
  },
  a140a: {
    // 3 主炮（全舰首）+ 10 副炮（左4 / 右4 / 舰中2）；武器选型与前卫一致（2026-09-19 字人确认）
    mainGun: ['battleship-460mm-contract', 'battleship-460mm-contract', 'battleship-460mm-contract'],
    secondary: ['battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12'],
    torpedo: [],
    mine: [],
  },
  fargo: {
    mainGun: ['cruiser-burst-impact', 'cruiser-burst-impact', 'cruiser-burst-impact', 'cruiser-burst-impact'],   // 4 主炮（2026-08-08 测试武器删除 → 速爆冲击）
    secondary: ['cruiser-130mm-proto', 'cruiser-130mm-proto', 'cruiser-130mm-proto', 'cruiser-130mm-proto', 'cruiser-130mm-proto', 'cruiser-130mm-proto'],  // 6 副炮
    torpedo: [],
    mine: [],
  },
  tsar: {
    mainGun: ['battleship-460mm-contract', 'battleship-460mm-contract', 'battleship-460mm-contract', 'battleship-460mm-contract'],  // 4 主炮（2026-08-09）
    secondary: ['battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12'],                      // 4 副炮
    torpedo: [],
    mine: ['battleship-flame-dragon', 'battleship-flame-dragon', 'battleship-flame-dragon'],                                       // 3 水雷（战-炎中盘龙）
  },
  wisconsin: {
    // 威斯康星（2026-11-08）：3 主炮（前2后1）+ 8 副炮 + 2 水雷；主炮用最新的四联装「战-赤色霞光」
    mainGun: ['battleship-crimson-glow', 'battleship-crimson-glow', 'battleship-crimson-glow'],
    secondary: ['battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12',
                'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12', 'battleship-152mm-12'],
    torpedo: [],
    mine: ['battleship-flame-dragon', 'battleship-flame-dragon'],
  },
};

function loadLoadout(shipId) {
  try {
    var raw = localStorage.getItem('huanjian.loadout.' + shipId);
    if (raw) {
      var parsed = JSON.parse(raw);
      // 验证所有武器ID仍然有效，若有无效则回退默认
      var valid = true;
      for (var type in parsed) {
        for (var i = 0; i < parsed[type].length; i++) {
          if (!getWeaponById(parsed[type][i])) { valid = false; break; }
        }
        if (!valid) break;
      }
      if (valid) {
        // 老存档升级（2026-08-08）：新武器类型缺键/空数组 → 补默认装配
        // （例：古鹰老档只有 mainGun/torpedo，没有 secondary/mine → 补 4 副炮 + 2 水雷）
        var defL = DEFAULT_LOADOUT[shipId];
        if (defL) {
          var upgraded = false;
          for (var dt in defL) {
            if (!parsed[dt] || parsed[dt].length === 0) {
              parsed[dt] = JSON.parse(JSON.stringify(defL[dt]));
              upgraded = true;
            }
          }
          if (upgraded) {
            saveLoadout(shipId, parsed);   // 回写，下次直接读新档
          }
        }
        return parsed;
      }
    }
  } catch (e) {}
  var def = DEFAULT_LOADOUT[shipId];
  if (!def) {
    // Mod 船未注册默认负载 → 返回空负载（不崩，只是无武器；规范要求 Mod 注册 DEFAULT_LOADOUT）
    return { mainGun: [], torpedo: [], mine: [], secondary: [] };
  }
  return JSON.parse(JSON.stringify(def));
}

function saveLoadout(shipId, loadout) {
  try {
    localStorage.setItem('huanjian.loadout.' + shipId, JSON.stringify(loadout));
  } catch (e) {}
}
