/**
 * yanyin-pursuit.js — 阳炎-利刃「鱼雷追击」技能（2026-10-01）
 *
 * 纯被动机制（无主动、无冷却）。四个子机制：
 *
 *   ① 布雷（每颗水雷）→ 立即装填**剩余装填时间最长**的那一座鱼雷炮位（全部就绪则浪费）
 *                    → 反雷达干扰 +1km，10s（buff `antiRadarJamming`，同 key 覆盖式刷新）
 *                    → 机动性 +10%，10s（buff `speedMulAdd`，见下方「加法通道」说明）
 *   ② 释放鱼雷（每轮齐射）→ 等概率 4 选 1，给**下一颗水雷**挂待命强化
 *                    （引爆 +1km / 爆炸 +2.5km / 暴击 +50 个百分点 / 无效果），
 *                    写入 `ship._pendingMineBuff`，由 `ship-weapons.js` fireMine 一次性消费。
 *   ③ 鱼雷命中敌舰 → 临时层 +1（0~5，30s 刷新式）
 *   ④ 击沉/助攻敌舰 → 永久层 +1（0~5，不随时间消失）
 *      助攻判定数据源 = `target._stats.assisters`（battle-stats.js checkDeaths 帧末算好，
 *      窗口 20s、排除最后一击者与同阵营），见下方 scanKills。
 *
 * 两类层数合并生效：buff `yanyinReloadStack` 的 mod `reloadFlatReduce_mine` = 0.5 × (temp + perm)。
 * 通道已存在（`Ship.getWeaponReloadSec` 动态拼 `reloadFlatReduce_` + weaponKey），无需新建。
 *
 * ── 加法通道说明（重要，勿改成 speedMul: 1.10）────────────────────────────────
 * 消费点在 `ship-mobility.js` Ship.smoothSpeed：
 *     var sa = this.getBuffMod('speedMulAdd'); if (sa) speedMult *= (1 + sa);
 *     var sp = this.getBuffMod('speedMulPen'); if (sp) speedMult *= (1 - sp);
 * `speedMulAdd` 本身就是**加法百分比**通道：多来源的 mods 先被 getBuffMod **相加**，
 * 再以 (1 + 和) 一次性相乘。故本模块用 `speedMulAdd: 0.10` 得到 +10%，
 * 与「畏惧光环 speedMulPen」等其它来源**不会**互相污染（不同 key，且消费点分别相乘）。
 * 若误用不存在的乘法型 `speedMul: 1.10`，才会出现 getBuffMod 求和成 2.0 的问题 —— 该 key 无人消费。
 * ⚠️ 项目**没有**转向转速的 buff 通道（smoothTurn 只消费 `noTurn`），故「机动性 +10%」只作用于航速。
 *
 * ── temp 层到期 ──────────────────────────────────────────────────────────────
 * temp 层的存活由 buff `yanyinReloadStack` 的 endTime 承载（每次鱼雷命中刷新 30s）；
 * perm 层是 ship 上的纯数字字段、不挂 buff。本模块 `update` 每帧检测
 * 「buff 已过期但 temp > 0」→ temp 归零 → 按剩余 perm 重建 buff（endTime = Infinity = 永久）。
 *
 * 加载顺序：后于 systems/registry.js（末尾自登记 GameSystems）、constants.js（PX_PER_KM）。
 */

  /** 技能 id（与 ships/yanyin.js 配置一致） */
  const YANYIN_PURSUIT_SKILL_ID = 'yanyin-pursuit';
  /** 临时层 / 永久层各自上限（总上限 10） */
  const YANYIN_PURSUIT_MAX_LAYERS = 5;
  /** 每层水雷装填常数缩减（秒） */
  const YANYIN_PURSUIT_RELOAD_PER_LAYER = 0.5;
  /** 临时层持续（ms），每次鱼雷命中刷新 */
  const YANYIN_PURSUIT_TEMP_MS = 30000;
  /** 反雷达干扰 buff：持续（ms）/ 数值（km） */
  const YANYIN_PURSUIT_ANTIRADAR_MS = 10000;
  const YANYIN_PURSUIT_ANTIRADAR_KM = 1;
  /** 机动性 buff：持续（ms）/ 数值（小数，0.10 = +10%，走 speedMulAdd 加法通道） */
  const YANYIN_PURSUIT_MOBILITY_MS = 10000;
  const YANYIN_PURSUIT_MOBILITY_ADD = 0.10;
  /** 随机「下一颗水雷」四项的取值（单位见字段名：px / 小数） */
  const YANYIN_PURSUIT_DETONATION_ADD = 1 * PX_PER_KM;      // +1km 引爆半径
  const YANYIN_PURSUIT_EXPLOSION_ADD = 2.5 * PX_PER_KM;     // +2.5km 爆炸半径
  const YANYIN_PURSUIT_CRIT_CHANCE_ADD = 0.5;               // +50 个百分点（非 ×1.5）

const YanyinPursuit = {
  /** 该舰是否拥有「鱼雷追击」（读战舰技能配置；不看存活，死后仍返回 true 便于清理） */
  hasPursuit(ship) {
    const skills = ship && ship._shipConfig && ship._shipConfig.skills;
    if (!skills) return false;
    for (let i = 0; i < skills.length; i++) {
      if (skills[i].id === YANYIN_PURSUIT_SKILL_ID) return true;
    }
    return false;
  },

  /**
   * 布雷（**每颗**水雷）触发 —— ship-weapons.js fireMine 内、弹丸构造与
   * _pendingMineBuff 消费**之后**调用（本次布的雷已定型，技能只影响「下一颗」）。
   */
  onMineFired(ship, now) {
    now = now != null ? now : Date.now();
    // ① 立即装填剩余装填时间最长的鱼雷炮位（全部就绪 = 浪费）
    this._reloadLongestTorpedo(ship, now);
    // ② 反雷达干扰 +1km / 10s —— 同 key 覆盖式，数值恒 +1km，仅刷新 endTime
    ship.addBuff('yanyinAntiRadar', '反雷达干扰+1km', now + YANYIN_PURSUIT_ANTIRADAR_MS,
      { antiRadarJamming: YANYIN_PURSUIT_ANTIRADAR_KM }, 1);
    // ③ 机动性 +10% / 10s —— **综合词条，四项通道同加**（2026-10-01 字人确认：
    //   「机动性是新词条，最大航速/加速功率/转向转速/转向功率都加，类比武器真伤之于各武器专属真伤」）。
    //   四个 mod 键都是加法通道、消费点统一 `* (1 + getBuffMod(key))`，多来源先求和再乘算。
    //   ⚠ speedMulAdd = 最大航速（ship-mobility.js smoothSpeed）
    //   ⚠ accelPowerAdd = 加速功率（smoothSpeed）；rotationSpeedAdd = 转向转速（smoothTurn）；
    //   ⚠ turnPowerAdd = 转向功率（smoothTurn）
    //   rotateLeft/rotateRight 是遗留死函数（游戏代码零调用），全部转向经 rudderInput→smoothTurn，
    //   故改 smoothTurn 即 100% 覆盖（单测 78.06 固化该决策）。
    var mob = YANYIN_PURSUIT_MOBILITY_ADD;
    ship.addBuff('yanyinMobility', '机动性+10%', now + YANYIN_PURSUIT_MOBILITY_MS,
      { speedMulAdd: mob, accelPowerAdd: mob, rotationSpeedAdd: mob, turnPowerAdd: mob }, 1);
  },

  /**
   * 释放鱼雷（**每轮**齐射一次）触发 —— ship-weapons.js fireTorpedo 返回前调用。
   * 等概率 4 选 1，给下一颗水雷挂待命强化（④ 无效果 = 不设 _pendingMineBuff）。
   * 覆盖式写入：若上一颗的待命强化还没被消费，本次结果直接取代（不排队、不叠加）。
   */
  onTorpedoFired(ship, now) {
    const roll = Math.random();
    if (roll < 0.25) {
      ship._pendingMineBuff = { detonationAdd: YANYIN_PURSUIT_DETONATION_ADD };
    } else if (roll < 0.5) {
      ship._pendingMineBuff = { explosionAdd: YANYIN_PURSUIT_EXPLOSION_ADD };
    } else if (roll < 0.75) {
      ship._pendingMineBuff = { critChanceAdd: YANYIN_PURSUIT_CRIT_CHANCE_ADD };
    } else {
      ship._pendingMineBuff = null;   // ④ 无效果
    }
  },

  /**
   * 鱼雷命中敌舰（伤害已结算）→ 临时层 +1（封顶 5），并刷新 30s 窗口。
   * 已满层时不再叠加，但**仍然刷新** 30s（刷新式语义）。
   */
  onTorpedoHit(ship, target, now) {
    now = now != null ? now : Date.now();
    if (!ship._yanyinTempLayers) ship._yanyinTempLayers = 0;
    if (ship._yanyinTempLayers < YANYIN_PURSUIT_MAX_LAYERS) ship._yanyinTempLayers++;
    this._refreshReloadBuff(ship, now);
  },

  /**
   * 击沉 / 助攻敌舰 → 永久层 +1（封顶 5）。
   * @param {boolean} isAssist — true = 助攻（不是最后一击，但击沉前 20s 内对其造成过伤害）；
   *   false = 直接击沉（最后一击）。**两者对同一目标互斥**（scanKills 保证同一舰每目标只进一次），
   *   故 perm 层语义 = 「击沉或助攻击沉的敌舰数」，不随打了几发重复累加。
   * @param {Object} target — 被击沉的舰（当前实现只用它做 debug 参照，保留形参以备后续按目标区分）
   */
  onKill(ship, target, isAssist, now) {
    now = now != null ? now : Date.now();
    if (!ship._yanyinPermLayers) ship._yanyinPermLayers = 0;
    if (ship._yanyinPermLayers < YANYIN_PURSUIT_MAX_LAYERS) ship._yanyinPermLayers++;
    this._refreshReloadBuff(ship, now);
  },

  /**
   * 帧末扫描击沉事件（main.js 在 battleStats.checkDeaths 之后调一行）。
   *   击沉者 = `target._stats.lastAttacker`（battle-stats.onHit/onDot 已在每次承伤时写入，
   *     帧末即为**最后一击的伤害来源**）→ onKill(killer, target, **false**)。
   *   助攻者 = `target._stats.assisters`（battle-stats.checkDeaths 同帧算好：20s 窗口内有伤害、
   *     且非最后一击、且与目标不同阵营）→ onKill(assister, target, **true**)。
   *     该名单已排除 killer，故与击杀路径天然互斥。
   * 每艘被击沉的舰只结算一次（独立标记 `_yanyinKillScanned`，不复用 battleStats 的 counted）
   *   → **同一舰对同一目标最多 +1 层 perm**，无论击杀还是助攻、无论打了几发。
   */
  scanKills(ships, now) {
    now = now != null ? now : Date.now();
    const list = ships || [];
    for (let i = 0; i < list.length; i++) {
      const target = list[i];
      if (!target || target.isAlive || target._yanyinKillScanned) continue;
      target._yanyinKillScanned = true;   // 幂等闸门：击杀 + 助攻共用，只放行一次
      if (!target._stats) continue;
      const killer = target._stats.lastAttacker;
      if (killer && killer !== target && this._isFoeOf(killer, target) && this.hasPursuit(killer)) {
        this.onKill(killer, target, false, now);
      }
      const assisters = target._stats.assisters || [];
      for (let j = 0; j < assisters.length; j++) {
        const a = assisters[j];
        if (!a || a === target || a === killer) continue;   // 与击杀者互斥（名单本身也已排除）
        if (!this._isFoeOf(a, target)) continue;            // 同阵营（友伤/自伤）不计
        if (this.hasPursuit(a)) this.onKill(a, target, true, now);
      }
    }
  },

  /**
   * 每帧维护（GameSystems 驱动，玩家 + AI 友军各自调用）：
   *   ① 临时层到期（buff 已过期但 temp 仍 > 0）→ temp 归零，perm 保留并重建常驻 buff
   *   ② 帧末击沉扫描（永久层）
   */
  update(ship, dt, now, allies, enemies) {
    if (!this.hasPursuit(ship)) return;
    now = now != null ? now : Date.now();
    // ① temp 到期（hasBuff 走 endTime > now，与 cleanBuffs 的执行时机无关）
    if ((ship._yanyinTempLayers || 0) > 0 && !ship.hasBuff('yanyinReloadStack', now)) {
      ship._yanyinTempLayers = 0;
      this._refreshReloadBuff(ship, now);
    }
    // ② 击沉扫描：只需扫敌方（我方舰不互伤，perm 层只可能来自击沉敌舰）
    const cand = [];
    if (enemies) for (let i = 0; i < enemies.length; i++) cand.push(enemies[i]);
    if (allies) for (let j = 0; j < allies.length; j++) cand.push(allies[j]);
    cand.push(ship);
    this.scanKills(cand, now);
  },

  /* ── 内部工具 ─────────────────────────────────────────────────────────── */

  /**
   * a 是否为 target 的敌对方（true = 可给击杀/助攻层）。
   * 同阵营（友伤/自伤）返回 false。口径与 battle-stats._collectAssisters 一致：
   * 双方都有 team 时才比较，缺失 team 视为敌对（沿用本模块原 scanKills 行为，不改旧语义）。
   */
  _isFoeOf(a, target) {
    if (!a || !target) return false;
    if (a.team && target.team && a.team === target.team) return false;
    return true;
  },

  /**
   * 立即装填剩余装填时间最长的**一座**鱼雷炮位。
   * 判定：cooldownEnd > now（尚在装填）中剩余时间最大者 → cooldownEnd = now（立即就绪）。
   * 全部就绪（无 cooldownEnd > now 者）→ 效果浪费，不动任何炮位。
   * 「一座」= 一个武器槽位，与联装管数无关（已确认决策 B3）。
   * ⚠️ 直接写 cooldownEnd（不经 getMountCooldownEnd）：武损中的炮位仍会被"装填"，
   *    但 isMountReady 在武损结束前恒 false —— 与既有「装填冻结」语义一致，不会造成提前开火。
   */
  _reloadLongestTorpedo(ship, now) {
    const mounts = ship.torpedoMounts || [];
    let best = null, bestRemain = 0;
    for (let i = 0; i < mounts.length; i++) {
      const m = mounts[i];
      if (!m) continue;
      const remain = m.cooldownEnd - now;
      if (remain > 0 && remain > bestRemain) { bestRemain = remain; best = m; }
    }
    if (best) best.cooldownEnd = now;
    return !!best;
  },

  /**
   * 按当前 temp + perm 重建装填加速 buff（单一出口，所有加层路径都走这里）。
   *   temp > 0 → endTime = now + 30s（刷新式窗口；每次鱼雷命中顺延）
   *   temp = 0 → endTime = Infinity（仅剩永久层，常驻不显示倒计时）
   *   合计 0   → 移除 buff（mod 自然消失）
   * layer 角标 = temp + perm（总计 0~10）。
   */
  _refreshReloadBuff(ship, now) {
    const temp = ship._yanyinTempLayers || 0;
    const perm = ship._yanyinPermLayers || 0;
    const total = temp + perm;
    if (total <= 0) { ship.removeBuff('yanyinReloadStack'); return; }
    const endTime = temp > 0 ? now + YANYIN_PURSUIT_TEMP_MS : Infinity;
    ship.addBuff('yanyinReloadStack', '水雷装填加速', endTime,
      { reloadFlatReduce_mine: YANYIN_PURSUIT_RELOAD_PER_LAYER * total }, total);
  },
};

// 系统自登记（2026-10-01）：main.js 经 GameSystems.updateAll 每帧对每艘本方舰调用
//（玩家 + AI 友军），故**无需**在 main.js gameLoop 单独插 update 调用。
// 击杀扫描也一并放在 update 里 —— checkDeaths 在 main.js 帧末，早于下一帧的 updateAll，
//  故 lastAttacker / _stats.assisters 在扫描时已是最终值（延迟 1 帧入账，不影响正确性）。
GameSystems.register('yanyin-pursuit', {
  order: 20,   // 后于 a140a-storm(10)
  update: function(ship, dt, now, allies, enemies) {
    YanyinPursuit.update(ship, dt, now, allies, enemies);
  },
});
