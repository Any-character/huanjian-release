/**
 * 血池系统（沙皇「血池熔铸」2026-08-09）
 *
 * 核心规则（字人确认）：
 * - 储入来源不限（武器/燃烧/漏水/技能/自己对自己），护盾吸收的伤害也算入 X
 * - 小伤害（X ≤ 5% 最大血量）：储入 20%（红场 40%），实际扣血返还 20%（等效扣 80%）
 * - 大伤害（X > 5% 最大血量）：全额扣血，储入 (X − 5% 最大血量) 全部
 * - 血池上限：普通 50% 最大血量；红场期 100%
 * - 储满 → 立即清池 + 30s 回复等量血量（回复期间受击不储入）
 * - 层数 L = 储量 / 上限 × 50（池储满 = 50 层）
 *   攻击向（武器规避[三口径+鱼雷+水雷]/穿甲伤害/暴击伤害）= 0.20 − L×0.002
 *   防御向（穿甲伤害减免 = L×0.01、暴击伤害减免 = L×0.02）
 * - 濒死保护：池 ≥ 25% 最大血量 且 受到致死伤害 → 免疫该次 + 10s 无敌 + 清池 + 10s 回复等量，冷却 120s
 * - 红场之魂（主动）：30s 内储入 40%、上限 100%；二次使用提前结算（30s 回全部池量）；
 *   结束/池满 → 清池 30s 回 70% + 25km 友军/敌军光环（30s，2026-08-09 字人更正）
 *
 * 加成走 buff 系统（bloodPoolBonus，池每次变化刷新）→ 增益图标可见。
 * ⚠️ 本类不依赖 main.js（allies/enemies 由 update 参数传入）。
 */
class BloodPool {
  constructor(ship, cfg) {
    cfg = cfg || {};
    this.ship = ship;
    this.maxHp = ship.maxHp || 1;
    this.stored = 0;
    this.maxPct = cfg.maxPct != null ? cfg.maxPct : 0.5;
    this.ratioSmall = cfg.ratioSmall != null ? cfg.ratioSmall : 0.2;
    this.ratioRed = cfg.ratioRed != null ? cfg.ratioRed : 0.4;
    this.reviveThreshold = cfg.reviveThreshold != null ? cfg.reviveThreshold : 0.25;
    this.reviveCooldownSec = cfg.reviveCooldownSec != null ? cfg.reviveCooldownSec : 120;
    this.reviveInvincibleSec = cfg.reviveInvincibleSec != null ? cfg.reviveInvincibleSec : 10;
    this.reviveRecoverSec = cfg.reviveRecoverSec != null ? cfg.reviveRecoverSec : 10;
    this.fullRecoverSec = cfg.fullRecoverSec != null ? cfg.fullRecoverSec : 30;
    this.redsquareSec = cfg.redsquareSec != null ? cfg.redsquareSec : 30;
    this.settleRecoverSec = cfg.settleRecoverSec != null ? cfg.settleRecoverSec : 30;
    this.settleRecoverPct = cfg.settleRecoverPct != null ? cfg.settleRecoverPct : 0.7;
    this.settleAuraSec = cfg.settleAuraSec != null ? cfg.settleAuraSec : 30;   // 结算光环 30s（2026-08-09 字人更正：与回血同步，总盾量=15% 池量/30s）
    this.settleAuraKm = cfg.settleAuraKm != null ? cfg.settleAuraKm : 25;
    this.settleAllyPct = cfg.settleAllyPct != null ? cfg.settleAllyPct : 0.15;
    this.settleEnemyPct = cfg.settleEnemyPct != null ? cfg.settleEnemyPct : 0.15;
    this.settleAllySpeed = cfg.settleAllySpeed != null ? cfg.settleAllySpeed : 0.05;
    this.settleEnemySpeed = cfg.settleEnemySpeed != null ? cfg.settleEnemySpeed : 0.15;
    this.cooldownSec = cfg.cooldownSec != null ? cfg.cooldownSec : 110;   // 红场之魂冷却（结束时才开始，2026-08-09）
    this.onHealTick = null;   // 回血飘字回调（main.js 注入）：fn(amount, worldX, worldY)
    this.onRevive = null;     // 濒死免疫飘字回调（main.js 注入）：fn(now, worldX, worldY)
    this.onEnemyDamage = null; // 红场压制敌舰掉血飘字回调（main.js 注入）：fn(amount, worldX, worldY)（2026-10-18）

    this.state = 'idle';            // 'idle' | 'redsquare' | 'recovering'
    this.stateEnd = 0;
    this.recoverTotal = 0;
    this.recoverDone = 0;
    this.recoverSec = 30;
    this._recoverAccum = 0;         // 回血 tick 累计（每秒一跳，2026-08-09）
    this.recoverDone = 0;
    this.recoverSec = 30;
    this.reviveReadyAt = 0;
    this.redsquareActive = false;   // 红场中（决定上限/储入比例）
    this.settleAura = null;         // { endTime, totalAllyShield, totalEnemyDmg, lastTick }
    this._allies = [];              // update 传入缓存（结算光环用）
    this._enemies = [];
  }

  getMaxStored() { return this.redsquareActive ? this.maxHp : this.maxHp * this.maxPct; }

  /** 层数 L = 储量 / 上限 × 50（上限随红场变化） */
  level() {
    var max = this.getMaxStored();
    if (max <= 0) return 0;
    return Math.min(50, Math.floor(this.stored / max * 50));
  }

  /**
   * 受击储入（takeDamage 末尾调用）。
   * 规则（2026-08-09 字人更正）：
   * - 小伤害（≤5% 最大血量）或**非武器伤害**（技能/dot/主动扣血）：一律按比例储入 20%（红场 40%）+ 返还
   * - **武器伤害**（gun/torp/mine）且 >5% 最大血量：全额扣，储入 (X − 5%最大血量)，不返还
   * @param {number} totalX — 本应损失血量 = 护盾吸收 + 实际扣血
   * @param {number} now
   * @param {boolean} isWeapon — 是否武器伤害（大伤害规则仅武器生效）
   * @returns {number} 返还比例（小伤害/非武器 0.2 或红场 0.4；武器大伤害/回复中 0）
   */
  onDamage(totalX, now, isWeapon) {
    now = now != null ? now : Date.now();   // 2026-08-09 修：0 是合法时间戳（0 || 默认 老坑）
    if (totalX <= 0 || this.state === 'recovering') return 0;
    var max = this.getMaxStored();
    var threshold = this.maxHp * 0.05;
    var refundPct = 0;
    var ratio = this.redsquareActive ? this.ratioRed : this.ratioSmall;
    if (isWeapon && totalX > threshold) {
      // 武器大伤害：超出 5% 部分全储，不返还（2026-08-09 字人更正：仅武器伤害走此流程）
      this.stored = Math.min(max, this.stored + (totalX - threshold));
    } else {
      // 小伤害 或 非武器伤害（技能/dot/主动扣血）：按比例储入 + 返还
      this.stored = Math.min(max, this.stored + totalX * ratio);
      refundPct = ratio;
    }
    this._refreshBonus(now);
    if (this.stored >= max) this._onFull(now);
    return refundPct;
  }

  /** 储满：清池 + 回复（红场期走红场结算，否则 30s 回 100% 池量） */
  _onFull(now) {
    var pool = this.stored;
    this.stored = 0;
    if (this.redsquareActive) {
      this._settleRedSquare(now, pool);
    } else {
      this._startRecover(now, pool, this.fullRecoverSec, 1.0);
    }
  }

  _startRecover(now, amount, sec, pct) {
    this.state = 'recovering';
    this.stateEnd = now + sec * 1000;
    var _rm = (this.ship.getRepairMult ? this.ship.getRepairMult() : 1);  // 维修效率加成（唯一入口，2026-10-01）
    this.recoverTotal = Math.round(amount * pct * _rm);
    this.recoverDone = 0;
    this.recoverSec = sec;
    this._refreshBonus(now);
  }

  /**
   * 每帧更新（main.js 调用）。allies/enemies 供红场结算光环使用。
   */
  update(dt, now, allies, enemies) {
    if (allies) this._allies = allies;
    if (enemies) this._enemies = enemies;
    // 结算光环（红场结算后 30s：友军加限时盾/敌军掉血）——必须在 recovering 之前处理，
    // 否则 _settleRedSquare 进入回复态后 return 导致光环永不生效（2026-08-09 修复）
    if (this.settleAura) {
      if (now < this.settleAura.endTime) {
        this._updateSettleAura(now);
      } else {
        this.settleAura = null;
      }
    }
    if (this.state === 'recovering') {
      if (this.recoverDone < this.recoverTotal) {
        // 每秒回一次（总量均摊到回复时长；2026-08-09 字人要求），飘绿字由 onHealTick 回调触发
        this._recoverAccum += dt;
        var tickSec = 1;
        if (this._recoverAccum >= tickSec) {
          this._recoverAccum -= tickSec;
          var perSec = this.recoverTotal / Math.max(0.1, this.recoverSec);
          var step = Math.round(Math.min(this.recoverTotal - this.recoverDone, perSec * tickSec));
          this.ship.hp = Math.min(this.ship.maxHp, Math.round(this.ship.hp + step));
          this.recoverDone += step;
          if (this.onHealTick && step > 0) this.onHealTick(step, this.ship.x, this.ship.y);
        }
      }
      if (now >= this.stateEnd || this.recoverDone >= this.recoverTotal) {
        this.state = 'idle';
        this.recoverDone = 0;
        this._recoverAccum = 0;
        if (this.redsquareActive) this.redsquareActive = false;   // 二次使用结算后退出红场
        this._refreshBonus(now);
      }
      return;
    }
    if (this.state === 'redsquare' && now >= this.stateEnd) {
      this.state = 'idle';
      this.redsquareActive = false;
      var pool = this.stored;
      this.stored = 0;
      this._settleRedSquare(now, pool);
      return;
    }
  }

  /** 红场结算：清池 → 30s 回 70% + 25km 友军/敌军光环 30s（每人总盾/掉血 = 清空前 15%，2026-08-09 字人更正）；此时才开始 110s 冷却 */
  _settleRedSquare(now, stored) {
    this._startRedSquareCooldown(now);
    this._startRecover(now, stored, this.settleRecoverSec, this.settleRecoverPct);
    this.settleAura = {
      endTime: now + this.settleAuraSec * 1000,
      totalAllyShield: stored * this.settleAllyPct,
      totalEnemyDmg: stored * this.settleEnemyPct,
      lastTick: now,
    };
  }

  /** 红场冷却（结束时才开始；ship._shipActiveCd 由 ship-skills 读取） */
  _startRedSquareCooldown(now) {
    if (!this.ship._shipActiveCd) this.ship._shipActiveCd = {};
    this.ship._shipActiveCd['tsar-redsquare'] = now + this.cooldownSec * 1000;
  }

  /** 结算光环：25km 友军加限时护盾（30s 内每秒加，每份 80s 后到期）+ 航速+5%；敌军减速−15%+掉血 */
  _updateSettleAura(now) {
    var a = this.settleAura;
    if (now - a.lastTick < 1000) return;
    a.lastTick = now;
    var rangePx = this.settleAuraKm * PX_PER_KM;
    var shieldPerTick = Math.round(a.totalAllyShield / this.settleAuraSec);
    var dmgPerTick = Math.round(a.totalEnemyDmg / this.settleAuraSec);
    var i;
    for (i = 0; i < this._allies.length; i++) {
      var al = this._allies[i];
      if (!al || !al.isAlive) continue;
      if (al === this.ship) continue;   // 不含自己（2026-08-09 字人更正）
      if (Math.hypot(al.x - this.ship.x, al.y - this.ship.y) > rangePx) continue;
      // 每个友军独立获得全额（总量 15% 池量，不均摊）；限时护盾 80s 后到期（2026-08-09 字人澄清）
      if (al.addTimedShield) al.addTimedShield(shieldPerTick, now + 80 * 1000);
      if (al.addBuff) al.addBuff('redsquareAlly', '红场庇护', now + 1100, { speedMulAdd: this.settleAllySpeed, noDuration: true });   // 条件性（每帧刷新）→ 不显示倒计时
    }
    for (i = 0; i < this._enemies.length; i++) {
      var en = this._enemies[i];
      if (!en || !en.isAlive) continue;
      if (Math.hypot(en.x - this.ship.x, en.y - this.ship.y) > rangePx) continue;
      if (en.addBuff) en.addBuff('redsquareEnemy', '红场压制', now + 1100, { speedMulPen: this.settleEnemySpeed });
      en.takeDamage(dmgPerTick, 'skill');
      // 敌舰压制掉血跳字（2026-10-18 字人要求「玩家造成的所有伤害都应当跳字」）
      if (dmgPerTick > 0 && this.onEnemyDamage) this.onEnemyDamage(dmgPerTick, en.x, en.y);
    }
  }

  /**
   * 濒死保护（takeDamage 扣血前调用）：池 ≥ 25% 且冷却好 → 免疫该次 + 10s 无敌 + 清池 + 10s 回复等量。
   * @returns {boolean} 是否触发
   */
  tryRevive(now) {
    now = now != null ? now : Date.now();   // 2026-08-09 修：0 是合法时间戳（0 || 默认 老坑）
    if (now < this.reviveReadyAt) return false;
    if (this.stored < this.maxHp * this.reviveThreshold) return false;
    var pool = this.stored;
    this.stored = 0;
    this.reviveReadyAt = now + this.reviveCooldownSec * 1000;
    this.ship.addBuff('invincible', '无敌', now + this.reviveInvincibleSec * 1000, {});
    this._startRecover(now, pool, this.reviveRecoverSec, 1.0);
    // 飘字提示（main.js 注入 onRevive）：让玩家明确看到濒死免疫触发（2026-08-09）
    if (this.onRevive) this.onRevive(now, this.ship.x, this.ship.y);
    return true;
  }

  /**
   * 红场之魂（主动）：进入红场态——储入 40%、上限 100%。
   * 立即损失 55% **最大血量**（2026-08-09 字人更正）：
   * - 该损失**非武器伤害**（不走 >5% 流程），吃 40% 储入加成
   * - 准备扣血量 = min(55% 最大血量, 当前血量)；血池 + 准备量×40%，实际扣 = 准备量×60%，护盾 = 实际扣血量
   * - 先储血池再扣血（防当前血量不足时先扣满触发死亡/濒死判定）
   */
  activateRedSquare(now) {
    now = now != null ? now : Date.now();   // 2026-08-09 修：0 是合法时间戳（0 || 默认 老坑）
    this.redsquareActive = true;
    this.state = 'redsquare';
    this.stateEnd = now + this.redsquareSec * 1000;
    var maxLoss = Math.round(this.ship.maxHp * 0.55);      // 55% 最大血量
    var pending = Math.min(maxLoss, Math.round(this.ship.hp));   // 准备扣血量（不足则全部当前血量）
    var storedAdd = Math.round(pending * this.ratioRed);   // 40% 储入
    var actualLoss = pending - storedAdd;                   // 实际扣 60%
    this.stored = Math.min(this.getMaxStored(), this.stored + storedAdd);   // 先储（防死亡判定）
    this.ship.hp = Math.max(0, this.ship.hp - actualLoss);
    this.ship.shield = (this.ship.shield || 0) + actualLoss;   // 护盾 = 实际扣血量
    this._refreshBonus(now);
    if (this.stored >= this.getMaxStored()) this._onFull(now);
  }

  /** 红场二次使用：还原上限 + 提前结算（30s 回全部池量）；开始 110s 冷却（2026-08-09） */
  reactivateRedSquare(now) {
    now = now != null ? now : Date.now();   // 2026-08-09 修：0 是合法时间戳（0 || 默认 老坑）
    var pool = this.stored;
    this.stored = 0;
    this.redsquareActive = false;
    this.state = 'recovering';
    this._startRedSquareCooldown(now);
    this._startRecover(now, pool, this.fullRecoverSec, 1.0);
  }

  /** 刷新血池加成 buff（bloodPoolBonus） */
  _refreshBonus(now) {
    now = now != null ? now : Date.now();   // 2026-08-09 修：0 是合法时间戳（0 || 默认 老坑）
    var L = this.level();
    var w = Math.max(0, 0.20 - L * 0.002);
    var mods = {
      evasionAllAdd: w,
      torpedoEvasionAdd: w,
      mineEvasionAdd: w,
      penDmgAdd: w,
      critDmgAdd: w,
      reducePenDmgAdd: L * 0.01,
      reduceCritDmgAdd: L * 0.02,
    };
    // 常驻 buff（Infinity + noTimer 图标 ∞；2026-08-09 修：此前 100s 时限 → 100s 后加成全消失 + 进场显示 100s 倒计时）
    this.ship.addBuff('bloodPoolBonus', '血池熔铸', Infinity, mods);
    if (this.ship.buffs && this.ship.buffs.bloodPoolBonus) this.ship.buffs.bloodPoolBonus.noTimer = true;
  }

  /** 战斗开始初始化 */
  init(now) {
    this.maxHp = this.ship.maxHp || 1;
    this.stored = 0;
    this.state = 'idle';
    this.reviveReadyAt = 0;
    this._refreshBonus(now != null ? now : Date.now());
  }
}

// 系统自登记（2026-10-01）：main.js 经 GameSystems.initAll/updateAll 统一调用，不再直接 new。
// 休眠态：本登记只是把自己挂进注册表；main.js 切换前仍走旧直接接线，互不干扰。
GameSystems.register('blood-pool', {
  order: 20,
  init: function(ship, config, now, ctx) {
    if (!config || !config.bloodPool) return;
    ship._bloodPool = new BloodPool(ship, config.bloodPool);
    ship._bloodPool.init(now);
    // 回血飘绿字 + 战绩（main.js 闭包里的 renderer/Popups/battleStats 经 ctx 传入）
    ship._bloodPool.onHealTick = function(amount, wx, wy) {
      var sp = ctx.renderer.worldToScreen(wx, wy);
      ctx.popups.spawnHealPopup(sp.x, sp.y, amount);
      ctx.battleStats.onHeal(amount);
    };
    // 濒死免疫飘字
    ship._bloodPool.onRevive = function(t, wx, wy) {
      var sp = ctx.renderer.worldToScreen(wx, wy);
      ctx.popups.spawnTextPopup(sp.x, sp.y, '血池熔铸·免疫', '#FFB000', '#553300');
    };
    // 红场压制敌舰掉血飘字（2026-10-18）：白字 '-N'，与其他技能伤害飘字同款
    ship._bloodPool.onEnemyDamage = function(amount, wx, wy) {
      var sp = ctx.renderer.worldToScreen(wx, wy);
      ctx.popups.spawnDamagePopup(sp.x, sp.y, amount, false, false, false);
    };
  },
  update: function(ship, dt, now, allies, enemies) {
    if (ship._bloodPool) ship._bloodPool.update(dt, now, [ship].concat(allies), enemies);
  },
});
