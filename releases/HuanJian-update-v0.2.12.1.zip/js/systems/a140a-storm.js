/**
 * a140a-storm.js — A-140A「炮火风暴」技能（2026-09-19）
 *
 * 完整规格见 docs/systems.md §5.29。本模块负责**除光环外**的全部机制：
 *
 * 被动（常驻）
 *   ① 每有一层**锁定**（主动锁定与随机锁定**都算**，2026-10-18 字人改）→ 自身副炮装填 -0.3s
 *      （全局、无上限、随层数动态）
 *      → 走 `reloadFlatReduce_secondary` 常数减通道（getWeaponReloadSec 统一入口）
 *   ② 副炮射程内本方战舰光环（减免武器伤害 +10 / 抵抗穿甲 +10% / 抵抗暴击 +10%，多艘不叠加）
 *      → 由 ShipSkills.updateAuras 按技能配置的 aura 数据施加（radiusFromSecondary = 副炮射程）
 *
 * 主动（20s，**冷却 90s 从使用时刻起算** —— 与沙皇"结束时起算"不同）
 *   ③ 主炮射程 +5km        → buff `mainRangeAddPx`（getMainGunRangePx 消费）
 *   ④ 主炮装填 -3s          → buff `reloadFlatReduce_mainGun`
 *   ⑤ 每座副炮锁定配额 1→2  → ship._lockStormUntil（LockSystem.quotaPerMount 消费，**替换**非叠加）
 *   ⑥ 自身免疫基础武损      → buff `immuneBaseWeaponDamage`（Ship.applyWeaponDamage 下沉免疫）
 *   ⑦ 被锁定敌舰 → 私有「被发现」：仅本舰可见、**不共享队友**（雷达来源视野照常共享）
 *      → 写 target._litPrivate[本舰uid]（Detection.canSeeShip 私有分支）
 *   ⑧ 主炮每次**开火** → 对所有被锁定敌舰各造成 1 次固定伤害
 *      = 10% × 基础副炮伤害 × 锁定层数（基数取副炮武器面板最高值；无距离限制；不吃武器减伤）
 *   ⑨ 期间敌舰**每被锁定 1 次** → 随机 1 座武器损毁 20s（不可清除；战役不触发）
 *      → 由 LockSystem 在新增锁定层时调用 target.applySpecialWeaponDamage（见 lock-system.js）
 *
 * 加载顺序：后于 lock-system.js（用 LockSystem.uid / getLayers）与 ship-weapon-damage.js。
 */

/** 技能 id（与 a140a.js 配置一致） */
const STORM_SKILL_ID = 'a140a-storm';
/** 主动持续（ms） */
const STORM_DURATION_MS = 20000;
/** 主动冷却（秒，从**使用时刻**起算） */
const STORM_COOLDOWN_SEC = 90;
/** 主动：主炮射程增加（px，5 km） */
const STORM_MAIN_RANGE_ADD_PX = 5 * PX_PER_KM;
/** 主动：主炮装填常数缩减（秒） */
const STORM_MAIN_RELOAD_FLAT = 3;
/** 被动：每层锁定（主动 + 随机，2026-10-18 改）→ 副炮装填常数缩减（秒） */
const STORM_RELOAD_PER_LAYER = 0.3;
/** 主动：主炮开火附加固定伤害系数（10% × 基础副炮伤害 × 层数） */
const STORM_FLAT_DMG_PCT = 0.10;

const A140AStorm = {
  /** 玩家侧技能伤害跳字队列（世界坐标；main.js 每帧 drainPopups 后转屏幕坐标飘字，2026-10-18） */
  pendingPopups: [],

  /** 该舰是否拥有「炮火风暴」（读战舰技能配置；不看存活，便于死后清理 buff） */
  hasStorm(ship) {
    const skills = ship && ship._shipConfig && ship._shipConfig.skills;
    if (!skills) return false;
    for (let i = 0; i < skills.length; i++) {
      if (skills[i].id === STORM_SKILL_ID) return true;
    }
    return false;
  },

  /** 主动是否进行中 */
  isActive(ship, now) {
    now = now != null ? now : Date.now();
    return !!(ship && ship._stormUntil && now < ship._stormUntil);
  },

  /**
   * 主动使用（ShipSkills._runActive 调用）。
   * 冷却**立即**从使用时刻起算（90s），期间无法再次使用（triggerActive 查 _shipActiveCd）。
   */
  activate(ship, now) {
    now = now != null ? now : Date.now();
    ship._stormUntil = now + STORM_DURATION_MS;
    ship._lockStormUntil = now + STORM_DURATION_MS;   // 每座副炮锁定配额 1 → 2（替换）
    if (!ship._shipActiveCd) ship._shipActiveCd = {};
    ship._shipActiveCd[STORM_SKILL_ID] = now + STORM_COOLDOWN_SEC * 1000;
  },

  /**
   * 每帧维护（main.js 调用；玩家 + AI 友军各自调用）。
   * @param {Ship}   ship
   * @param {Array}  enemies — 敌方舰船数组（私有「被发现」用）
   * @param {number} now
   */
  update(ship, enemies, now) {
    if (!this.hasStorm(ship)) return;
    if (!ship.isAlive) {
      ship.removeBuff('stormPassive');
      ship.removeBuff('stormActive');
      return;
    }

    // ① 被动：锁定层数（主动 + 随机**都算**，2026-10-18 字人改）→ 副炮装填常数缩减（随层数动态，noIcon 纯机制 buff）
    const lockLayers = ship.getTotalLockLayers ? ship.getTotalLockLayers() : 0;
    if (lockLayers > 0) {
      ship.addBuff('stormPassive', '炮火风暴·锁定装填', Infinity,
        { reloadFlatReduce_secondary: STORM_RELOAD_PER_LAYER * lockLayers, noIcon: true });
    } else {
      ship.removeBuff('stormPassive');
    }

    // ② 主动常驻效果（noIcon 纯机制 buff；状态由 _stormUntil 单一来源驱动）
    const on = this.isActive(ship, now);
    if (on) {
      ship.addBuff('stormActive', '炮火风暴', ship._stormUntil, {
        mainRangeAddPx: STORM_MAIN_RANGE_ADD_PX,
        reloadFlatReduce_mainGun: STORM_MAIN_RELOAD_FLAT,
        immuneBaseWeaponDamage: 1,
        noIcon: true,
      });
    } else {
      ship.removeBuff('stormActive');
    }

    // ③ 私有「被发现」：主动期间，被本舰锁定的敌舰对本舰恒可见（不共享队友；雷达视野不受影响）
    const uid = LockSystem.uid(ship);
    const list = enemies || [];
    for (let i = 0; i < list.length; i++) {
      const e = list[i];
      if (!e || !e.isAlive) continue;
      const lockedNow = on && LockSystem.getLayers(ship, e) > 0;
      if (lockedNow) {
        if (!e._litPrivate) e._litPrivate = {};
        e._litPrivate[uid] = ship._stormUntil;
      } else if (e._litPrivate && e._litPrivate[uid]) {
        delete e._litPrivate[uid];
      }
    }
  },

  /**
   * 主炮**每次开火**时调用（ship-weapons.js fireMainGun 内）：
   * 对所有被锁定敌舰各造成 1 次固定伤害 = 10% × 基础副炮伤害 × 锁定层数（无距离限制、不吃武器减伤）。
   * 基数为**固定伤害**：直接走 takeDamage（不再经伤害公式 → 天然不受武器减伤影响）。
   * 跳字（2026-10-18 字人要求「玩家造成的所有伤害都应当跳字」）：每笔伤害入队 pendingPopups
   * （世界坐标），main.js 每帧 drain 后经 worldToScreen → Popups.spawnDamagePopup
   * （仿指挥官杜尔曼盾爆的 drain 模式 —— 机制系统拿不到 renderer，屏幕坐标只能由 main.js 转）。
   */
  onMainGunFired(ship, now) {
    if (!this.isActive(ship, now)) return;
    const targets = ship._stormLockedTargets;
    if (!targets || !targets.length) return;
    const base = ship.getSecondaryPanelDamageMax ? ship.getSecondaryPanelDamageMax() : 0;
    if (base <= 0) return;
    for (let i = 0; i < targets.length; i++) {
      const t = targets[i];
      if (!t || !t.isAlive || !t.takeDamage) continue;
      const n = LockSystem.getLayers(ship, t);
      if (n <= 0) continue;
      const dmg = Math.round(base * STORM_FLAT_DMG_PCT * n);
      if (dmg > 0) {
        t.takeDamage(dmg, 'skill');
        this.pendingPopups.push({ x: t.x, y: t.y, damage: dmg });
      }
    }
  },

  /**
   * 玩家侧技能伤害跳字队列（2026-10-18）：onMainGunFired 入队，main.js 每帧 drain。
   * 返回 [{x, y, damage}]（世界坐标）并清空队列。
   */
  drainPopups() {
    const q = this.pendingPopups;
    this.pendingPopups = [];
    return q;
  },
};

// 系统自登记（2026-10-01）：main.js 经 GameSystems.updateAll 每帧对每艘本方舰调用。
// 休眠态：本登记只是挂进注册表；main.js 切换前仍走旧 A140AStorm.update 直接调用，互不干扰。
GameSystems.register('a140a-storm', {
  order: 10,
  // 无 init：单例 + 状态在 ship 上（_shipConfig 由 ship-skills.applyStatic 设；activate 由 ShipSkills._runActive 调）
  update: function(ship, dt, now, allies, enemies) {
    A140AStorm.update(ship, enemies, now);
  },
});
