/**
 * class-skills.js — 舰种技能系统（2026-10-03）
 *
 * ⚠️ 与「战舰技能」（`js/systems/ship-skills.js`，单艘船独有）是两个不同系统 —— 叫法见 `docs/glossary.md`。
 *    数据源 `js/data/ship-class-skills.js` 的 CLASS_SKILLS；本文件负责「读存档 + 过滤 + 合并 + 生效」。
 *
 * 设计要点（docs/superpowers/plans/2026-10-03-ship-class-skills.md §8.1）：
 *   **单一入口** `getEffects(ship)` 返回已按舰种 + 选系过滤好的合并 effects，
 *   杜绝「多处各自判断该不该生效」导致的分叉。
 *
 * 生效范围（设计文档 §二.2，字人确认）：**只对玩家自己的船生效**。
 *   ⚠️ 本文件**不判玩家**（getEffects 只算效果）；isPlayer 判断放在调用方
 *      （战斗开始时对 player 舰调 applyTo 一次）。
 *
 * 通道分两类（§3.1）：
 *   ① BUFF 通道（6 条）—— 走 buff 系统常驻挂载（noIcon + noDuration），消费点 `getBuffMod(key)`。
 *      选 buff 而非 ship 字段的理由：`torpedoSpeedAdd` 的既有实现（ship-weapons.js:289 `_torpedoSpeedAdd`）
 *      = `ship.torpedoSpeedBonus`（战舰技能静态加成）+ `getBuffMod('torpedoSpeedAdd')`（限时层数）；
 *      舰种技能是「战斗中不可切换」的常驻加成，语义上属于后者（同族通道保持一致，
 *      且复用 buff 的「多来源求和」，天然满足 §4 的 Σ 口径）。
 *   ② 舰体字段通道 —— 直接加算到 ship 字段，与 `applyTermOverridesToShip`
 *      （js/systems/term-overrides.js）的「基础属性 + 额外加成」惯例完全一致。
 *      支持三种形态（2026-11-15）：一个 stat → 一个字段、一个 stat → 多个字段（`fields`，
 *      如「炮弹速度」= 主炮 + 副炮）、基础属性百分比乘算（`mul`，如「武器转速 +10%」）。
 */

const ClassSkills = {
  /** localStorage key（设计文档 §七） */
  STORAGE_KEY: 'hj_classSkills',

  /** buff 通道：stat → getBuffMod 的 key（同名单射，便于静态守卫遍历） */
  BUFF_CHANNELS: {
    torpedoSpeedPct: 'torpedoSpeedPct',                 // 小数，鱼雷航速百分比
    torpedoSpeedAdd: 'torpedoSpeedAdd',                 // 节
    torpedoReloadPct: 'torpedoReloadPct',               // 小数，鱼雷装填缩减百分比
    mineReloadPct: 'mineReloadPct',                     // 小数，水雷装填缩减百分比
    reloadFlatReduce_torpedo: 'reloadFlatReduce_torpedo', // 秒
    reloadFlatReduce_mine: 'reloadFlatReduce_mine',       // 秒
  },

  /**
   * 舰体字段通道：stat → { field, scale?, factor?, mul?, after?, fields? }
   *   field      — 目标 ship 字段名
   *   scale:'deg' — 存储层是「度」，应用到 ship（弧度）时 ×π/180（同 TERM_OVERRIDES rad:true）
   *   factor     — 比例因子（如「武器速度单位」→ px/s 的 0.057）；缺省 1
   *   mul:true   — **基础属性百分比乘算**：field × (1 + value)，而不是加固定值
   *                （applyTo 在开局跑一次，此时 field 仍是 cfg 基础值 → 等价于「基础值 ×(1+%)」，
   *                  与 §5.34「基础属性加百分比 = 乘算」同口径）
   *   after      — 改完该字段后需调用的方法（如 maxSpeed → 重建速力档位）
   *   fields     — 复合通道：一个 stat 展开到多个字段（每项结构同本对象）
   *                —— 2026-11-15 战列舰「炮弹速度」（主炮+副炮）/「中小口径规避」用
   */
  FIELD_CHANNELS: {
    floodChance:       { field: 'floodChance' },        // 小数
    floodDuration:     { field: 'floodDuration' },      // 小数
    floodPower:        { field: 'floodPower' },         // 小数
    detonationRadius:  { field: 'detonationRadius' },   // km
    explosionRadius:   { field: 'explosionRadius' },    // km
    lifetimeSec:       { field: 'lifetimeSec' },        // 秒
    maxSpeed:          { field: 'maxSpeed', after: '_rebuildSpeedGears' },  // 节
    rotationSpeed:     { field: 'rotationSpeed', scale: 'deg' },             // 度/秒

    // ── 战列舰「毁灭」一系（2026-11-15）────────────────────────────────
    // 攻击侧字段：消费端是 data/attack-stats.js 的表（Ship 字段 → baseStats → 弹丸），
    //   哪类武器吃到由表里的 `weapons` 列决定（穿甲只对主炮生效）。
    penetrationChance: { field: 'penetrationChance' },  // 小数（主炮专属）
    shatterChance:     { field: 'shatterChance' },      // 小数
    critChance:        { field: 'critChance' },         // 小数
    critDmg:           { field: 'critDmg' },            // 小数（与默认 ×2.0 相加）
    // 复合通道①：炮弹速度 = 主炮 + 副炮（武器速度单位 → px/s，两个字段各 +v×0.057）
    shellSpeedAdd: {
      fields: [
        { field: 'mainShellSpeedBonus', factor: 0.057 },   // 消费点 ship-weapons.js fireMainGun / getMainGunShellSpeedPx
        { field: 'secShellSpeedBonus',  factor: 0.057 },   // 消费点 ship-weapons.js _fireSecondaryMount
      ],
    },
    // 复合通道②：中小口径炮弹规避（直接加 3 个点，非乘算）
    shellEvasionSmallMedium: {
      fields: [
        { field: 'smallCaliberEvasion' },   // 消费点 collision.js 跳弹判定
        { field: 'mediumCaliberEvasion' },
      ],
    },
    // 基础属性乘算：武器转速（消费点 ship-weapons.js updateAimHeading 的 maxStep）
    weaponRotationSpeedPct: { field: 'weaponRotationSpeed', mul: true },
  },

  /* ── 存档（localStorage['hj_classSkills'] = { destroyer: 0|1 }）──────────── */

  /** 读存档。**任何异常都吞掉回落 {}**（损坏 JSON / 非对象 / 无 localStorage 环境）。 */
  getSelection() {
    try {
      var raw = localStorage.getItem(this.STORAGE_KEY);
      if (!raw) return {};
      var obj = JSON.parse(raw);
      if (obj && typeof obj === 'object' && !Array.isArray(obj)) return obj;
      return {};
    } catch (e) { return {}; }
  },

  /** 写存档（UI 切系时调）。异常吞掉（隐私模式 / 配额满不应崩游戏）。 */
  setSelection(shipType, pathIndex) {
    var sel = this.getSelection();
    sel[shipType] = (pathIndex === 1 ? 1 : 0);
    try { localStorage.setItem(this.STORAGE_KEY, JSON.stringify(sel)); } catch (e) {}
  },

  /** 该舰种当前选中的系 index（0/1）。缺失/非法 → 0（一系「突击」）。 */
  getPathIndex(shipType) {
    var sel = this.getSelection();
    var v = (sel[shipType] === 1) ? 1 : 0;
    // 防御（2026-11-15）：**单系舰种**（战列舰只有「毁灭」一系）的存档若被手改成 1，
    //   直接拿去索引 paths 会得到 undefined → getEffects/getActiveSkills 静默变空（技能全失效，不报错）。
    //   故 clamp 到该舰种实际系数的合法范围。空壳舰种（paths: []）一律 0。
    var n = this.getPaths(shipType).length;
    if (n === 0) return 0;
    return (v > n - 1) ? 0 : v;
  },

  /** 某舰种的舰种技能定义（无此舰种 → null）。 */
  getDef(shipType) {
    if (!shipType) return null;
    var def = CLASS_SKILLS[shipType];
    return (def && Array.isArray(def.paths)) ? def : null;
  },

  /** 某舰种的系列表（空壳舰种 → 空数组，**不抛异常**，设计文档 §9.3）。 */
  getPaths(shipType) {
    var def = this.getDef(shipType);
    return def ? def.paths : [];
  },

  /**
   * 取舰船的舰种。优先 `_shipConfig.shipType`（ShipSkills.applyStatic 会挂 _shipConfig），
   * 回落 `ship.shipType`（Ship 构造器从 cfg.shipType 存的），都没有 → null。
   */
  getShipType(ship) {
    if (!ship) return null;
    if (ship._shipConfig && ship._shipConfig.shipType) return ship._shipConfig.shipType;
    return ship.shipType || null;
  },

  /* ── 单一入口 ─────────────────────────────────────────────────────────── */

  /**
   * 当前生效的系（舰种 + 存档选系，index 已 clamp）。取不到 → null。
   * 被动（getEffects）与主动（getActiveSkills）共用它，保证两者**永远看同一系**。
   */
  _currentPath(ship) {
    var type = this.getShipType(ship);
    var def = this.getDef(type);
    if (!def || def.paths.length === 0) return null;
    var path = def.paths[this.getPathIndex(type)];
    return (path && Array.isArray(path.skills)) ? path : null;
  },

  /**
   * 当前生效的舰种技能效果（已按舰种 + 选系过滤 + 同 stat 多来源合并）。
   * @param {Ship} ship
   * @returns {Array<{stat:string, value:number}>} 空舰种 / 巡洋（空壳）→ []
   */
  getEffects(ship) {
    var path = this._currentPath(ship);
    if (!path) return [];

    var out = [];
    var byStat = Object.create(null);   // stat → 合并后的 {stat,value} 引用
    for (var i = 0; i < path.skills.length; i++) {
      var sk = path.skills[i];
      // ⚠️ 只收「已开放的被动」：主动技能（哪怕 ready:true）不参与被动加成（设计文档 §2）
      if (!sk || sk.type !== 'passive' || sk.ready !== true) continue;
      var effs = sk.effects || [];
      for (var j = 0; j < effs.length; j++) {
        var e = effs[j];
        if (!e || !e.stat) continue;
        var v = (typeof e.value === 'number' && isFinite(e.value)) ? e.value : 0;
        if (byStat[e.stat] === undefined) {
          byStat[e.stat] = { stat: e.stat, value: 0 };
          out.push(byStat[e.stat]);
        }
        byStat[e.stat].value += v;   // 同 stat 多来源 → 相加（设计文档 §8.1.5）
      }
    }
    return out;
  },

  /** getEffects 的对象视图（测试/调试方便）。 */
  getEffectMap(ship) {
    var out = {};
    var effs = this.getEffects(ship);
    for (var i = 0; i < effs.length; i++) out[effs[i].stat] = effs[i].value;
    return out;
  },

  /* ── 生效 ─────────────────────────────────────────────────────────────── */

  /**
   * 落一条字段通道（`fields` 展开 / `factor` 换算 / `scale:'deg'` / `mul` 乘算）。
   * @param {Ship} ship
   * @param {Object} def — FIELD_CHANNELS 的一项（或 `fields` 里的一项）
   * @param {number} v   — 数据里的数值（单位见 js/data/ship-class-skills.js 头部注释）
   */
  _applyFieldChannel(ship, def, v) {
    var list = def.fields || [def];
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      if (d.mul) {
        // 基础属性百分比乘算（0.10 = ×1.10）。applyTo 每次开局只跑一次且幂等，
        //   此时字段还是 cfg 基础值 → 等价于「基础值 ×(1+%)」。
        ship[d.field] = (ship[d.field] || 0) * (1 + v);
      } else {
        // scale:'deg' → 存储层「度」转弧度（与 systems/term-overrides.js:27 同惯例）
        var add = (d.scale === 'deg') ? v * Math.PI / 180 : v * (d.factor != null ? d.factor : 1);
        ship[d.field] = (ship[d.field] || 0) + add;
      }
      if (d.after && typeof ship[d.after] === 'function') ship[d.after]();
    }
  },

  /**
   * 把当前生效效果落到舰船上（战斗开始时对**玩家舰**调一次）。
   * 幂等：重复调用直接 return，防止叠加两次。
   * @param {Ship} ship
   * @returns {Array} 实际生效的 effects（便于测试/调试）
   */
  applyTo(ship) {
    if (!ship) return [];
    if (ship._classSkillsApplied) return [];
    ship._classSkillsApplied = true;

    var effs = this.getEffects(ship);
    var buffs = Object.create(null);   // BUFF 通道先合并，最后一次性挂（getBuffMod 本身也会跨 buff 求和）

    for (var i = 0; i < effs.length; i++) {
      var stat = effs[i].stat, v = effs[i].value;
      if (!v) continue;

      if (this.BUFF_CHANNELS[stat]) {
        buffs[stat] = (buffs[stat] || 0) + v;
        continue;
      }
      var fc = this.FIELD_CHANNELS[stat];
      if (!fc) continue;
      this._applyFieldChannel(ship, fc, v);
    }

    if (ship.addBuff) {
      for (var k in buffs) {
        var mods = { noIcon: true, noDuration: true };   // 常驻、无时间 → 不显示图标/时间（§5.29）
        mods[k] = buffs[k];
        ship.addBuff('classskill_' + k, '舰种技能', Infinity, mods);
      }
    }
    return effs;
  },

  /* ── 主动技能（2026-11-15 战列舰「毁灭」为第一批真实消费者）─────────────────
   * 与战舰技能的主动（`js/systems/ship-skills.js` 的 triggerActive/_runActive）刻意**不共用**：
   *   · 数据源不同：这里读 CLASS_SKILLS 的「舰种 + 当前系」，那边读单舰配置的 skills。
   *   · 冷却字段不同：这里 `ship._classActiveCd[skillId]`，那边 `ship._shipActiveCd[skillId]`。
   *   · 分发目标不同：这里 `ClassSkillActives.run`，那边 `ShipSkills._runActive`。
   * 两者可以并存在同一艘船上（战舰技能 C 键 + 舰种技能 q/e/r），互不影响。
   *
   * 契约：
   *   · 只收 `type === 'active' && ready === true`（未开放/占位技能不出图标、不响应按键）。
   *   · 冷却**各自独立**、**从使用时刻起算**（`now + cooldownSec*1000` 写入冷却结束时间）。
   *   · 冷却中按键**无效**（不续冷却、不执行）。
   *   · 「只对玩家生效」由**调用方**保证（main.js 唯一调用点，同 applyTo 的口径），
   *     本文件不判 isPlayer —— 这样 AI 舰也能复用（未来若需要）而不必改系统。
   */

  /** 当前生效的舰种主动技能表：`[{ id, name, key, cooldownSec, desc }]`（无 → []）。 */
  getActiveSkills(ship) {
    var path = this._currentPath(ship);
    if (!path) return [];
    var out = [];
    for (var i = 0; i < path.skills.length; i++) {
      var sk = path.skills[i];
      // 缺 active 配置的主动技能无法绑键 → 跳过（数据守卫在单测第 85 节：已开放主动技能必须配 active）
      if (!sk || sk.type !== 'active' || sk.ready !== true || !sk.active || !sk.active.key) continue;
      out.push({
        id: sk.id,
        name: sk.name,
        key: sk.active.key,
        cooldownSec: sk.active.cooldownSec || 0,
        desc: sk.desc || '',
      });
    }
    return out;
  },

  /** 主动技能冷却结束时间（毫秒）。未用过 → 0。 */
  _cdEnd(ship, skillId) {
    return (ship && ship._classActiveCd && ship._classActiveCd[skillId]) || 0;
  },

  /**
   * HUD 图标状态（ui.js 渲染用）：`[{ id, name, ready, remaining, cooldownSec, key }]`。
   * remaining 单位为**秒**（与战舰技能 getActiveSkillStates 一致，UI 直接 toFixed(1)）。
   */
  getActiveStates(ship, now) {
    now = now || Date.now();
    var out = [];
    var list = this.getActiveSkills(ship);
    for (var i = 0; i < list.length; i++) {
      var sk = list[i];
      var cdEnd = this._cdEnd(ship, sk.id);
      out.push({
        id: sk.id,
        name: sk.name,
        ready: now >= cdEnd,
        remaining: Math.max(0, (cdEnd - now) / 1000),
        cooldownSec: sk.cooldownSec,
        key: sk.key,
      });
    }
    return out;
  },

  /**
   * 按键触发（main.js 每帧调；同帧最多触发一个技能）。
   * @param {Ship} ship
   * @param {number} now
   * @param {InputHandler} input — 只用到 isActionJustPressed（测试可传假对象）
   * @returns {boolean} 是否真的触发了
   */
  triggerActive(ship, now, input) {
    if (!ship || !input || typeof input.isActionJustPressed !== 'function') return false;
    now = now || Date.now();
    var list = this.getActiveSkills(ship);
    for (var i = 0; i < list.length; i++) {
      var sk = list[i];
      if (!input.isActionJustPressed(sk.key)) continue;
      if (now < this._cdEnd(ship, sk.id)) return false;   // 冷却中按键无效（不续冷却、不执行）
      if (!ship._classActiveCd) ship._classActiveCd = {};
      // 冷却是**闭区间终点**，从使用时刻起算（不是效果结束时刻）——与 A-140A/阳炎同口径
      ship._classActiveCd[sk.id] = now + sk.cooldownSec * 1000;
      if (typeof ClassSkillActives !== 'undefined') ClassSkillActives.run(ship, sk.id, now);
      return true;
    }
    return false;
  },
};

