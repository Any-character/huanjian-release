/**
 * yanyin-hunt.js — 阳炎-利刃「蜃光猎影」技能（2026-10-01）
 *
 * 姊妹文件 `yanyin-pursuit.js`（技能①鱼雷追击）。被动常驻 + 主动 15s（冷却 60s，**从使用时刻起算**）。
 *
 * 被动（常驻）
 *   ① 布雷（**每颗**水雷）→ 护盾 +500；本来源（source='yanyinHunt'）护盾累计不超过最大血量 50%
 *      → ship.addTimedShield(add, Infinity, 'yanyinHunt')；cap 用 getSourceShieldTotal 判定
 *   ② 水雷命中敌舰 → ① 固定伤害 = 基数 × 10%（走 takeDamage(dmg,'skill')）
 *                          ② **必定**漏水（绕过 resistFloodChance，程度仍吃 resistFloodPower）
 *      每敌舰 60s 冷却，冷却表 `target._yanyinFloodCd[施法者 uid] = 结束时刻`
 *      → A 舰对某目标的冷却不影响 B 舰，也不影响 A 舰对别的目标
 *
 * 主动（15s，冷却 60s 从使用时刻起算，A-140A 式）
 *   ③ 期间自身水雷减伤 +50 点（reduceMineDmg，点数尺度 0~100）
 *   ④ 期间每次**布雷** → 鱼雷加速层 +1（上限 4，10s **刷新式**：层数不清零、全部时长顺延）
 *                    鱼雷速度 +5 节/层（torpedoSpeedAdd）+ 鱼雷面板伤害 +5%/层（torpPanelDmgPct）
 *   ④' 期间每次**射鱼雷** → **所有**正在装填中的水雷炮位 cooldownEnd 推进 2s（**瞬间推进**，非改 stat；
*                      2026-10-02 字人修正：此前只推进第一座，其余漏掉）
 *   ⑤ 期间每次**鱼雷命中** → 敌舰鱼雷/水雷减伤各 -5 点/层（上限 4，10s 刷新式）
 *                    ⚠️ ⑤ 不受 ② 的 60s 冷却限制（60s 只管「固定伤害 + 漏水」，
 *                      否则 10s 的减伤降层 buff 一次都叠不上去）。
 *
 * ── 触发源对照表（2026-10-02 按原版截图重排，防「水雷 vs 鱼雷」再搞混）──────────────
 *   | 效果                               | 触发 hook             | 归类   |
 *   |------------------------------------|-----------------------|--------|
 *   | 护盾 +500                           | onMineFired    布雷   | 被动① |
 *   | 鱼雷加速层 +1（速度+5节/伤害+5%）   | onMineFired    布雷   | 主动④ |
 *   | 鱼雷命中 → 敌舰鱼雷/水雷减伤 -5/层  | onTorpedoHit   鱼雷命中 | 主动⑤ |
 *   | 水雷装填 -2s（加速对象=水雷炮位）   | onTorpedoFired 射鱼雷  | 主动④'|
 *   | 10% 固定伤害 + 必定漏水（60s 冷却） | onMineHit      水雷命中 | 被动② |
 *   ⚠️ ④' 最容易读错：**触发源是鱼雷，被加速的是水雷**。本项目已因「水雷/鱼雷」混淆
 *      反复出 bug（82.12c/d、83.19 同源），单测 77.20 有静态守卫钉死此表。
 *
 * ── 三处「规格纠偏」（与任务书原文不同，按代码实际语义实现）────────────────────────
 * ① `takeDamage` 签名是 **(amount, type)**，不是 (dmg, attacker, now)。
 *    ship-status.js:15 `Ship.prototype.takeDamage = function(amount, type)`；
 *    type='skill' 才是「非武器伤害」语境 → ship-status.js:79-81 才吃杜尔曼 flatDamageReduce，
 *    正好对齐已确认决策 E（不吃武器减伤、吃护盾、吃 flatDamageReduce）。
 * ② `applyFlood` 第 5 参是 **attacker（施法者）**，不是 proj —— ship-status.js:288。
 *    故漏水程度按「本舰水雷的 floodPower」现算（见 `_mineFloodProfile`），
 *    与 weapon-config.js:51/221 `effFloodPower = baseStats + bonuses` 同一算法。
 * ③ **buff mod 键 `reduceMineDmg` / `reduceTorpedoDmg` 在本项目没有消费点**：
 *    collision-hit.js:129 只读 `target[opts.reduceKey]`（舰体字段）与
 *    `getBuffMod('reduceWeaponDmgAdd')`（**全武器**通用、不是分口径）。
 *    故 ③⑤ 改为**直写舰体减伤字段 + 显式回收**（`_setSelfMineReduce` / `_setEnemyReduce`），
 *    而非挂在 buff 上（挂上去会是静默失效 —— 与技能①同源的教训）。
 *    ⚠️ 敌舰减伤字段可能为负 → collision-hit.js:129 的 `Math.min(100 - y + x, 100)` 封顶 100，
 *       **不会**变成增伤（只会把敌舰的减伤抹到 0）。
 *
 * ── 施法者唯一标识 ──────────────────────────────────────────────────────────────
 * 用既有 `ShipSkills._uid(ship)`（ship-skills.js:20，已有 `ship._uid` 则复用）：
 * 这是技能系统自己的「按船区分」通道（光环 buff key 同款），**不新造 uid**。
 * （未用 `LockSystem.uid` —— 那是 A-140A 锁定系统私有的 key 生成器。）
 *
 * 加载顺序：后于 systems/registry.js（末尾自登记 GameSystems）、systems/ship-skills.js（_uid）。
 */

  /** 技能 id（与 ships/yanyin.js 配置一致） */
  const YANYIN_HUNT_SKILL_ID = 'yanyin-hunt';
  /** 主动持续（ms） */
  const YANYIN_HUNT_DURATION_MS = 15000;
  /** 主动冷却（秒，从**使用时刻**起算，写 ship._shipActiveCd —— triggerActive/getActiveSkillStates 既有通道） */
  const YANYIN_HUNT_COOLDOWN_SEC = 60;
  /** 被动①：每颗水雷给的护盾点数 / 本来源上限占最大血量比例 */
  const YANYIN_HUNT_SHIELD_PER_MINE = 500;
  const YANYIN_HUNT_SHIELD_CAP_PCT = 0.5;
  /** 被动②：固定伤害占「百分比扣血基数」的比例（基数走 getPercentDamageBase，AGENTS §5.30 唯一入口） */
  const YANYIN_HUNT_FLAT_DMG_PCT = 0.10;
  /** 被动②：每个目标上的漏水冷却（ms） */
  const YANYIN_HUNT_FLOOD_CD_MS = 60000;
  /** 主动③：自身水雷减伤点数（0~100 尺度） */
  const YANYIN_HUNT_ACTIVE_MINE_REDUCE = 50;
  /** 主动④⑤ 层数：上限 / 持续（ms，每次命中刷新）/ 每层数值 */
  const YANYIN_HUNT_STACK_MAX = 4;
  const YANYIN_HUNT_STACK_MS = 10000;
  const YANYIN_HUNT_TORP_SPEED_PER = 5;      // 鱼雷速度 +5 节/层（走 torpedoSpeedAdd，与 torpedoSpeedBonus 相加）
  const YANYIN_HUNT_TORP_PANEL_PCT_PER = 0.05;   // 鱼雷面板伤害 +5%/层（0.05 = 5%）
  const YANYIN_HUNT_ENEMY_REDUCE_PER = 5;    // 敌舰鱼雷/水雷减伤各 -5 点/层（负号 = 降低减伤）
  /** 主动④：当前正在装填的水雷炮位 cooldownEnd 推进（ms） */
  const YANYIN_HUNT_MINE_CD_SKIP_MS = 2000;

const YanyinHunt = {
  /** 玩家侧技能伤害跳字队列（世界坐标；main.js 每帧 drainPopups 后转屏幕坐标飘字，2026-10-18） */
  pendingPopups: [],

  /** 该舰是否拥有「蜃光猎影」（读战舰技能配置；不看存活，死后仍返回 true 便于清理） */
  hasHunt(ship) {
    const skills = ship && ship._shipConfig && ship._shipConfig.skills;
    if (!skills) return false;
    for (let i = 0; i < skills.length; i++) {
      if (skills[i].id === YANYIN_HUNT_SKILL_ID) return true;
    }
    return false;
  },

  /** 主动是否进行中（单一时间戳字段 _yanyinHuntUntil，与 buff endTime 同源） */
  isActive(ship, now) {
    now = now != null ? now : Date.now();
    return !!(ship && ship._yanyinHuntUntil && now < ship._yanyinHuntUntil);
  },

  /**
   * 主动使用（ShipSkills._runActive 调用）。
   * 冷却**立即**从使用时刻起算（60s）写 `ship._shipActiveCd[skillId]` ——
   *   triggerActive(ship-skills.js:230) 查它判冷却、getActiveSkillStates(:261) 读它画倒计时，
   *   两处都是既有通道，本文件不另造冷却字段。
   */
  activate(ship, now) {
    now = now != null ? now : Date.now();
    ship._yanyinHuntUntil = now + YANYIN_HUNT_DURATION_MS;
    if (!ship._shipActiveCd) ship._shipActiveCd = {};
    ship._shipActiveCd[YANYIN_HUNT_SKILL_ID] = now + YANYIN_HUNT_COOLDOWN_SEC * 1000;
    ship._yanyinHuntStacks = 0;                       // 每次开主动重新从 0 层起
    this._setSelfMineReduce(ship, YANYIN_HUNT_ACTIVE_MINE_REDUCE);
    ship.addBuff('yanyinHuntActive', '蜃光猎影', ship._yanyinHuntUntil, { huntActive: 1 }, 1);
  },

  /**
   * 布雷（**每颗**水雷）触发 —— ship-weapons.js fireMine:384 内调用。
   *   被动：护盾 +500（本来源 cap 50% maxHp）
   *   主动期间：鱼雷加速层 +1（4 层封顶 10s 刷新式）
   * ⚠️ 2026-10-02 规格纠偏：本函数**只管水雷自己的两件事**（护盾 / 鱼雷加速层），
   *    「水雷装填 -2s」**不属于这里** —— 它的触发源是**射鱼雷**（onTorpedoFired），
   *    只是被加速的对象恰好是水雷炮位。见 onTorpedoFired。
   */
  onMineFired(ship, now) {
    now = now != null ? now : Date.now();
    this._addMineShield(ship, now);
    if (!this.isActive(ship, now)) return;
    this._addTorpStack(ship, now);
  },

  /**
   * 水雷命中敌舰触发 —— collision.js:344 _applyMineHit 内调用（跳弹已在上面 return，
   *   即"没命中"不给；调用前提 totalDmg > 0）。
   */
  onMineHit(ship, target, now) {
    now = now != null ? now : Date.now();
    if (!target || !target.isAlive) return;
    // ⚠️ 2026-10-02 规格纠偏：本函数**只有被动②**（10% 固定伤害 + 必定漏水 + 60s 冷却）。
    //    主动⑤「敌舰减伤降层」的触发源是**鱼雷命中**（onTorpedoHit），不在这里 —— 原版
    //    截图第 2 行写的是「被自身**水雷**命中的敌舰」，被动②留在这里是对的。
    // ② 每敌舰 60s 冷却（冷却表记在**敌舰**身上、按施法者 uid 分桶）
    if (!target._yanyinFloodCd) target._yanyinFloodCd = {};
    const uid = this._uid(ship);
    if (target._yanyinFloodCd[uid] && target._yanyinFloodCd[uid] > now) return;
    target._yanyinFloodCd[uid] = now + YANYIN_HUNT_FLOOD_CD_MS;
    // 固定伤害 = 基数 × 10%，走 takeDamage('skill')
    const base = target.getPercentDamageBase(ship.maxHp);
    const dmg = Math.round(base * YANYIN_HUNT_FLAT_DMG_PCT);
    if (dmg > 0) {
      target.takeDamage(dmg, 'skill');
      // 跳字（2026-10-18 字人要求「玩家造成的所有伤害都应当跳字」）：世界坐标入队，main.js 每帧 drain
      this.pendingPopups.push({ x: target.x, y: target.y, damage: dmg });
    }
    // 必定漏水（绕过 resistFloodChance；程度仍吃 resistFloodPower）。
    // 返回是否成功上水 —— collision.js 用它置 ev.isFlood → 命中统计「漏水」药丸 +1
    // （2026-10-18 字人要求：必漏水与普通漏水同一统计显示；冷却期内 / 已在漏水中 → false 不计数）
    return this._applyFlood(ship, target, now);
  },

  /**
   * 玩家侧技能伤害跳字队列（2026-10-18）：onMineHit 入队，main.js 每帧 drain。
   * 返回 [{x, y, damage}]（世界坐标）并清空队列。
   */
  drainPopups() {
    const q = this.pendingPopups;
    this.pendingPopups = [];
    return q;
  },

  /**
   * **射鱼雷**触发 —— ship-weapons.js:336 fireTorpedo 内调用（每轮齐射一次）。
   *   主动④：水雷炮位装填 -2s（**所有**正在装填中的），见 _skipMineReload。
   * ⚠️ 2026-10-02 规格纠偏（此前判断错误）：以为「主动效果全挂水雷」故留空。
   *    原版截图第 4 行原文是「每次释放**鱼雷**，减少 2 秒当前**水雷**装填时间」——
   *    触发源 = 射鱼雷，被加速的对象 = 水雷炮位，两者不是一回事。
   *    （鱼雷加速层 `_addTorpStack` 仍在 onMineFired，那是第 3 行「每次释放**水雷**，鱼雷速度+5节」。）
   */
  onTorpedoFired(ship, now) {
    now = now != null ? now : Date.now();
    if (!this.isActive(ship, now)) return;
    this._skipMineReload(ship, now);
  },

  /**
   * **鱼雷命中**触发 —— collision.js:263 _applyTorpedoHit 内调用
   *   （跳弹已在上面 return，即"没命中"不给；调用前提 totalDmg > 0）。
   *   主动⑤：敌舰鱼雷/水雷减伤各 -5 点/层（上限 4，10s 刷新式），见 _applyEnemyDebuff。
   * ⚠️ 2026-10-02 规格纠偏：原版截图第 4 行是「**鱼雷**命中时，降低敌舰 5% 鱼雷、水雷减伤」。
   *    此前挂在 onMineHit（水雷命中）上是读错行；**被动②的 10% 固定伤害 + 漏水
   *    仍留在 onMineHit**（第 2 行原文确实是「被自身水雷命中的敌舰」），两者别混。
   *    ⚠️ 每颗鱼雷**弹丸**各触发一次 → 一次齐射 N 管齐中即 N 层（同 yanyin-pursuit.onTorpedoHit）。
   */
  onTorpedoHit(ship, target, now) {
    now = now != null ? now : Date.now();
    if (!target || !target.isAlive) return;
    if (!this.isActive(ship, now)) return;
    this._applyEnemyDebuff(target, now);
  },

  /**
   * 每帧维护（GameSystems 驱动，玩家 + AI 友军各自调用）：
   *   ① 主动结束 → 收回自身水雷减伤、清鱼雷加速层（buff 由 cleanBuffs 天然过期）
   *   ② 敌舰减伤降层到期回收（敌舰不在 updateAll 名单里 —— main.js:666 只跑 player+allies，
   *      故本模块自己在 update 里扫 enemies 做回收）
   */
  update(ship, dt, now, allies, enemies) {
    if (!this.hasHunt(ship)) return;
    now = now != null ? now : Date.now();
    // ① 主动结束回收
    if (!this.isActive(ship, now)) {
      this._setSelfMineReduce(ship, 0);
      if (ship._yanyinHuntStacks) ship._yanyinHuntStacks = 0;
      ship.removeBuff('yanyinHuntActive');
    }
    // ② 敌舰减伤降层到期回收（hasBuff 走 endTime > now，与 cleanBuffs 的执行时机无关）
    if (enemies) {
      for (let i = 0; i < enemies.length; i++) {
        const e = enemies[i];
        if (e && e._yanyinHuntDebuffPoints && !e.hasBuff('yanyinHuntDebuff', now)) this._revertEnemyDebuff(e);
      }
    }
  },

  /* ── 内部工具 ─────────────────────────────────────────────────────────── */

  /** 施法者唯一标识（复用 ShipSkills._uid —— 技能系统既有的「按船区分」通道） */
  _uid(ship) {
    if (typeof ShipSkills !== 'undefined' && ShipSkills._uid) return ShipSkills._uid(ship);
    if (!ship._yanyinHuntUid) ship._yanyinHuntUid = 'YH' + (++YanyinHunt._uidCounter).toString(36);
    return ship._yanyinHuntUid;
  },
  _uidCounter: 0,

  /**
   * 被动①：每颗水雷 +500 护盾，本来源累计不超过 maxHp × 50%。
   * 门槛用 `getSourceShieldTotal('yanyinHunt')`（只算**当前未被打掉的**余量），
   * 故护盾被打掉后还能再攒回来 —— 与「护盾是当前存量」的语义一致。
   * expireAt = Infinity → cleanupTimedShields 的 `expireAt <= now` 恒 false，永不过期。
   */
  _addMineShield(ship, now) {
    const cap = ship.maxHp * YANYIN_HUNT_SHIELD_CAP_PCT;
    const cur = ship.getSourceShieldTotal('yanyinHunt', now);
    const add = Math.min(YANYIN_HUNT_SHIELD_PER_MINE, Math.max(0, cap - cur));
    if (add > 0) ship.addTimedShield(add, Infinity, 'yanyinHunt');
    return add;
  },

  /**
   * 主动③：把自身水雷减伤字段设到目标点数（幂等；points=0 表示回收）。
   * 记账在 `ship._yanyinHuntMineReducePoints`，故 update 每帧调用不会重复加减。
   * ⚠️ 直写舰体字段而非 buff —— collision-hit.js:129 只读 target[reduceKey]，
   *    buff 键 `reduceMineDmg` 无消费点（挂 buff = 静默失效）。
   */
  _setSelfMineReduce(ship, points) {
    const cur = ship._yanyinHuntMineReducePoints || 0;
    const d = points - cur;
    if (d !== 0) ship.reduceMineDmg = Math.max(0, (ship.reduceMineDmg || 0) + d);
    ship._yanyinHuntMineReducePoints = points;
  },

  /**
   * 主动④：鱼雷加速层 +1（4 层封顶，10s 刷新式 —— 满层也继续刷新时长）。
   *   torpedoSpeedAdd：节/层。消费点 ship-weapons.js:289 `_torpedoSpeedAdd()` =
   *     `torpedoSpeedBonus + getBuffMod('torpedoSpeedAdd')` —— 两个不同字段相加，
   *     故与技能②「鱼雷大师」的 +30 节（写 torpedoSpeedBonus）正确叠加（30 + 5×层）。
   *   torpPanelDmgPct：小数/层。消费点 weapon-config.js:198-205（面板×pct 加到每管）。
   *     ⚠️ **玩家舰路径缺一环**：ship-weapons.js:305 fireTorpedo 的 baseStats 没带
   *     `torpPanelDmgPct`（custom-enemy.js:511 有带）。补上后本键即刻生效，见汇报。
   */
  _addTorpStack(ship, now) {
    const n = Math.min(YANYIN_HUNT_STACK_MAX, (ship._yanyinHuntStacks || 0) + 1);
    ship._yanyinHuntStacks = n;
    ship.addBuff('yanyinHuntTorp', '鱼雷加速', now + YANYIN_HUNT_STACK_MS, {
      torpedoSpeedAdd: YANYIN_HUNT_TORP_SPEED_PER * n,
      torpPanelDmgPct: YANYIN_HUNT_TORP_PANEL_PCT_PER * n,
    }, n);
    return n;
  },

  /**
   * 主动④：**所有**正在装填中的水雷炮位 cooldownEnd 推进 2s（瞬间推进，非改 stat）。
   * ⚠️ 与 `reloadFlatReduce_mine`（getWeaponReloadSec 改有效装填时长）是两回事，不要混。
   *    也不走 getMountCooldownEnd —— 那会把「武损中装填冻结」的语义污染掉
   *    （与技能① _reloadLongestTorpedo 同样的直写理由）。
   *
   * 2026-10-02 字人修正：此前循环内 `return true` 只减了**第一座**装填中的炮位，
   * 其余漏掉（描述说的是「当前水雷装填时间-2s」，玩家预期是所有在装填的都加速）。
   * 现改为遍历全部 `mineMounts`。返回值改为「被推进的座数」，供调用方/测试观察。
   */
  _skipMineReload(ship, now) {
    const mounts = ship.mineMounts || [];
    let n = 0;
    for (let i = 0; i < mounts.length; i++) {
      const m = mounts[i];
      if (m && m.cooldownEnd > now) {
        m.cooldownEnd = Math.max(now, m.cooldownEnd - YANYIN_HUNT_MINE_CD_SKIP_MS);
        n++;
      }
    }
    return n;
  },

  /**
   * 主动⑤：敌舰鱼雷/水雷减伤各 -5 点/层（4 层封顶，10s 刷新式）。
   * 先回收已过期层（hasBuff 独立于 cleanBuffs 时机），再叠新层 → 断档后从 1 层重新起。
   */
  _applyEnemyDebuff(target, now) {
    if (target._yanyinHuntDebuffPoints && !target.hasBuff('yanyinHuntDebuff', now)) this._revertEnemyDebuff(target);
    const n = Math.min(YANYIN_HUNT_STACK_MAX, (target._yanyinHuntDebuffStacks || 0) + 1);
    target._yanyinHuntDebuffStacks = n;
    this._setEnemyReduce(target, -YANYIN_HUNT_ENEMY_REDUCE_PER * n);
    target.addBuff('yanyinHuntDebuff', '鱼雷水雷减伤降低', now + YANYIN_HUNT_STACK_MS,
      { huntDebuff: n }, n);
    return n;
  },

  /**
   * 把敌舰的鱼雷/水雷减伤字段设到目标点数（points 可为负 = 降低减伤；幂等）。
   * 只记 delta，不改舰体原有减伤；负值 → collision-hit.js:129 的
   * `Math.min(100 - y + x, 100)` 封顶 100，不会变成增伤。
   */
  _setEnemyReduce(target, points) {
    const cur = target._yanyinHuntDebuffPoints || 0;
    const d = points - cur;
    if (d !== 0) {
      target.reduceTorpedoDmg = (target.reduceTorpedoDmg || 0) + d;
      target.reduceMineDmg = (target.reduceMineDmg || 0) + d;
    }
    target._yanyinHuntDebuffPoints = points;
  },

  /** 回收敌舰减伤降层（到期时调用；幂等） */
  _revertEnemyDebuff(target) {
    this._setEnemyReduce(target, 0);
    target._yanyinHuntDebuffStacks = 0;
    target.removeBuff('yanyinHuntDebuff');
  },

  /**
   * 被动②：必定漏水（**不判** Math.random() < floodChance − resistFloodChance）。
   * 每跳伤害 / 间隔 / 时长 三个参数**照抄** collision.js:325-331 的算法，
   *   唯一区别是 floodPower 取「本舰水雷的」而非命中弹丸的（hook 未传 proj，故现算）。
   * 程度仍吃 target.resistFloodPower（与普通漏水一致）。
   */
  _applyFlood(ship, target, now) {
    const prof = this._mineFloodProfile(ship);
    const pHp = target.getPercentDamageBase(ship.maxHp);
    const dmgPerTick = Math.round(pHp * FLOOD_DAMAGE_PCT
      * Math.max(0, 1 + prof.floodPower - (target.resistFloodPower || 0)));
    let tickInterval = FLOOD_INTERVAL / ((100 + prof.floodSpeed - (target.floodDelay || 0)) / 100);
    if (tickInterval < 1) tickInterval = 1;     // 下限 1s
    if (tickInterval > 4) tickInterval = 4;     // 上限 4s
    const duration = FLOOD_DURATION * (1 + prof.floodDuration);
    return target.applyFlood(dmgPerTick, tickInterval, duration, now, ship);
  },

  /**
   * 本舰水雷的漏水词条合计（舰体基础 + 武器 bonuses）——
   *   与 weapon-config.js:51-53 的 effFlood* 同一算法；hook 未传弹丸，故按武器库现算。
   * 取第一个有效水雷槽的武器（多槽同武器为常态；槽位顺序 = mineMounts 顺序）。
   */
  _mineFloodProfile(ship) {
    let w = null;
    const mounts = ship.mineMounts || [];
    for (let i = 0; i < mounts.length && !w; i++) {
      if (!mounts[i] || !mounts[i].weaponId) continue;
      const g = getWeaponById(mounts[i].weaponId);
      if (g && g.type === 'mine') w = g;
    }
    const b = (w && w.bonuses) || {};
    return {
      floodPower: (ship.floodPower || 0) + (b.floodPower || 0),
      floodSpeed: (ship.floodSpeed || 0) + (b.floodSpeed || 0),
      floodDuration: (ship.floodDuration || 0) + (b.floodDuration || 0),
    };
  },
};

// 系统自登记（2026-10-01）：main.js 经 GameSystems.updateAll 每帧对每艘本方舰调用
// （玩家 + AI 友军），故**无需**在 main.js gameLoop 单独插 update 调用。
// 敌舰减伤降层的回收也放在这里 —— updateAll 只跑 player+allies（main.js:666），
//   故本模块自己在 update 里扫 enemies。
GameSystems.register('yanyin-hunt', {
  order: 21,   // 后于 yanyin-pursuit(20) / a140a-storm(10)
  update: function(ship, dt, now, allies, enemies) {
    YanyinHunt.update(ship, dt, now, allies, enemies);
  },
});