/**
 * detection.js — Player-only detection / spotting system.
 *
 * Surface (12 km) : enemy ships visible on map & minimap only inside this range.
 * Underwater (6 km) : enemy torpedoes visible only inside this range.
 * Player's own torpedoes are always visible.
 * AI has unlimited detection (no checks needed).
 *
 * Dependencies: PX_PER_KM (constants.js)
 */
const Detection = {

  /** Surface detection range in world px (12 km). */
  surfaceRange: 12 * PX_PER_KM,       // 1200

  /** Underwater (sonar) detection range in world px (6 km). */
  underwaterRange: 6 * PX_PER_KM,     // 600

  /**
   * Whether the observer can currently see the given target ship.
   *
   * 判定顺序（2026-09-13 统一收敛，字人要求"雷达损毁依然能看到队友点亮的敌人、
   * 不影响看见有'被发现'减益的敌人"）：
   *   ① 目标带「被点亮」标记（lit / visibleToBlue）→ 恒可见（无视观察者雷达状态）
   *   ①b 私有「被发现」（A-140A）→ 仅施加者可见
   *   ①c 目标带「雷达干扰」且距离 > 有效干扰值 → 不可见（2026-10-01 阳炎-利刃）
   *   ② 观察者雷达损毁（radarOff）→ 自身水上探测归零
   *   ③ 否则按观察者水上探测范围判定
   *
   * @param {Ship} observer — 观察者（历史参数名 player）
   * @param {Ship} target   — 目标舰
   * @returns {boolean}
   */
  canSeeShip(observer, target) {
    if (!observer || !target || !target.isAlive) return false;
    // 观察者已阵亡 → 不贡献视野（2026-09-13 修"死亡敌人视野残留"：
    //   enemies 数组从不移除死舰，此前死舰仍作为观察者参与 canSeeShipByAny 阵营共享 →
    //   2 个敌人打死 1 个后，给另一个打雷达损毁也无效（死舰替它"看见"了玩家）。
    //   字人反馈场景：自定义战斗 2 敌，打死 1 个再对另 1 个雷达损毁 → 依然被发现）
    // ⚠️ 判据用 "hp 已初始化为数字且 ≤0"（而非 isAlive getter）：isAlive = hp>0，
    //   未传 hp 的 mock/测试夹具（this.hp === undefined）会被误判为阵亡 —— 严格区分两者。
    if (typeof observer.hp === 'number' && observer.hp <= 0) return false;
    // ① 被点亮（华晟战神盾破 / 杜尔曼盾爆等给的 lit，标记型 visibleToBlue）：恒可见
    if (target.hasBuff && target.hasBuff('lit')) return true;
    // ①b 私有「被发现」（A-140A 炮火风暴，2026-09-19）：**仅施加者本人**可见，不共享队友。
    //   存于 target._litPrivate[施法者uid]（uid = LockSystem.uid）；由 A140AStorm.update 维护与清理。
    //   ⚠️ 与 ① 的全局 lit 区分：本分支只让"施加者这一艘"看见，阵营共享（canSeeShipByAny）时其它友军看不到；
    //      而"雷达来源的视野"仍走 ③ 正常共享，不受本分支影响。
    var obsUid = observer._lockUid;
    if (obsUid && target._litPrivate && target._litPrivate[obsUid] > Date.now()) return true;
    // ①c 雷达干扰（2026-10-01 阳炎-利刃）：目标带 radarJamming 且 ≠ null/undefined 时，
    //   距离 > 有效干扰值 → 不可见。有效干扰 = max(0, 目标.radarJamming − 观察者.antiRadarJamming)。
    //   antiRadarJamming = ship 字段（base）+ buff mod（技能「反雷达干扰+1km」）。
    //   三态：undefined = 无词条跳过（当前行为）；0 = 永久隐身（dist > 0 恒 true）；>0 = 正常。
    //   不影响 ① 的 lit（技能点亮）与 ①b 的私有可见——它们在前面已 return true。
    if (target.radarJamming != null) {
      var _antiJam = (observer.antiRadarJamming || 0)
        + (observer.getBuffMod ? (observer.getBuffMod('antiRadarJamming') || 0) : 0);
      var _effJamKm = Math.max(0, target.radarJamming - _antiJam);
      if (Math.hypot(observer.x - target.x, observer.y - target.y) > _effJamKm * PX_PER_KM) return false;
    }
    // ② 雷达损毁：自身水上探测归零（阵营共享 ByAny 仍靠其它观察者贡献）
    var range = (observer.getBuffMod && observer.getBuffMod('radarOff') > 0) ? 0 : (observer.surfaceRange || this.surfaceRange);
    return Math.hypot(observer.x - target.x, observer.y - target.y) <= range;
  },

  /**
   * Whether the observer can currently see a projectile (torpedo).
   * Main-gun shells are ALWAYS visible (move too fast to matter).
   * Observer's own torpedoes are ALWAYS visible.
   * Enemy torpedoes visible only inside underwater detection range.
   * @param {Ship} observer — 观察者（历史参数名 player）
   * @param {object}     proj — TorpedoProjectile or MainGunShell
   * @returns {boolean}
   */
  canSeeProjectile(observer, proj) {
    if (!observer || !proj) return true;
    // Always show main-gun shells (they are fast & visible to both sides)
    if (proj instanceof MainGunShell) return true;
    // Observer's own torpedoes
    if (proj instanceof TorpedoProjectile && proj.isPlayer) return true;
    // 观察者已阵亡 → 不贡献水下探测（2026-09-13，同 canSeeShip：防死亡敌人视野残留）
    // 判据同 canSeeShip：hp 已初始化为数字且 ≤0（兼容未传 hp 的 mock/测试夹具）
    if (typeof observer.hp === 'number' && observer.hp <= 0) return false;
    // Enemy torpedoes — visibility gated by underwater detection
    if (proj instanceof TorpedoProjectile) {
      // 雷达损毁（2026-09-05）：自身水下探测归零
      var urange = (observer.getBuffMod && observer.getBuffMod('radarOff') > 0) ? 0 : (observer.underwaterRange || this.underwaterRange);
      return Math.hypot(observer.x - proj.x, observer.y - proj.y) <= urange;
    }
    // 水雷：我方/友军恒可见；敌方水雷需进入"引爆半径 + 0.5 km"才显示（与探测无关，每帧刷新）
    if (proj instanceof SeaMine) {
      if (proj.isPlayer || (proj.team && proj.team !== 'enemy')) return true;
      return Math.hypot(observer.x - proj.x, observer.y - proj.y) <= proj.detonationRadius + MINE_REVEAL_EXTRA_KM * PX_PER_KM;
    }
    return true; // fallback
  },

  /**
   * 任一观察者能看到目标舰船（阵营共享视野核心）。
   * 阵营内任一单位按自己探测范围看到 → 全阵营共享。
   * @param {Array} observers — 观察者数组（如蓝方 [player].concat(allies)）
   * @param {Ship}  target
   * @returns {boolean}
   */
  canSeeShipByAny(observers, target) {
    if (!observers || !observers.length) return false;
    for (var i = 0; i < observers.length; i++) {
      if (this.canSeeShip(observers[i], target)) return true;
    }
    return false;
  },

  /**
   * 任一观察者能看到弹丸（鱼雷/水雷；内部规则复用 canSeeProjectile）。
   * @param {Array} observers
   * @param {object} proj
   * @returns {boolean}
   */
  canSeeProjectileByAny(observers, proj) {
    if (!observers || !observers.length) return false;
    for (var i = 0; i < observers.length; i++) {
      if (this.canSeeProjectile(observers[i], proj)) return true;
    }
    return false;
  },
  /**
   * 目标是否被观察者阵营发现（水上探测；用于"被发现"警示）。
   * @param {Array} observers — 观察者数组（如红方 enemies）
   * @param {Ship}  target
   * @returns {boolean}
   */
  isDetectedBy(observers, target) {
    return this.canSeeShipByAny(observers, target);
  },
};
