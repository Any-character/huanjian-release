/**
 * class-skill-actives.js — 舰种主动技能的「执行体」分发表（2026-11-15）
 *
 * 为什么单独一个文件：`systems/class-skills.js` 负责**通用机制**（选系过滤 / 冷却 / 按键 /
 *   图标状态），具体每个技能「干了什么」是另一件事，生命周期也不同（机制一次做对，技能会一直加）。
 *   这里只放 skillId → 执行函数的表，加技能 = 往 HANDLERS 里加一行，机制文件不用动。
 *   与战舰技能的分发点 `ShipSkills._runActive`（if-else 链）分工相同，只是那边按舰写死。
 *
 * 契约（缺一条就静默失效，别改）：
 *   · 调用方只有 `ClassSkills.triggerActive`（它已经判过冷却并写好 `ship._classActiveCd`）。
 *     本文件**不判冷却、不写冷却**——冷却属于机制层，技能执行体只负责效果本身。
 *   · `run(ship, skillId, now)` 返回 boolean（true = 有执行体且被执行）。
 *     表里登记为 `null` 的技能 = **效果尚未实装**，run 返回 false 且**什么也不做**
 *     （冷却照常由调用方写入：技能按钮确实按出去了，只是暂时没有战斗效果）。
 *   · 新增已开放（`ready:true`）的主动技能，必须在 HANDLERS 里登记它的 id，
 *     否则按键能按、冷却会转、但永远不会有效果，且没有任何报错 —— 守卫在单测第 85 节。
 *
 * ⚠️ 效果的通用约束（做具体技能时照做，详见 specs/2026-11-15-battleship-class-skills-design.md §4）：
 *   · 回血走唯一入口 `ship.gainHp(amount)`（自动飘绿字，§5.36），禁止直接写 ship.hp
 *   · 百分比扣血走 `target.getPercentDamageBase()`
 *   · 按 maxHp 百分比的回血基数 = **本舰最大生命**
 */

const ClassSkillActives = {
  /* ── 主动弹种口径（2026-11-15 战列舰「毁灭」）────────────────────────────
   * 碎甲弹：碎甲程度 +5%、主炮炮速 +2000 武器速度单位（×0.057 = 114 px/s）
   * 致命弹：暴击伤害 +10%
   * 口径与数据 desc / 设计规格 §3 一致；改这里必须同步 desc 与单测第 85 节。 */
  SHATTER_POWER: 0.05,
  SHATTER_SHELL_SPEED_UNITS: 2000,
  FATAL_CRIT_DMG: 0.10,

  /* ── 绝望讴歌口径（2026-11-15 战列舰「毁灭」）──────────────────────────────
   * 持续 20s；暴击伤害 +10% / 穿甲伤害 +10%（走 buff mod critDmgAdd / penDmgAdd）；
   * 主炮每命中回 1% 最大生命（无次数上限）；期间每击沉敌舰回 20% 最大生命。 */
  DESPERATE_DURATION_MS: 20000,
  DESPERATE_CRIT_DMG: 0.10,
  DESPERATE_PEN_DMG: 0.10,
  DESPERATE_HIT_HEAL_PCT: 0.01,
  DESPERATE_KILL_HEAL_PCT: 0.20,

  /**
   * skillId → function(ship, now) | null
   * `null` = 只为「一键一技能」占位，效果由后续任务填。
   */
  HANDLERS: {
    // ── 战列舰「毁灭」一系（2026-11-15）────────────────────────────────────
    'destruction-shatter-shot': function(ship, now) { return ClassSkillActives._armShells(ship, 'shatter'); },  // 碎甲射击（q，60s）
    'destruction-fatal-shot': function(ship, now) { return ClassSkillActives._armShells(ship, 'fatal'); },      // 致命射击（e，180s）
    'destruction-desperate-chant': function(ship, now) { return ClassSkillActives._startDesperateChant(ship, now); },  // 绝望讴歌（r，200s） 绝望讴歌（r，200s）：下一棒
  },

  /**
   * 给全部主炮各挂一发弹种（碎甲/致命互斥：后挂清先挂，效果不叠加）。
   * @param {Ship} ship
   * @param {string} kind — 'shatter' | 'fatal'
   * @returns {boolean} 是否真的挂上（无主炮 → false）
   */
  _armShells(ship, kind) {
    if (!ship || !ship.mainGunMounts || !ship.mainGunMounts.length) return false;
    var onKey = kind === 'shatter' ? '_shatterShell' : '_fatalShell';
    var offKey = kind === 'shatter' ? '_fatalShell' : '_shatterShell';
    for (var i = 0; i < ship.mainGunMounts.length; i++) {
      ship.mainGunMounts[i][onKey] = true;
      ship.mainGunMounts[i][offKey] = false;
    }
    return true;
  },

  /**
   * 开火消费（ship-weapons.js fireMainGun 调）：把炮位上挂的弹种标到本轮齐射**全部炮弹**并消费。
   * 与威斯康星重击弹（mount._heavy）同模型；碎甲/致命互斥（挂弹时已清另一个），但都与重击弹共存。
   * @param {Object} mount — mainGunMounts[i]
   * @param {Array} shells — 本轮齐射弹丸
   */
  consumeMount(mount, shells) {
    if (!mount || !shells || !shells.length) return;
    if (mount._shatterShell) {
      for (var i = 0; i < shells.length; i++) {
        shells[i].isShatterShell = true;
        shells[i].shatterPower = (shells[i].shatterPower || 0) + this.SHATTER_POWER;
        shells[i].speed = (shells[i].speed || 0) + this.SHATTER_SHELL_SPEED_UNITS * 0.057;
      }
      mount._shatterShell = false;
    }
    if (mount._fatalShell) {
      for (var j = 0; j < shells.length; j++) {
        shells[j].isFatalShell = true;
        shells[j].critDmg = (shells[j].critDmg || 0) + this.FATAL_CRIT_DMG;
      }
      mount._fatalShell = false;
    }
  },

  /**
   * 绝望讴歌（战列舰「毁灭」）：开启 20s 增益。
   * 增益走 buff mod `critDmgAdd` / `penDmgAdd` —— 主炮弹丸构造（ship-weapons.js）会读这两个 mod，
   * 所以「暴击伤害 +10% / 穿甲伤害 +10%」会真的进弹丸（不是只挂个图标）。
   * 命中回血 / 击沉回血由 onMainGunHit / onKill 在命中与击沉处调用。
   * @param {Ship} ship
   * @param {number} now
   * @returns {boolean}
   */
  _startDesperateChant(ship, now) {
    if (!ship || !ship.addBuff) return false;
    ship.addBuff('desperateChant', '绝望讴歌', now + this.DESPERATE_DURATION_MS, {
      critDmgAdd: this.DESPERATE_CRIT_DMG,
      penDmgAdd: this.DESPERATE_PEN_DMG,
    });
    return true;
  },

  /**
   * 主炮命中回调（collision.js `_applyMGHit` 调）：绝望讴歌激活中 → 回 1% 最大生命（无次数上限）。
   * @param {Ship} owner — 开火舰（攻击方）
   * @param {number} now
   * @returns {boolean} 是否回了血
   */
  onMainGunHit(owner, now) {
    if (!owner || !owner.hasBuff || !owner.gainHp) return false;
    if (!owner.hasBuff('desperateChant', now)) return false;
    owner.gainHp(owner.maxHp * this.DESPERATE_HIT_HEAL_PCT);
    return true;
  },

  /**
   * 击沉回调（battle-stats.js `checkDeaths` 调）：绝望讴歌激活中的玩家击沉敌舰 → 回 20% 最大生命。
   * @param {Ship} killer — 击杀者（只有玩家才回）
   * @param {number} now
   * @returns {boolean} 是否回了血
   */
  onKill(killer, now) {
    if (!killer || !killer.hasBuff || !killer.gainHp) return false;
    if (!killer.hasBuff('desperateChant', now)) return false;
    killer.gainHp(killer.maxHp * this.DESPERATE_KILL_HEAL_PCT);
    return true;
  },

  /**
   * 执行一个舰种主动技能。
   * @param {Ship} ship
   * @param {string} skillId — 数据里的 skill.id
   * @param {number} now
   * @returns {boolean} 是否有执行体被执行
   */
  run(ship, skillId, now) {
    if (!ship || !skillId) return false;
    var fn = this.HANDLERS[skillId];
    if (typeof fn !== 'function') return false;   // 未实装 → 无战斗效果（不是错误）
    return fn(ship, now) !== false;
  },
};
