/**
 * commander.js — 指挥官运行时（被动聚合 + 主动技能状态机 + 命中处理）
 *
 * 挂载方式：main.js 战斗开始时 `commander = new CommanderRuntime(id, player)`，
 * 并 `commander.applyPassives()`；开火钩子/碰撞/主循环经 `player.commander` 访问。
 *
 * 效果词条分发（effect → 聚合）：
 *   mainGunShellSpeed       → _shellSpeedBonus（px/s，value 为游戏炮速单位 ×0.057）
 *   armorFlat               → _armorBonus（player.armor 直接加）
 *   dmgPct / cdPct          → _dmgPct/_cdPct[weapon]（weapons 字段指定生效武器）
 *   surfaceBuffOnEnemyHit   → 受敌方主炮命中触发探测范围 buff（value km / duration s / cooldown s）
 *
 * 主动技能（activeSkills[0] = Z计划 状态机）：
 *   useActive → 净化窗口（clearWindowSec，每 clearTickMs 清一次燃烧/进水）
 *               + 回血窗口（healWindowSec，命中敌舰按等级回血）
 *   命中计数：每 hitsPerLevel 次 +1 级（至 maxLevel），等级提升伤害/冷却词条
 *   窗口到期：回 1 级并清零计数；60s 冷却
 */

class CommanderRuntime {
  constructor(commanderId, player) {
    this.player = player;
    this.def = null;
    if (commanderId && COMMANDER_LIBRARY) {
      for (var i = 0; i < COMMANDER_LIBRARY.length; i++) {
        if (COMMANDER_LIBRARY[i].id === commanderId) this.def = COMMANDER_LIBRARY[i];
      }
    }
    this.active = !!this.def;
    this._handler = createCommanderHandler(commanderId);   // 指挥官专属状态机处理器（2026-09-18 Phase 2）

    // 被动聚合
    this._shellSpeedBonus = 0;            // px/s
    this._armorBonus = 0;
    this._dmgPct = { mainGun: 0, torpedo: 0, secondary: 0, mine: 0 };
    this._cdPct   = { mainGun: 0, torpedo: 0, secondary: 0, mine: 0 };
    this._surfacePassive = null;

    // 战争局势
    this._baseSurfaceRange = player ? player.surfaceRange : 0;
    this.surfaceBuff = null;              // { baseRange, endTime }
    this._surfaceCooldownUntil = 0;       // 冷却独立于 buff 对象（buff 到期即清除，冷却须保留）

    // Z计划状态机
    this.zplan = {
      level: 1, hitCount: 0, nextLevelAt: 8,
      clearEnd: 0, nextClear: 0, healEnd: 0, cdEnd: 0,
    };

    // 塞耶·马汉状态机（暴击/燃烧炮术 + 战略论 + 海权论）
    this._critPassive = null;      // critBuff 被动定义
    this._burnPassive = null;      // burnBuff 被动定义
    this._lowHpPassive = null;     // lowHpRegen 被动定义
    this.mahan = {
      critBuff: false, burnBuff: false,      // 增益是否持有（无时限，打出暴击/燃烧移除）
      nextCritTick: 0, nextBurnTick: 0,      // 每分钟检查点（ms）
      nextLowHpRegen: 0,                     // 战略论下次回血点（0 = 未开始计时）
      useCount: 0, cdEnd: 0,                 // 海权论已用次数 / 冷却
    };

    // 华晟聚合（2026-08-06）：被动数值先聚合到 this._xxxFlat，applyPassives 末尾应用到玩家
    this._penFlat = 0;             // 全武器穿透
    this._shieldShredFlat = 0;     // 护盾撕裂
    this._hpFlat = 0;              // 血量
    this._dmgToOneFlat = 0;        // 受到武器伤害为1几率
    this._negateCritFlat = 0;      // 被暴击豁免
    this._fearAuraPassive = null;  // 畏惧光环定义

    // 杜尔曼聚合（2026-08-06）
    this._ignoreArmorFlat = 0;     // 无视装甲（点）
    this._cdPctFlatAll = 0;        // 全武器装填（基础减）
    this._resistShatterDegreeFlat = 0;  // 抵抗碎甲程度
    this._hullProtectFlat = 0;     // 舰体保护
    this._dmgPctFlatAll = 0;       // 全武器伤害%（装填大师，走 getDmgPct，2026-08-06）
    this._accuracyFlat = 0;        // 射击精度（装填大师，常驻 buff weaponAccuracyAdd，2026-08-06）
    this._learnMaster = null;      // 学有所长定义
    this._matrixPassive = null;    // 防御矩阵定义
    this._attackTransform = null;  // 进攻转化定义
    // 杜尔曼状态机
    this.durman = {
      charge: 0,                   // 当前充能层数（使用机会）
      chargeMax: 1,                // 充能上限（击沉 1 舰 → 2）
      chargeAt: 0,                 // 下次充能时间（冷却循环）
      unlocked2: false,            // 是否已解锁第 2 层（击沉 1 舰）
      lastKills: 0,                // 上次击杀数（轮询解锁）
      mirrorEnd: 0,                // 水镜盾到期时间（技能持续至）
      mirrorShield: 0,             // 水镜数值盾剩余
      mirrorBurstBroken: false,    // 盾是否被打爆过（决定减600/疲弱）
      matrixTriggered: false,      // 防御矩阵低血是否已触发（每场一次）
      layerShield: 0,              // 防御矩阵层盾剩余层数
      layerEnd: 0,                 // 层盾到期
      learnCd: {},                 // 学有所成冷却（shatter/crit/pen 各自 endTime）
      transformUsed: false,        // 进攻转化涅槃是否已触发（致死免疫，每场一次，2026-08-06）
    };
    // 军魂状态机（T5 实现完整逻辑）
    this.huasheng = {
      souls: 0,                    // 当前军魂数（0~6）
      lostAccum: 0,                // 被打血量累计（占 maxHp 比例，每 10% 得 1 军魂）
      dealtAccum: 0,               // 造成伤害累计（占目标 maxHp 比例）
      next40sTick: 0,              // 每 40 秒 +1 军魂检查点
      lastHp: player ? player.hp : 0,  // 上次血量（被打 10% 判定）
      warGodEnd: 0, cdEnd: 0,      // 战神模式结束 / 主动冷却
      invincibleUntil: 0,          // 无敌截止
      prevSoulsApplied: 0,         // 已应用的军魂数（属性增量重算基准）
      warGodOn: false,             // 战神模式中（护盾破事件用）
    };

    // 卢金斯状态机（2026-09-13）
    this.lutjens = {
      salvoOn: false,            // 齐射模式开关（true=齐射模式）
      switchCdEnd: 0,            // 切换冷却截止（1s 防连点）
      perfectAccum: 0,           // 完美装甲：受敌舰伤害累计（hp）
      perfectLayers: 0,          // 完美装甲：武器精度层数（0~5）
    };

    this.buffs = [];                      // [{key, name, endTime}] → 增益图标
    this.pendingHeals = [];               // [{amount}] → 绿字回血飘字
    this.pendingSkillHits = [];           // [{x, y, damage}] → 技能伤害红字飘字（杜尔曼水镜盾爆炸 2026-08-06）
    this.enemiesRef = null;               // 敌舰引用（华晟战神/杜尔曼盾爆遍历用）
  }

  /* ── 被动聚合 ──────────────────────────────────────────────── */

  applyPassives() {
    if (!this.active) return;
    var p = this.def.passives;
    for (var i = 0; i < p.length; i++) {
      var fx = p[i];
      if (fx.effect === 'mainGunShellSpeed') {
        this._shellSpeedBonus += fx.value * 0.057;
      } else if (fx.effect === 'armorFlat') {
        this._armorBonus += fx.value;
        if (this.player) this.player.armor += fx.value;
      } else if (fx.effect === 'dmgPct') {
        for (var w = 0; w < fx.weapons.length; w++) this._dmgPct[fx.weapons[w]] += fx.value;
      } else if (fx.effect === 'cdPct') {
        for (var w2 = 0; w2 < fx.weapons.length; w2++) this._cdPct[fx.weapons[w2]] += fx.value;
      } else if (fx.effect === 'surfaceBuffOnEnemyHit') {
        this._surfacePassive = fx;
      } else if (fx.effect === 'critBuff') {
        this._critPassive = fx;
      } else if (fx.effect === 'burnBuff') {
        this._burnPassive = fx;
      } else if (fx.effect === 'lowHpRegen') {
        this._lowHpPassive = fx;
      } else if (fx.effect === 'penFlat') {
        this._penFlat += fx.value;
      } else if (fx.effect === 'shieldShredFlat') {
        this._shieldShredFlat += fx.value;
      } else if (fx.effect === 'hpFlat') {
        this._hpFlat += fx.value;
      } else if (fx.effect === 'dmgToOneFlat') {
        this._dmgToOneFlat += fx.value;
      } else if (fx.effect === 'negateCritFlat') {
        this._negateCritFlat += fx.value;
      } else if (fx.effect === 'fearAura') {
        this._fearAuraPassive = fx;
      } else if (fx.effect === 'ignoreArmorFlat') {
        this._ignoreArmorFlat += fx.value;
        this._hpFlat += fx.hpFlat || 0;   // 坚固护甲：血量+2000
      } else if (fx.effect === 'cdPctFlatAll') {
        this._cdPctFlatAll += fx.value;
        this._shieldShredFlat += fx.shieldShredFlat || 0;   // 装填大师：护盾撕裂+10%
        this._dmgPctFlatAll += fx.dmgPctFlatAll || 0;       // 装填大师：武器伤害+8%（2026-08-06）
        this._accuracyFlat += fx.accuracyFlat || 0;         // 装填大师：射击精度+10%（2026-08-06）
      } else if (fx.effect === 'resistShatterDegreeFlat') {
        this._resistShatterDegreeFlat += fx.value;
        this._hullProtectFlat += fx.hullProtectFlat || 0;   // 船体加固：舰体保护+20%
        this._resistCritChanceFlat = (this._resistCritChanceFlat || 0) + (fx.resistCritChanceFlat || 0);   // 船体加固：抵抗暴击+10%（2026-08-06）
        this._reduceCritDmgFlat = (this._reduceCritDmgFlat || 0) + (fx.reduceCritDmgFlat || 0);             // 船体加固：减免暴击伤害+20%（2026-08-06）
      } else if (fx.effect === 'learnMaster') {
        this._learnMaster = fx;
      } else if (fx.effect === 'defenseMatrix') {
        this._matrixPassive = fx;
      } else if (fx.effect === 'attackTransform') {
        this._attackTransform = fx;
      } else if (fx.effect === 'secondaryRangeFlat') {
        // 卢金斯·极限副炮：副炮射程 km（动态消费 getSecondaryRangePx，不改 weaponCfg）
        this._secondaryRangeFlatKm = (this._secondaryRangeFlatKm || 0) + (fx.value || 0);
      } else if (fx.effect === 'critDmgFlat') {
        // 卢金斯·暴伤提升
        if (this.player) this.player.critDmg = (this.player.critDmg || 0) + fx.value;
      } else if (fx.effect === 'resistDamageFlat') {
        // 卢金斯·抵抗损毁：抵抗武损 + 抵抗配损
        if (this.player) {
          this.player.resistWeaponDamageChance = (this.player.resistWeaponDamageChance || 0) + (fx.resistWeaponDamage || 0);
          this.player.resistAccessoryChance = (this.player.resistAccessoryChance || 0) + (fx.resistAccessory || 0);
        }
      } else if (fx.effect === 'perfectArmor') {
        // 卢金斯·完美装甲：静态抵抗 +3%×4；动态触发（受敌舰伤害累计）在 main.js hitEvents
        if (this.player) {
          this.player.resistBurnChance = (this.player.resistBurnChance || 0) + (fx.resistBurn || 0);
          this.player.resistFloodChance = (this.player.resistFloodChance || 0) + (fx.resistFlood || 0);
          this.player.resistCritChance = (this.player.resistCritChance || 0) + (fx.resistCrit || 0);
          this.player.resistPenetration = (this.player.resistPenetration || 0) + (fx.resistPen || 0);
        }
        this._perfectArmor = fx;
      } else if (fx.effect === 'professionalDispatch') {
        // 卢金斯·专业调度：击沉互装填（main.js hitEvents 检测击沉分发）
        this._professionalDispatch = fx;
      }
    }
    // 应用到玩家（player 存在时；测试传 null 只聚合字段）
    if (this.player) {
      if (this._penFlat) {
        this.player.mainPen = (this.player.mainPen || 0) + this._penFlat;
        this.player.torpPen = (this.player.torpPen || 0) + this._penFlat;
        this.player.minePen = (this.player.minePen || 0) + this._penFlat;
      }
      if (this._shieldShredFlat) this.player.shieldShred = (this.player.shieldShred || 0) + this._shieldShredFlat;
      if (this._hpFlat) {
        this.player.maxHp += this._hpFlat;
        this.player.hp += this._hpFlat;
      }
      if (this._dmgToOneFlat) this.player.dmgToOneChance = (this.player.dmgToOneChance || 0) + this._dmgToOneFlat;
      if (this._negateCritFlat) this.player.negateCritChance = (this.player.negateCritChance || 0) + this._negateCritFlat;
      // 杜尔曼（2026-08-06）
      if (this._ignoreArmorFlat) this.player.ignoreArmor = (this.player.ignoreArmor || 0) + this._ignoreArmorFlat;
      if (this._resistShatterDegreeFlat) this.player.resistShatterDegree = (this.player.resistShatterDegree || 0) + this._resistShatterDegreeFlat;
      if (this._hullProtectFlat) this.player.hullProtect = (this.player.hullProtect || 0) + this._hullProtectFlat;
      if (this._resistCritChanceFlat) this.player.resistCritChance = (this.player.resistCritChance || 0) + this._resistCritChanceFlat;   // 船体加固：抵抗暴击（2026-08-06）
      if (this._reduceCritDmgFlat) this.player.reduceCritDmg = (this.player.reduceCritDmg || 0) + this._reduceCritDmgFlat;             // 船体加固：减免暴击伤害（2026-08-06）
      // 装填大师：射击精度 +10% → 常驻 buff weaponAccuracyAdd（所有武器弹丸创建时聚合，2026-08-06）
      if (this._accuracyFlat) {
        this.player.addBuff('loaderAccuracy', '装填大师·精度', Infinity, { weaponAccuracyAdd: this._accuracyFlat });
      }
      // 进攻转化：按初始装甲/血量精确比例加暴击率/穿甲率/暴击伤害/穿甲伤害（碎甲等临时装甲变化不重算）
      if (this._attackTransform && this.player) {
        var armorK = Math.max(0, this.player.armor || 0) / this._attackTransform.armorPerK;
        var hpK = Math.max(0, this.player.maxHp || 0) / this._attackTransform.hpPerK;
        var atPct = armorK * this._attackTransform.critPenPctPerK;
        var atDmg = hpK * this._attackTransform.critPenDmgPerK;
        this.player.critChance = (this.player.critChance || 0) + atPct;
        this.player.penetrationChance = (this.player.penetrationChance || 0) + atPct;
        this.player.critDmg = (this.player.critDmg || 0) + atDmg;
        this.player.penDmg = (this.player.penDmg || 0) + atDmg;
        this.durman.atPct = atPct; this.durman.atDmg = atDmg;
      }
      // 水镜盾充能初始化（杜尔曼 2026-08-06）：初始满层（上限 1，击沉解锁 2）
      var dsk = this.def.activeSkills && this.def.activeSkills[0];
      if (dsk && dsk.type === 'mirrorShield') {
        this.durman.chargeMax = dsk.maxCharge || 1;
        this.durman.charge = dsk.maxCharge || 1;
      }
    }
  }

  getShellSpeedBonus() {
    return this.active ? this._shellSpeedBonus : 0;
  }

  /**
   * 武器伤害百分比（多词条累加 + Z计划被动等级加成，按当前等级常驻生效；作用于武器伤害加成因子，2026-08-06）。
   * @param {string} weapon — 'mainGun' | 'torpedo' | 'secondary' | 'mine'
   */
  getDmgPct(weapon) {
    if (!this.active) return 0;
    var pct = this._dmgPct[weapon] || 0;
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (sk && sk.perLevelDmgPct && (weapon === 'mainGun' || weapon === 'torpedo')) {
      pct += this.zplan.level * sk.perLevelDmgPct;
    }
    // 装填大师：全武器伤害 +%（2026-08-06）
    if (this._dmgPctFlatAll) pct += this._dmgPctFlatAll;
    return pct;
  }

  /** 冷却百分比缩短（面板冷却 - 面板冷却×pct），含 Z计划被动等级加成（常驻，仅主炮/鱼雷）。 */
  getCdPct(weapon) {
    if (!this.active) return 0;
    var pct = this._cdPct[weapon] || 0;
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (sk && sk.perLevelCdPct && (weapon === 'mainGun' || weapon === 'torpedo')) {
      pct += this.zplan.level * sk.perLevelCdPct;
    }
    // 华晟军魂：每军魂全武器冷却 -2%（2026-08-06）
    if (sk && sk.type === 'warsoul' && this.huasheng.souls > 0) {
      pct += sk.perSoulCdPct * this.huasheng.souls;
    }
    // 杜尔曼装填大师：全武器装填 -value（2026-08-06）
    if (this._cdPctFlatAll) {
      pct += this._cdPctFlatAll;
    }
    return pct;
  }

  getBuffs() {
    return this.buffs;
  }

  /* ── 华晟：畏惧光环（22km 内敌舰 debuff，走 buff 系统，2026-08-06） ── */

  updateAura(now, enemies) {
    if (!this.player || !this.player.isAlive) return;
    // 畏惧光环（华晟）
    if (this._fearAuraPassive) {
      var rangePx = this._fearAuraPassive.value * PX_PER_KM;
      for (var i = 0; i < enemies.length; i++) {
        var e = enemies[i];
        if (!e || !e.isAlive) continue;
        if (Math.hypot(e.x - this.player.x, e.y - this.player.y) <= rangePx) {
          e.addBuff('fearAura', '畏惧光环', now + 1000, {
            shellSpeedMul: this._fearAuraPassive.shellSpeedMul,
            shotAccuracyPen: this._fearAuraPassive.shotAccuracyPen,
            critDmgPen: this._fearAuraPassive.critDmgPen,
          });
        }
      }
    }
    // 防御矩阵光环（杜尔曼 2026-08-06）：20km 内敌舰减益「武器伤害-8%」（畏惧光环同款：每帧刷新、出圈消失）
    if (this._matrixPassive) {
      var mxRangePx = this._matrixPassive.auraRadiusKm * PX_PER_KM;
      for (var mi = 0; mi < enemies.length; mi++) {
        var me = enemies[mi];
        if (!me || !me.isAlive) continue;
        if (Math.hypot(me.x - this.player.x, me.y - this.player.y) <= mxRangePx) {
          me.addBuff('defenseMatrix', '防御矩阵', now + 1000, {
            weaponDmgPen: this._matrixPassive.weaponDmgPen,
          });
        }
      }
    }
  }

  /**
   * 学有所长（杜尔曼 2026-08-06）：被打出碎甲/暴击/穿甲时触发（各 60s 冷却独立）。
   * @param {Ship} target — 受击方（须为杜尔曼玩家）
   * @param {string} type — 'shatter' | 'crit' | 'pen'
   * @param {number} now
   * @returns {boolean} 是否触发（shatter 触发后 tryShatter 因免疫 buff 返回 false → 本次碎甲被取消）
   */
  tryLearnTrigger(target, type, now) {
    if (!this._learnMaster || !target) return false;
    var cd = this.durman.learnCd;
    if (now < (cd[type] || 0)) return false;
    var lm = this._learnMaster;
    cd[type] = now + (lm[type + 'CdSec'] || 60) * 1000;
    if (type === 'shatter') {
      target.addBuff('shatterImmune', '免疫碎甲', now + (lm.shatterImmuneSec || 5) * 1000, {});
      return true;   // 本次碎甲将因 shatterImmune 被 tryShatter 拒绝
    }
    if (type === 'crit') {
      target.addBuff('armorBuff', '装甲强化', now + (lm.critBuffSec || 10) * 1000, { armorAdd: lm.critArmorBuff || 500 });
      return true;
    }
    if (type === 'pen') {
      target.addBuff('evasionBuff', '全口径规避', now + (lm.penBuffSec || 10) * 1000, { evasionAllAdd: lm.penEvasionBuff || 0.05 });
      return true;
    }
    return false;
  }

  /* ── 华晟：军魂（获取/属性/战神模式，2026-08-06） ─────────────────── */

  /** 军魂数量变化时的属性增量重算（每层：暴击伤害/最终增伤/穿透/最终减伤 +2%、探测 +0.5km） */
  _applySoulMods() {
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (!sk || !this.player) return;
    var diff = this.huasheng.souls - this.huasheng.prevSoulsApplied;
    if (diff === 0) return;
    this.player.critDmg = (this.player.critDmg || 0) + sk.perSoulCritDmg * diff;
    this.player.finalDmg = (this.player.finalDmg || 0) + sk.perSoulFinalDmg * diff;
    this.player.mainPen = (this.player.mainPen || 0) + sk.perSoulPen * diff;
    this.player.torpPen = (this.player.torpPen || 0) + sk.perSoulPen * diff;
    this.player.minePen = (this.player.minePen || 0) + sk.perSoulPen * diff;
    this.player.resistFinalDmg = (this.player.resistFinalDmg || 0) + sk.perSoulResistFinal * diff;
    this.player.surfaceRange += sk.perSoulDetectKm * PX_PER_KM * diff;
    this.player.underwaterRange += sk.perSoulDetectKm * PX_PER_KM * diff;
    this.huasheng.prevSoulsApplied = this.huasheng.souls;
  }

  /** 军魂 +1（上限 maxSouls；变化后重算属性） */
  _gainSoul() {
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (!sk || sk.type !== 'warsoul' || this.huasheng.souls >= sk.maxSouls) return;
    this.huasheng.souls++;
    this._applySoulMods();
  }

  /** 战神模式中？ */
  isWarGod(now) {
    return now !== undefined ? now < this.huasheng.warGodEnd : Date.now() < this.huasheng.warGodEnd;
  }

  /** 战神模式命中附加伤害（自身 maxHp×0.6%），非战神返回 0 */
  getExecFlatDmg(now) {
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (!sk || !this.isWarGod(now) || !this.player) return 0;
    return Math.round(this.player.maxHp * sk.hitMaxHpDmgPct);
  }

  /** 战神护盾被打破 → 无敌 3.5s + 22km 敌舰被点亮 6s（buff 系统） */
  onShieldBreak(now) {
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (!sk || !this.player) return;
    this.huasheng.invincibleUntil = now + sk.invincibleSec * 1000;
    this.player.addBuff('invincible', '无敌', now + sk.invincibleSec * 1000, {});
    this.buffs.push({ key: 'invincible', name: '无敌', endTime: now + sk.invincibleSec * 1000 });
    // 22km 内全部敌舰被点亮
    if (this.enemiesRef) {
      var litPx = sk.litRadiusKm * PX_PER_KM;
      for (var i = 0; i < this.enemiesRef.length; i++) {
        var e = this.enemiesRef[i];
        if (!e || !e.isAlive) continue;
        if (Math.hypot(e.x - this.player.x, e.y - this.player.y) <= litPx) {
          e.addBuff('lit', '被点亮', now + sk.litSec * 1000, { visibleToBlue: true });
        }
      }
    }
  }

  /* ── 命中处理（战争局势 + Z计划计数/回血） ───────────────── */

  onHitEvents(hitEvents, now) {
    if (!this.active || !hitEvents) return;
    // 共享：战争局势（敌方主炮命中 → 探测范围增益）
    for (var i = 0; i < hitEvents.length; i++) {
      var ev = hitEvents[i];
      if (ev.target === this.player && ev.type === 'mainGun' &&
          ev.attacker && ev.attacker.team === 'enemy') {
        if (!this.surfaceBuff && now >= this._surfaceCooldownUntil) {
          if (this._surfacePassive) {
            this.surfaceBuff = {
              baseRange: this.player.surfaceRange,
              endTime: now + this._surfacePassive.duration * 1000,
            };
            this._surfaceCooldownUntil = now + this._surfacePassive.cooldown * 1000;
            this.player.surfaceRange = this._baseSurfaceRange +
              this._surfacePassive.value * PX_PER_KM;
            this.buffs.push({ key: 'surface', name: '战争局势', endTime: this.surfaceBuff.endTime });
          }
        }
      }
    }
    // 指挥官专属命中事件（委托 handler）
    this._handler.onHitEvents(hitEvents, now, this);
  }

  drainHealEvents() {
    var out = this.pendingHeals;
    this.pendingHeals = [];
    return out;
  }

  /**
   * 玩家回血（统一入口，2026-08-06）。
   * 钳制到 maxHp：飘字显示请求量（含溢出，display 字段），战绩只统计实际回复量（amount 字段）。
   * 2026-08-07 改：溢出时依然飘绿字（display=请求量），但不会进入最终战绩统计（amount=实际量）。
   * @param {number} amount — 请求回复量
   * @returns {number} 实际回复量（0 = 满血无回复）
   */
  _healPlayer(amount) {
    if (!this.player || this.player.hp === undefined) return 0;
    amount = amount || 0;
    if (this.player.getRepairMult) amount = Math.round(amount * this.player.getRepairMult());  // 维修效率加成（唯一入口，2026-10-01）
    var before = this.player.hp;
    this.player.hp = Math.min(before + amount, this.player.maxHp);
    var actual = this.player.hp - before;
    // 只要请求回血就飘绿字（display=请求量，含溢出）；战绩只统计实际量（amount）
    if (amount > 0) this.pendingHeals.push({ amount: actual, display: amount });
    return actual;
  }

  /* ── 主动技能 ─────────────────────────────────────────────── */

  /**
   * 使用第 index 个主动技能（当前 index 0 = Z计划 或 海权论）。
   * @param {number} index
   * @param {number} now
   * @param {Array}  [allies] — 己方友军列表（海权论群体回血用；雷德尔不传）
   * @returns {boolean} 是否成功触发
   */
  /**
   * 卢金斯「完美装甲」触发（2026-09-13）：移除全部普通异常状态（燃烧/漏水/碎甲/武损/配损）
   * + 刷新武器精度层数 buff（永久层，∞ 图标；层内 mods 由层数重算）。
   * 「普通异常状态」定义见词条库 other 类（燃烧/漏水/碎甲/武损/配损五种）。
   */
  _triggerPerfectArmor(now) {
    var lj = this.lutjens;
    var p = this.player;
    if (!p || !lj) return;
    // 移除普通异常状态（五种）
    p.burnStacks = [];              // 燃烧
    p.floodState = null;            // 漏水
    p.shattered = false;            // 碎甲
    p.shatterEndTime = 0;
    var allM = p.getAllMounts();
    for (var gi = 0; gi < allM.length; gi++) {   // 武损（全部炮位清零）
      allM[gi].mount.wepDamageStart = 0;
      allM[gi].mount.wepDamageEnd = 0;
    }
    p.removeBuff('engineDamage');   // 配损 ×3
    p.removeBuff('rudderDamage');
    p.removeBuff('radarDamage');
    // 武器精度层（同 key 覆盖式重算：mods = 2% × 当前层数；永久层 → endTime Infinity 自动 ∞ 图标）
    var fx = this._perfectArmor;
    var acc = fx ? fx.accuracyPerLayer * lj.perfectLayers : 0;
    p.addBuff('perfectArmor', '完美装甲', Infinity, { weaponAccuracyAdd: acc });
  }

  useActive(index, now, allies) {
    if (!this.active) return false;
    var sk = this.def.activeSkills && this.def.activeSkills[index];
    if (!sk) return false;
    if (sk.type === 'seapower') {
      // 海权论：清自身燃烧/漏水 + 己方所有人回血；冷却 30s；至多 maxUses 次
      var m = this.mahan;
      if (m.useCount >= sk.maxUses) return false;   // 次数用尽
      if (now < m.cdEnd) return false;              // 冷却中
      m.cdEnd = now + sk.cooldownSec * 1000;
      m.useCount++;
      if (this.player) {
        this.player.burnStacks = [];
        this.player.floodState = null;
        var selfHeal = Math.round(this.player.maxHp * sk.healPct);
        this._healPlayer(selfHeal);   // 2026-08-06：钳制 maxHp，溢出不计战绩
      }
      // 己方友军回血（直接改 hp；不飘字不计数，友军无战绩）
      if (allies) {
        for (var ai = 0; ai < allies.length; ai++) {
          var a = allies[ai];
          if (a && a.isAlive && a.team !== 'enemy') {
            a.hp = Math.min(a.hp + Math.round(a.maxHp * sk.healPct), a.maxHp);
          }
        }
      }
      return true;
    }
    if (sk.type === 'warsoul') {
      // 军魂：开启战神模式（回血 + 护盾 + 附加伤害 25s）；冷却 90s
      // 2026-08-08 改：不再开启时消耗军魂——军魂保留到战神模式结束时统一清零（类似雷德尔）；
      // 回血/回盾量仍按开启瞬间的军魂数 n 计算（n 提前记录）。
      var hs = this.huasheng;
      if (hs.souls <= 0) return false;          // 无军魂不可用
      if (now < hs.cdEnd) return false;         // 冷却中
      var n = hs.souls;                         // 开启瞬间军魂数（决定回血回盾量）
      hs.cdEnd = now + sk.cooldownSec * 1000;
      hs.warGodEnd = now + sk.warGodDurationSec * 1000;
      hs.warGodOn = true;
      if (this.player) {
        var healAmt = Math.round(this.player.maxHp * sk.healPctPerSoul * n);
        this._healPlayer(healAmt);   // 2026-08-06：钳制 maxHp，溢出不计战绩
        var shieldAmt = Math.round(this.player.maxHp * sk.shieldPctPerSoul * n);
        this.player.shield += shieldAmt;
        this.player.maxShield += shieldAmt;
      }
      this.buffs.push({ key: 'warGod', name: '战神模式', endTime: hs.warGodEnd });
      return true;
    }
    if (sk.type === 'mirrorShield') {
      // 水镜之盾（杜尔曼 2026-08-06）：充能制，消耗 1 层；45% 生命值护盾 30s + 清异常 + 40% 舰体保护
      var dm = this.durman;
      if (dm.charge <= 0) return false;              // 无充能不可用
      if (!this.player) return false;
      dm.charge--;
      this._openMirrorShield(now);                   // 开盾逻辑（进攻转化涅槃复用，2026-08-06）
      return true;
    }
    if (sk.type === 'salvoSwitch') {
      // 齐射模式（卢金斯 2026-09-13）：**模式切换类**——鼠标中键开/关，切换后 1s 冷却防连点。
      // 属性均为**动态消费**（弹丸构造/射程判定处读 lutjens.salvoOn），不直接改 weaponCfg。
      var lj = this.lutjens;
      if (now < lj.switchCdEnd) return false;        // 切换冷却中
      lj.switchCdEnd = now + sk.cooldownSec * 1000;
      lj.salvoOn = !lj.salvoOn;
      // 同步通用机制开关（2026-09-13 字人要求"以后会有别的方式也有副炮跟随主炮瞄准状态"）：
      //   副炮图标行显示 / 副炮不自动开火 / 主炮开火同步副炮 都挂在 ship.secondaryFollowsMain 上，
      //   未来其它来源直接设置该字段即可（齐射模式只是当前唯一入口）
      if (this.player) this.player.secondaryFollowsMain = lj.salvoOn;
      // 切换后重建指挥官增益图标（齐射模式开 → 显示 ∞ 图标；关 → 移除）
      for (var bi = this.buffs.length - 1; bi >= 0; bi--) {
        if (this.buffs[bi].key === 'salvoMode') this.buffs.splice(bi, 1);
      }
      if (lj.salvoOn) {
        this.buffs.push({ key: 'salvoMode', name: '齐射模式', endTime: Infinity });
      }
      return true;
    }
    // Z计划
    if (now < this.zplan.cdEnd) return false;
    this.zplan.cdEnd = now + sk.cooldownSec * 1000;
    this.zplan.clearEnd = now + sk.clearWindowSec * 1000;
    this.zplan.nextClear = now + sk.clearTickMs;
    this.zplan.healEnd = now + sk.healWindowSec * 1000;
    this.buffs.push({ key: 'zplan-clear', name: 'Z计划·净化', endTime: this.zplan.clearEnd });
    this.buffs.push({ key: 'zplan-heal', name: 'Z计划·狼群', endTime: this.zplan.healEnd });
    return true;
  }

  /**
   * 水镜之盾开盾逻辑（2026-08-06 抽离）：45% 血盾 30s + 清异常 + 40% 舰体保护 + 增益图标。
   * 供 useActive（消耗充能）与进攻转化涅槃（免费）复用，不处理充能消耗。
   */
  _openMirrorShield(now) {
    var dm = this.durman;
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    if (!this.player || !sk) return;
    dm.mirrorEnd = now + sk.durationSec * 1000;
    dm.mirrorShield = Math.round(this.player.maxHp * sk.shieldPct);
    dm.mirrorBurstBroken = false;
    // 移除普通异常（燃烧/漏水/碎甲）
    this.player.burnStacks = [];
    this.player.floodState = null;
    if (this.player.shattered) {
      this.player.armor = this.player._baseArmor != null ? this.player._baseArmor : this.player.armor;
      this.player.shattered = false;
    }
    // 技能期间舰体保护 +40%（buff 自带到期）
    this.player.addBuff('mirrorHullProtect', '水镜之盾', dm.mirrorEnd, { hullProtectAdd: sk.hullProtectBonus });
    // 增益图标：盾 + 舰体保护 分开注册；盾爆只移除盾图标，舰体保护保留到 mirrorEnd
    // 重新开盾时清掉旧的破盾减伤图标（mirrorBurstBroken 已重置，-600 结束）
    this.buffs = this.buffs.filter(function (b) { return b.key !== 'mirrorShield' && b.key !== 'mirrorHullProtect' && b.key !== 'mirrorBrokenReduce'; });
    this.buffs.push({ key: 'mirrorShield', name: '水镜之盾', endTime: dm.mirrorEnd });
    this.buffs.push({ key: 'mirrorHullProtect', name: '舰体保护', endTime: dm.mirrorEnd });
  }

  /**
   * 进攻转化·涅槃（2026-08-06）：致死伤害触发一次——
   * 免疫此次伤害 + 回 20% 血 + 免费水镜之盾（不消耗充能/不冷却）+ 永久 30% 固定伤害减免（非武器伤害）。
   * 由 ship-status.js takeDamage 检测致死时调用；只触发一次。
   * @returns {boolean} 是否触发（触发后本次伤害应免疫）
   */
  _triggerTransform(now) {
    var dm = this.durman;
    var fx = this._attackTransform;
    if (!this.player || !fx || !fx.deathSave || dm.transformUsed) return false;
    dm.transformUsed = true;
    // ① 回 20% 血（钳制 maxHp，溢出不计战绩——走 _healPlayer）
    var healAmt = Math.round(this.player.maxHp * (fx.reviveHpPct || 0.2));
    this._healPlayer(healAmt);
    // ② 免费触发一次水镜之盾（不消耗充能、不进入冷却）
    if (fx.freeMirror) {
      this._openMirrorShield(now);
    }
    // ③ 永久固定伤害减免 +30%（仅非武器伤害：燃烧/漏水/技能伤害，takeDamage 消费）
    this.player.flatDamageReduce = (this.player.flatDamageReduce || 0) + (fx.reducePct || 0.3);
    // ④ 增益图标：永久减伤提示（无时限）
    this.buffs.push({ key: 'transformReduce', name: '固定减伤', endTime: Infinity, noTimer: true });
    return true;
  }

  /**
   * 主动技能显示状态：{name, ready, remaining, total, level}[]
   * Z计划 额外带 dotsTotal/dotsLit/atMaxLevel —— 图标画进度点用（ui.js 只消费，不重算命中数）。
   */
  getActiveSkillStates(now) {
    if (!this.active) return [];
    var out = [];
    var acts = this.def.activeSkills || [];
    for (var i = 0; i < acts.length; i++) {
      var sk = acts[i];
      if (sk.type === 'seapower') {
        var m = this.mahan;
        var remSp = Math.max(0, (m.cdEnd - now) / 1000);
        out.push({
          name: sk.name,
          ready: m.useCount < sk.maxUses && remSp <= 0,   // 用完 3 次恒不可用
          remaining: remSp,
          total: sk.cooldownSec,
          level: 1,
        });
        continue;
      }
      if (sk.type === 'warsoul') {
        var hs = this.huasheng;
        var remWs = Math.max(0, (hs.cdEnd - now) / 1000);
        out.push({
          name: sk.name,
          ready: hs.souls > 0 && remWs <= 0,    // 有军魂且非冷却
          remaining: remWs,
          total: sk.cooldownSec,
          level: hs.souls,
        });
        continue;
      }
      if (sk.type === 'mirrorShield') {
        var dm = this.durman;
        var remMs = dm.chargeAt > 0 ? Math.max(0, (dm.chargeAt - now) / 1000) : 0;
        out.push({
          name: sk.name,
          ready: dm.charge > 0,                 // 有充能即可用（无传统冷却）
          remaining: remMs,                     // 下一层充能剩余（charge<max 时）
          total: sk.chargeSec,
          level: dm.charge,
          chargeMax: dm.chargeMax,
        });
        continue;
      }
      if (sk.type === 'salvoSwitch') {
        // 齐射模式（卢金斯 2026-09-13）：模式切换类——
        //   冷却 = 切换冷却（switchCdEnd，1s 防连点，2026-09-13 字人要求与其它技能冷却显示一致）；
        //   activeMode = 当前是否处于齐射激活态（ui.js 据此画激活特效）
        var ljSt = this.lutjens;
        var remLj = Math.max(0, (ljSt.switchCdEnd - now) / 1000);
        out.push({
          name: sk.name,
          ready: remLj <= 0,
          remaining: remLj,
          total: sk.cooldownSec,
          level: 1,
          activeMode: ljSt.salvoOn,
        });
        continue;
      }
      var remaining = Math.max(0, (this.zplan.cdEnd - now) / 1000);
      // 雷德尔 Z计划：图标画 hitsPerLevel 个进度点（每命中 1 次主炮/鱼雷亮 1 点，点满升 1 级），
      //   不显示等级数字（2026-11-08 字人要求：与华晟军魂同一套圆点语言）。
      //   满级后 hitsPerLevel 全亮并停更——此时 hitCount 仍会累加，故须夹紧，不能直传。
      var zpDots = sk.type === 'zplan' ? (sk.hitsPerLevel || 8) : 0;
      var zpMaxLevel = sk.type === 'zplan' ? (sk.maxLevel || 1) : 0;
      var zpAtMax = zpDots > 0 && this.zplan.level >= zpMaxLevel;
      out.push({
        name: sk.name,
        ready: remaining <= 0,
        remaining: remaining,
        total: sk.cooldownSec,
        level: sk.type === 'zplan' ? this.zplan.level : 1,
        dotsTotal: zpDots,
        dotsLit: zpAtMax ? zpDots : Math.min(this.zplan.hitCount, zpDots),
        atMaxLevel: zpAtMax,
      });
    }
    return out;
  }

  /* ── 每帧更新（buff 过期 / 净化节拍 / 窗口重置） ─────────── */

  update(dt, now, enemies) {
    if (!this.active) return;
    // 华晟畏惧光环：22km 内敌舰获得 debuff（每帧刷新 endTime 保持存在，离开自动过期）
    if (this._fearAuraPassive) this.updateAura(now, enemies || []);
    // buff 系统过期清理（玩家 + 敌舰）
    if (this.player) this.player.cleanBuffs(now);
    if (enemies) {
      for (var ea = 0; ea < enemies.length; ea++) {
        if (enemies[ea]) enemies[ea].cleanBuffs(now);
      }
    }
    // 战争局势 buff 过期 → 还原探测范围
    if (this.surfaceBuff && now >= this.surfaceBuff.endTime) {
      this.player.surfaceRange = this.surfaceBuff.baseRange;
      this.surfaceBuff = null;
    }
    // 指挥官专属状态机（委托 handler）
    this._handler.update(dt, now, enemies, this);
    // 清理过期增益图标
    if (this.buffs.length) {
      this.buffs = this.buffs.filter(function (b) { return now < b.endTime; });
    }
  }

  /**
   * 水镜盾爆炸（杜尔曼 2026-08-06）：被打爆或到期消失都触发。
   * 22km 内敌舰 maxHp×10% 技能伤害（走 takeDamage 吃护盾/无敌、不吃因子）+ 被点亮 15s。
   * @param {boolean} broken — true=被打爆（剩余时间减600/疲弱专属）/ false=到期消失
   * @param {number} now
   */
  onMirrorBurst(broken, now) {
    var dm = this.durman;
    var sk = this.def.activeSkills && this.def.activeSkills[0];
    dm.mirrorShield = 0;
    if (broken) dm.mirrorBurstBroken = true;
    var dmg = Math.round((this.player ? this.player.maxHp : 20000) * sk.explodeDmgPct);
    if (this.enemiesRef && this.player) {
      for (var i = 0; i < this.enemiesRef.length; i++) {
        var e = this.enemiesRef[i];
        if (!e || !e.isAlive) continue;
        if (Math.hypot(e.x - this.player.x, e.y - this.player.y) <= sk.explodeRadiusKm * PX_PER_KM) {
          e.takeDamage(dmg, 'skill');   // 技能伤害：吃护盾/无敌，不吃伤害因子
          e.addBuff('lit', '被点亮', now + sk.litSec * 1000, { visibleToBlue: true });
          this.pendingSkillHits.push({ x: e.x, y: e.y, damage: dmg });
        }
      }
    }
    this.buffs = this.buffs.filter(function (b) { return b.key !== 'mirrorShield' && b.key !== 'mirrorBrokenReduce'; });
    // 被打爆专属：剩余技能时间火炮伤害固定 -600 → 增益图标（2026-08-06，endTime=mirrorEnd 到期自动消失）
    if (broken) {
      this.buffs.push({ key: 'mirrorBrokenReduce', name: '火炮减伤', endTime: dm.mirrorEnd });
    }
  }

  /** 防御矩阵低血触发（杜尔曼 2026-08-06）：清异常 + 回 30% 血 + 20 层特殊护盾（45s） */
  _triggerMatrix(now) {
    var dm = this.durman;
    var mp = this._matrixPassive;
    dm.matrixTriggered = true;
    if (!this.player) return;
    this.player.burnStacks = [];
    this.player.floodState = null;
    if (this.player.shattered) {
      this.player.armor = this.player._baseArmor != null ? this.player._baseArmor : this.player.armor;
      this.player.shattered = false;
    }
    this._healPlayer(Math.round(this.player.maxHp * mp.healPct));
    dm.layerShield = mp.layerShield;
    dm.layerEnd = now + mp.layerSec * 1000;
    this._applyLayerMods(now);
  }

  /** 层盾 buff 重建（杜尔曼 2026-08-06）：层数动态，每层 +1% 武器精度 +1% 主炮真伤 */
  _applyLayerMods(now) {
    var mp = this._matrixPassive;
    if (!mp || !this.player) return;
    // 增益图标同步（2026-08-06）：layerShield 以增益图标呈现，右上角层数角标随剩余层数实时更新
    var idx = -1;
    for (var bi = 0; bi < this.buffs.length; bi++) {
      if (this.buffs[bi].key === 'layerShield') { idx = bi; break; }
    }
    if (this.durman.layerShield <= 0) {
      if (idx >= 0) this.buffs.splice(idx, 1);
      this.player.removeBuff('layerShield');
      return;
    }
    var layerEntry = { key: 'layerShield', name: '防御矩阵', endTime: this.durman.layerEnd, layer: this.durman.layerShield };
    if (idx >= 0) this.buffs[idx] = layerEntry; else this.buffs.push(layerEntry);
    this.player.addBuff('layerShield', '防御矩阵', this.durman.layerEnd, {
      weaponAccuracyAdd: mp.layerAccuracyPct * this.durman.layerShield,
      mainTrueDmgAdd: mp.layerTrueDmgPct * this.durman.layerShield,
    });
  }

  /** 技能伤害飘字队列（杜尔曼盾爆 2026-08-06）——main.js 每帧 drain 后 spawnDamagePopup 红字 */
  drainSkillHits() {
    var out = this.pendingSkillHits;
    this.pendingSkillHits = [];
    return out;
  }
}

/* ── 持久化（全局唯一激活指挥官，localStorage） ─────────────── */

function getActiveCommanderId() {
  try {
    var v = localStorage.getItem('huanjian.activeCommander');
    return v ? v : null;
  } catch (e) {
    return null;
  }
}

function saveActiveCommander(id) {
  try {
    localStorage.setItem('huanjian.activeCommander', id || '');
  } catch (e) {}
}
