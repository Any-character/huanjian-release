/**
 * armor.js — Armour damage reduction + Shatter debuff system.
 *
 * Armour: every 1000 points reduces incoming damage by 10 %.
 *         e.g. 2000 armour → damage × 0.8.
 *
 * Shatter:  reduces armour by 20 % for 10 seconds.
 *           Cannot stack / overwrite an existing shatter.
 *
 * Dependencies: constants.js
 */
const Armor = {

  /**
   * Damage multiplier for a given armour value.
   * multiplier = 1 - armour / 10000
   *
   * @param {number} armor — current armour value
   * @returns {number} multiplier (e.g. 0.8 for 2000 armour)
   */
  getMultiplier(armor) {
    return Math.max(0, 1 - armor / 10000);
  },

  /**
   * Attempt to proc shatter on a hit (both main-gun and torpedo).
   *
   * @param {Ship}   ship         — the ship being hit
   * @param {number} shatterChance — effective shatter chance (ship base + weapon bonus)
   * @param {number} now          — Date.now() timestamp
   * @param {number} shatterPower — 额外碎甲减甲（与 SHATTER_ARMOR_REDUCTION 叠加）
   * @param {boolean} [force] — 必定碎甲（碎甲弹，2026-11-15）：绕过概率判定、抵抗碎甲与
   *        「免疫碎甲」buff。已处于碎甲状态仍不刷新（碎甲不可叠加/覆盖，与是否强制无关）。
   * @returns {boolean} true if shatter was just applied
   */
  tryShatter(ship, shatterChance, now, shatterPower, force) {
    if (!ship || ship.shattered) return false;
    // 2026-08-06 杜尔曼「学有所长」：免疫碎甲 buff 期间不施加（先于概率判定）
    //   —— 碎甲弹的「必定碎甲」是唯一例外（与「必定暴击无视免疫暴击」同口径，2026-11-15）
    if (!force && ship.hasBuff && ship.hasBuff('shatterImmune')) return false;
    if (!force && Math.random() >= (shatterChance != null ? shatterChance : SHATTER_CHANCE)) return false;

    ship.shattered = true;
    ship.shatterEndTime = now + SHATTER_DURATION * 1000;
    ship._baseArmor = ship.armor;
    // 2026-08-06 杜尔曼「船体加固」：碎甲减甲对冲抵抗碎甲程度（基础 20% + 威力 − 抵抗，钳 0）
    var reduction = Math.max(0, SHATTER_ARMOR_REDUCTION + (shatterPower || 0) - (ship.resistShatterDegree || 0));
    ship.armor = Math.round(ship.armor * Math.max(0, 1 - reduction));
    return true;
  },

  /**
   * Update shatter state — restore armour when the debuff expires.
   * Must be called every frame for every ship that can be shattered.
   *
   * @param {Ship}   ship
   * @param {number} now
   */
  updateShatter(ship, now) {
    if (!ship || !ship.shattered) return;
    if (now >= ship.shatterEndTime) {
      ship.shattered = false;
      ship.armor = ship._baseArmor;  // 恢复到碎甲前的原始装甲值
    }
  },
};
