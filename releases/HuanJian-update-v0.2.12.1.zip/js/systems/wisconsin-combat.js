/**
 * wisconsin-combat.js — 威斯康星「威慑重击」+ [重击炮弹] 弹种（2026-11-08）
 *
 * 规格：docs/superpowers/specs/2026-11-08-wisconsin-design.md
 *
 * 被动（常驻，无需主动技）
 *   ① 每命中 1 次重击炮弹 → 主炮**数值真伤** +20（上限 50 层 = +1000）
 *      → 写 `ship.trueDmgFlat`，由 attack-stats 的 trueDmgFlat 行带到弹丸；
 *        公式里排在百分比真伤**之后**、无视减伤（collision-hit.js）
 *   ② 每命中 4 次重击炮弹 → 护盾 = 5% 最大血量；**当前护盾**钳在 40% 最大血量
 *      → addTimedShield(add, Infinity, 'wiHeavy')（与阳炎猎影同款来源门槛）
 *   ③ 濒死：受到致死伤害时免疫并保留 1 血（每场 1 次）→ 无敌 5s + 重击弹无冷却 10s
 *      → 致死判定与无敌 buff 在 ship-status.js 的 takeDamage 里（那里才有 hp 上下文）
 *   ④ 不屈：每次受主炮/鱼雷/水雷伤害回固定血（ship.unyielding，受维修效率加成）
 *      → 同样在 ship-status.js 的 takeDamage 尾部
 *
 * [重击炮弹] 弹种
 *   ⑤ 「不动堡垒」姿态内每 5 秒给**1 门**已就绪倾向的主炮装填（上限 1 门）
 *      → mount._heavy = true；fireMainGun 把该轮齐射全部炮弹标 isHeavyShell 并消费
 *   ⑥ 命中敌舰：额外 4% 最大血量固定伤害（走 getPercentDamageBase）
 *      + 一次普通武损 + 减益 10s（机动性 -15% / 装填 +15% / 极限装填 +3s）
 *      → 由 collision.js 的 _applyMGHit 调用 onHeavyHit
 *
 * ⚠️ 真伤叠层的层数用**既有 layer 角标**显示（增益图标右上角 ×N，同杜尔曼「防御矩阵」），
 *    名字固定「重击·真伤」，不把层数拼进名字（2026-11-08 字人反馈）。
 *    getStacks()/getStacksMax() 仍供 UI 读取。
 */
const WisconsinHeavy = {
  HITS_PER_SHIELD: 4,
  SHIELD_PCT: 0.05,
  SHIELD_CAP_PCT: 0.40,
  SHIELD_SOURCE: 'wiHeavy',
  TRUE_DMG_PER_STACK: 20,
  MAX_STACKS: 50,
  RELOAD_MS: 5000,
  DEBUFF_MS: 10000,

  _popups: [],

  /** 每艘船的威斯康星状态（幂等） */
  ensure(ship) {
    if (!ship._wi) {
      ship._wi = {
        heavyHits: 0,       // 重击弹累计命中（每 4 次给一次盾）
        stacks: 0,          // 主炮真伤叠层 0..50
        deathSaved: false,  // 濒死保护是否已用掉（每场 1 次）
        heavyMount: -1,     // 已装填重击弹的炮位（-1 = 无）
        loadAt: 0,          // 下一次装填时刻
        noCdUntil: 0,       // 濒死后「重击弹无冷却」结束时刻
      };
    }
    return ship._wi;
  },

  init(ship, config, now) {
    const st = this.ensure(ship);
    st.loadAt = (now || 0) + this.RELOAD_MS;
    ship.trueDmgFlat = 0;
  },

  update(ship, dt, now) {
    const st = this.ensure(ship);
    // 真伤叠层 → 单一来源字段（attack-stats 的 trueDmgFlat 行在开火时快照）
    ship.trueDmgFlat = st.stacks * this.TRUE_DMG_PER_STACK;

    // 只有堡垒姿态内才会自动装填重击弹
    if (typeof WisconsinFortress === 'undefined' || !WisconsinFortress.isOn(ship)) return;
    if (st.heavyMount >= 0) return;               // 上限：同时只存在 1 门
    if (now < st.noCdUntil) { this.loadOne(ship, now); return; }   // 濒死 10s 内无冷却
    if (now < st.loadAt) return;
    this.loadOne(ship, now);
  },

  /** 给「最接近就绪」的一门主炮装填重击弹 */
  loadOne(ship, now) {
    const st = this.ensure(ship);
    if (!ship.mainGunMounts || !ship.mainGunMounts.length) return;
    let idx = 0;
    let best = Infinity;
    for (let i = 0; i < ship.mainGunMounts.length; i++) {
      const remain = Math.max(0, (ship.mainGunMounts[i].cooldownEnd || 0) - now);
      if (remain < best) { best = remain; idx = i; }
    }
    ship.mainGunMounts[idx]._heavy = true;
    st.heavyMount = idx;
    st.loadAt = now + this.RELOAD_MS;
  },

  /**
   * 开火消费（ship-weapons.js 调）：该炮位重击弹 → 本轮齐射全部炮弹标记。
   * @returns {boolean} 是否消费到
   */
  consume(ship, mountIndex, now) {
    const m = ship.mainGunMounts && ship.mainGunMounts[mountIndex];
    if (!m || !m._heavy) return false;
    m._heavy = false;
    const st = this.ensure(ship);
    st.heavyMount = -1;
    // 打出去后重新计时；濒死「无冷却」期为 0 延迟
    st.loadAt = (now < st.noCdUntil) ? 0 : now + this.RELOAD_MS;
    return true;
  },

  /**
   * 重击弹命中（collision.js 调）：固定伤害 + 普通武损 + 减益。
   * @param {Ship} attacker — 打出这发弹的舰（威斯康星）
   * @param {Ship} target
   */
  onHeavyHit(attacker, target, now) {
    if (!attacker || !target || !target.isAlive) return;
    const st = this.ensure(attacker);

    // ① 命中计数 + 真伤叠层
    st.heavyHits += 1;
    if (st.stacks < this.MAX_STACKS) st.stacks += 1;
    attacker.trueDmgFlat = st.stacks * this.TRUE_DMG_PER_STACK;
    // 叠层增益图标（字人 A3 要求「要显示增益图标」）：层数走**既有 layer 角标**（同杜尔曼「防御矩阵 20 层」），
    //   不再拼进名字（2026-11-08 字人反馈「写在名字里不直观」）。noDuration → 不显示持续时间文本。
    if (attacker.addBuff) {
      attacker.addBuff('wiHeavyStacks', '重击·真伤', Date.now() + 1e9, { noDuration: true }, st.stacks);
    }

    // ② 每 4 次命中 → 护盾 5%（当前护盾钳 40%）
    if (st.heavyHits % this.HITS_PER_SHIELD === 0) {
      const cap = attacker.maxHp * this.SHIELD_CAP_PCT;
      const cur = (attacker.shield || 0)
        + (attacker.getTimedShieldTotal ? attacker.getTimedShieldTotal() : 0);
      const add = Math.max(0, Math.min(attacker.maxHp * this.SHIELD_PCT, cap - cur));
      if (add > 0 && attacker.addTimedShield) {
        attacker.addTimedShield(add, Infinity, this.SHIELD_SOURCE);
      }
    }

    // ③ 额外 4% 最大血量固定伤害（走唯一入口：非战役按被打者 / 战役按我舰）
    const base = target.getPercentDamageBase
      ? target.getPercentDamageBase(attacker.maxHp)
      : target.maxHp;
    const dmg = Math.round(base * 0.04);
    if (dmg > 0) {
      target.takeDamage(dmg, 'skill');
      this._popups.push({ x: target.x, y: target.y, damage: dmg });
    }

    // ④ 一次普通武损（受目标免疫武损约束）
    if (target.applyWeaponDamage) target.applyWeaponDamage(now);

    // ⑤ 减益 10s：机动性 -15%（四通道）/ 装填 +15% / 极限装填 +3s（刷新式，不叠加）
    if (target.addBuff) {
      target.addBuff('wiHeavyDebuff', '重击·压制', now + this.DEBUFF_MS, {
        speedMulAdd: -0.15,
        accelPowerAdd: -0.15,
        rotationSpeedAdd: -0.15,
        turnPowerAdd: -0.15,
        reloadPctReduce: -0.15,     // 负值 = 装填变长（getWeaponReloadSec 的 pct 池）
        weaponMinReloadAdd: 3,      // 极限装填 1.5s → 4.5s
      });
    }
  },

  /** 真伤叠层（UI 增益图标用） */
  getStacks(ship) { return ship && ship._wi ? ship._wi.stacks : 0; },
  getStacksMax() { return this.MAX_STACKS; },

  /** 技能伤害飘字（main.js 每帧 drain，与 A140AStorm/YanyinHunt 同款） */
  drainPopups() {
    const out = this._popups;
    this._popups = [];
    return out;
  },
};

if (typeof GameSystems !== 'undefined') {
  GameSystems.register('wisconsinHeavy', {
    order: 120,
    init(ship, config, now) { WisconsinHeavy.init(ship, config, now); },
    update(ship, dt, now) { WisconsinHeavy.update(ship, dt, now); },
  });
}
