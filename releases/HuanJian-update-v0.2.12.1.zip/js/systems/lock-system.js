/**
 * lock-system.js — A-140A「国度的雄心」锁定系统（2026-09-19）
 *
 * 锁定 = 敌舰身上**可叠加多层的标记型减益**（走 buff 系统；敌舰不显示图标）。
 * 完整规格见 docs/systems.md §5.29，要点：
 *   - 层数 = 锁住该敌舰的副炮占位数；**上限 = 副炮锁定配额总额**（每门 1 次，主动期 2 次）
 *     ⚠️ 2026-09-19 字人改动：**取消了"敌舰非自动武器数"这一层上限** —— 敌舰层数只受副炮配额约束，
 *     故单艘敌舰可吃满全部配额（10 层；主动期 20 层）
 *   - 配额：每门副炮同时仅占 1 次（炮火风暴主动期 2 次，替换）；**解除即归还**
 *     （目标被击沉 / 脱离副炮射程 → 释放占用，可再锁其它目标）
 *   - **额度缩减回收**（2026-09-19 修 BUG）：主动期结束（每门 2 → 1）时超额占用**必须归还**
 *     （从尾部 LIFO 回收）→ 层数立即从 20 回落到 10；否则层数会永久停在 20
 *   - 随机锁定：敌舰进入副炮射程 → 有配额的副炮各锁 1 层
 *   - 主动锁定：**按层记录**（2026-09-19 字人规格细化）——每次副炮命中把「**1 层**」从当前持有者
 *     **转移**给被命中目标并刷新 15s；15s 内该层未再被刷新 → 自动降级为随机层（层数不变）。
 *     例：打 A 10 次 → A 10 层主动；再打 B 3 次 → B 3 层主动、A 7 层主动（总占用不变）
 *     → 实现见 onSecondaryHit 的 ①~⑤ 取层优先级
 *   - 作用：**纯标记 + 技能判据**，不改变副炮开火方向（副炮恒跟随主炮瞄准）
 *   - 我舰图标：增益「锁定 ×N」（N = 最后攻击目标的层数，目标切换立即跳变）
 *
 * 加载顺序：后于 ship.js / ship-weapons.js（用 getSecondaryRangePx / getWeaponById）。
 */

/** 拥有锁定系统的技能 id */
const LOCK_SKILL_ID = 'a140a-ambition';
/** 主动锁定保持时长（秒） */
const LOCK_ACTIVE_KEEP_SEC = 15;
/** 主炮命中火力层上限（副炮炮速 +500 / 真伤 +1% 每层） */
const LOCK_FIRE_LAYER_MAX = 10;
/** 国度的雄心扇形判定：目标方位相对本舰的夹角范围（船侧轴 ±60°，即 |rel| ∈ [30°,150°]） */
const LOCK_ARC_MIN_RAD = Math.PI / 6;
const LOCK_ARC_MAX_RAD = 5 * Math.PI / 6;

const LockSystem = {
  /** 该舰是否拥有锁定系统（读战舰技能配置） */
  hasLock(ship) {
    if (!ship || !ship.isAlive) return false;
    const skills = ship._shipConfig && ship._shipConfig.skills;
    if (!skills) return false;
    for (let i = 0; i < skills.length; i++) {
      if (skills[i].id === LOCK_SKILL_ID) return true;
    }
    return false;
  },

  /** 施法者唯一标识（buff key 用，按船区分） */
  uid(caster) {
    if (!caster._lockUid) caster._lockUid = 'L' + Math.floor(Math.random() * 1e9).toString(36);
    return caster._lockUid;
  },

  /** 该施法者对某敌舰的锁定层数（锁定 buff 为常驻 Infinity，增删由配额维护） */
  getLayers(caster, target) {
    if (!caster || !target || !target.buffs) return 0;
    const b = target.buffs['lock_' + this.uid(caster)];
    if (!b) return 0;
    return (b.mods && b.mods.lockLayers) || 0;
  },

  /**
   * 该施法者对某敌舰的**主动锁定**层数（2026-09-19 改为**按层**记录）：
   * 每个占用条目 { target, activeEnd } 自带主动到期时间；activeEnd > now 的层即为"主动锁定层"。
   * 15s 内未再被命中 → 自动降级为随机层（层数不变，只是不再算主动）。
   */
  getActiveLayers(caster, target, now) {
    if (!caster || !target || !caster._lockQuota) return 0;
    now = now !== undefined ? now : Date.now();
    const q = caster._lockQuota;
    let n = 0;
    for (let i = 0; i < q.length; i++) {
      if (q[i].target === target && q[i].activeEnd > now) n++;
    }
    return n;
  },

  /** 单门副炮的锁定配额（炮火风暴主动期 = 2，否则 1） */
  quotaPerMount(caster, now) {
    return caster._lockStormUntil && now < caster._lockStormUntil ? 2 : 1;
  },

  /** 总配额 = 副炮数 × 每门配额 */
  quotaTotal(caster, now) {
    const n = (caster.secondaryMounts && caster.secondaryMounts.length) || 0;
    return n * this.quotaPerMount(caster, now);
  },

  /** 已占用数 */
  quotaUsed(caster) {
    return (caster._lockQuota && caster._lockQuota.length) || 0;
  },

  /** 占用一次配额锁定指定目标（activeEnd = 0 表示**随机锁定**层） */
  _occupy(caster, target) {
    if (!caster._lockQuota) caster._lockQuota = [];
    caster._lockQuota.push({ target: target, activeEnd: 0 });
  },

  /**
   * 每帧维护（main.js 调用）：归还失效占用 → 随机锁定 → 主动锁定降级 → 写 buff/图标/扇形增益
   * @param {Ship}    caster
   * @param {Array}   enemies
   * @param {number}  now
   * @param {boolean} [isCampaign] — 战役环境（炮火风暴「每被锁定 1 次 → 特殊武损」在战役不触发）
   */
  update(caster, enemies, now, isCampaign) {
    if (!this.hasLock(caster)) return;
    if (!caster._lockQuota) caster._lockQuota = [];
    const rangePx = caster.getSecondaryRangePx ? caster.getSecondaryRangePx() : 0;
    // 炮火风暴主动期标志（每座副炮配额 2；「每被锁定 1 次 → 特殊武损」的开关）
    const stormOn = !!(caster._stormUntil && now < caster._stormUntil);

    // ① 归还：目标被击沉 / 脱离副炮射程 → 释放占用（配额回到可用池）
    // ① 归还：目标被击沉 / 脱离副炮射程 → 释放占用（配额回到可用池）
    for (let i = caster._lockQuota.length - 1; i >= 0; i--) {
      const t = caster._lockQuota[i].target;
      if (!t || !t.isAlive || Math.hypot(t.x - caster.x, t.y - caster.y) > rangePx) {
        caster._lockQuota.splice(i, 1);
      }
    }

    // ①b 配额缩减回收（2026-09-19 修 BUG）：炮火风暴结束 → 每门配额 2 降回 1，总额度减半，
    //     此时**必须把超额占用归还**，否则层数会一直停在 20（字人实测反馈）。
    //     `_lockQuota` 按占用时间顺序追加 → 从**尾部**回收（LIFO）= 优先释放主动期额外占用，
    //     常规期原有的 10 层得以保留；被回收的目标若层数归零，会自动走到 ③ 之后的清理分支移除 buff。
    const total = this.quotaTotal(caster, now);
    while (caster._lockQuota.length > total) caster._lockQuota.pop();

    // ② 随机锁定：射程内的敌舰，由空闲配额各锁 1 层（**无频率上限、无"非自动武器数"层上限**）
    let used = this.quotaUsed(caster);
    for (let e = 0; e < enemies.length && used < total; e++) {
      const tgt = enemies[e];
      if (!tgt || !tgt.isAlive) continue;
      if (Math.hypot(tgt.x - caster.x, tgt.y - caster.y) > rangePx) continue;
      while (used < total) {
        this._occupy(caster, tgt);
        used++;
        // 炮火风暴主动（2026-09-19）：敌舰**每被锁定 1 次** → 随机 1 座武器损毁 20s（特殊武损；战役不触发）
        if (stormOn && !isCampaign && tgt.applySpecialWeaponDamage) {
          // 成功施加才计数（per-caster，main.js 只取玩家的进「武损」命中统计药丸，2026-10-18）
          if (tgt.applySpecialWeaponDamage(now)) caster._lockSpecWepCount = (caster._lockSpecWepCount || 0) + 1;
        }
      }
    }

    // ③ 按当前占用重算每艘敌舰的锁定 buff（层数 + **主动层数**）
    //    主动为**按层**记录（2026-09-19）：条目 activeEnd > now 才计入主动层，过期即自动降级为随机层
    const byTarget = new Map();
    for (let q = 0; q < caster._lockQuota.length; q++) {
      const e = caster._lockQuota[q];
      let list = byTarget.get(e.target);
      if (!list) { list = []; byTarget.set(e.target, list); }
      list.push(e);
    }
    let activeTotal = 0;
    byTarget.forEach((list, tgt) => {
      const key = 'lock_' + this.uid(caster);
      let activeLayers = 0;
      for (let k = 0; k < list.length; k++) if (list[k].activeEnd > now) activeLayers++;
      activeTotal += activeLayers;
      tgt.addBuff(key, '锁定', Infinity, { lockLayers: list.length, lockActiveLayers: activeLayers, lockCasterUid: this.uid(caster) }, list.length);
    });
    caster._lockActiveLayersTotal = activeTotal;   // 炮火风暴「每有一层主动锁定 -0.3s」读此值
    caster._stormLockedTargets = Array.from(byTarget.keys());   // 炮火风暴主动「主炮开火 → 对所有被锁定敌舰附加伤害」读此值
    // 清理不再被锁定的目标
    for (let e2 = 0; e2 < enemies.length; e2++) {
      const t2 = enemies[e2];
      if (!t2 || byTarget.has(t2)) continue;
      if (t2.hasBuff && t2.hasBuff('lock_' + this.uid(caster), now)) t2.removeBuff('lock_' + this.uid(caster));
    }

    // ④ 我舰图标：显示**最后攻击目标**的层数（目标切换立即跳变）
    const last = caster._lockLastTarget;
    const iconLayers = (last && last.isAlive) ? this.getLayers(caster, last) : 0;
    if (iconLayers > 0) caster.addBuff('ambitionLockIcon', '锁定', Infinity, {}, iconLayers);
    else caster.removeBuff('ambitionLockIcon');

    // ⑤ 主炮命中火力层（副炮炮速 +500 / 副炮真伤 +1% 每层，上限 10，永久）
    const fireL = Math.min(LOCK_FIRE_LAYER_MAX, caster._lockMainHitLayers || 0);
    if (fireL > 0) {
      caster.addBuff('ambitionFireLayer', '雄心·火力', Infinity,
        { secShellSpeedAdd: 500 * fireL, secTrueDmgAdd: 0.01 * fireL }, fireL);
    } else {
      caster.removeBuff('ambitionFireLayer');
    }

    // ⑥ 扇形判定增益（25km 内、船侧轴两侧各 60° 内有敌舰 → 最终减伤+15 / 炮弹规避+15）
    //   炮弹规避走既有 evasionAllAdd 通道（collision.js 跳弹判定：全口径规避）
    //   noDuration：条件性光环（每帧刷新、出圈即消失），**不显示倒计时**（2026-09-19 字人要求）
    if (this._enemyInArc(caster, enemies)) {
      caster.addBuff('ambitionArc', '国度的雄心', now + 300,
        { finalReduceAdd: 0.15, evasionAllAdd: 0.15, noDuration: true });
    }
  },

  /** 25km 内、船侧轴 ±60°（|相对角| ∈ [30°,150°]）内是否存在敌舰 */
  _enemyInArc(caster, enemies) {
    const r = 25 * PX_PER_KM;
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (!e || !e.isAlive) continue;
      if (Math.hypot(e.x - caster.x, e.y - caster.y) > r) continue;
      let rel = Math.atan2(e.x - caster.x, -(e.y - caster.y)) - caster.heading;
      while (rel > Math.PI) rel -= 2 * Math.PI;
      while (rel < -Math.PI) rel += 2 * Math.PI;
      const abs = Math.abs(rel);
      if (abs >= LOCK_ARC_MIN_RAD && abs <= LOCK_ARC_MAX_RAD) return true;
    }
    return false;
  },

  /**
   * 副炮命中敌舰 → **切换 1 层主动锁定**给该目标（2026-09-19 字人规格细化）。
   *
   * 语义：每次副炮命中把「**1 层**主动锁定」从当前持有者**转移**到被命中目标，并刷新该层 15s 计时。
   *   字人例：副炮打 A 10 次 → A 10 层主动；再打 B 3 次 → **B 3 层主动、A 7 层主动**
   *   （总占用不变，只是把 A 的 3 层改挂到 B）。
   *
   * 取层优先级（保证上面例子成立）：
   *   ① 其它目标有**主动层** → 取「主动层最多的目标」中最早到期的一条，改挂到 T 并刷新计时
   *   ② T 自身还有**随机层**（activeEnd=0/已过期）→ 就地激活最早的一条
   *      （打 A 10 次 → A 自己的 10 层被逐层激活）
   *   ③ 其它目标有层（但都已非主动）→ 从**层数最多的目标**转一条过来并激活
   *      （B 原本 0 层时，靠这一条拿到层）
   *   ④ 还有空闲额度 → 直接占用一条新额度挂在 T
   *   ⑤ 都不可行 → 仅更新最后攻击目标
   * 无论走哪一支，都把 T 记为「最后攻击目标」（我舰图标立即跳变）。
   */
  onSecondaryHit(caster, target, now) {
    if (!this.hasLock(caster) || !target) return;
    now = now !== undefined ? now : Date.now();
    const until = now + LOCK_ACTIVE_KEEP_SEC * 1000;
    if (!caster._lockQuota) caster._lockQuota = [];
    const q = caster._lockQuota;
    const move = (idx) => { q[idx].target = target; q[idx].activeEnd = until; };

    // ① 从「主动层最多的其它目标」转移 1 条
    let bestA = 0, victimA = null;
    const actCnt = new Map();
    for (let i = 0; i < q.length; i++) {
      const e = q[i];
      if (e.target === target || !(e.activeEnd > now)) continue;
      const n = (actCnt.get(e.target) || 0) + 1;
      actCnt.set(e.target, n);
      if (n > bestA) { bestA = n; victimA = e.target; }
    }
    if (victimA) {
      for (let i = 0; i < q.length; i++) {
        if (q[i].target === victimA && q[i].activeEnd > now) { move(i); caster._lockLastTarget = target; return; }
      }
    }

    // ② 就地激活 T 自己的随机层
    for (let i = 0; i < q.length; i++) {
      if (q[i].target === target && !(q[i].activeEnd > now)) { move(i); caster._lockLastTarget = target; return; }
    }

    // ③ 从「层数最多的其它目标」转 1 条过来（该层的主动计时随之刷新）
    let bestT = 0, victimT = null;
    const allCnt = new Map();
    for (let i = 0; i < q.length; i++) {
      if (q[i].target === target) continue;
      const n = (allCnt.get(q[i].target) || 0) + 1;
      allCnt.set(q[i].target, n);
      if (n > bestT) { bestT = n; victimT = q[i].target; }
    }
    if (victimT) {
      for (let i = 0; i < q.length; i++) {
        if (q[i].target === victimT) { move(i); caster._lockLastTarget = target; return; }
      }
    }

    // ④ 有空闲额度 → 新占一条挂在 T
    if (q.length < this.quotaTotal(caster, now)) {
      q.push({ target: target, activeEnd: until });
    }

    caster._lockLastTarget = target;   // 图标立即跳到该目标
  },

  /** 主炮命中 → 火力层 +1（上限 10，永久）；同时更新最后攻击目标 */
  onMainHit(caster, target, now) {
    if (!this.hasLock(caster) || !target) return;
    caster._lockMainHitLayers = Math.min(LOCK_FIRE_LAYER_MAX, (caster._lockMainHitLayers || 0) + 1);
    caster._lockLastTarget = target;
  },
};

/* ── Ship 扩展（锁定系统的读接口 / 副炮跟随判定）────────────────────────── */

/** 副炮是否处于「跟随主炮瞄准」状态（卢金斯齐射开关 OR 常驻跟随技能） */
Ship.prototype.isSecondaryFollowing = function() {
  return !!(this.secondaryFollowsMain || this.secondaryAlwaysFollows);
};

/** 本舰对某目标的锁定层数（供命中加成 / 附加伤害读取） */
Ship.prototype.getLockLayersOn = function(target) {
  return LockSystem.getLayers(this, target);
};

/** 本舰对其主动锁定的层数（单测/未来扩展用；炮火风暴减装填 2026-10-18 起改读 getTotalLockLayers） */
Ship.prototype.getActiveLockLayersOn = function(target, now) {
  return LockSystem.getActiveLayers(this, target, now);
};

/** 当前主动锁定总层数（跨所有敌舰；由 LockSystem.update 每帧维护） */
Ship.prototype.getTotalActiveLockLayers = function() {
  return this._lockActiveLayersTotal || 0;
};

/** 当前锁定总层数（跨所有敌舰，**主动层 + 随机层** = 已占用配额数；炮火风暴「每有一层锁定 -0.3s」读此值，2026-10-18 字人改） */
Ship.prototype.getTotalLockLayers = function() {
  return (this._lockQuota && this._lockQuota.length) || 0;
};

/** 副炮武器面板伤害的最高值（主炮命中被锁定敌舰时附加固定伤害的基数） */
Ship.prototype.getSecondaryPanelDamageMax = function() {
  let max = 0;
  const mounts = this.secondaryMounts || [];
  for (let i = 0; i < mounts.length; i++) {
    const w = mounts[i].weaponId && getWeaponById(mounts[i].weaponId);
    if (w && w.damage > max) max = w.damage;
  }
  if (!max && this.weaponCfg && this.weaponCfg.secondary) max = this.weaponCfg.secondary.damage || 0;
  return max;
};
