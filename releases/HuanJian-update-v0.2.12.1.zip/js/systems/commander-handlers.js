/**
 * commander-handlers.js — 指挥官专属状态机处理器（2026-09-18 Phase 2）
 *
 * 将 CommanderRuntime 中各指挥官的 update()/onHitEvents() 逻辑拆分到独立处理器对象。
 * CommanderRuntime 根据 def.id 选择对应处理器，委托调用。
 * 处理器通过 ctx（CommanderRuntime 实例）访问共享状态和辅助方法。
 *
 * 处理器列表：
 *   RaederHandler   — Z计划（净化窗口 + 回血窗口 + 命中升级）
 *   MahanHandler    — 暴击/燃烧炮术 + 战略论
 *   HuashengHandler — 军魂系统（军魂获取 + 战神模式）
 *   DurmanHandler   — 水镜盾（充能 + 盾爆 + 防御矩阵）
 *   LutjensHandler  — 齐射模式 + 完美装甲 + 专业调度
 *   NullHandler     — 空处理器（无主动技能的指挥官）
 */

// ── 空处理器（无主动技能）──────────────────────────────────────────────
function NullHandler() {}
NullHandler.prototype.update = function() {};
NullHandler.prototype.onHitEvents = function() {};

// ── 雷德尔：Z计划 ─────────────────────────────────────────────────────
function RaederHandler() {}

RaederHandler.prototype.update = function(dt, now, enemies, ctx) {
  // Z计划净化窗口：每 clearTickMs 清一次燃烧/进水
  if (ctx.zplan.clearEnd > 0) {
    if (now >= ctx.zplan.clearEnd) {
      ctx.zplan.clearEnd = 0;
    } else {
      while (now >= ctx.zplan.nextClear) {
        if (ctx.player) {
          ctx.player.burnStacks = [];
          ctx.player.floodState = null;
        }
        ctx.zplan.nextClear += 500;
      }
    }
  }
  // Z计划回血窗口到期 → 回 1 级 + 清零
  if (ctx.zplan.healEnd > 0 && now >= ctx.zplan.healEnd) {
    var sk = ctx.def.activeSkills && ctx.def.activeSkills[0];
    ctx.zplan.healEnd = 0;
    ctx.zplan.level = 1;
    ctx.zplan.hitCount = 0;
    ctx.zplan.nextLevelAt = sk ? sk.hitsPerLevel : 8;
  }
};

RaederHandler.prototype.onHitEvents = function(hitEvents, now, ctx) {
  var sk = ctx.def.activeSkills && ctx.def.activeSkills[0];
  if (!sk || sk.type !== 'zplan') return;
  for (var i = 0; i < hitEvents.length; i++) {
    var ev = hitEvents[i];
    // Z计划被动：玩家主炮/鱼雷命中敌舰 → 累计 8 次升 1 级（常驻，不限窗口）
    if (ev.attacker === ctx.player &&
        (ev.type === 'mainGun' || ev.type === 'torpedo') &&
        ev.target && ev.target.team === 'enemy') {
      ctx.zplan.hitCount++;
      if (ctx.zplan.hitCount >= ctx.zplan.nextLevelAt && ctx.zplan.level < sk.maxLevel) {
        ctx.zplan.level++;
        ctx.zplan.hitCount = 0;
      }
      // 主动窗口内：每次命中按当前等级回血（升级当次用新等级）
      if (now < ctx.zplan.healEnd) {
        var pct = sk.healBasePct + sk.healPerLevelPct * (ctx.zplan.level - 1);
        var healAmount = Math.round(ctx.player.maxHp * pct);
        ctx._healPlayer(healAmount);
      }
    }
  }
};

// ── 马汉：暴击/燃烧炮术 + 战略论 ─────────────────────────────────────
function MahanHandler() {}

MahanHandler.prototype.update = function(dt, now, enemies, ctx) {
  var m = ctx.mahan;
  // 暴击炮术（每分钟检查一次，无 buff 则获得；buff 无时限，打出暴击移除）
  if (ctx._critPassive) {
    if (now >= m.nextCritTick) {
      if (!m.critBuff && ctx.player) {
        ctx.player.critChance += ctx._critPassive.value;
        m.critBuff = true;
        ctx.buffs.push({ key: 'critArtillery', name: '暴击炮术', endTime: Infinity, noTimer: true });
      }
      m.nextCritTick = now + ctx._critPassive.intervalSec * 1000;
    }
  }
  // 燃烧炮术
  if (ctx._burnPassive) {
    if (now >= m.nextBurnTick) {
      if (!m.burnBuff && ctx.player) {
        ctx.player.burnChance += ctx._burnPassive.value;
        m.burnBuff = true;
        ctx.buffs.push({ key: 'burnArtillery', name: '燃烧炮术', endTime: Infinity, noTimer: true });
      }
      m.nextBurnTick = now + ctx._burnPassive.intervalSec * 1000;
    }
  }
  // 战略论（血量 < 阈值时每 intervalSec 回 value×maxHp；高于阈值重置计时）
  if (ctx._lowHpPassive && ctx.player) {
    if (ctx.player.hp / ctx.player.maxHp < ctx._lowHpPassive.threshold) {
      if (m.nextLowHpRegen === 0) m.nextLowHpRegen = now + ctx._lowHpPassive.intervalSec * 1000;
      if (now >= m.nextLowHpRegen) {
        var regenAmt = Math.round(ctx.player.maxHp * ctx._lowHpPassive.value);
        ctx._healPlayer(regenAmt);
        m.nextLowHpRegen = now + ctx._lowHpPassive.intervalSec * 1000;
      }
    } else {
      m.nextLowHpRegen = 0;
    }
  }
};

MahanHandler.prototype.onHitEvents = function(hitEvents, now, ctx) {
  var m = ctx.mahan;
  for (var i = 0; i < hitEvents.length; i++) {
    var ev = hitEvents[i];
    // 马汉：暴击/燃烧炮术移除（玩家自己的攻击打出暴击/燃烧 → 增益消失）
    if (ev.attacker === ctx.player) {
      if (m.critBuff && ev.isCritical) {
        ctx.player.critChance -= (ctx._critPassive ? ctx._critPassive.value : 0);
        m.critBuff = false;
        ctx.buffs = ctx.buffs.filter(function (b) { return b.key !== 'critArtillery'; });
      }
      if (m.burnBuff && ev.isBurn) {
        ctx.player.burnChance -= (ctx._burnPassive ? ctx._burnPassive.value : 0);
        m.burnBuff = false;
        ctx.buffs = ctx.buffs.filter(function (b) { return b.key !== 'burnArtillery'; });
      }
    }
  }
};

// ── 华晟：军魂系统 ───────────────────────────────────────────────────
function HuashengHandler() {}

HuashengHandler.prototype.update = function(dt, now, enemies, ctx) {
  var ws = ctx.def.activeSkills && ctx.def.activeSkills[0];
  if (!ws || ws.type !== 'warsoul' || !ctx.player) return;
  var hs = ctx.huasheng;
  ctx.enemiesRef = enemies || ctx.enemiesRef || [];
  // 每 40s +1 军魂
  if (hs.next40sTick === 0) hs.next40sTick = now + 40000;
  if (now >= hs.next40sTick) {
    hs.next40sTick = now + 40000;
    ctx._gainSoul();
  }
  // 被打血量累计：每损失 maxHp 的 10% 得 1 军魂
  var lost = hs.lastHp - ctx.player.hp;
  if (lost > 0) {
    hs.lostAccum += lost / ctx.player.maxHp;
    while (hs.lostAccum >= 0.1) {
      hs.lostAccum -= 0.1;
      ctx._gainSoul();
    }
  }
  hs.lastHp = ctx.player.hp;
  // 战神模式到期
  if (hs.warGodOn && now >= hs.warGodEnd) {
    hs.warGodOn = false;
    hs.souls = 0;
    ctx._applySoulMods();
    ctx.buffs = ctx.buffs.filter(function (b) { return b.key !== 'warGod'; });
  }
};

HuashengHandler.prototype.onHitEvents = function(hitEvents, now, ctx) {
  var sk = ctx.def.activeSkills && ctx.def.activeSkills[0];
  if (!sk || sk.type !== 'warsoul') return;
  for (var i = 0; i < hitEvents.length; i++) {
    var ev = hitEvents[i];
    // 军魂：玩家对敌舰造成伤害累计（每累计敌舰 10% 血量得 1 军魂）
    if (ev.attacker === ctx.player &&
        ev.target && ev.target.maxHp > 0 && ev.target.team === 'enemy') {
      ctx.huasheng.dealtAccum += (ev.damage || 0) / ev.target.maxHp;
      while (ctx.huasheng.dealtAccum >= 0.1) {
        ctx.huasheng.dealtAccum -= 0.1;
        ctx._gainSoul();
      }
    }
  }
};

// ── 杜尔曼：水镜盾 ───────────────────────────────────────────────────
function DurmanHandler() {}

DurmanHandler.prototype.update = function(dt, now, enemies, ctx) {
  var dsk = ctx.def.activeSkills && ctx.def.activeSkills[0];
  if (!dsk || dsk.type !== 'mirrorShield' || !ctx.player) return;
  var dm = ctx.durman;
  ctx.enemiesRef = enemies || ctx.enemiesRef || [];
  // 击杀解锁充能上限 1→2
  if (dm.unlocked2 === false && ctx.player._stats) {
    var killsNow = ctx.player._stats.kills || 0;
    if (killsNow > dm.lastKills) {
      dm.lastKills = killsNow;
      if (dm.chargeMax < dsk.unlockMaxCharge) {
        dm.chargeMax = dsk.unlockMaxCharge;
        dm.unlocked2 = true;
      }
    }
  }
  // 充能累积：charge < max 时每 chargeSec 得 1 层
  if (dm.charge < dm.chargeMax) {
    if (dm.chargeAt === 0) dm.chargeAt = now + dsk.chargeSec * 1000;
    if (now >= dm.chargeAt) {
      dm.charge++;
      dm.chargeAt = dm.charge < dm.chargeMax ? now + dsk.chargeSec * 1000 : 0;
    }
  }
  // 水镜盾到期（未被打爆）→ 爆炸（无减600/疲弱）
  if (dm.mirrorShield > 0 && now >= dm.mirrorEnd) {
    ctx.onMirrorBurst(false, now);
  }
  // 防御矩阵低血触发（每场一次）：<30% → 清异常 + 回 30% + 20 层盾
  if (ctx._matrixPassive && dm.matrixTriggered === false &&
      ctx.player.hp / ctx.player.maxHp < ctx._matrixPassive.lowHpPct) {
    ctx._triggerMatrix(now);
  }
  // 层盾到期
  if (dm.layerShield > 0 && now >= dm.layerEnd) {
    dm.layerShield = 0;
    ctx._applyLayerMods(now);
  }
};

DurmanHandler.prototype.onHitEvents = function(hitEvents, now, ctx) {
  // 杜尔曼命中事件暂无专属处理（学有所成触发在 collision-hit.js）
};

// ── 卢金斯：齐射模式 + 完美装甲 + 专业调度 ───────────────────────────
function LutjensHandler() {}

LutjensHandler.prototype.update = function(dt, now, enemies, ctx) {
  // 卢金斯 update 暂无专属逻辑（齐射切换在 useActive，完美装甲在 onHitEvents）
};

LutjensHandler.prototype.onHitEvents = function(hitEvents, now, ctx) {
  var lj = ctx.lutjens;
  if (!lj) return;
  for (var i = 0; i < hitEvents.length; i++) {
    var ev = hitEvents[i];
    // 完美装甲：受到**敌舰来源**伤害累计，每达到 20% maxHp → 移除普通异常状态 + 武器精度层（≤5）
    var ljDef = ctx._perfectArmor;
    if (ljDef && ev.target === ctx.player && ev.damage > 0 &&
        ev.attacker && ev.attacker.team === 'enemy') {
      lj.perfectAccum += ev.damage;
      var threshold = ctx.player.maxHp * ljDef.hpThresholdPct;
      var guardPa = 0;
      while (lj.perfectAccum >= threshold && lj.perfectLayers < ljDef.maxLayers && guardPa++ < 10) {
        lj.perfectAccum -= threshold;
        lj.perfectLayers++;
        ctx._triggerPerfectArmor(now);
      }
      if (lj.perfectLayers >= ljDef.maxLayers) lj.perfectAccum = 0;
    }
    // 专业调度：副炮击沉 → 主炮立即装填；主炮击沉 → 副炮立即装填
    if (ctx._professionalDispatch && ev.attacker === ctx.player &&
        ev.target && !ev.target.isAlive && ev.target.team === 'enemy') {
      if (ev.type === 'secondary') {
        for (var pm = 0; pm < ctx.player.mainGunMounts.length; pm++) ctx.player.mainGunMounts[pm].cooldownEnd = 0;
      } else if (ev.type === 'mainGun') {
        for (var ps = 0; ps < ctx.player.secondaryMounts.length; ps++) ctx.player.secondaryMounts[ps].cooldownEnd = 0;
      }
    }
    // 常规模式（非齐射）：主炮命中敌舰 → 减速减益（不可叠加，每次命中刷新 10s）
    var ljSk = ctx.def.activeSkills && ctx.def.activeSkills[0];
    if (ljSk && ljSk.type === 'salvoSwitch' && !lj.salvoOn &&
        ev.attacker === ctx.player && ev.type === 'mainGun' &&
        ev.target && ev.target.isAlive && ev.target.team === 'enemy') {
      ev.target.addBuff('lutjensSlow', '最大航速-5%', now + ljSk.slowDurationSec * 1000,
        { speedMulPen: ljSk.slowMaxSpeedPct });
    }
  }
};

// ── 处理器注册表 ─────────────────────────────────────────────────────
var HANDLER_MAP = {
  raeder:   function() { return new RaederHandler(); },
  mahan:    function() { return new MahanHandler(); },
  huasheng: function() { return new HuashengHandler(); },
  durman:   function() { return new DurmanHandler(); },
  lutjens:  function() { return new LutjensHandler(); },
};

/** 根据指挥官 id 创建对应处理器（未注册返回空处理器） */
function createCommanderHandler(commanderId) {
  var factory = HANDLER_MAP[commanderId];
  return factory ? factory() : new NullHandler();
}
