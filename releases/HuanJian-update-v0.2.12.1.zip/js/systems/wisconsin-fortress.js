/**
 * wisconsin-fortress.js — 威斯康星「不动堡垒」切换型主动（2026-11-08）
 *
 * 规格：docs/superpowers/specs/2026-11-08-wisconsin-design.md
 *
 * 姿态内（进入时施加、退出时原值还原 —— 直写舰体字段，不走 buff 键：
 *   collision-hit.js 只读 target[字段]，buff 键无消费点会静默失效，见阳炎猎影的教训）：
 *   主炮装填 -1s   → buff reloadFlatReduce_mainGun（getWeaponReloadSec 消费）
 *   射击精度 +10%  → ship.shotAccuracy
 *   装甲 +1500     → buff armorAdd（collision-hit ② 消费）
 *   抵抗碎甲 +50%  → ship.resistShatterDegree（armor.js tryShatter 消费）
 *   主炮射程 +5km  → buff mainRangeAddPx
 *   副炮射程 +5km  → buff secRangeAddPx（getSecondaryRangePx 消费）
 *   主炮/副炮速度 +2000 → ship.mainShellSpeedBonus / secShellSpeedBonus（×0.057 换算）
 *   减免鱼雷伤害 +150% → ship.reduceTorpedoDmg（点数，对冲鱼雷穿透）
 *   受到穿甲伤害 +100% → ship.takePenDmgAdd（collision-hit ④ 同类相加）
 *   受到武器伤害 -90%  → ship.takeWeaponDmgAdd（collision-hit ① 同类相加）
 *   免疫暴击 / 武损    → buff immuneCrit / immuneBaseWeaponDamage
 *   无法移动（保留 1 节）→ buff speedClampMax（ship-mobility.smoothSpeed 消费）
 *
 * 切换：卢金斯式，冷却 10s 从**使用时刻**起算（进入/退出各计一次）。
 */
const WisconsinFortress = {
  BUFF: 'wiFortress',
  COOLDOWN_MS: 10000,
  RANGE_ADD_PX: 5 * PX_PER_KM,
  SHELL_SPEED_ADD: 2000 * 0.057,   // 炮速单位 → px/s

  isOn(ship) {
    return !!(ship && ship._wiFortressOn);
  },

  /** 兼容 ShipSkills 的「激活中」判断 */
  isActive(ship, now) {
    return this.isOn(ship);
  },

  /** 主动技能入口（ShipSkills._runActive 调） */
  activate(ship, now) {
    if (!ship || !ship.isAlive) return false;
    if (!ship._shipActiveCd) ship._shipActiveCd = {};
    ship._shipActiveCd['wisconsin-fortress'] = now + this.COOLDOWN_MS;
    this.toggle(ship, now);
    return true;
  },

  toggle(ship, now) {
    if (this.isOn(ship)) this._exit(ship);
    else this._enter(ship, now);
  },

  _enter(ship, now) {
    ship._wiFortressOn = true;
    // 记录原值（可能是 undefined —— 恢复时必须还原成 undefined 而不是 0）
    ship._wiFtSaved = {
      shotAccuracy: ship.shotAccuracy,
      resistShatterDegree: ship.resistShatterDegree,
      reduceTorpedoDmg: ship.reduceTorpedoDmg,
      takePenDmgAdd: ship.takePenDmgAdd,
      takeWeaponDmgAdd: ship.takeWeaponDmgAdd,
      mainShellSpeedBonus: ship.mainShellSpeedBonus,
      secShellSpeedBonus: ship.secShellSpeedBonus,
    };
    ship.shotAccuracy = (ship.shotAccuracy != null ? ship.shotAccuracy : 1) + 0.10;
    ship.resistShatterDegree = (ship.resistShatterDegree || 0) + 0.50;
    ship.reduceTorpedoDmg = (ship.reduceTorpedoDmg || 0) + 150;
    ship.takePenDmgAdd = (ship.takePenDmgAdd || 0) + 1.0;
    ship.takeWeaponDmgAdd = (ship.takeWeaponDmgAdd || 0) - 0.90;
    ship.mainShellSpeedBonus = (ship.mainShellSpeedBonus || 0) + this.SHELL_SPEED_ADD;
    ship.secShellSpeedBonus = (ship.secShellSpeedBonus || 0) + this.SHELL_SPEED_ADD;

    ship.addBuff(this.BUFF, '不动堡垒', Infinity, {
      reloadFlatReduce_mainGun: 1,
      mainRangeAddPx: this.RANGE_ADD_PX,
      secRangeAddPx: this.RANGE_ADD_PX,
      armorAdd: 1500,
      immuneCrit: 1,
      immuneBaseWeaponDamage: 1,
      speedClampMax: 1,
      noIcon: true,
    });

    // 重击弹：进入姿态 5 秒后装第一门（之后由 WisconsinHeavy.update 维护）
    if (typeof WisconsinHeavy !== 'undefined') {
      const st = WisconsinHeavy.ensure(ship);
      st.loadAt = now + WisconsinHeavy.RELOAD_MS;
    }
  },

  _exit(ship) {
    ship._wiFortressOn = false;
    const s = ship._wiFtSaved || {};
    ship.shotAccuracy = s.shotAccuracy;
    ship.resistShatterDegree = s.resistShatterDegree;
    ship.reduceTorpedoDmg = s.reduceTorpedoDmg;
    ship.takePenDmgAdd = s.takePenDmgAdd;
    ship.takeWeaponDmgAdd = s.takeWeaponDmgAdd;
    ship.mainShellSpeedBonus = s.mainShellSpeedBonus;
    ship.secShellSpeedBonus = s.secShellSpeedBonus;
    ship._wiFtSaved = null;
    ship.removeBuff(this.BUFF);
    // 已装填的重击弹作废（退出姿态即收回）
    if (typeof WisconsinHeavy !== 'undefined') {
      const st = WisconsinHeavy.ensure(ship);
      if (st.heavyMount >= 0 && ship.mainGunMounts && ship.mainGunMounts[st.heavyMount]) {
        ship.mainGunMounts[st.heavyMount]._heavy = false;
      }
      st.heavyMount = -1;
    }
  },
};
