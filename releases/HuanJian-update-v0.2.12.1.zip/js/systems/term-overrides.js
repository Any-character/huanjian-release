/**
 * term-overrides.js — 词条应用与古鹰词条持久化
 *
 * 数据源：TERM_OVERRIDES（js/data/term-overrides.js）。
 * 单位约定：rotationSpeed（rad: true）存储层为「度数」，应用到舰船实例时转弧度。
 *
 * 性质区分（2026-08-05 字人确认）：
 * - 「基础属性」= 舰船 config 原始值，首次应用时快照到 ship._baseStats
 * - 「额外加成」= 「加成」窗口填入的数值，最终值 = 基础属性 + 额外加成（加法）
 *   （例：古鹰航速基础 35 节，填 5 → 战场 40 节）
 * - 百分比口径（2026-11-08 字人澄清，分类单一来源 js/data/stat-groups.js）：
 *   基础属性加百分比 = 基础值 × (1+%)（60000 血 +10% = 66000，以 _baseStats 为基准）；
 *   词条加百分比 = 直接加算（自带 10% 暴击 + 10% = 20%）——别把乘算规则套到词条上。
 */
function applyTermOverridesToShip(ship, overrides) {
  if (!ship || !overrides) return;
  // 首次应用时快照「基础属性」（此后加成都以基础值为基准累加，与加成性质区分）
  if (!ship._baseStats) {
    ship._baseStats = {};
    for (var b = 0; b < TERM_OVERRIDES.length; b++) {
      var bid = TERM_OVERRIDES[b].id;
      if (ship[bid] !== undefined) ship._baseStats[bid] = ship[bid];
    }
  }
  for (var i = 0; i < TERM_OVERRIDES.length; i++) {
    var to = TERM_OVERRIDES[i];
    var v = overrides[to.id];
    if (v === undefined || v === null) continue;
    var bonus = to.rad ? v * Math.PI / 180 : v;
    var base = ship._baseStats[to.id];
    if (base === undefined || base === null) base = 0;
    ship[to.id] = base + bonus;   // 最终值 = 基础属性 + 额外加成
  }
  // shield 应用后同步 maxShield：maxShield = shield 是"初始值快照"（护盾不会再生，2026-08-05）
  if (ship.shield !== undefined && ship.maxShield !== undefined) {
    ship.maxShield = ship.shield;
  }
  // maxSpeed 加成后重建速力档位（移动读 speedGears 而非 maxSpeed，否则航速加成不生效）
  if (ship._rebuildSpeedGears) ship._rebuildSpeedGears();
}

/** 古鹰词条：localStorage['huanjian.guyingTermOverrides']（对象；PCT 存小数，0.15 = 15%） */
function loadGuyingTermOverrides() {
  try {
    var raw = localStorage.getItem('huanjian.guyingTermOverrides');
    if (raw) {
      var obj = JSON.parse(raw);
      if (obj && typeof obj === 'object') return obj;
    }
  } catch (e) {}
  return {};
}

function saveGuyingTermOverrides(overrides) {
  try {
    localStorage.setItem('huanjian.guyingTermOverrides', JSON.stringify(overrides || {}));
  } catch (e) {}
}
