/**
 * ship-skills.js — 战舰技能系统（2026-08-08 架构）
 *
 * 概念（字人定义）：
 * - 多数新增战舰带技能（通常 4 个），声明式存储在战舰配置 `skills` 数组
 * - 每个 effect 带 mode：'always'（全部模式生效）/ 'battle'（仅战役模式生效，
 *   即"战役"前缀属性——真战役或自定义战斗开启「视同战役」）
 * - 静态加成：战斗开始时 applyStatic 一次性加进舰船属性
 * - 光环加成（如穿甲尖兵 12km 友军）：updateAuras 每帧挂 buff（复用 buff 系统），
 *   aura.stack === 'unique' 时同技能光环不叠加（固定 buff key 互相覆盖）
 * - 数据驱动：新技能 = 战舰配置加 effects/aura 数据，本文件按 stat 映射生效，零改动
 *
 * 注：强化界面里预留的「技能」tab 是舰种技能系统（未来另做），与本系统无关。
 */

const ShipSkills = {
  _uidCounter: 0,

  /** 实例唯一 id（玩家船没有 _uid，光环 buff key 需要；有则复用） */
  _uid(ship) {
    if (!ship._uid) ship._uid = 'ship' + (++this._uidCounter);
    return ship._uid;
  },

  /**
   * stat 生效器映射表（effect.stat → 应用函数）。新增效果类型在此登记。
   * @param {Ship} ship
   * @param {number} v — 数值（几率类存 0~1 小数，如 0.02 = +2%）
   */
  APPLYERS: {
    // 血量（maxHp 同步 hp，保持满血）
    maxHp(ship, v) { ship.maxHp += v; ship.hp += v; },
    // 炮弹规避（字人确认：三口径规避全部加）
    shellEvasion(ship, v) {
      ship.smallCaliberEvasion = (ship.smallCaliberEvasion || 0) + v;
      ship.mediumCaliberEvasion = (ship.mediumCaliberEvasion || 0) + v;
      ship.largeCaliberEvasion = (ship.largeCaliberEvasion || 0) + v;
    },
    critChance(ship, v) { ship.critChance = (ship.critChance || 0) + v; },
    penetrationChance(ship, v) { ship.penetrationChance = (ship.penetrationChance || 0) + v; },
    burnChance(ship, v) { ship.burnChance = (ship.burnChance || 0) + v; },
    penDmg(ship, v) { ship.penDmg = (ship.penDmg || 0) + v; },
    // 主炮速度（炮速单位 → px/s 换算 ×0.057）
    //   2026-10-25：只写 mainShellSpeedBonus（开火时消费）。AI 提前量改由
    //   Ship.getMainGunShellSpeedPx() 从武器库现值 + 本字段算出，故不再写 weaponCfg（那是死字段）。
    mainGunShellSpeed(ship, v) {
      ship.mainShellSpeedBonus = (ship.mainShellSpeedBonus || 0) + v * 0.057;
    },
    // ── 沙皇「射击大师/生存专家」（2026-08-09）──
    critDmg(ship, v) { ship.critDmg = (ship.critDmg || 0) + v; },                 // 暴击伤害
    burnDelay(ship, v) { ship.burnDelay = (ship.burnDelay || 0) + v; },           // 延缓燃烧
    floodDelay(ship, v) { ship.floodDelay = (ship.floodDelay || 0) + v; },        // 延缓漏水
    armor(ship, v) { ship.armor = (ship.armor || 0) + v; },                       // 装甲强度
    // 减免武器伤害（全口径：主炮/鱼雷/副炮/水雷 reduce 字段全加）
    reduceWeaponDmg(ship, v) {
      ship.reduceMainDmg = (ship.reduceMainDmg || 0) + v;
      ship.reduceTorpedoDmg = (ship.reduceTorpedoDmg || 0) + v;
      ship.reduceSecondaryDmg = (ship.reduceSecondaryDmg || 0) + v;
      ship.reduceMineDmg = (ship.reduceMineDmg || 0) + v;
    },
    // 副炮速度（炮速单位 → px/s；2026-09-19 A-140A「射击大师」）：与主炮同机制
    //   2026-10-25：同主炮，只写 secShellSpeedBonus（weaponCfg 那份没有消费点）
    secondaryShellSpeed(ship, v) {
      ship.secShellSpeedBonus = (ship.secShellSpeedBonus || 0) + v * 0.057;
    },
    // 射击精度（2026-09-19 A-140A「生存专家」）：+x% → 精度 +x/100（1 = 100% 精度）
    //   消费端：跳弹率 = max(0, 1 − 精度 + 目标规避)（collision.js）
    shotAccuracy(ship, v) {
      ship.shotAccuracy = (ship.shotAccuracy != null ? ship.shotAccuracy : 1) + v;
    },
    // 单项减免鱼雷伤害（2026-09-19 A-140A「生存专家」；点数尺度 0~100）
    reduceTorpedoDmg(ship, v) { ship.reduceTorpedoDmg = (ship.reduceTorpedoDmg || 0) + v; },
    // 减免暴击伤害（2026-09-19 A-140A「生存专家」；小数尺度，与 critDmg 相减）
    reduceCritDmg(ship, v) { ship.reduceCritDmg = (ship.reduceCritDmg || 0) + v; },
    // 常驻"副炮跟随主炮瞄准"（2026-09-19 A-140A「国度的雄心」；value 真值时启用）
    //   与卢金斯齐射开关的 secondaryFollowsMain 并存：判定统一走 ship.isSecondaryFollowing()
    secondaryAlwaysFollows(ship, v) { if (v) ship.secondaryAlwaysFollows = true; },
    // 副炮射程始终跟随主炮射程（2026-09-19 A-140A；消费点 getSecondaryRangePx）
    secondaryRangeFollowsMain(ship, v) { if (v) ship.secondaryRangeFollowsMain = true; },
    // 鱼雷速度（2026-10-01 阳炎-利刃「鱼雷大师」）：⚠️ 单位是**节**，**不做** ×0.057 换算
    //   （炮速 1000 单位 = 0.57 km/s = 57 px/s；鱼雷 speed 本来就以节计）
    //   消费链：torpedoSpeedBonus —— fireTorpedo 的 baseStats.torpedoSpeedAdd 快照（真正生效的那条）
    //   2026-10-25：AI 提前量改由 Ship.getTorpedoSpeedKn()（武器库现值 + 本字段）算出，
    //   故不再写 weaponCfg.torpedo.speed（那是船配置里手抄的死字段，已移除）。
    torpedoSpeed(ship, v) {
      ship.torpedoSpeedBonus = (ship.torpedoSpeedBonus || 0) + v;
    },
    // 不屈（2026-11-08 威斯康星「威慑重击」；raw 点数）：每次受主炮/鱼雷/水雷伤害回该点数血量
    //   消费端：ship-status.js 的 takeDamage 尾部（× 维修效率）
    unyielding(ship, v) { ship.unyielding = (ship.unyielding || 0) + v; },
    // ── 新效果类型在此追加 ──
  },

  /**
   * stat 单位尺度表（2026-09-19 新增，防"尺度错位"复发）。
   * 背景：沙皇「生存专家」曾把 reduceWeaponDmg/burnDelay 写成 0.15/0.30，
   *   而消费端按「点数」（0~100 / 0~200）解读 → 技能几乎无效（实测减免武器伤害仅 0.15%）。
   *   pct    — 小数（0.15 = 15%）：几率类、暴伤/减免暴伤、抵抗类、真伤比例、精度增量
   *   points — 点数（15 = 15%）：减免武器伤害、穿透、延缓燃烧/漏水
   *   raw    — 原始值：装甲、炮速（炮速单位）、血量
   *   flag   — 布尔开关（value 为真值即启用）：如"副炮常驻跟随主炮"
   * ★ 新增 stat 必须在此登记 —— tests 第 64 节守卫会校验配置 value 与尺度一致。
   */
  SCALES: {
    maxHp: 'raw',
    shellEvasion: 'pct',
    critChance: 'pct',
    penetrationChance: 'pct',
    burnChance: 'pct',
    penDmg: 'pct',
    mainGunShellSpeed: 'raw',
    secondaryShellSpeed: 'raw',
    critDmg: 'pct',
    burnDelay: 'points',
    floodDelay: 'points',
    armor: 'raw',
    reduceWeaponDmg: 'points',
    shotAccuracy: 'pct',
    reduceTorpedoDmg: 'points',
    reduceCritDmg: 'pct',
    secondaryAlwaysFollows: 'flag',
    secondaryRangeFollowsMain: 'flag',
    torpedoSpeed: 'raw',   // 节（⚠️ 非百分比，非 ×0.057 换算）
    unyielding: 'raw',     // 不屈（点数 = 每次受武器伤害回复的具体血量，2026-11-08）
  },

  /** 取战舰配置的技能列表（无技能 → 空数组） */
  getSkills(config) {
    return (config && config.skills) || [];
  },

  /**
   * 静态效果生效（战斗开始时调用一次）：遍历技能 effects，
   * battle 模式仅在 isCampaign 时生效，always 全模式生效。
   * @param {Ship} ship
   * @param {Object} config — 战舰配置（含 skills）
   * @param {boolean} isCampaign — 是否战役环境（真战役 / 自定义+视同战役）
   */
  applyStatic(ship, config, isCampaign) {
    ship._shipConfig = config;   // 光环 updateAuras 需要读配置里的 aura 技能（Ship 基类不存 config）
    var skills = this.getSkills(config);
    for (var i = 0; i < skills.length; i++) {
      var effs = skills[i].effects || [];
      for (var j = 0; j < effs.length; j++) {
        var e = effs[j];
        if (e.mode === 'battle' && !isCampaign) continue;   // 战役专属，非战役跳过
        var fn = this.APPLYERS[e.stat];
        if (fn) fn(ship, e.value);
      }
    }
  },

  /**
   * 光环效果（每帧调用）：拥有 aura 技能的战舰，给 radiusKm 内本方舰船挂 buff。
   * 含自己（距离 0 必在范围内）；aura.stack === 'unique' → 同技能固定 key 互相覆盖（不叠加），
   * 否则 key 含船 uid（按船叠加）。
   * @param {number} now
   * @param {Array} ships — 本方舰船数组（玩家 + AI 友军）
   * @param {boolean} isCampaign
   */
  updateAuras(now, ships, isCampaign) {
    if (!ships || ships.length === 0) return;
    for (var i = 0; i < ships.length; i++) {
      var caster = ships[i];
      if (!caster || !caster.isAlive || !caster.addBuff) continue;
      var skills = this.getSkills(caster._shipConfig);
      for (var s = 0; s < skills.length; s++) {
        var sk = skills[s];
        if (!sk.aura) continue;
        if (sk.aura.mode === 'battle' && !isCampaign) continue;
        // 半径：默认 radiusKm；radiusFromSecondary = 以**该舰副炮有效射程**为半径
        //   （A-140A 炮火风暴 2026-09-19：副炮射程 = 主炮射程，含主动期 +5km → 光环随射程动态扩大）
        var radiusPx = sk.aura.radiusFromSecondary && caster.getSecondaryRangePx
          ? caster.getSecondaryRangePx()
          : (sk.aura.radiusKm || 12) * PX_PER_KM;
        var unique = sk.aura.stack === 'unique';
        var keyBase = 'shipskill_' + sk.id;
        // 光环 buff 为**条件性**（每帧刷新、出圈即消失）→ 无持续时间，不显示倒计时（2026-09-19 字人要求）
        var auraMods = Object.assign({ noDuration: true }, sk.aura.mods);
        for (var a = 0; a < ships.length; a++) {
          var ally = ships[a];
          if (!ally || !ally.isAlive) continue;
          if (Math.hypot(ally.x - caster.x, ally.y - caster.y) > radiusPx) continue;
          var key = unique ? keyBase : keyBase + '_' + this._uid(caster);
          if (ally.addBuff) ally.addBuff(key, sk.name, now + 1000, auraMods);
        }
      }
    }
  },

  /* ── 主动技能（2026-08-09，沙皇「红场之魂」首个实例）────────────────── */
  // 技能配置 active = { key: 动作名, cooldownSec }；触发函数按 skill.id 映射。
  // 冷却状态存 ship._shipActiveCd = { [skillId]: 冷却结束时间 }。

  /** 取配置中的主动技能列表 */
  getActiveSkills(config) {
    var out = [];
    var skills = this.getSkills(config);
    for (var i = 0; i < skills.length; i++) {
      if (skills[i].active) out.push(skills[i]);
    }
    return out;
  },

  /**
   * 触发主动技能（main.js 按键调用）。
   * 冷却规则（2026-08-09 修）：红场进行中再次使用 = 提前结算（不查冷却）；
   * 首次使用进入红场**不设冷却**，红场结束时（提前结算/池储满/30s 结束）才开始 110s 冷却。
   * @returns {boolean} 是否成功触发
   */
  triggerActive(ship, now, input) {
    now = now || Date.now();
    var skills = this.getActiveSkills(ship._shipConfig);
    for (var i = 0; i < skills.length; i++) {
      var sk = skills[i];
      if (!input || input.isActionJustPressed(sk.active.key)) {
        if (sk.id === 'tsar-redsquare' && ship._bloodPool && ship._bloodPool.state === 'redsquare') {
          this._runActive(ship, sk, now);   // 红场中：二次使用提前结算（冷却结束时才设）
          return true;
        }
        if (!ship._shipActiveCd) ship._shipActiveCd = {};
        if (ship._shipActiveCd[sk.id] && now < ship._shipActiveCd[sk.id]) return false;   // 冷却中
        this._runActive(ship, sk, now);
        return true;
      }
    }
    return false;
  },

  /** 主动技能执行体（按 skill.id 分发；新主动技能在此追加） */
  _runActive(ship, sk, now) {
    if (sk.id === 'tsar-redsquare') {
      if (ship._bloodPool) {
        if (ship._bloodPool.state === 'redsquare') {
          ship._bloodPool.reactivateRedSquare(now);   // 二次使用：提前结算
        } else {
          ship._bloodPool.activateRedSquare(now);
        }
      }
    } else if (sk.id === 'a140a-storm') {
      // A-140A 炮火风暴（2026-09-19）：20s 效果，冷却 90s **从使用时刻起算**（与沙皇不同）
      if (typeof A140AStorm !== 'undefined') A140AStorm.activate(ship, now);
    } else if (sk.id === 'yanyin-hunt') {
      // 阳炎-利刃 蜃光猎影（2026-10-01）：15s 效果，冷却 60s **从使用时刻起算**（A-140A 式）
      //   冷却写 ship._shipActiveCd[skillId]（activate 内部）—— 上面的 triggerActive 判冷却、
      //   getActiveSkillStates 读它画倒计时，都是既有通道，本处不另设冷却字段。
      if (typeof YanyinHunt !== 'undefined') YanyinHunt.activate(ship, now);
    } else if (sk.id === 'wisconsin-fortress') {
      // 威斯康星 不动堡垒（2026-11-08）：切换型（卢金斯式），冷却 10s 从使用时刻起算
      //   activate 内部写 ship._shipActiveCd[skillId]（上面的冷却判定与图标倒计时共用）
      if (typeof WisconsinFortress !== 'undefined') WisconsinFortress.activate(ship, now);
    }
  },

  /** 主动技能图标状态（ui.js 渲染用）：[{ id, name, ready, remainingCooldown, cooldownSec, key }] */
  getActiveSkillStates(ship, now) {
    now = now || Date.now();
    var out = [];
    var skills = this.getActiveSkills(ship && ship._shipConfig);
    for (var i = 0; i < skills.length; i++) {
      var sk = skills[i];
      var cdEnd = ship && ship._shipActiveCd ? (ship._shipActiveCd[sk.id] || 0) : 0;
      var remaining = Math.max(0, (cdEnd - now) / 1000);
      // 激活中标志（图标特效）：沙皇红场进行中 / A-140A 炮火风暴生效期内 / 阳炎蜃光猎影生效期内
      var isAct = false;
      if (sk.id === 'tsar-redsquare') isAct = !!(ship._bloodPool && ship._bloodPool.state === 'redsquare');
      else if (sk.id === 'a140a-storm') isAct = (typeof A140AStorm !== 'undefined') && A140AStorm.isActive(ship, now);
      else if (sk.id === 'yanyin-hunt') isAct = (typeof YanyinHunt !== 'undefined') && YanyinHunt.isActive(ship, now);
      else if (sk.id === 'wisconsin-fortress') isAct = (typeof WisconsinFortress !== 'undefined') && WisconsinFortress.isOn(ship);
      out.push({
        id: sk.id,
        name: sk.name,
        ready: now >= cdEnd,
        remaining: remaining,
        cooldownSec: sk.active.cooldownSec || 0,
        key: sk.active.key,
        active: isAct,
        bloodPool: sk.id === 'tsar-redsquare' ? (ship._bloodPool || null) : null,
      });
    }
    return out;
  },
};
