/**
 * camera.js — 相机偏移系统（2026-08-07 偏移跟随 + 2026-10-01 中点跟随）
 *
 * 职责：把「玩家活着时相机 = 玩家 + camOffset」的全部逻辑从 js/main.js 搬出来，
 *      使其可被单元测试直接加载（main.js 依赖 DOM/canvas，Node 跑不起来）。
 *
 * 分层：
 *   ① 纯函数（无副作用、不碰 document/window、不依赖本文件状态）—— 可直接单测：
 *        Camera.midpointOffset(mouseWorld, playerPos, out?)  「准星—我舰」连线中点偏移
 *        Camera.clampOffset(offset, playerPos, mapSize, out?) 目标偏移 clamp（相机中心在地图内）
 *        Camera.lerpStep(cur, target, k)                    线性插值一步
 *        Camera.clampRate(v, lo, hi, fallback)              阻尼比例安全取值（挡 NaN/Infinity）
 *      纯函数统一支持可选 out 参数（写入并返回），避免逐帧分配临时对象（60fps 垃圾）。
 *   ② 状态机（可变状态 + 逐帧逻辑）—— 需要 input / SETTINGS：
 *        Camera.init(inputRef)                              绑定 input 并重置全部状态
 *        Camera.updateAlive(dt, player, zoom, mapSize)      玩家存活时逐帧更新
 *        Camera.updateDead(dt)                              玩家阵亡时：目标归零 + 沿 lerp 滑回
 *        Camera.freeze()                                    战斗结束冻结：停跟随、偏移保持原地
 *        Camera.updateEnded(dt, base, zoom, mapSize)        战斗结束后逐帧：仅方向键可移（2026-10-18）
 *        Camera.reset()                                     四个偏移一次性归零（页面初始化用）
 *
 * 逐帧执行顺序（**顺序敏感，改动前先读 js/main.js 原实现逐条核对**）：
 *   设置项切换探测 → L(cameraReset) → 空格(cameraFocus) → 方向键(带 moved 标记)
 *   → 临时接管 → 跟随平滑逼近 → 目标 clamp → 当前值 lerp
 *
 * 依赖说明：
 *   - SETTINGS 每帧从全局读取（js/systems/settings.js 的 `let SETTINGS` 会被 loadSettings
 *     整体重新赋值，缓存引用会拿到旧对象 → bug），故不缓存。
 *   - player / currentZoom / MAP_SIZE_PX 是 main.js 闭包变量（player 每次战斗重建、
 *     zoom 每帧变、地图尺寸按模式变），故由调用方每帧传入，不缓存。
 *   - input 是 main.js 的 const 单例，init() 时绑定一次即可。
 */

const CAM_LERP_RATE = 12;        // 相机偏移平滑速率（每秒接近目标的百分比系数；~0.3s 到位）
const OBSERVER_CAM_SPEED = 400;  // px/s（方向键移标速度基准 + 阵亡旁观 WSAD 速度）
const CAM_FOLLOW_SMOOTH_DEFAULT = 0.25;   // SETTINGS.cameraFollowSmooth 缺失/非法时的兜底
const CAM_FOLLOW_SMOOTH_MIN = 0.01;       // 跟随比例下界（防 0 → 永不移动）

// 逐帧复用的暂存对象（模块级单例，仅本文件内部使用；不进全局命名空间语义）
var _camScratchMw = { x: 0, y: 0 };
var _camScratchOff = { x: 0, y: 0 };
var _camScratchOut = { x: 0, y: 0 };

const Camera = {

  // ── 常量（导出引用，勿在别处复制第二份）─────────────────────────────
  LERP_RATE: CAM_LERP_RATE,
  OBSERVER_SPEED: OBSERVER_CAM_SPEED,

  // ══════════════════════════════════════════════════════════════════
  //  ① 纯函数（无副作用；可直接单测）
  // ══════════════════════════════════════════════════════════════════

  /**
   * 「准星世界坐标」与「玩家位置」连线中点，相对于玩家的偏移。
   * 等价于 (mouseWorld + playerPos) / 2 − playerPos。
   * @param {{x,y}} mouseWorld 准星世界坐标
   * @param {{x,y}} playerPos  玩家位置
   * @param {{x,y}} [out]      可选输出对象（传入则写入并返回，避免逐帧分配）
   */
  midpointOffset: function (mouseWorld, playerPos, out) {
    var o = out || { x: 0, y: 0 };
    o.x = (mouseWorld.x + playerPos.x) / 2 - playerPos.x;
    o.y = (mouseWorld.y + playerPos.y) / 2 - playerPos.y;
    return o;
  },

  /**
   * 目标偏移 clamp：保证「相机中心 = 玩家 + 偏移」落在 [0, mapSize] 内。
   * 等价于 clamp(playerPos + offset) − playerPos。
   * @param {{x,y}} offset    待 clamp 的目标偏移
   * @param {{x,y}} playerPos 玩家位置
   * @param {number} mapSize  地图边长（px）
   * @param {{x,y}} [out]     可选输出对象
   */
  clampOffset: function (offset, playerPos, mapSize, out) {
    var o = out || { x: 0, y: 0 };
    o.x = Math.max(0, Math.min(mapSize, playerPos.x + offset.x)) - playerPos.x;
    o.y = Math.max(0, Math.min(mapSize, playerPos.y + offset.y)) - playerPos.y;
    return o;
  },

  /** 线性插值一步：cur + (target − cur) × k */
  lerpStep: function (cur, target, k) {
    return cur + (target - cur) * k;
  },

  /**
   * 阻尼比例的安全取值：非有限数（NaN / Infinity / 非 number）→ fallback，
   * 否则夹到 [lo, hi]。
   */
  clampRate: function (v, lo, hi, fallback) {
    if (typeof v !== 'number' || !isFinite(v)) return fallback;
    return Math.max(lo, Math.min(hi, v));
  },

  // ══════════════════════════════════════════════════════════════════
  //  ② 状态 + 逐帧逻辑
  // ══════════════════════════════════════════════════════════════════

  // 当前偏移（相机中心 = 玩家 + offsetX/offsetY）
  offsetX: 0,
  offsetY: 0,
  // 目标偏移（玩家操作直接改目标；offset 每帧向它 lerp 逼近）
  targetX: 0,
  targetY: 0,
  // 跟随模式：设置开启时相机常驻「准星—我舰连线中点」；
  // 玩家按方向键 → 临时接管（false，停在原地不回中）；按 L / 空格 → 恢复。
  // 设置关闭时恒为 false，行为与跟随功能加入前完全一致。
  followMode: false,
  settingOn: false,   // 仅用于探测设置项刚被切换
  input: null,        // init() 绑定的 InputHandler

  /**
   * 初始化：绑定 input + 重置全部状态（含 followMode/settingOn 读设置项）。
   * 时机与原 main.js 闭包里的 `let camOffsetX = 0 …` 一致 —— 页面加载执行一次，
   * 重开关卡走 location.reload()，所以每次战斗都是干净初始状态（无跨战斗残留）。
   */
  init: function (inputRef) {
    Camera.input = inputRef || null;
    Camera.reset();
    var midFollow = !!(typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.cameraMidFollow);
    Camera.followMode = midFollow;
    Camera.settingOn = midFollow;
  },

  /** 四个偏移全部归零（页面初始化 init 用；战斗结束改走 freeze —— 归零会让结算瞬间相机暴跳，2026-10-18） */
  reset: function () {
    Camera.offsetX = 0;
    Camera.offsetY = 0;
    Camera.targetX = 0;
    Camera.targetY = 0;
  },

  /**
   * 战斗结束冻结（2026-10-18 字人要求「结束后相机就别动」）：
   * 只停跟随（followMode=false），**偏移保持原地** —— 相机冻在结算瞬间的位置。
   * ⚠ 不能在此归零偏移：跟随模式下偏移可达上千 px，硬归零会让相机在结算瞬间暴跳近一整屏
   * （同 updateDead 注释的理由）；而且旧实现 reset 后下一帧 updateAlive 又把跟随拉起来，
   * 就是「结算画面相机持续漂移」的根源。
   * 之后逐帧走 updateEnded（仅方向键可移）。
   */
  freeze: function () {
    Camera.followMode = false;
  },

  /**
   * 相机偏移更新（2026-08-07 + P 键跳准星 + 2026-10-01 中点跟随）：
   * - 方向键：直接改目标偏移（移动）
   * - L（cameraReset）：目标归零；跟随开启时兼作「恢复跟随」。
   *   注意：跟随开启时这一帧的归零会被紧随其后的跟随块覆盖，净效果是
   *   「立即回到准星中点」而非「回到锁定玩家」；设置关闭时才是纯粹的回中。
   * - 空格（cameraFocus）：目标 = (准星世界坐标 + 玩家位置)/2 − 玩家位置
   *   （相机移到准星与我舰连线中点），并恢复跟随
   * 每帧 camOffset 向目标 lerp（快速过渡动画）；相机中心 clamp 在地图内。
   * 跟随模式（SETTINGS.cameraMidFollow，默认关）：开启后每帧把目标平滑推向中点；
   * 跟随中按方向键 → 临时接管，相机停在玩家推到的位置不再自动回中（无屏幕提示）。
   *
   * @param {number} dt       本帧时长（s）
   * @param {{x,y}} player    玩家（每帧传入，勿缓存）
   * @param {number} zoom     当前缩放 currentZoom（每帧传入，勿缓存）
   * @param {number} mapSize  地图边长 MAP_SIZE_PX（每帧传入，勿缓存）
   */
  updateAlive: function (dt, player, zoom, mapSize) {
    var input = Camera.input;
    var S = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS : {};
    var midFollow = !!S.cameraMidFollow;   // 设置项（定义在 js/systems/settings.js）

    // 设置项刚被切换 → 跟随模式跟随它（刚勾上就立刻看到效果；关掉则回到纯手动）
    if (midFollow !== Camera.settingOn) {
      Camera.settingOn = midFollow;
      Camera.followMode = midFollow;
    }

    var tx = Camera.targetX;
    var ty = Camera.targetY;

    // L 还原：跟随开启时兼作「恢复跟随」；否则保持原义（目标偏移归零）
    if (input.isActionJustPressed('cameraReset')) {
      if (midFollow) Camera.followMode = true;
      tx = 0;
      ty = 0;
    }

    // 空格（cameraFocus）：相机移到准星与我舰连线中点；跟随开启时同时恢复跟随（2026-08-09 字人改）
    if (input.isActionJustPressed('cameraFocus')) {
      Camera.followMode = true;
      _camScratchMw.x = input.mouseWorldX;
      _camScratchMw.y = input.mouseWorldY;
      var focus = Camera.midpointOffset(_camScratchMw, player, _camScratchOut);
      tx = focus.x;
      ty = focus.y;
    }

    // 方向键：移动目标偏移（屏幕手感恒定：世界速度 = 基准 × 灵敏度 / zoom）
    var spd = OBSERVER_CAM_SPEED * (S.cameraSensitivity || 1) / Math.max(0.1, zoom) * dt;
    var moved = false;
    if (input.isActionHeld('cameraUp'))    { ty -= spd; moved = true; }
    if (input.isActionHeld('cameraDown'))  { ty += spd; moved = true; }
    if (input.isActionHeld('cameraLeft'))  { tx -= spd; moved = true; }
    if (input.isActionHeld('cameraRight')) { tx += spd; moved = true; }
    // 方向键 → 临时接管：相机停在玩家推到的位置，不再自动回中
    if (moved && midFollow) Camera.followMode = false;

    // 跟随：把目标平滑推向「准星与我舰连线中点」（必须在方向键之后，否则会覆盖玩家的手动推算）
    //   2026-10-01 抗抖动：原先每帧直接赋值 = 1:1 全耦合，鼠标手抖被原样传给相机（实测 11.7% 透过），
    //   玩家感到「晃」。改为按比例逐帧逼近，稳态仍精确对准中点（永久偏离 0），只是到达得更滑顺。
    //   比例由设置项 SETTINGS.cameraFollowSmooth 控制：1 = 立即跟随（等同改动前），越小越滑顺。
    if (midFollow && Camera.followMode) {
      var followSmooth = Camera.clampRate(S.cameraFollowSmooth, CAM_FOLLOW_SMOOTH_MIN, 1, CAM_FOLLOW_SMOOTH_DEFAULT);
      _camScratchMw.x = input.mouseWorldX;
      _camScratchMw.y = input.mouseWorldY;
      var raw = Camera.midpointOffset(_camScratchMw, player, _camScratchOut);
      tx += (raw.x - tx) * followSmooth;
      ty += (raw.y - ty) * followSmooth;
    }

    // 目标偏移 clamp：相机中心 = 玩家 + 目标偏移 ∈ [0, mapSize]
    _camScratchOff.x = tx;
    _camScratchOff.y = ty;
    var clamped = Camera.clampOffset(_camScratchOff, player, mapSize, _camScratchOut);
    Camera.targetX = clamped.x;
    Camera.targetY = clamped.y;

    // 当前偏移向目标平滑过渡（快速动画）
    var lerpK = Math.min(1, CAM_LERP_RATE * dt);
    Camera.offsetX = Camera.lerpStep(Camera.offsetX, Camera.targetX, lerpK);
    Camera.offsetY = Camera.lerpStep(Camera.offsetY, Camera.targetY, lerpK);
  },

  /**
   * 玩家阵亡：偏移只服务于「活着时」的跟随/手动，旁观视角由 observerCam 独占，
   * 不归零会带着鼠标偏移量漂移（跟随模式下尤其明显）。
   * 目标立即归零、当前值沿用同一条 lerp 滑回中点（~0.3s）——跟随模式下偏移可达
   * 上千 px，硬置 0 会让相机在阵亡瞬间暴跳近一整屏。
   */
  updateDead: function (dt) {
    Camera.targetX = 0;
    Camera.targetY = 0;
    var deadLerpK = Math.min(1, CAM_LERP_RATE * dt);
    Camera.offsetX = Camera.lerpStep(Camera.offsetX, Camera.targetX, deadLerpK);
    Camera.offsetY = Camera.lerpStep(Camera.offsetY, Camera.targetY, deadLerpK);
  },

  /**
   * 战斗结束后逐帧更新（2026-10-18 字人要求）：**不跟随、不读鼠标** —— 鼠标怎么甩相机都不动；
   * 只有相机方向键（默认 ↑↓←→）移动目标偏移，当前值沿用同一条 lerp 平滑过去。
   * base = 相机锚点（玩家存活 = 玩家位置；玩家阵亡 = 旁观 observerCam），clamp 保证相机中心不出地图。
   * @param {number} dt      本帧时长（s）
   * @param {{x,y}} base     相机锚点（每帧传入，勿缓存）
   * @param {number} zoom    当前缩放（每帧传入，勿缓存）
   * @param {number} mapSize 地图边长（每帧传入，勿缓存）
   */
  updateEnded: function (dt, base, zoom, mapSize) {
    var input = Camera.input;
    var S = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS : {};
    var tx = Camera.targetX;
    var ty = Camera.targetY;

    // 方向键：移动目标偏移（速度公式与 updateAlive 手动挡一致：屏幕手感恒定）
    var spd = OBSERVER_CAM_SPEED * (S.cameraSensitivity || 1) / Math.max(0.1, zoom) * dt;
    if (input && input.isActionHeld('cameraUp'))    ty -= spd;
    if (input && input.isActionHeld('cameraDown'))  ty += spd;
    if (input && input.isActionHeld('cameraLeft'))  tx -= spd;
    if (input && input.isActionHeld('cameraRight')) tx += spd;

    // 目标偏移 clamp（锚点 = base）：相机中心 = base + 目标偏移 ∈ [0, mapSize]
    _camScratchOff.x = tx;
    _camScratchOff.y = ty;
    var clamped = Camera.clampOffset(_camScratchOff, base, mapSize, _camScratchOut);
    Camera.targetX = clamped.x;
    Camera.targetY = clamped.y;

    // 当前偏移向目标平滑过渡（与存活时同一条 lerp）
    var lerpK = Math.min(1, CAM_LERP_RATE * dt);
    Camera.offsetX = Camera.lerpStep(Camera.offsetX, Camera.targetX, lerpK);
    Camera.offsetY = Camera.lerpStep(Camera.offsetY, Camera.targetY, lerpK);
  },
};
