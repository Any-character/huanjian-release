/**
 * registry.js — 独特机制系统注册表（2026-10-01）
 *
 * 目的：把"需要代码逻辑的独特机制技能系统"（血池/炮火风暴/及以后新增）的生命周期从 main.js 解耦。
 * main.js 不再认识具体系统，只调 GameSystems.initAll（开战）+ updateAll（每帧）。
 * 系统在自己的 systems/X.js 末尾用 GameSystems.register 自登记，main.js 自动覆盖。
 *
 * 与 ship-skills.js 的区别：ship-skills 处理"数据驱动"的普通被动（+属性，纯数据 effects）；
 * 本注册表处理"需要代码逻辑"的独特机制（自成一体的状态机/每帧维护）。
 *
 * 事件型钩子（takeDamage→bloodPool.onDamage、fireMainGun→A140AStorm.onMainGunFired 等）
 * 不经本注册表——由各自消费点直接调（系统挂在 ship._xxx 或全局单例）。
 */
const GameSystems = {
  _list: [],

  /**
   * 注册一个系统。
   * @param {string} id — 唯一标识
   * @param {Object} opts
   * @param {number} [opts.order] — update 执行顺序（升序，小先执行；默认 100）
   * @param {Function} [opts.init] — (ship, config, now, ctx) 战斗开始时对玩家调用一次
   * @param {Function} [opts.update] — (ship, dt, now, allies, enemies) 每帧对每艘本方舰船调用
   */
  register(id, opts) {
    opts = opts || {};
    this._list.push({ id: id, order: opts.order != null ? opts.order : 100,
                      init: opts.init, update: opts.update });
    this._list.sort(function(a, b) { return a.order - b.order; });
  },

  /** 战斗开始：对玩家船调用所有系统的 init（按 order 升序）。ctx 传 main.js 闭包里的依赖。 */
  initAll(ship, config, now, ctx) {
    for (var i = 0; i < this._list.length; i++) {
      var s = this._list[i];
      if (s.init) s.init(ship, config, now, ctx);
    }
  },

  /** 每帧：对 ships（[player, ...allies]）每艘调所有系统的 update（按 order 升序；系统外层×船内层）。 */
  updateAll(ships, dt, now, allies, enemies) {
    for (var i = 0; i < this._list.length; i++) {
      var s = this._list[i];
      if (!s.update) continue;
      for (var j = 0; j < ships.length; j++) {
        s.update(ships[j], dt, now, allies, enemies);
      }
    }
  },
};