/**
 * term-overrides.js — 「更多词条」可调清单（纯数据，可直接编辑）
 *
 * ════════════════════════════════════════════════════════════════════
 *  ★本文件 = 「自定义加成」弹窗的可调清单（自定义战斗敌/友军 + 选船界面古鹰）
 *  ★**新词条一律加到这里**，不要加进 js/constants-custom.js 的 OVERRIDE_RANGES
 *    （那是「基础属性」并列表，只放血量/装甲/航速/武器数量/装填/射程/各类几率）
 *    —— 2026-11-08 字人要求：机制词条不与基础属性并列，统一走「自定义加成」。
 *    守卫：单测第 98 节（TERM_ONLY_OVERRIDE_KEYS 里的词条不得出现在 OVERRIDE_RANGES）。
 *
 *  如何编辑本文件：
 *   1. 想改某词条的调节范围 → 改它的 min/max/step（min ≤ max，step > 0）
 *   2. 想新增可调词条 → 复制任意一个 { ... } 对象，改 id（英文小写）、
 *      name（中文名）、category（damage/status/ship）、范围、isPct
 *   3. 想删除可调词条 → 删掉对应那一个 { ... } 对象（含逗号）
 *  注意：
 *   - id 不能重复；id 必须已存在于 js/data/terms.js 词条库（有测试兜底：第 63.10 节）
 *   - 【开发者】新增条目后：若该属性已接入战斗（ship 字段），同步加进 tests/run_tests.js
 *     第 63 节守卫清单；applyTermOverridesToShip 直接写 ship[id]，故 ship.js 必须有同名字段
 *   - isPct=true：UI 显示整数百分比，存储小数（0.15 = 15%）
 *   - isPct=false：数值直存（如燃烧加速 15 = +15，间隔公式 100+15）
 * ════════════════════════════════════════════════════════════════════
 */

/** 「更多词条」可调清单：id / name / category / min / max / step / isPct */
const TERM_OVERRIDES = [
  /* ── 伤害机制 ─────────────────────────────────────────────── */
  { id: 'critChance',         name: '暴击几率',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'critDmg',            name: '暴击伤害',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'penetrationChance',  name: '穿甲几率',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'penDmg',             name: '穿甲伤害',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'shatterChance',      name: '碎甲几率',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'shatterPower',       name: '碎甲程度',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'finalDmg',           name: '最终增伤',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'bonusVsBurning',     name: '对燃烧目标增伤', category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'reduceMainDmg',      name: '减免主炮伤害', category: 'damage', min: 0,    max: 100, step: 1,    isPct: false },
  { id: 'mainPen',            name: '主炮穿透',     category: 'damage', min: 0,    max: 100, step: 1,    isPct: false },
  { id: 'reduceTorpedoDmg',   name: '减免鱼雷伤害', category: 'damage', min: 0,    max: 100, step: 1,    isPct: false },
  { id: 'torpPen',            name: '鱼雷穿透',     category: 'damage', min: 0,    max: 100, step: 1,    isPct: false },
  { id: 'reduceCritDmg',      name: '减免暴击伤害', category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'reducePenDmg',       name: '减免穿甲伤害', category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'resistCritChance',   name: '抵抗暴击',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistPenetration',  name: '抵抗穿甲',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistBurnChance',   name: '抵抗燃烧',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistAccessoryChance', name: '抵抗配损',   category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistWeaponDamageChance', name: '抵抗武损', category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistFloodChance',  name: '抵抗漏水',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistShatterChance',name: '抵抗碎甲',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'resistBurnPower',    name: '抵抗燃烧程度', category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'resistFloodPower',   name: '抵抗漏水程度', category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'resistFinalDmg',     name: '最终减伤',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'ignoreArmor',        name: '无视装甲',     category: 'damage', min: 0,    max: 100000, step: 1,    isPct: false },
  { id: 'executeChance',      name: '收割几率',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'executeDmg',         name: '收割伤害',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'executeThreshold',   name: '收割血限',     category: 'damage', min: 0,    max: 0.75, step: 0.01, isPct: true },
  { id: 'minePen',            name: '水雷穿透',     category: 'damage', min: 0,    max: 100, step: 1,    isPct: false },
  { id: 'reduceMineDmg',      name: '减免水雷伤害', category: 'damage', min: 0,    max: 100, step: 1,    isPct: false },
  { id: 'shotAccuracy',       name: '射击精度',     category: 'damage', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'smallCaliberEvasion',  name: '小口径炮弹规避', category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },
  { id: 'mediumCaliberEvasion', name: '中口径炮弹规避', category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },
  { id: 'largeCaliberEvasion',  name: '大口径炮弹规避', category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },
  { id: 'shield',            name: '护盾',         category: 'damage', min: 0,    max: 100000, step: 1, isPct: false },
  { id: 'shieldShred',       name: '护盾撕裂',     category: 'damage', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'dmgToOneChance',    name: '受到武器伤害为1几率', category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'torpedoEvasion',     name: '鱼雷规避',     category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },
  { id: 'mineEvasion',        name: '水雷规避',     category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },
  { id: 'ignoreFinalReduce',  name: '无视减伤',     category: 'damage', min: 0, max: 5, step: 0.01, isPct: true },
  { id: 'hullProtect',        name: '舰体保护',     category: 'damage', min: 0, max: 5, step: 0.01, isPct: true },
  { id: 'resistShatterDegree',name: '抵抗碎甲程度', category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },
  // 武器真伤（2026-09-19）：通用 + 各武器专属（同类相加，基数 = 武器总面板）+ 抵抗（对冲）
  { id: 'trueDmg',            name: '武器真伤',     category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'mainTrueDmg',        name: '主炮真伤',     category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'torpTrueDmg',        name: '鱼雷真伤',     category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'mineTrueDmg',        name: '水雷真伤',     category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'secTrueDmg',         name: '副炮真伤',     category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'resistTrueDmg',      name: '抵抗武器真伤', category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'repairEff',          name: '维修效率',     category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  // 鱼雷专属通道（2026-10-01 阳炎-利刃基础设施）
  //   torpPanelDmgPct：小数比例（0.05 = 5%），与真伤同尺度；基数 = 武器总面板，整笔加到单管
  //   torpedoSpeedAdd：单位「节」（绝对值，非百分比），与 burnSpeed/floodSpeed 同类尺度
  { id: 'torpPanelDmgPct',    name: '鱼雷面板伤害', category: 'damage', min: 0, max: 2, step: 0.01, isPct: true },
  { id: 'torpedoSpeedAdd',    name: '鱼雷速度',     category: 'damage', min: 0, max: 100, step: 1, isPct: false },
  // 不屈（2026-11-08 威斯康星「威慑重击」）：每次受主炮/鱼雷/水雷伤害回**固定点数**血量
  //   单位 = 点血（不是百分比！），受维修效率加成；消费端 ship-status.js 的 takeDamage 尾部
  { id: 'unyielding',         name: '不屈',         category: 'damage', min: 0, max: 10000, step: 1, isPct: false },
  // 受到穿甲伤害 / 受到武器伤害 / 固定伤害减免（2026-11-08 威斯康星「不动堡垒」等新词条补登记）
  //   ⚠️ takeWeaponDmgAdd 可为**负**（减伤），min 必须是负数
  { id: 'takePenDmgAdd',      name: '受到穿甲伤害', category: 'damage', min: 0, max: 5, step: 0.01, isPct: true },
  { id: 'takeWeaponDmgAdd',   name: '受到武器伤害', category: 'damage', min: -1, max: 2, step: 0.01, isPct: true },
  { id: 'flatDamageReduce',   name: '固定伤害减免', category: 'damage', min: 0, max: 1, step: 0.01, isPct: true },

  /* ── 状态效果 ─────────────────────────────────────────────── */
  { id: 'burnChance',         name: '燃烧几率',     category: 'status', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'accessoryChance',    name: '配损几率',     category: 'status', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'weaponDamageChance', name: '武损几率',     category: 'status', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'burnPower',          name: '燃烧程度',     category: 'status', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'burnSpeed',          name: '燃烧加速',     category: 'status', min: 0,    max: 200, step: 1,    isPct: false },
  { id: 'burnDuration',       name: '燃烧延长',     category: 'status', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'burnDelay',          name: '延缓燃烧',     category: 'status', min: 0,    max: 200, step: 1,    isPct: false },
  { id: 'floodChance',        name: '漏水几率',     category: 'status', min: 0,    max: 2,   step: 0.01, isPct: true },
  { id: 'floodPower',         name: '漏水程度',     category: 'status', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'floodSpeed',         name: '漏水加速',     category: 'status', min: 0,    max: 200, step: 1,    isPct: false },
  { id: 'floodDuration',      name: '漏水延长',     category: 'status', min: 0,    max: 5,   step: 0.01, isPct: true },
  { id: 'floodDelay',         name: '延缓漏水',     category: 'status', min: 0,    max: 200, step: 1,    isPct: false },

  /* ── 舰船属性 ─────────────────────────────────────────────── */
  { id: 'armor',              name: '装甲强度',     category: 'ship',   min: 0,    max: 100000, step: 1,    isPct: false },
  { id: 'maxSpeed',           name: '航速',         category: 'ship',   min: 0,    max: 110,     step: 0.1,  isPct: false },
  { id: 'rotationSpeed',      name: '转向转速',     category: 'ship',   min: 0,    max: 180,     step: 1,    isPct: false, rad: true },
  { id: 'detonationRadius',   name: '水雷引爆半径', category: 'ship',   min: 0.1,  max: 5,       step: 0.1,  isPct: false },
  { id: 'explosionRadius',    name: '水雷爆炸半径', category: 'ship',   min: 0.1,  max: 10,      step: 0.1,  isPct: false },
  { id: 'lifetimeSec',        name: '水雷存在时间', category: 'ship',   min: 5,    max: 600,     step: 5,    isPct: false },
  // 雷达干扰 / 反雷达干扰（2026-10-01 阳炎-利刃）
  //   单位 km（绝对值，非百分比）。⚠️ radarJamming 语义特殊：留空 = 无词条（跳过检查），
  //   填 0 = 永久隐身 —— 面板留空即「无词条」，勿在 SHIP_TYPE_DEFAULTS 里补 0 默认值。
  { id: 'radarJamming',       name: '雷达干扰',     category: 'ship',   min: 0,    max: 50,      step: 0.5,  isPct: false },
  { id: 'antiRadarJamming',   name: '反雷达干扰',   category: 'ship',   min: 0,    max: 50,      step: 0.5,  isPct: false },
];
