/**
 * attack-stats.js — 攻击侧属性单一来源表（2026-10-25 深模块重构）
 *
 * ⚠️ 这个文件是「新增一个攻击侧属性」时**唯一必须改的代码位置**。
 *
 * ── 为什么要有它 ──────────────────────────────────────────────
 * 【历史，不是现状】重构前，加一条攻击侧属性要跨十余处同步（配置/弹丸构造/词条/面板/守卫），
 * 漏一处就**静默失效**：不报错、看起来正常、实际没生效。配损、武损、武器真伤各翻车一次。
 * 本文件就是为了把那份散落的知识收成一张表（细节见 docs/adding-content.md §8.6）。
 *
 * 真正的知识不是「有这个字段」，而是「这个字段对哪几类武器有效」——
 * 副炮不穿甲/不燃烧/不漏水/无配损，主炮无漏水，鱼雷无穿甲率，水雷无护盾撕裂。
 * 所以本表的每一行都用 `weapons` 显式声明适用范围，**这个矩阵就是原来散落 N 处的知识**。
 *
 * ── 改完之后哪些地方自动生效 ──────────────────────────────────
 *   · Ship 构造器读取（ship.js 末尾按表补读未登记的键）
 *   · 玩家侧 4 类武器 baseStats（ship-weapons.js 调 buildAttackStats）
 *   · 自定义战斗敌舰公共池（custom-enemy.js 调 buildEnemyAttackStats）
 *   · weaponToMountConfig 的「舰体值 + 武器 bonuses」相加（weapon-config.js 调 fillAttackFields）
 *   · 单测守卫（tests 第 87 节：哨兵值必须端到端流到弹丸）
 *
 * ── 仍需人改的（这些是数据，不是坑）──────────────────────────
 *   · 舰船配置里的具体数值（js/ships/*.js）
 *   · 词条文案 js/data/terms.js（守卫会检查每个 key 都有词条）
 *   · 面板可调 js/data/term-overrides.js / OVERRIDE_RANGES（仅当要暴露给玩家调）
 *   · SHIP_TYPE_DEFAULTS / ENEMY_CONFIG 的默认值（新属性默认 0 时可不写）
 *
 * ── 字段含义 ─────────────────────────────────────────────────
 *   key        Ship 上的字段名（也是弹丸字段名，除非 projectile:false）
 *   weapons    该属性对哪几类武器生效（'mainGun' | 'secondary' | 'torpedo' | 'mine'）
 *   enemy      是否进自定义战斗敌舰的公共池 _baseAttackStats（口径必须与玩家侧一致）
 *   def        舰体没配时的默认值（null/undefined 语义见下）
 *   read       (ship, weaponType) => 值 —— 取值不是「直接读同名字段」时用
 *   projectile 是否会出现在弹丸配置 wcfg 上（true 才能被 fillAttackFields 自动补齐）
 *   fill       weapon-config 是否自动做「舰体值 + weapon.bonuses」相加（默认 true）
 *   term       是否有词条（守卫检查 TERM_LIBRARY 里必须有）
 *
 * ⚠️ 三态属性（radarJamming / antiRadarJamming）**不属于攻击侧**，且 `undefined` 是
 *    正确值，绝不能加进本表（加进去会被补成 0 = 全舰队永久隐身，见 AGENTS §5.32.7）。
 */

/** 四类武器（顺序 = 面板/调试输出顺序） */
const ATTACK_WEAPON_TYPES = ['mainGun', 'secondary', 'torpedo', 'mine'];

/**
 * 攻击侧属性表。
 * 加一行 = 新增一个攻击侧属性；`weapons` 决定它对哪些武器生效。
 */
const ATTACK_STATS = [
  // ── 暴击 / 碎甲（四类武器通用）────────────────────────────────
  { key: 'critChance',        weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  { key: 'critDmg',           weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  { key: 'shatterChance',     weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  { key: 'shatterPower',      weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },

  // ── 处决 / 护盾撕裂 / 无视末减（四类通用）────────────────────
  { key: 'executeChance',     weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  { key: 'executeDmg',        weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  { key: 'executeThreshold',  weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  { key: 'ignoreFinalReduce', weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },
  // 护盾撕裂：按定义对**全武器**生效（2026-10-25 字人确认）。
  //   此前只有副炮/鱼雷带 ship 级值（主炮/水雷漏接，属静默失效），已补齐四类。
  { key: 'shieldShred',       weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true },

  // ── 伤害类（副炮不吃燃烧/漏水/最终增伤/配损/武损）────────────
  { key: 'finalDmg',          weapons: ['mainGun', 'torpedo', 'mine'],               enemy: true,  def: 0, term: true },
  { key: 'bonusVsBurning',    weapons: ['mainGun', 'torpedo', 'mine'],               enemy: true,  def: 0, term: true },
  { key: 'penDmg',            weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },
  { key: 'penetrationChance', weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },
  { key: 'mainPen',           weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },
  { key: 'torpPen',           weapons: ['torpedo'],                                  enemy: false, def: 0, term: true },

  // ── 配件损毁 / 武器损毁（副炮刻意关闭：isSecondary 双保险）────
  { key: 'accessoryChance',    weapons: ['mainGun', 'torpedo', 'mine'],              enemy: true,  def: 0, term: true },
  { key: 'weaponDamageChance', weapons: ['mainGun', 'torpedo', 'mine'],              enemy: true,  def: 0, term: true },

  // ── 燃烧（主炮专属）──────────────────────────────────────────
  { key: 'burnChance',        weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },
  { key: 'burnPower',         weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },
  { key: 'burnSpeed',         weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },
  { key: 'burnDuration',      weapons: ['mainGun'],                                  enemy: false, def: 0, term: true },

  // ── 漏水（鱼雷 / 水雷）───────────────────────────────────────
  { key: 'floodChance',       weapons: ['torpedo', 'mine'],                          enemy: false, def: 0, term: true },
  { key: 'floodPower',        weapons: ['torpedo', 'mine'],                          enemy: false, def: 0, term: true },
  { key: 'floodSpeed',        weapons: ['torpedo', 'mine'],                          enemy: false, def: 0, term: true },
  { key: 'floodDuration',     weapons: ['torpedo', 'mine'],                          enemy: false, def: 0, term: true },

  // ── 武器真伤（通用 + 各武器专属，同类相加；实现在 weapon-config）──
  { key: 'trueDmg',           weapons: ['mainGun', 'secondary', 'torpedo', 'mine'], enemy: true,  def: 0, term: true, fill: false },
  { key: 'mainTrueDmg',       weapons: ['mainGun'],   enemy: true, def: 0, term: true, projectile: false },
  { key: 'secTrueDmg',        weapons: ['secondary'], enemy: true, def: 0, term: true, projectile: false },
  { key: 'torpTrueDmg',       weapons: ['torpedo'],   enemy: true, def: 0, term: true, projectile: false },
  { key: 'mineTrueDmg',       weapons: ['mine'],      enemy: true, def: 0, term: true, projectile: false },
  // 数值真伤（2026-11-08 威斯康星「威慑重击」叠层）：固定数值，**无视减伤**，
  //   在百分比真伤**之后**加（collision-hit.js）。与 trueDmg/mainTrueDmg 是两条独立通道。
  { key: 'trueDmgFlat',       weapons: ['mainGun'],   enemy: false, def: 0, term: true } ,

  // ── 命中/精度（口径决定跳弹率）───────────────────────────────
  { key: 'shotAccuracy',      weapons: ['mainGun', 'secondary'], enemy: false, def: 1, term: true,
    read: function (ship, type) { return ship.shotAccuracy != null ? ship.shotAccuracy : 1; } },
  // 主炮/副炮口径：主炮按舰种推导（ship.shellCaliber），副炮恒小口径
  { key: 'shellCaliber',      weapons: ['mainGun', 'secondary'], enemy: false, projectile: false, term: false,
    read: function (ship, type) { return type === 'secondary' ? 'small' : (ship.shellCaliber || 'medium'); } },

  // ── 鱼雷专属通道（2026-10-01 阳炎-利刃基础设施）────────────────
  //   ⚠️ 这三条只服务鱼雷，故 `projectile:false`：它们在 weapon-config 内部被折进
  //      damage / speed / shotAccuracy，不直接落到弹丸字段上。
  { key: 'torpPanelDmgPct',   weapons: ['torpedo'], enemy: true,  def: 0, term: true, projectile: false,
    read: function (ship) { return (ship.torpPanelDmgPct || 0) + (ship.getBuffMod ? (ship.getBuffMod('torpPanelDmgPct') || 0) : 0); } },
  { key: 'torpedoSpeedAdd',   weapons: ['torpedo'], enemy: true,  def: 0, term: true, projectile: false,
    read: function (ship) { return ship._torpedoSpeedAdd ? ship._torpedoSpeedAdd() : (ship.torpedoSpeedAdd || 0); } },
  { key: 'torpedoSpeedPct',   weapons: ['torpedo'], enemy: false, def: 0, term: false, projectile: false,
    read: function (ship) { return ship.getBuffMod ? (ship.getBuffMod('torpedoSpeedPct') || 0) : 0; } },
  { key: 'torpedoAccuracy',   weapons: ['torpedo'], enemy: false, def: 0, term: true, projectile: false,
    read: function (ship) { return ship.torpedoAccuracy || 0; } },

  // ── 水雷几何（随 baseStats 进入 weapon-config 的「船值 vs 武器值」优先级判定）──
  //   ⚠️ 必须保留 **undefined**（不能补 0）：weapon-config 用 `!= null && !== 默认常量`
  //      判断「词条是否调节过」，补 0 会让水雷半径变成 0。
  { key: 'detonationRadius', weapons: ['mine'], enemy: false, term: false, projectile: false,
    read: function (ship) { return ship.detonationRadius; } },
  { key: 'explosionRadius',  weapons: ['mine'], enemy: false, term: false, projectile: false,
    read: function (ship) { return ship.explosionRadius; } },
  { key: 'lifetimeSec',      weapons: ['mine'], enemy: false, term: false, projectile: false,
    read: function (ship) { return ship.lifetimeSec; } },
];

/** 表按 key 索引（守卫/测试用，避免各处再手抄清单） */
const ATTACK_STATS_BY_KEY = {};
ATTACK_STATS.forEach(function (row) { ATTACK_STATS_BY_KEY[row.key] = row; });

/** 该属性是否对某类武器生效 */
function attackStatAppliesTo(row, weaponType) {
  return row.weapons.indexOf(weaponType) >= 0;
}

/** 取某个属性的默认值（未声明 def 视为 0） */
function attackStatDefault(row) {
  return row.def != null ? row.def : 0;
}

/**
 * 玩家/AI 舰的「攻击侧 baseStats」——替代 ship-weapons.js 里原有的手抄对象（历史）。
 * @param {Ship}   ship
 * @param {string} weaponType — 'mainGun' | 'secondary' | 'torpedo' | 'mine'
 * @returns {Object} 只含该武器适用的属性（顺序无关）
 */
function buildAttackStats(ship, weaponType) {
  var out = {};
  for (var i = 0; i < ATTACK_STATS.length; i++) {
    var row = ATTACK_STATS[i];
    if (!attackStatAppliesTo(row, weaponType)) continue;
    if (row.read) {
      out[row.key] = row.read(ship, weaponType);
    } else {
      out[row.key] = ship[row.key] !== undefined ? ship[row.key] : attackStatDefault(row);
    }
  }
  return out;
}

/**
 * 自定义战斗敌舰的公共攻击词条池（替代 custom-enemy.js 的 _baseAttackStats 手抄对象）。
 * 口径：只取 `enemy:true` 的行，值 = 舰体字段（缺省 0），不吃 buff。
 * @param {Ship} ship
 * @returns {Object}
 */
function buildEnemyAttackStats(ship) {
  var out = {};
  for (var i = 0; i < ATTACK_STATS.length; i++) {
    var row = ATTACK_STATS[i];
    if (!row.enemy) continue;
    out[row.key] = ship[row.key] || attackStatDefault(row);
  }
  return out;
}

/**
 * 弹丸配置补齐（weapon-config.js 各分支调用）：
 * 表里声明为 projectile 的攻击属性，若分支对象里还没写，就按
 * 「舰体 baseStats 值 + 武器 bonuses 值」补上（同类相加，与显式分支同口径）。
 *
 * 今天所有分支都已显式写全 → 本函数是 no-op；它的作用是**以后加字段不必再改 weapon-config**。
 * @param {Object} out        — 分支返回的 wcfg 对象（原地补字段并返回）
 * @param {Object} baseStats  — buildAttackStats 的结果
 * @param {Object} bonuses    — weapon.bonuses
 * @param {string} weaponType
 */
function fillAttackFields(out, baseStats, bonuses, weaponType) {
  baseStats = baseStats || {};
  bonuses = bonuses || {};
  for (var i = 0; i < ATTACK_STATS.length; i++) {
    var row = ATTACK_STATS[i];
    if (row.projectile === false || row.fill === false) continue;
    if (!attackStatAppliesTo(row, weaponType)) continue;
    if (out[row.key] !== undefined) continue;   // 显式写过的以显式为准（含真伤汇总等特例）
    out[row.key] = (baseStats[row.key] || 0) + (bonuses[row.key] || 0);
  }
  return out;
}
