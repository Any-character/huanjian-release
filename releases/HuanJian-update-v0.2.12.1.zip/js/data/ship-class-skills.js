/**
 * ship-class-skills.js — 舰种技能数据（2026-10-03）
 *
 * ⚠️ 本文件是「舰种技能」（整个舰种共有，玩家在选船界面选一系/二系）；与「战舰技能」
 *    （js/systems/ship-skills.js，单艘船独有）的区分见 `docs/glossary.md`。
 *
 * 数据结构（设计文档 §3）：
 *   CLASS_SKILLS[shipType] = { label, paths: [ { id, name, enabled, skills: [...] } ] }
 *   单条技能 = { id, name, type:'passive'|'active', ready:boolean, effects:[{stat,value}], desc }
 *   - ready:false = 未开放（弹窗显示「敬请期待」），**不产生任何战斗效果**
 *   - effects 按 stat 分通道：百分比通道与固定值通道**独立**（设计文档 §3.1）
 *
 * ── 单位约定（⚠️ 已逐条核对消费端代码，改数值前先看这里）────────────────────
 *   torpedoSpeedPct            小数（0.05 = +5%）
 *   torpedoSpeedAdd            节（固定值；不做 ×0.057 换算，鱼雷 speed 本就以节计）
 *   torpedoReloadPct           小数（0.10 = 冷却 -10%，**加进** getWeaponReloadSec 的 pct 池）
 *   mineReloadPct             同上（水雷）
 *   reloadFlatReduce_torpedo  秒（固定减，与 reloadPctReduce 类不同量纲）
 *   reloadFlatReduce_mine     秒
 *   floodChance               小数（0.05 = +5%，collision.js 与 resistFloodChance 相减）
 *   floodPower                小数（0.15 = +15%，collision.js `1 + floodPower - resist`）
 *   floodDuration             小数（0.60 = +60%；collision.js `FLOOD_DURATION × (1 + 和)`，
 *                             多来源**先求和再乘一次**，故 0.6+0.6 = ×2.2 而非 ×1.6×1.6）
 *   detonationRadius          **km**（ship.js 存 km；weapon-config.js 开火时才 ×PX_PER_KM）
 *   explosionRadius           **km**（同上）
 *   lifetimeSec               **秒**（SeaMine.lifeLeft = lifetimeSec，直接秒）
 *   maxSpeed                  **节**（= px/s；改后必须 _rebuildSpeedGears 重建档位）
 *   rotationSpeed             **度/秒**（⚠️ 存储层是「度」，应用到 ship 实例时 ×π/180 转弧度
 *                             —— 与 TERM_OVERRIDES 的 `rad:true` 同惯例，见 systems/term-overrides.js:27）
 *
 * ── 战列舰「毁灭」一系新增通道（2026-11-15）──────────────────────────────
 *   penetrationChance / shatterChance / critChance / critDmg
 *                             小数（0.05 = +5%）。落到同名 Ship 字段，由
 *                             `js/data/attack-stats.js` 的 `weapons` 列决定哪类武器吃到
 *                             （穿甲只对主炮生效，其余四类通用）
 *   shellSpeedAdd             **武器速度单位**（500 = 主炮、副炮**各** +500 单位；1 单位 = 0.057 px/s）
 *                             —— 一个 stat 展开成 mainShellSpeedBonus / secShellSpeedBonus 两个 px/s 字段
 *   shellEvasionSmallMedium   小数（0.03 = **直接加 3 个点**），展开到小口径 + 中口径规避
 *   weaponRotationSpeedPct    小数，**基础属性乘算**（0.10 = 基础值 × 1.10，**不是** +0.1 度/秒）
 */

const CLASS_SKILLS = Object.freeze({
  destroyer: {
    label: '驱逐舰',
    paths: [
      {
        id: 'assault',
        name: '突击',
        enabled: true,          // 一系默认启用
        skills: [
          {
            id: 'assault-torpedo-improve',
            name: '鱼雷改进',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'torpedoSpeedPct', value: 0.05 },
              { stat: 'torpedoSpeedAdd', value: 5 },
            ],
            desc: '鱼雷航速+5%，鱼雷航速+5节',
          },
          {
            id: 'assault-torpedo-service',
            name: '鱼雷整备',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'torpedoReloadPct', value: 0.10 },
              { stat: 'reloadFlatReduce_torpedo', value: 1 },
            ],
            desc: '鱼雷冷却-10%，鱼雷冷却-1秒',
          },
          {
            id: 'assault-horsepower-1',
            name: '马力全开Ⅰ',
            type: 'active',
            ready: false,          // ⏸ 敬请期待（本轮不实现，无 effects）
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'assault-armor-pierce',
            name: '装甲击穿',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'floodChance', value: 0.05 },
              { stat: 'floodDuration', value: 0.60 },
            ],
            desc: '鱼雷漏水几率+5%，漏水延长+60%',
          },
          {
            id: 'assault-battleship-cover',
            name: '战舰遮蔽',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'assault-precision-lock',
            name: '精准锁定',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'floodPower', value: 0.15 },
            ],
            desc: '漏水程度+15%',
          },
          {
            id: 'assault-pure-oxygen',
            name: '纯氧助燃',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
        ],
      },
      {
        id: 'blockade',
        name: '封锁',
        enabled: false,         // 二系默认未启用（UI 里点此切换）
        skills: [
          {
            id: 'blockade-mine-enhance',
            name: '水雷强化',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'detonationRadius', value: 0.255 },   // km
              { stat: 'explosionRadius', value: 1.25 },     // km
            ],
            desc: '水雷引爆半径+0.255km，水雷爆炸半径+1.25km',
          },
          {
            id: 'blockade-power-boost',
            name: '动力强化',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'maxSpeed', value: 2.5 },             // 节
              { stat: 'rotationSpeed', value: 2 },          // 度/秒（应用时转弧度）
            ],
            desc: '最大航速+2.5节，转向转速+2度每秒',
          },
          {
            id: 'blockade-horsepower-2',
            name: '马力全开Ⅱ',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'blockade-mine-service',
            name: '水雷整备',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'mineReloadPct', value: 0.10 },
              { stat: 'reloadFlatReduce_mine', value: 1 },
            ],
            desc: '水雷冷却-10%，水雷冷却-1秒',
          },
          {
            id: 'blockade-recon-mine',
            name: '侦察水雷',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
          {
            id: 'blockade-mine-improve',
            name: '水雷改进',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'lifetimeSec', value: 60 },           // 秒
            ],
            desc: '水雷存在时间+60秒',
          },
          {
            id: 'blockade-chain-mine',
            name: '连锁水雷',
            type: 'active',
            ready: false,
            effects: [],
            desc: '敬请期待',
          },
        ],
      },
    ],
  },
  cruiser:   { label: '巡洋舰', paths: [] },   // 空壳 → UI 显示「敬请期待」（查询不得抛异常）
  battleship: {
    label: '战列舰',
    paths: [
      {
        id: 'destruction',
        name: '毁灭',
        enabled: true,          // 一系默认启用（二系「据守」留空，UI 继续显示「敬请期待」）
        skills: [
          {
            id: 'destruction-pierce-pro',
            name: '专业炮击',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'penetrationChance', value: 0.05 },   // 小数；attack-stats 声明为**主炮专属**
              { stat: 'shellSpeedAdd', value: 500 },        // 武器速度单位（主炮 + 副炮各 +500）
            ],
            desc: '穿甲几率+5%，炮弹速度+500单位',
          },
          {
            id: 'destruction-shatter-improve',
            name: '碎甲强化',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'shatterChance', value: 0.05 },       // 小数（四类武器通用）
              { stat: 'shellSpeedAdd', value: 500 },        // 与「专业炮击」同 stat → getEffects 相加 = 1000
            ],
            desc: '碎甲几率+5%，炮弹速度+500单位',
          },
          {
            id: 'destruction-shatter-shot',
            name: '碎甲射击',
            type: 'active',
            ready: true,            // 数据已开放；战斗效果由主动技能机制实装（effects 仍为空）
            active: { key: 'classActiveSkill1', cooldownSec: 60 },
            effects: [],            // ⚠️ 主动技能不参与被动加成（getEffects 只收 passive）
            desc: '全部主炮各挂一发碎甲弹，打光为止：必定碎甲、碎甲程度+5%、主炮炮速+2000单位',
          },
          {
            id: 'destruction-fatal-improve',
            name: '致命强化',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'critChance', value: 0.02 },          // 小数
              { stat: 'critDmg', value: 0.10 },             // 小数（与默认暴击 ×2.0 相加）
            ],
            desc: '暴击几率+2%，暴击伤害+10%',
          },
          {
            id: 'destruction-fatal-shot',
            name: '致命射击',
            type: 'active',
            ready: true,
            active: { key: 'classActiveSkill2', cooldownSec: 180 },
            effects: [],
            desc: '全部主炮各挂一发致命弹，打光为止：必定暴击、暴击伤害+10%',
          },
          {
            id: 'destruction-hull-improve',
            name: '舰体改良',
            type: 'passive',
            ready: true,
            effects: [
              { stat: 'shellEvasionSmallMedium', value: 0.03 },   // 小数（直接加 3 个点，小/中口径各 +3%）
              { stat: 'weaponRotationSpeedPct', value: 0.10 },    // 小数（基础属性乘算 ×1.10）
            ],
            desc: '小口径炮弹规避+3%，中口径炮弹规避+3%，武器转速+10%',
          },
          {
            id: 'destruction-desperate-chant',
            name: '绝望讴歌',
            type: 'active',
            ready: true,
            active: { key: 'classActiveSkill3', cooldownSec: 200 },
            effects: [],
            desc: '20秒内：暴击伤害+10%、穿甲伤害+10%、主炮每命中回复1%最大生命、期间每击沉回复20%最大生命',
          },
        ],
      },
    ],
  },
});
