/**
 * debug-hud-dump.js — HUD 冻结现场捕捉器（2026-09-13）
 *
 * 背景：字人反馈"齐射模式时所有武器冷却条卡住（逻辑正常）"，本地 5 套自动化环境
 * （headless/headed、合成调用/真实按键、最长 60s 全系统压测）均无法重现。
 * 本文件提供**零常态开销**的现场捕捉：卡住发生时按 F9 → 导出完整诊断 JSON 到下载目录，
 * 把文件交给开发即可精准定位（数据层 or 显示层，一对照便知）。
 *
 * 使用：游戏内任意时刻按 F9（战斗中/大厅均可）。文件名 hud-diag-<时间戳>.json。
 *
 * 加载顺序：任意位置（仅依赖 window/document，不依赖其它游戏对象的存在）。
 */

(function () {
  'use strict';

  /** 收集当前完整 HUD 诊断快照 */
  function collectDump() {
    var now = Date.now();
    var dump = {
      capturedAt: now,
      perfNow: (typeof performance !== 'undefined') ? Math.round(performance.now()) : null,
      game: {},
      ui: {},
      commander: {},
    };

    // ── 数据层：4 类武器 getter + mount 原始状态 ──
    try {
      var p = window.__testHooks && window.__testHooks.player;
      if (p) {
        var groups = [
          ['mainGun', p.mainGunMounts, p.getMainGunCooldowns],
          ['torpedo', p.torpedoMounts, p.getTorpedoCooldowns],
          ['mine', p.mineMounts, p.getMineCooldowns],
          ['secondary', p.secondaryMounts, p.getSecondaryCooldowns],
        ];
        for (var g = 0; g < groups.length; g++) {
          var name = groups[g][0];
          var mounts = groups[g][1] || [];
          var getCds = groups[g][2];
          var arr = [];
          for (var i = 0; i < mounts.length; i++) {
            var m = mounts[i];
            arr.push({
              index: i,
              // UI getter 输出（显示层依赖的数据）
              uiRemaining: getCds ? Math.round(getCds.call(p, now)[i].remaining * 1000) / 1000 : null,
              uiReady: getCds ? getCds.call(p, now)[i].ready : null,
              uiDamaged: getCds ? getCds.call(p, now)[i].damaged : null,
              // mount 原始状态（数据层真相）
              rawCooldownEnd: m.cooldownEnd,
              rawCdEndMinusNow: Math.round((m.cooldownEnd - now) * 10) / 10,
              wepDamageStart: m.wepDamageStart,
              wepDamageEnd: m.wepDamageEnd,
              isMountReady: p.isMountReady ? p.isMountReady(m, now) : null,
              getMountCooldownEnd: p.getMountCooldownEnd ? p.getMountCooldownEnd(m, now) : null,
            });
          }
          dump.game[name] = arr;
        }
        dump.game.followsMain = p.secondaryFollowsMain;
        dump.game.aimHeading = Math.round((p.aimHeading || 0) * 180 / Math.PI);
      } else {
        dump.game.player = 'window.__testHooks.player 不存在（非战中？）';
      }
    } catch (e) {
      dump.game.error = String(e && e.message);
    }

    // ── 显示层：4 个容器的实际 DOM 样式（"卡住"的直接证据） ──
    try {
      var containers = {
        mainGun: 'main-gun-icons', torpedo: 'torpedo-icons',
        mine: 'mine-icons', secondary: 'secondary-icons',
      };
      Object.keys(containers).forEach(function (k) {
        var el = document.getElementById(containers[k]);
        if (!el) { dump.ui[k] = '容器不存在'; return; }
        var icons = [];
        for (var i = 0; i < el.children.length; i++) {
          var icon = el.children[i];
          var fill = icon.querySelector('.cooldown-fill');
          var text = icon.querySelector('.cooldown-text');
          icons.push({
            index: i,
            className: icon.className,
            fillHeight: fill ? fill.style.height : null,
            fillBg: fill ? fill.style.backgroundColor : null,
            fillOpacity: fill ? fill.style.opacity : null,
            text: text ? text.textContent : null,
          });
        }
        dump.ui[k] = { display: el.style.display, icons: icons };
      });
    } catch (e) {
      dump.ui.error = String(e && e.message);
    }

    // ── 指挥官状态机 ──
    try {
      var c = window.__testHooks && window.__testHooks.player && window.__testHooks.player.commander;
      if (c) {
        dump.commander = {
          id: c.def && c.def.id,
          lutjens: c.lutjens ? {
            salvoOn: c.lutjens.salvoOn,
            switchCdRemaining: Math.max(0, (c.lutjens.switchCdEnd - now) / 1000),
            perfectLayers: c.lutjens.perfectLayers,
          } : null,
          buffs: (c.getBuffs ? c.getBuffs() : []).map(function (b) {
            return { key: b.key, name: b.name, endTime: String(b.endTime) };
          }),
        };
      }
    } catch (e) {
      dump.commander.error = String(e && e.message);
    }

    return dump;
  }

  /** 导出 JSON 下载文件 */
  function downloadDump(dump) {
    try {
      var blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'hud-diag-' + dump.capturedAt + '.json';
      document.body.appendChild(a);
      a.click();
      setTimeout(function () {
        URL.revokeObjectURL(a.href);
        document.body.removeChild(a);
      }, 500);
    } catch (e) { /* 下载失败不影响游戏 */ }
  }

  /** 屏幕角落提示（1.5s 淡出，无依赖） */
  function flashTip(text) {
    var el = document.createElement('div');
    el.textContent = text;
    el.style.cssText = 'position:fixed;right:12px;bottom:120px;z-index:9999;'
      + 'background:rgba(20,30,40,0.85);color:#CFE3F0;font-size:12px;'
      + 'padding:6px 10px;border-radius:4px;pointer-events:none;';
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 1500);
  }

  // F9 捕捉（keydown 常驻监听，常态零开销）
  window.addEventListener('keydown', function (e) {
    if (e.key !== 'F9') return;
    var dump = collectDump();
    downloadDump(dump);
    flashTip('HUD 诊断已导出（hud-diag-*.json）');
  });

  // 供冒烟脚本直接调用（不触发下载）
  window.__hudDump = collectDump;
})();
