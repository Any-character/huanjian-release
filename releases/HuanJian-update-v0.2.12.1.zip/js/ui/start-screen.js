/**
 * start-screen.js — Pre-battle ship selection screen.
 *
 * Two modes:
 *   ship-select  — 战舰选择 + 属性面板 + 预览 (default)
 *   enhancement  — 强化界面（tab 栏切换进入）
 *
 * Calls onStart(ship) when the player confirms a ship.
 */

class StartScreen {
  /**
   * @param {string} overlayId — DOM id of the overlay container
   * @param {string} canvasId  — DOM id of the preview canvas
   * @param {function} onStart — callback (ship) when "开始战斗" clicked
   */
  constructor(overlayId, canvasId, onStart) {
    this.overlay = document.getElementById(overlayId);
    this.canvas  = document.getElementById(canvasId);
    this.ctx     = this.canvas.getContext('2d');
    this.onStart = onStart;
    // 恢复上次选船
    var savedIdx = parseInt(localStorage.getItem('huanjian.selectedShipIndex'));
    this.selectedIndex = (!isNaN(savedIdx) && savedIdx >= 0 && savedIdx < SHIP_LIBRARY.length) ? savedIdx : 0;
    this.state = 'ship-select';
    this._currentPopup = null;    // 当前弹窗引用，确保同时只有一个
    this._settingsScreen = new SettingsScreen();
    this._popup = new TermOverridesPopup();
    this._build();
    this._drawPreview();
  }

  _build() {
    var cfg = START_SCREEN;
    // 版面：报头 / 左轨页签 / 海图（船）+ 铭牌（属性）/ 船坞（选船 + 出击）
    this.overlay.innerHTML = ''
      + '<div id="ss-masthead">'
      + '  <div id="ss-brand">'
      + '    <span id="ss-brand-name">幻舰</span>'
      + '    <span id="ss-brand-sub">鸟瞰海战</span>'
      + '  </div>'
      + '  <button id="ss-help-btn" title="设置">设置</button>'
      + '</div>'
      + '<div id="ss-main">'
      + '  <div id="ss-tab-bar">'
      // 「选船」是选船页本身（原来这一页没有页签，默认却把「强化」标成激活态 —— 导航在说谎）
      + '    <div class="ss-tab active" data-tab="ships">选船</div>'
      + '    <div class="ss-tab" data-tab="enhancement">强化</div>'
      + '    <div class="ss-tab" data-tab="commander">指挥官</div>'
      // ⚠️ 文案必须是「舰种技能」：与强化页里的「战舰技能」（单艘船独有，enhance.js 渲染）
      //    是两个系统，同叫「技能」会让玩家分不清。第 85 节有断言守着这个文案。
      + '  <div class="ss-tab" data-tab="classskill">舰种技能</div>'
      + '    <div class="ss-tab disabled" data-tab="skin">涂装</div>'
      + '    <div id="ss-rail-foot"></div>'
      + '  </div>'
      + '  <div id="ss-body">'
      + '    <div id="ss-ship-select">'
      + '      <div id="ss-top">'
      + '        <div id="ss-preview-panel">'
      + '          <div id="ss-plate">'
      + '            <div id="ss-ship-name"></div>'
      + '            <div id="ss-ship-type"></div>'
      + '            <div id="ss-ship-arms"></div>'
      + '          </div>'
      + '          <canvas id="ss-preview-canvas-actual" width="' + cfg.previewSize.w + '" height="' + cfg.previewSize.h + '"></canvas>'
      + '        </div>'
      + '        <div id="ss-stats-panel">'
      + '          <div id="ss-stats-title">战舰属性</div>'
      + '          <div id="ss-stats-list"></div>'
      + '        </div>'
      + '      </div>'
      + '      <div id="ss-bottom">'
      + '        <div id="ss-ships-row"></div>'
      + '        <button id="ss-start-btn">出击</button>'
      + '      </div>'
      + '    </div>'
      + '    <div id="ss-enhancement" style="display:none;flex:1"></div>'
      + '    <div id="ss-commander" style="display:none;flex:1"></div>'
      // 舰种技能页签容器（内容由 js/ui/class-skills.js 渲染）
      + '    <div id="ss-classskill" style="display:none;flex:1"></div>'
      + '  </div>'
      + '</div>';
    // use the in-DOM canvas (browsers may swap innerHTML's canvas)
    this.canvas = document.getElementById('ss-preview-canvas-actual');
    this.ctx = this.canvas.getContext('2d');

    // 左轨底部版本号（航海图的图号位；版本号单一来源 = js/version.js）
    document.getElementById('ss-rail-foot').textContent =
      (typeof GAME_VERSION !== 'undefined') ? 'v' + GAME_VERSION : '';

    this._renderStats();
    this._renderShipCards();

    document.getElementById('ss-start-btn').addEventListener('click', () => {
      var ship = SHIP_LIBRARY[this.selectedIndex];
      this.hide();
      this.onStart(ship);
    });

    // 设置（齿轮）
    document.getElementById('ss-help-btn').addEventListener('click', () => {
      this._settingsScreen.show();
    });

    this._bindTabs();
  }

  /* ── 弹窗管理 ──────────────────────────────────────────────────── */

  /** 关闭当前弹窗（如果存在），显示新弹窗 */
  _openPopup(popup) {
    if (this._currentPopup) {
      this._currentPopup.remove();
      this._currentPopup = null;
    }
    this._currentPopup = popup;
    this.overlay.appendChild(popup);
  }

  /** 关闭当前弹窗 */
  _closePopup() {
    if (this._currentPopup) {
      this._currentPopup.remove();
      this._currentPopup = null;
    }
  }

  /* ── tab 切换 ──────────────────────────────────────────────────── */

  _bindTabs() {
    var self = this;
    document.querySelectorAll('.ss-tab').forEach(function(tab) {
      tab.addEventListener('click', function() {
        if (this.classList.contains('disabled')) return;
        document.querySelectorAll('.ss-tab').forEach(function(t) { t.classList.remove('active'); });
        this.classList.add('active');
        if (this.dataset.tab === 'ships') { self._showShipSelect(); }
        if (this.dataset.tab === 'enhancement') { self._showEnhancement(); }
        if (this.dataset.tab === 'commander') { self._showCommander(); }
        // 舰种技能（js/ui/class-skills.js 提供 _showClassSkills）
        if (this.dataset.tab === 'classskill') { self._showClassSkills(); }
      });
    });
  }

  _showShipSelect() {
    this.state = 'ship-select';
    this._closePopup();
    document.getElementById('ss-enhancement').style.display = 'none';
    document.getElementById('ss-commander').style.display = 'none';
    document.getElementById('ss-classskill').style.display = 'none';
    document.getElementById('ss-ship-select').style.display = 'flex';
    // 页签高亮跟随当前页（选船页对应「选船」页签）
    document.querySelectorAll('.ss-tab').forEach(function(t) { t.classList.remove('active'); });
    var shipsTab = document.querySelector('.ss-tab[data-tab="ships"]');
    if (shipsTab) shipsTab.classList.add('active');
  }

  /* ── 指挥官界面 ────────────────────────────────────────────────── */

  _showCommander() {
    this.state = 'commander';
    this._closePopup();
    document.getElementById('ss-ship-select').style.display = 'none';
    document.getElementById('ss-enhancement').style.display = 'none';
    document.getElementById('ss-classskill').style.display = 'none';
    var el = document.getElementById('ss-commander');
    el.style.display = 'flex';
    var self = this;
    if (!this._commanderScreen) {
      this._commanderScreen = new CommanderScreen(el, function() { self._showShipSelect(); });
    }
    this._commanderScreen.render();
  }

  /* ── 强化界面 ──────────────────────────────────────────────────── */

  /* ── 原有方法 ─────────────────────────────────────────────────── */

  /**
   * 战舰属性栏：基础属性 / 附加词条 分组显示（2026-11-08）
   *
   * 分类唯一来源 = js/data/stat-groups.js（基础属性百分比乘算、词条百分比加算）。
   * 船自带的词条（如阳炎抵抗配损）与基础属性性质不同，必须分开显示——
   * 单测第 92 节守卫：舰船 stats 里出现未登记的属性名会直接红。
   * ⚠️ 口径只写在文档/代码里，**不进界面**（字人 2026-11-08）：面板只显示组名。
   */
  _renderStats() {
    var ship = SHIP_LIBRARY[this.selectedIndex];
    // 铭牌三段：舰名（宋体大字号）/ 舰种 / 火力配置。舰名与舰种分开是刻意的——
    // 原来拼成「古鹰 · 巡洋舰」一个 22px 字符串，主次不分，像一句话而不是一块铭牌。
    document.getElementById('ss-ship-name').textContent = ship.name;
    document.getElementById('ss-ship-type').textContent = ship.desc || '';
    document.getElementById('ss-ship-arms').textContent = this._armsText(ship);
    var list = document.getElementById('ss-stats-list');

    var base = [], terms = [], info = [];
    for (var key in ship.stats) {
      if (!ship.stats.hasOwnProperty(key)) continue;
      if (isBaseStatLabel(key)) base.push(key);
      else if (isInfoStatLabel(key)) info.push(key);
      else terms.push(key);   // 未登记的新属性默认按词条显示（单测会红，提示去登记）
    }

    // 一次性拼到局部变量再赋值（禁 el.innerHTML +=）
    var h = this._statGroupHtml('基础属性', 'base');
    for (var b = 0; b < base.length; b++) h += this._statRowHtml(base[b], ship.stats[base[b]], 'base');
    if (terms.length) {
      h += this._statGroupHtml('附加词条', 'term');
      for (var t = 0; t < terms.length; t++) h += this._statRowHtml(terms[t], ship.stats[terms[t]], 'term');
    }
    for (var i = 0; i < info.length; i++) h += this._statRowHtml(info[i], ship.stats[info[i]], 'info');
    list.innerHTML = h;
  }

  /** 属性分组标题（只写组名；乘算/加算口径不进界面） */
  _statGroupHtml(label, kind) {
    return '<div class="ss-stat-group ss-stat-group-' + kind + '">' + label + '</div>';
  }

  /** 火力配置行（主炮/副炮/鱼雷/水雷的座数，全部来自船配置） */
  _armsText(ship) {
    var w = (ship.config && ship.config.weapon) || {};
    var parts = [];
    if (w.mainGun) parts.push('主炮 ' + w.mainGun.mountCount);
    if (w.secondary) parts.push('副炮 ' + w.secondary.mountCount);
    if (w.torpedo) parts.push('鱼雷 ' + w.torpedo.mountCount);
    if (w.mine) parts.push('水雷 ' + w.mine.mountCount);
    // 全角空格分隔：比中点（·）像注记，也不会被读成一段元信息串
    return parts.join('　');
  }

  /** 单行属性：键 / 引线 / 值（引线 = 航海表里的点线，替代原来每行一条虚线下边框） */
  _statRowHtml(key, val, kind) {
    return '<div class="ss-stat-row ss-stat-' + kind + '">'
      + '<span class="ss-stat-key">' + key + '</span>'
      + '<span class="ss-stat-leader"></span>'
      + '<span class="ss-stat-val">' + this._statValueHtml(val, kind) + '</span></div>';
  }

  /**
   * 数值排版：数字与单位拆开。
   *   数字 = 等宽仪表读数（能上下对齐、扫一眼比得出量级），单位 = 小号注记。
   *   千位加逗号：65922 → 65,922。只加在整数部分，'19.9' 不会被写坏。
   */
  _statValueHtml(val, kind) {
    var s = String(val);
    if (kind === 'info') return s;                // 说明行（技能名列表）不是数值，原样输出
    var m = s.match(/^([\d.]+)\s*(.*)$/);
    if (!m) return s;
    var num = m[1].replace(/^\d+/, function(d) {
      return d.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    });
    // 单位栏**总是**输出（哪怕是空的）：这样每个数字的右端、每个单位的左端各自成一条竖列。
    // 只有有的行有单位时，数字列会被单位挤得参差不齐（第一版就是这样）。
    var unit = '<span class="ss-stat-unit">' + (m[2] || '') + '</span>';
    return '<span class="ss-stat-num">' + num + '</span>' + unit;
  }

  _renderShipCards() {
    var row = document.getElementById('ss-ships-row');
    row.innerHTML = '';
    SHIP_LIBRARY.forEach(function(ship, idx) {
      var self = this;
      var card = document.createElement('div');
      card.className = 'ss-ship-card' + (idx === this.selectedIndex ? ' selected' : '');
      var cardHtml = '<div class="ss-ship-card-name">' + ship.name + '</div>'
        + '<div class="ss-ship-card-type">' + (ship.desc || '') + '</div>';
      // 古鹰（测试舰）专属「加成」按钮（填入值 = 对基础属性的额外加成），其余战舰没有
      if (ship.id === 'guying') {
        cardHtml += '<button class="ss-card-more-btn" title="调节加成（填入值作为基础属性的额外加成）">加成</button>';
      }
      card.innerHTML = cardHtml;
      card.addEventListener('click', function() {
        self.selectedIndex = idx;
        try { localStorage.setItem('huanjian.selectedShipIndex', idx); } catch (e) {}
        self._renderStats();
        self._renderShipCards();
        self._drawPreview();
      });
      if (ship.id === 'guying') {
        card.querySelector('.ss-card-more-btn').addEventListener('click', function(e) {
          e.stopPropagation();
          var vals = loadGuyingTermOverrides();
          self._popup.open({
            title: '古鹰加成',
            values: vals,
            onCommit: function() { saveGuyingTermOverrides(vals); },
          });
        });
      }
      row.appendChild(card);
    }.bind(this));
  }

  // 舰体预览的绘制在 js/ui/ship-preview.js（2026-11-15 拆出，本文件当时已超 400 行）

  show() { this.overlay.style.display = 'flex'; }
  hide() { this.overlay.style.display = 'none'; }
}
