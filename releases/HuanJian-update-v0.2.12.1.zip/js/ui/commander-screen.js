/**
 * commander-screen.js — 指挥官界面（start-screen「指挥官」tab 内容）
 *
 * 左侧列表：COMMANDER_LIBRARY 全部指挥官（含激活状态标识）
 * 右侧详情：描述 / 被动逐条 / 主动技能 / 启动·取消按钮
 * 持久化：getActiveCommanderId / saveActiveCommander（全局唯一激活）
 */

class CommanderScreen {
  constructor(container, onBack) {
    this.container = container;
    this.onBack = onBack;
    this.selectedId = null;
    this._bindNav();
  }

  /* ── 顶部返回栏 ──────────────────────────────────────────────── */

  _bindNav() {
    var self = this;
    this.container.innerHTML = ''
      + '<div class="enh-top-bar">'
      + '  <button id="cmd-back-btn">← 返回选船</button>'
      + '  <span class="enh-title">指挥官</span>'
      + '</div>'
      + '<div class="cmd-body">'
      + '  <div class="cmd-list" id="cmd-list"></div>'
      + '  <div class="cmd-detail" id="cmd-detail"></div>'
      + '</div>';
    var backBtn = this.container.querySelector('#cmd-back-btn');
    if (backBtn) {
      backBtn.addEventListener('click', function() {
        self.onBack();
      });
    }
  }

  /* ── 渲染 ────────────────────────────────────────────────────── */

  render() {
    var self = this;
    var activeId = getActiveCommanderId();
    var listEl = this.container.querySelector('#cmd-list');
    var detailEl = this.container.querySelector('#cmd-detail');

    // 默认选中：已激活者优先，否则第一个
    if (!this.selectedId || !COMMANDER_LIBRARY.some(function(c) { return c.id === self.selectedId; })) {
      this.selectedId = activeId || (COMMANDER_LIBRARY.length ? COMMANDER_LIBRARY[0].id : null);
    }

    // ── 左侧列表 ──
    var h = '';
    if (!COMMANDER_LIBRARY.length) {
      h = '<div class="cmd-empty">暂无指挥官</div>';
    }
    for (var i = 0; i < COMMANDER_LIBRARY.length; i++) {
      var c = COMMANDER_LIBRARY[i];
      var isActive = c.id === activeId;
      var isSelected = c.id === this.selectedId;
      h += '<div class="cmd-card' + (isSelected ? ' active' : '') + '" data-id="' + c.id + '">'
        + '<div class="cmd-card-name">'
        + '  <span class="cmd-dot" style="background:' + c.color + '"></span>' + c.name
        + '</div>'
        + '<div class="cmd-card-title">' + c.title + '</div>'
        + (isActive ? '<div class="cmd-card-state">已启动</div>' : '')
        + '</div>';
    }
    listEl.innerHTML = h;
    listEl.querySelectorAll('.cmd-card').forEach(function(card) {
      card.addEventListener('click', function() {
        self.selectedId = this.dataset.id;
        self.render();
      });
    });

    // ── 右侧详情 ──
    var sel = null;
    for (var si = 0; si < COMMANDER_LIBRARY.length; si++) {
      if (COMMANDER_LIBRARY[si].id === this.selectedId) sel = COMMANDER_LIBRARY[si];
    }
    if (!sel) {
      detailEl.innerHTML = '<div class="cmd-empty">选择一个指挥官查看详情</div>';
      return;
    }

    var isActive = sel.id === activeId;
    var dh = '<div class="cmd-detail-name">' + sel.name + '</div>'
      + '<div class="cmd-detail-title">' + sel.title + '</div>'
      + '<div class="cmd-detail-desc">' + sel.desc + '</div>';

    dh += '<div class="cmd-passive-group"><div class="cmd-group-title">被动技能</div>';
    for (var pi = 0; pi < sel.passives.length; pi++) {
      var p = sel.passives[pi];
      dh += '<div class="cmd-passive-item">'
        + '<div class="cmd-p-name">' + p.name + '</div>'
        + '<div class="cmd-p-desc">' + p.desc + '</div>'
        + '</div>';
    }
    dh += '</div>';

    dh += '<div class="cmd-active-group"><div class="cmd-group-title">主动技能（键位可在设置中修改）</div>';
    for (var ai = 0; ai < sel.activeSkills.length; ai++) {
      var a = sel.activeSkills[ai];
      var keyLabel = ai === 0 ? bindingLabel(SETTINGS.keys.commanderMain)
        : bindingLabel(SETTINGS.keys.commanderSecondary);
      dh += '<div class="cmd-active-item">'
        + '<div class="cmd-a-name">' + a.name + ' <span style="color:#8A93A8;font-size:10px">[' + keyLabel + ']</span></div>'
        + '<div class="cmd-a-desc">' + a.desc + '</div>'
        + '</div>';
    }
    dh += '</div>';

    // 启动 / 取消按钮（2026-10-01 一键切换）：有别的指挥官已启动时，
    // 直接显示"启动"——点击会自动顶掉旧指挥官（saveActiveCommander 只存单个 id，
    // 天然全局唯一），不必先取消再启动。
    if (isActive) {
      dh += '<button class="cmd-activate-btn cancel" id="cmd-activate-btn">取消启动</button>';
    } else {
      dh += '<button class="cmd-activate-btn" id="cmd-activate-btn">启动</button>';
    }
    detailEl.innerHTML = dh;

    var actBtn = detailEl.querySelector('#cmd-activate-btn');
    if (actBtn && !actBtn.disabled) {
      actBtn.addEventListener('click', function() {
        if (isActive) {
          saveActiveCommander(null);
        } else {
          saveActiveCommander(sel.id);
        }
        self.render();
      });
    }
  }
}
