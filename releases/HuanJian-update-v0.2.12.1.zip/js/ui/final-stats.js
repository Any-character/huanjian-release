/**
 * final-stats.js — 最终战绩窗口（FinalStatsScreen，z-index 500）
 *
 * 战斗结束结算界面「查看最终战绩」打开，展示玩家个人完整战绩：
 *   总览（击杀/总伤害/承受伤害/回复量）→ 伤害详情（6 类 + 比例条）→ 效果次数（9 项）
 * 数据源：BattleStats.playerFinal()（纯数据，show(data) 渲染一次，无定时刷新）。
 */
class FinalStatsScreen {
  /**
   * 助攻数格式化（2026-10-02）——纯函数，便于单测。
   * 老存档 / 旧调用方没带 `assists` 字段时显示 0，
   * 绝不把 undefined / NaN 渲染到界面上。
   * 注：与 BattleStatsScreen.fmtAssists 同一口径（两处刻意保持一致）。
   */
  static fmtAssists(v) {
    var n = Number(v);
    return (isFinite(n) && n >= 0) ? Math.round(n) : 0;
  }

  constructor() {
    this._overlay = null;
    this._build();
  }

  _build() {
    var self = this;
    var overlay = document.createElement('div');
    overlay.id = 'final-stats-overlay';
    overlay.className = 'fs-overlay';
    overlay.style.display = 'none';
    var html = ''
      + '<div class="fs-panel">'
      + '<div class="fs-header">'
      + '<span class="fs-title">最终战绩</span>'
      + '<button id="fs-close-btn" class="fs-close">关闭</button>'
      + '</div>'
      + '<div class="fs-body">'
      + '<div class="fs-meta">'
      +   '<span id="fs-ship-name">—</span>'
      +   '<span id="fs-battle-time">—</span>'
      + '</div>'
      + '<div class="fs-overview">'
      +   '<div class="fs-ov-item"><span class="fs-ov-val" id="fs-ov-kills">0</span><span class="fs-ov-label">击杀</span></div>'
      // 协助击沉（2026-10-02）：恒显示（0 也显示），保持总览 5 格布局不跳
      +   '<div class="fs-ov-item"><span class="fs-ov-val" id="fs-ov-assists">0</span><span class="fs-ov-label">协助击沉</span></div>'
      +   '<div class="fs-ov-item"><span class="fs-ov-val" id="fs-ov-damage">0</span><span class="fs-ov-label">总伤害</span></div>'
      +   '<div class="fs-ov-item"><span class="fs-ov-val" id="fs-ov-taken">0</span><span class="fs-ov-label">承受伤害</span></div>'
      +   '<div class="fs-ov-item fs-ov-heal"><span class="fs-ov-val" id="fs-ov-healed">0</span><span class="fs-ov-label">回复量</span></div>'
      + '</div>'
      + '<div class="fs-section-title">伤害详情</div>'
      + '<div class="fs-list" id="fs-dmg-list"></div>'
      + '<div class="fs-section-title">效果次数</div>'
      + '<div class="fs-list" id="fs-hits-list"></div>'
      + '</div>'
      + '</div>';
    overlay.innerHTML = html;
    document.body.appendChild(overlay);
    this._overlay = overlay;
    document.getElementById('fs-close-btn').addEventListener('click', function() { self.hide(); });
    overlay.addEventListener('click', function(e) { if (e.target === overlay) self.hide(); });
  }

  /** @param {Object} data — BattleStats.playerFinal() 快照 */
  show(data) {
    if (!data || !this._overlay) return;
    document.getElementById('fs-ship-name').textContent = '舰船：' + (data.name || '玩家');
    var dur = Math.max(0, data.durationSec || 0);
    var mm = Math.floor(dur / 60);
    var ss = dur % 60;
    document.getElementById('fs-battle-time').textContent = '战斗时长：' + (mm < 10 ? '0' + mm : mm) + ':' + (ss < 10 ? '0' + ss : ss);
    document.getElementById('fs-ov-kills').textContent = data.kills;
    // 恒显示（0 也显示），不做条件渲染 —— 否则总览格数会跳
    document.getElementById('fs-ov-assists').textContent = FinalStatsScreen.fmtAssists(data.assists);
    document.getElementById('fs-ov-damage').textContent = data.damage;
    document.getElementById('fs-ov-taken').textContent = data.taken;
    document.getElementById('fs-ov-healed').textContent = data.healed;
    document.getElementById('fs-dmg-list').innerHTML = this._buildDmg(data);
    document.getElementById('fs-hits-list').innerHTML = this._buildHits(data);
    this._overlay.style.display = 'flex';
  }

  hide() {
    if (this._overlay) this._overlay.style.display = 'none';
  }

  isOpen() {
    return !!this._overlay && this._overlay.style.display === 'flex';
  }

  /* ── 伤害详情：6 类 + 占比条 ────────────────────────────────────── */
  _buildDmg(data) {
    var rows = [
      ['主炮', data.dmgByType.mainGun],
      ['副炮', data.dmgByType.secondary],
      ['鱼雷', data.dmgByType.torpedo],
      ['水雷', data.dmgByType.mine],
      ['燃烧', data.dmgByType.burn],
      ['漏水', data.dmgByType.flood],
    ];
    var total = data.damage || 0;
    var h = '';
    for (var i = 0; i < rows.length; i++) {
      var pct = total > 0 ? Math.round(rows[i][1] / total * 100) : 0;
      h += '<div class="fs-row">'
        + '<span class="fs-row-label">' + rows[i][0] + '</span>'
        + '<span class="fs-row-bar"><span class="fs-bar-fill" style="width:' + pct + '%"></span></span>'
        + '<span class="fs-row-val">' + rows[i][1] + '</span>'
        + '</div>';
    }
    return h;
  }

  /* ── 效果次数：9 项 ─────────────────────────────────────────────── */
  _buildHits(data) {
    var rows = [
      ['主炮命中', data.hitCounts.mainGun],
      ['鱼雷命中', data.hitCounts.torpedo],
      ['水雷命中', data.hitCounts.mine],
      ['副炮命中', data.hitCounts.secondary],
      ['暴击', data.hitCounts.crit],
      ['穿甲', data.hitCounts.pen],
      ['碎甲', data.hitCounts.shatter],
      ['燃烧', data.hitCounts.burn],
      ['漏水', data.hitCounts.flood],
      ['收割', data.hitCounts.execute],
      ['配损', data.hitCounts.accessoryDamage],
      ['武损', data.hitCounts.weaponDamage],   // 武器损毁次数（2026-09-13）
    ];
    var h = '';
    for (var i = 0; i < rows.length; i++) {
      h += '<div class="fs-row fs-row-hits">'
        + '<span class="fs-row-label">' + rows[i][0] + '</span>'
        + '<span class="fs-row-val">' + rows[i][1] + '</span>'
        + '</div>';
    }
    return h;
  }
}
