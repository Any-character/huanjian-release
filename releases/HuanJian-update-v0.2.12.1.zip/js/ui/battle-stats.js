/**
 * battle-stats.js — 战绩窗口 UI（BattleStatsScreen）
 *
 * 纯展示层：main.js 通过 show(getSnapshot, onClose) 传入数据源回调
 * （返回 {left:[{name,kills,damage,taken}], right:[...]}）。
 * 打开时渲染一次 + 每 300ms 刷新；点击遮罩任意处关闭并回调 onClose。
 * 打开期间遮罩挡住 game canvas → 天然无法点击开火，移动/转向/缩放不受影响。
 */
class BattleStatsScreen {
  constructor() {
    this._overlay = null;
    this._getSnapshot = null;
    this._onClose = null;
    this._timer = null;
    this._build();
  }

  _build() {
    var self = this;
    var overlay = document.createElement('div');
    overlay.className = 'bstats-overlay';
    var panel = document.createElement('div');
    panel.className = 'bstats-panel';
    panel.innerHTML = ''
      + '<div class="bstats-title">战绩</div>'
      + '<div class="bstats-columns">'
      +   '<div class="bstats-side bstats-blue"><table class="bstats-table"><tbody></tbody></table></div>'
      +   '<div class="bstats-side bstats-red"><table class="bstats-table"><tbody></tbody></table></div>'
      + '</div>';
    overlay.appendChild(panel);
    overlay.addEventListener('click', function() { self.hide(); });
    this._leftTbody  = panel.querySelectorAll('tbody')[0];
    this._rightTbody = panel.querySelectorAll('tbody')[1];
    document.body.appendChild(overlay);
    this._overlay = overlay;
  }

  show(getSnapshot, onClose) {
    this._getSnapshot = getSnapshot;
    this._onClose = onClose;
    this._overlay.style.display = 'block';
    this._refresh();
    var self = this;
    this._timer = setInterval(function() { self._refresh(); }, 300);
  }

  hide() {
    if (!this._overlay || this._overlay.style.display === 'none') return;
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
    this._overlay.style.display = 'none';
    if (this._onClose) {
      var cb = this._onClose;
      this._onClose = null;
      cb();
    }
  }

  isOpen() {
    return !!this._overlay && this._overlay.style.display === 'block';
  }

  _refresh() {
    if (!this._getSnapshot) return;
    var data = this._getSnapshot();
    this._leftTbody.innerHTML  = this._buildTable('我方', data.left);
    this._rightTbody.innerHTML = this._buildTable('敌方', data.right);
  }

  /**
   * 助攻数格式化（2026-10-02）——纯函数，便于单测。
   * 敌舰/友军行没有 `assists` 字段（battle-stats 只给玩家计数），显示 0 而非 NaN/undefined。
   * 注：与 FinalStatsScreen.fmtAssists 同一口径（两处刻意保持一致）。
   */
  static fmtAssists(v) {
    var n = Number(v);
    return (isFinite(n) && n >= 0) ? Math.round(n) : 0;
  }

  _buildTable(title, rows) {
    // colspan 必须等于下面表头的列数（「协助」列加入后是 5），改列时两处一起改
    var html = '<tr><th colspan="5">' + title + '</th></tr>'
      + '<tr><th>名称</th><th>击杀</th><th>协助</th><th>伤害</th><th>承伤</th></tr>';
    for (var i = 0; i < rows.length; i++) {
      html += '<tr>'
        + '<td class="bstats-name">' + rows[i].name + '</td>'
        + '<td>' + rows[i].kills + '</td>'
        + '<td>' + BattleStatsScreen.fmtAssists(rows[i].assists) + '</td>'
        + '<td>' + rows[i].damage + '</td>'
        + '<td>' + rows[i].taken + '</td>'
        + '</tr>';
    }
    return html;
  }
}
