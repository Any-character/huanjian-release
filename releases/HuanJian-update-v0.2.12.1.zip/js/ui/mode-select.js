/**
 * mode-select.js — 模式选择覆盖层
 *
 * 在 StartScreen 之上显示三个选项：
 *   快速战斗 → 现有流程
 *   自定义战斗 → CustomBattleScreen
 *   战役模式 → CampaignScreen（2026-08-07）
 *   返回 → 回到选船界面
 */
class ModeSelectScreen {
  constructor(onQuick, onCustom, onBack, onCampaign) {
    this._onQuick = onQuick;
    this._onCustom = onCustom;
    this._onBack = onBack;
    this._onCampaign = onCampaign;
    this._build();
  }

  _build() {
    this._overlay = document.getElementById('mode-select-overlay');
    if (!this._overlay) return;
    var self = this;
    document.getElementById('mode-quick-btn').addEventListener('click', function() { self._onQuick(); });
    document.getElementById('mode-custom-btn').addEventListener('click', function() { self._onCustom(); });
    var campBtn = document.getElementById('mode-campaign-btn');
    if (campBtn) campBtn.addEventListener('click', function() { if (self._onCampaign) self._onCampaign(); });
    document.getElementById('mode-back-btn').addEventListener('click', function() { self.hide(); if (self._onBack) self._onBack(); });
  }

  show() {
    if (this._overlay) this._overlay.style.display = 'flex';
  }

  hide() {
    if (this._overlay) this._overlay.style.display = 'none';
  }
}
