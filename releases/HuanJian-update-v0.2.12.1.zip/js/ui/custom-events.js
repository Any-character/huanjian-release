/**
 * ui/custom-events.js — 自定义战斗卡片事件绑定（CustomBattleScreen.prototype 扩展，2026-08-09 自 custom-battle.js 拆出）
 *
 * _bindShipEvents：敌人/友军卡片的输入/展开/加成/武器/删除事件。
 */

  /* ── 舰船事件绑定（敌人/友军共用，team='enemy'|'ally'）────────────── */
  CustomBattleScreen.prototype._bindShipEvents = function(team) {
    var self = this;
    var listKey = team === 'ally' ? 'allies' : 'enemies';
    var minCount = team === 'ally' ? 0 : 1;  // 敌人至少 1 艘，友军可删到 0
    // 敌/友卡片共用 .cb-enemy-* 类名，必须限定在各自列表容器内查找，
    // 否则两个 team 的绑定会同时作用于全部卡片 → 敌我配置互相覆盖（历史 bug）
    var listEl = document.getElementById(team === 'ally' ? 'cb-ally-list' : 'cb-enemy-list');

    // 名字编辑
    listEl.querySelectorAll('.cb-enemy-name').forEach(function(input) {
      input.addEventListener('input', function() {
        var ei = parseInt(this.dataset.ei);
        self._config[listKey][ei].name = this.value || (team === 'ally' ? ('友军-' + (ei + 1)) : ('敌人-' + (ei + 1)));
      });
    });

    // 舰种选择
    listEl.querySelectorAll('.cb-enemy-type').forEach(function(sel) {
      sel.addEventListener('change', function() {
        var ei = parseInt(this.dataset.ei);
        self._config[listKey][ei].shipType = this.value;
        self._config[listKey][ei].overrides = null;
        self._render();
      });
    });

    // 行为选择
    listEl.querySelectorAll('.cb-enemy-behavior').forEach(function(sel) {
      sel.addEventListener('change', function() {
        var ei = parseInt(this.dataset.ei);
        self._config[listKey][ei].behavior = this.value;
      });
    });

    // 展开/收起
    listEl.querySelectorAll('.cb-enemy-toggle').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var ei = parseInt(this.dataset.ei);
        self._expanded[team] = self._expanded[team] === ei ? -1 : ei;
        self._render();
      });
    });

    // 人机武器更换（2026-08-08：同类统一槽，弹窗选人机武器，舰种隔离）
    listEl.querySelectorAll('.cb-enemy-weapon-swap').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var ei = parseInt(this.dataset.ei);
        self._showEnemyWeaponReplace(team, ei, this.dataset.wt);
      });
    });

    // 删除
    listEl.querySelectorAll('.cb-enemy-delete').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var ei = parseInt(this.dataset.ei);
        if (self._config[listKey].length <= minCount) return;
        self._config[listKey].splice(ei, 1);
        if (self._expanded[team] === ei) self._expanded[team] = -1;
        self._render();
      });
    });

    // 覆写输入
    listEl.querySelectorAll('.cb-override-input').forEach(function(input) {
      input.addEventListener('input', function() {
        var ei = parseInt(this.dataset.ei);
        var key = this.dataset.key;
        var val = parseFloat(this.value);
        if (!self._config[listKey][ei].overrides) {
          self._config[listKey][ei].overrides = {};
        }
        if (isNaN(val) || this.value === '') {
          delete self._config[listKey][ei].overrides[key];
        } else {
          var range = OVERRIDE_RANGES[key];
          var intKeys = ['hp', 'armor', 'mainGunCount', 'torpedoCount', 'secondaryCount', 'mineCount'];
          var finalVal = PCT_KEYS.indexOf(key) !== -1 ? val / 100 : val;
          // 钳制到合法范围 + 精度归一
          if (range) {
            finalVal = Math.max(range.min, Math.min(range.max, finalVal));
            if (intKeys.indexOf(key) !== -1) {
              finalVal = Math.round(finalVal);
            } else if (PCT_KEYS.indexOf(key) === -1) {
              finalVal = Math.round(finalVal * 10) / 10;
            }
          }
          self._config[listKey][ei].overrides[key] = finalVal;
        }
        // 武器数量变更 → 局部刷新武器槽（不整体重渲染，保留输入焦点；2026-08-08 修：改 0→6 副炮不出现更换选项）
        if (key === 'mainGunCount' || key === 'torpedoCount' || key === 'secondaryCount' || key === 'mineCount') {
          var slotEl = document.querySelector('.cb-enemy-weapons[data-wslot="' + team + '-' + ei + '"]');
          if (slotEl) {
            var ecfg2 = self._config[listKey][ei];
            slotEl.innerHTML = self._weaponSlotsHtml(ecfg2, ei, team);
            slotEl.querySelectorAll('.cb-enemy-weapon-swap').forEach(function(btn2) {
              btn2.addEventListener('click', function() {
                var ei2 = parseInt(this.dataset.ei);
                self._showEnemyWeaponReplace(team, ei2, this.dataset.wt);
              });
            });
          }
        }
      });
    });

    // 重置默认
    listEl.querySelectorAll('.cb-override-reset').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var ei = parseInt(this.dataset.ei);
        self._config[listKey][ei].overrides = null;
        self._render();
      });
    });

    // 自定义加成（弹窗编辑，敌/友军共用；termOverrides 叠加式 = 基础 + 加成，与古鹰一致）
    listEl.querySelectorAll('.cb-override-more').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var ei = parseInt(this.dataset.ei);
        var ecfg = self._config[listKey][ei];
        if (!ecfg.termOverrides) ecfg.termOverrides = {};
        // 炮弹规避按舰种默认（2026-08-06）：驱逐 10% 小口径 / 巡洋 20% 小+10% 中 / 战列 25% 小+15% 中+10% 大
        var typeD = SHIP_TYPE_DEFAULTS[ecfg.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
        self._popup.open({
          title: (ecfg.name || (team === 'ally' ? '友军' : '敌人')) + ' 加成',
          values: ecfg.termOverrides,
          defaults: {
            smallCaliberEvasion: typeD.smallCaliberEvasion,
            mediumCaliberEvasion: typeD.mediumCaliberEvasion,
            largeCaliberEvasion: typeD.largeCaliberEvasion,
          },
        });
      });
    });

    // 添加舰船（敌人/友军各一个按钮）
    var addBtnId = team === 'ally' ? 'cb-add-ally-btn' : 'cb-add-enemy-btn';
    var addBtn = document.getElementById(addBtnId);
    if (addBtn) {
      addBtn.addEventListener('click', function() {
        var max = team === 'ally' ? MAX_CUSTOM_ALLIES : MAX_CUSTOM_ENEMIES;
        if (self._config[listKey].length >= max) return;
        var idx = self._config[listKey].length;
        self._config[listKey].push({
          id: (team === 'ally' ? 'ally-' : 'enemy-') + (idx + 1),
          name: team === 'ally' ? ('友军-' + (idx + 1)) : ('敌人-' + (idx + 1)),
          shipType: 'cruiser',
          behavior: 'zigzag',   // 默认迂回接近（2026-08-06）
          overrides: null,
          termOverrides: null,
        });
        self._render();
      });
    }
  };
