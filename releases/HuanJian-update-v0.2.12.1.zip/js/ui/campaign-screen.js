/**
 * campaign-screen.js — 战役模式选择覆盖层（2026-08-07）
 *
 * 流程：模式选择页「战役模式」→ 本页展示 CAMPAIGN_LIBRARY 列表 →
 *      点「开始战役」→ main.js startCampaign(campaign.id)
 */
class CampaignScreen {
  /**
   * @param {function(string)} onStart — 回调 (campaignId)
   * @param {function} [onBack] — 返回模式选择
   */
  constructor(onStart, onBack) {
    this._onStart = onStart;
    this._onBack = onBack;
    this._build();
  }

  _build() {
    this._overlay = document.getElementById('campaign-select-overlay');
    if (!this._overlay) return;
    var self = this;

    // 渲染战役列表（CAMPAIGN_LIBRARY 纯数据）
    var list = document.getElementById('campaign-list');
    var html = '';
    for (var i = 0; i < CAMPAIGN_LIBRARY.length; i++) {
      var camp = CAMPAIGN_LIBRARY[i];
      html += '<div class="campaign-card" data-id="' + camp.id + '">'
        + '<div class="campaign-card-name">' + camp.name + '</div>'
        + '<div class="campaign-card-desc">' + camp.desc + '</div>'
        + '<button class="campaign-start-btn">开始战役</button>'
        + '</div>';
    }
    list.innerHTML = html || '<div class="campaign-empty">暂无战役</div>';

    // 开始按钮
    var cards = list.querySelectorAll('.campaign-card');
    for (var c = 0; c < cards.length; c++) {
      (function (card) {
        var btn = card.querySelector('.campaign-start-btn');
        if (btn) btn.addEventListener('click', function () {
          if (self._onStart) self._onStart(card.getAttribute('data-id'));
        });
      })(cards[c]);
    }

    document.getElementById('campaign-back-btn').addEventListener('click', function () {
      self.hide();
      if (self._onBack) self._onBack();
    });
  }

  show() {
    if (this._overlay) this._overlay.style.display = 'flex';
  }

  hide() {
    if (this._overlay) this._overlay.style.display = 'none';
  }
}
