/**
 * term-library.js — 词条库全屏页面（设置页内「词条库」按钮打开）
 *
 * 数据源：js/data/terms.js 的 TERM_LIBRARY / TERM_CATEGORIES（用户可编辑）。
 * 层级：z-index 401，盖在设置页（400）上方；返回按钮只 hide 自己，
 *       设置页仍显示（不依赖 hide() 自动 show() 的隐式行为）。
 */
class TermLibraryScreen {
  /**
   * @param {HTMLElement} container — 挂载节点（document.body）
   */
  constructor(container) {
    this._container = container;
    this._overlay = null;
    this._build();
  }

  _build() {
    var overlay = document.createElement('div');
    overlay.className = 'terms-overlay';
    overlay.style.display = 'none';
    this._container.appendChild(overlay);
    this._overlay = overlay;
    this._render();
  }

  show() { this._overlay.style.display = 'block'; }

  hide() { this._overlay.style.display = 'none'; }

  _render() {
    var lib = (typeof TERM_LIBRARY !== 'undefined') ? TERM_LIBRARY : [];
    var cats = (typeof TERM_CATEGORIES !== 'undefined') ? TERM_CATEGORIES : {};
    var h = ''
      + '<div class="terms-page">'
      + '  <div class="terms-header">'
      + '    <div class="terms-title">词条库'
      + '      <span class="terms-sub">同一行的两个词条互为逆属性或对冲属性</span></div>'
      + '    <button class="terms-back-btn">返回设置</button>'
      + '  </div>';
    if (!lib.length) {
      h += '<div class="terms-empty">词条库为空（未加载到词条数据）。</div>';
    } else {
      var cardHtml = function(t) {
        return '  <div class="terms-card">'
          + '    <div class="terms-card-name">' + t.name + '</div>'
          + '    <div class="terms-card-desc">' + t.desc + '</div>'
          + '  </div>';
      };
      var att = lib.filter(function(t) { return t.category === 'attack'; });
      var def = lib.filter(function(t) { return t.category === 'defense'; });
      var oth = lib.filter(function(t) { return t.category === 'other'; });
      var defMap = {};
      def.forEach(function(t) { defMap[t.id] = t; });
      var unpairedDef = def.filter(function(t) { return !t.pairWith; });

      // 两列对举：进攻列（左）按顺序逐行 + 防御列（右）逆/对冲配对归位；未配对防御追加尾部（左列空）
      // 列头直接落在各自列上方（2026-11-15）：比一行「A | B — 说明」更容易看出哪列是哪类
      h += '<div class="terms-pair-grid terms-legend">'
        + '<div>' + (cats.attack || '进攻类') + '（' + att.length + '）</div>'
        + '<div>' + (cats.defense || '防御类') + '（' + def.length + '）</div>'
        + '</div>';
      h += '<div class="terms-pair-grid">';
      for (var i = 0; i < att.length; i++) {
        h += cardHtml(att[i]);
        var pd = att[i].pairWith ? defMap[att[i].pairWith] : null;
        h += pd ? cardHtml(pd) : '<div class="terms-card terms-card-empty">&nbsp;</div>';
      }
      for (var j = 0; j < unpairedDef.length; j++) {
        h += '<div class="terms-card terms-card-empty">&nbsp;</div>';
        h += cardHtml(unpairedDef[j]);
      }
      h += '</div>';

      // 其它类整宽
      h += '<div class="terms-group">'
        + '  <div class="terms-group-title">' + (cats.other || '其它类') + '（' + oth.length + '）</div>';
      for (var oi = 0; oi < oth.length; oi++) {
        h += cardHtml(oth[oi]);
      }
      h += '</div>';
    }
    h += '</div>';
    this._overlay.innerHTML = h;
    var self = this;
    var backBtn = this._overlay.querySelector('.terms-back-btn');
    if (backBtn) {
      backBtn.addEventListener('click', function() { self.hide(); });
    }
  }
}
