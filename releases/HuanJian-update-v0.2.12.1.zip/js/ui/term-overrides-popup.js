/**
 * term-overrides-popup.js — 「更多词条」调节弹窗
 *
 * 两处共用：自定义战斗敌/友军卡片 + 选船界面古鹰卡片。
 * 交互：每行 = 词条名 + 数值输入框（无说明小字、无行内重置），顶部「全部重置」。
 * 约定：isPct 词条 UI 显示整数百分比（存储小数，0.15 = 15%）；空输入 = 删除该覆盖（默认 0）。
 */
class TermOverridesPopup {
  constructor() {
    // 单例：StartScreen 与 CustomBattleScreen 各 new 一次，必须共用同一实例/DOM，
    // 否则出现重复 id（#term-overrides-overlay 等），getElementById 会拿到不可见的那个（历史 bug 2026-08-05）
    if (TermOverridesPopup._instance) return TermOverridesPopup._instance;
    TermOverridesPopup._instance = this;
    this._values = null;
    this._onCommit = null;
    this._defaults = null;    // 词条默认加成值（仅炮弹规避按舰种默认，如战列 25% 小口径；其它词条默认 0）
    this._build();
  }

  _build() {
    var overlay = document.createElement('div');
    overlay.id = 'term-overrides-overlay';
    overlay.className = 'to-overlay';
    overlay.style.display = 'none';
    var html = ''
      + '<div class="to-popup">'
      + '<div class="to-header">'
      + '<span class="to-title" id="to-title">词条</span>'
      + '<button id="to-reset-btn" class="to-btn">全部重置</button>'
      + '<button id="to-close-btn" class="to-btn">关闭</button>'
      + '</div>'
      + '<div class="to-list" id="to-list"></div>'
      + '</div>';
    overlay.innerHTML = html;
    document.body.appendChild(overlay);
    this._overlay = overlay;
    this._titleEl = document.getElementById('to-title');
    this._listEl = document.getElementById('to-list');

    var self = this;
    document.getElementById('to-reset-btn').addEventListener('click', function() { self._resetAll(); });
    document.getElementById('to-close-btn').addEventListener('click', function() { self.hide(); });
  }

  /**
   * @param {Object} opts — { title, values, onCommit, defaults }
   *   values  — 目标对象引用（popup 直接读写 values[key]，空输入时 delete）
   *   onCommit— 关闭时回调（古鹰 → 持久化；自定义战斗 → 无操作）
   *   defaults— 词条默认加成值（仅炮弹规避按舰种：驱逐 10% 小口径 / 巡洋 20% 小+10% 中 / 战列 25% 小+15% 中+10% 大；古鹰特殊默认 0 不传）。
   *             语义：词条是「额外加成」（最终 = 基础属性 + 加成），默认值仅作展示基准，未修改不写入存储
   */
  open(opts) {
    this._values = (opts && opts.values) || {};
    this._onCommit = (opts && opts.onCommit) || null;
    this._defaults = (opts && opts.defaults) || null;
    if (this._titleEl) this._titleEl.textContent = (opts && opts.title) || '词条';
    this._renderList();
    this._overlay.style.display = 'flex';
  }

  hide() {
    this._overlay.style.display = 'none';
    if (this._onCommit) {
      var cb = this._onCommit;
      this._onCommit = null;
      cb();
    }
  }

  /* ── 渲染词条列表 ──────────────────────────────────────────────────── */
  _renderList() {
    var self = this;
    var h = '';
    for (var i = 0; i < TERM_OVERRIDES.length; i++) {
      var to = TERM_OVERRIDES[i];
      var raw = this._values[to.id];
      // 默认值：仅炮弹规避按舰种默认（2026-08-06）；其它词条默认 0。未修改不写入存储（raw==null 仅展示）
      var dflt = this._defaults && this._defaults[to.id] != null ? this._defaults[to.id] : 0;
      var display = (raw == null) ? (to.isPct ? Math.round(dflt * 100) : dflt)
        : (to.isPct ? Math.round(raw * 100) : raw);
      h += '<div class="to-item">'
        + '<span class="to-name">' + to.name + '</span>'
        + '<input type="number" class="to-input" data-key="' + to.id + '"'
        + ' value="' + display + '"'
        + ' min="' + (to.isPct ? to.min * 100 : to.min) + '"'
        + ' max="' + (to.isPct ? to.max * 100 : to.max) + '"'
        + ' step="' + (to.isPct ? to.step * 100 : to.step) + '">'
        + '</div>';
    }
    this._listEl.innerHTML = h;

    this._listEl.querySelectorAll('.to-input').forEach(function(input) {
      input.addEventListener('input', function() {
        self._onInput(this);
      });
    });
  }

  /* ── 输入处理：钳制 + 精度归一 + 写回 values ────────────────────────── */
  _onInput(input) {
    var key = input.dataset.key;
    var to = null;
    for (var i = 0; i < TERM_OVERRIDES.length; i++) {
      if (TERM_OVERRIDES[i].id === key) { to = TERM_OVERRIDES[i]; break; }
    }
    if (!to) return;
    var text = input.value;
    if (text === '') { delete this._values[key]; return; }
    var num = parseFloat(text);
    if (isNaN(num)) { delete this._values[key]; return; }
    var val = to.isPct ? num / 100 : num;
    val = Math.max(to.min, Math.min(to.max, val));
    if (to.isPct) {
      val = Math.round(val * 100) / 100;
    } else if (to.step >= 1) {
      val = Math.round(val);
    } else {
      val = Math.round(val * 10) / 10;
    }
    this._values[key] = val;
  }

  /* ── 全部重置：清空所有词条覆盖（回默认 0） ────────────────────────── */
  _resetAll() {
    for (var i = 0; i < TERM_OVERRIDES.length; i++) {
      delete this._values[TERM_OVERRIDES[i].id];
    }
    this._renderList();
  }
}
