/**
 * ui/custom-card.js — 自定义战斗单舰卡片渲染（CustomBattleScreen.prototype 扩展，2026-08-09 自 custom-battle.js 拆出）
 *
 * _renderShipCard：敌人/友军卡片（舰种/行为/自定义加成/武器槽/删除）。
 */

  /* ── 单个舰船卡片（敌人/友军共用，team='enemy'|'ally'）────────────── */
  CustomBattleScreen.prototype._renderShipCard = function(index, ecfg, team) {
    var label = SHIP_TYPE_LABELS[ecfg.shipType] || '巡洋舰';
    var behLabel = BEHAVIOR_LABELS[ecfg.behavior] || '全速追踪';
    var expanded = index === this._expanded[team];
    var cardClass = team === 'ally' ? 'cb-ally-card' : 'cb-enemy-card';
    var h = '';
    h += '<div class="' + cardClass + '" data-ei="' + index + '">';
    h += '<div class="cb-enemy-card-header">';
    h += '<input class="cb-enemy-name" value="' + ecfg.name + '" data-ei="' + index + '" maxlength="10">';
    h += '<select class="cb-enemy-type" data-ei="' + index + '">';
    for (var ti = 0; ti < SHIP_TYPES.length; ti++) {
      var t = SHIP_TYPES[ti];
      h += '<option value="' + t + '"' + (ecfg.shipType === t ? ' selected' : '') + '>' + SHIP_TYPE_LABELS[t] + '</option>';
    }
    h += '</select>';
    h += '<select class="cb-enemy-behavior" data-ei="' + index + '">';
    var behaviors = ['chase', 'zigzag', 'random', 'kite', 'idle'];
    for (var bi = 0; bi < behaviors.length; bi++) {
      var b = behaviors[bi];
      h += '<option value="' + b + '"' + (ecfg.behavior === b ? ' selected' : '') + '>' + BEHAVIOR_LABELS[b] + '</option>';
    }
    h += '</select>';
    h += '<button class="cb-enemy-toggle" data-ei="' + index + '">' + (expanded ? '收起' : '展开') + '</button>';
    h += '<button class="cb-enemy-delete" data-ei="' + index + '">×</button>';
    h += '</div>';

    if (expanded) {
      // ── 人机武器槽（2026-08-08 同类统一槽：如 4 主炮只显示一个主炮槽，换武器全主炮生效）──
      h += '<div class="cb-enemy-weapons" data-wslot="' + team + '-' + index + '">'
        + this._weaponSlotsHtml(ecfg, index, team)
        + '</div>';
      h += '<div class="cb-enemy-overrides">';
      var keys = Object.keys(OVERRIDE_RANGES);
      for (var ki = 0; ki < keys.length; ki++) {
        var k = keys[ki];
        var range = OVERRIDE_RANGES[k];
        var val = ecfg.overrides && ecfg.overrides[k] != null ? ecfg.overrides[k] : '';
        var defaults = SHIP_TYPE_DEFAULTS[ecfg.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
        var dVal = defaults[k] !== undefined ? defaults[k] : '';
        var isPct = PCT_KEYS.indexOf(k) !== -1;
        // display default with % sign
        var displayDVal = isPct ? (dVal * 100).toFixed(0) + '%' : dVal;
        // input value / placeholder use percentage integers (5 → 5%)
        var inputVal = isPct && val !== '' ? val * 100 : val;
        var placeholderVal = isPct && dVal !== '' ? dVal * 100 : dVal;
        h += '<div class="cb-override-item">'
          + '<span class="cb-override-label">' + (OVERRIDE_LABELS[k] || k) + ' (默认' + displayDVal + ')</span>'
          + '<input class="cb-override-input" data-key="' + k + '" data-ei="' + index + '" type="number"'
          + ' value="' + inputVal + '" placeholder="' + placeholderVal + '"'
          + ' min="' + (isPct ? range.min * 100 : range.min) + '" max="' + (isPct ? range.max * 100 : range.max) + '" step="' + (isPct ? range.step * 100 : range.step) + '">'
          + '</div>';
      }
      h += '<button class="cb-override-reset" data-ei="' + index + '">重置默认</button>';
      h += '<button class="cb-override-more" data-ei="' + index + '">自定义加成</button>';
      h += '</div>';
    }
    h += '</div>';
    return h;
  };
