/**
 * settings-screen.js — 设置面板（选船界面齿轮打开）
 *
 * 分区：特效开关（5）/ 战斗（副炮自动开火）/ 缩放（5 档）/ 键位（10 动作）
 * 改键：录制式——点击改键 → 捕获 keydown/mousedown/wheel → 冲突检测 → 落盘
 */
class SettingsScreen {
  constructor() {
    this._overlay = null;
    this._activeCleanup = null;   // 当前改键捕获的清理函数（关闭面板时强制结束）
    this._build();
  }

  _build() {
    var overlay = document.createElement('div');
    overlay.className = 'settings-overlay';
    overlay.style.display = 'none';
    document.body.appendChild(overlay);
    this._overlay = overlay;
    this._termLib = new TermLibraryScreen(document.body);
    this._formulaLib = new FormulaLibraryScreen(document.body);
    this._render();
  }

  show() { this._overlay.style.display = 'flex'; this._render(); }
  hide() {
    if (this._activeCleanup) {        // 改键未完成就关闭 → 必须移除捕获监听器
      this._activeCleanup();
      this._activeCleanup = null;
      this._render();                 // 恢复按钮显示
    }
    this._overlay.style.display = 'none';
  }

  _render() {
    var el = this._overlay;
    el.innerHTML = ''
      + '<div class="settings-page">'
      + '  <div class="settings-page-header">'
      + '    <div class="settings-title">设置</div>'
      + '    <button class="settings-back-btn">返回</button>'
      + '  </div>'
      + '  <div class="settings-page-body">'
      + this._sectionFx()
      + this._sectionCombat()
      + this._sectionLibrary()
      + this._sectionVersion()
      + this._sectionZoom()
      + this._sectionKeys()
      + '  </div>'
      + '  <div class="settings-buttons">'
      + '    <button class="settings-reset-btn">恢复默认</button>'
      + '  </div>'
      + '</div>';
    this._bindEvents();
  }

  _sectionFx() {
    var rows = [
      ['shake', '受击屏幕摇晃'],
      ['flash', '受击边缘泛红'],
      ['damagePopups', '伤害飘字'],
      ['hitStats', '命中统计'],
      ['wakeParticles', '尾迹粒子'],
      ['killToast', '击杀飘字'],   // 2026-08-06
    ];
    var h = '<div class="settings-group"><div class="settings-group-title">特效</div>';
    for (var i = 0; i < rows.length; i++) {
      h += '<div class="settings-row"><span>' + rows[i][1] + '</span>'
        + '<input type="checkbox" class="settings-fx-toggle" data-fx="' + rows[i][0] + '"'
        + (SETTINGS.fx[rows[i][0]] ? ' checked' : '') + '></div>';
    }
    return h + '</div>';
  }

  _sectionCombat() {
    return '<div class="settings-group"><div class="settings-group-title">战斗</div>'
      + '<div class="settings-row"><span>副炮自动开火</span>'
      + '<input type="checkbox" class="settings-secondary-toggle"' + (SETTINGS.secondaryAuto ? ' checked' : '') + '></div>'
      + '<div class="settings-row"><span>取消伤害浮动</span>'
      + '<input type="checkbox" class="settings-variance-toggle"' + (SETTINGS.noDamageVariance ? ' checked' : '') + '></div>'
      + '<div class="settings-row"><span>辅助瞄准（锁定发现敌舰）</span>'
      + '<input type="checkbox" class="settings-aimassist-toggle"' + (SETTINGS.aimAssist ? ' checked' : '') + '></div>'
      + '<div class="settings-row"><span>相机移动灵敏度</span>'
      + '<input type="range" class="settings-cam-sens" min="0.5" max="5" step="0.5" value="' + (SETTINGS.cameraSensitivity || 1) + '">'
      + '<span class="settings-cam-sens-val">' + (SETTINGS.cameraSensitivity || 1) + '×</span></div>'
      + '<div class="settings-row"><span>相机始终跟随准星与我舰连线中点</span>'
      + '<input type="checkbox" class="settings-cam-follow-toggle" title="开启后按方向键可临时接管，按 L 或空格恢复跟随"'
      + (SETTINGS.cameraMidFollow ? ' checked' : '') + '></div>'
      + '<div class="settings-row"><span>相机跟随平滑度</span>'
      + '<input type="range" class="settings-cam-smooth" min="0.05" max="1" step="0.05" value="' + (SETTINGS.cameraFollowSmooth != null ? SETTINGS.cameraFollowSmooth : 0.25) + '">'
      + '<span class="settings-cam-smooth-val">' + Math.round((SETTINGS.cameraFollowSmooth != null ? SETTINGS.cameraFollowSmooth : 0.25) * 100) + '%</span></div>'
      + '</div>';
  }

  _sectionLibrary() {
    return '<div class="settings-group"><div class="settings-group-title">资料</div>'
      + '<div class="settings-row"><span>游戏词条说明</span>'
      + '<button class="settings-library-btn">词条库</button></div>'
      + '<div class="settings-row"><span>伤害公式说明</span>'
      + '<button class="settings-library-btn">公式库</button></div>'
      + '</div>';
  }

  _sectionVersion() {
    // 版本 / 检查更新（2026-09-26 Updater；sources 见 js/systems/updater.js）
    // 「检查」= 有没有新版（有则弹 update.bat 引导）；「公告」= 无条件展示线上
    // 最新版的更新公告全文（已是最新版也看得到）。两者语义不同，故分两个按钮。
    var cur = (typeof Updater !== 'undefined' && Updater.current) ? Updater.current() : '?';
    return '<div class="settings-group"><div class="settings-group-title">版本</div>'
      + '<div class="settings-row"><span>当前版本</span>'
      + '<span class="settings-version-val">v' + cur + '</span></div>'
      + '<div class="settings-row"><span>检查更新（含更新公告）</span>'
      + '<span class="settings-update-btns">'
      + '<button class="settings-update-btn">检查</button>'
      + '<button class="settings-notes-btn">公告</button></span></div>'
      + '</div>';
  }

  _sectionZoom() {
    var h = '<div class="settings-group"><div class="settings-group-title">初始缩放</div><div class="settings-zoom-row">';
    for (var i = 0; i < ZOOM_LEVELS.length; i++) {
      var zoomPct = Math.round(ZOOM_LEVELS[i] * 100) + '%';
      h += '<button class="settings-zoom-btn' + (i === SETTINGS.zoomIndex ? ' active' : '') + '" data-zoom="' + i + '">'
        + zoomPct + '</button>';
    }
    return h + '</div></div>';
  }

  _sectionKeys() {
    var h = '<div class="settings-group"><div class="settings-group-title">键位</div>';
    for (var ak in SETTINGS.keys) {
      h += '<div class="settings-row"><span>' + (ACTION_LABELS[ak] || ak) + '</span>'
        + '<button class="settings-key-btn" data-action="' + ak + '">'
        + bindingLabel(SETTINGS.keys[ak]) + '</button></div>';
    }
    return h + '</div>';
  }

  _bindEvents() {
    var self = this;
    this._overlay.querySelectorAll('.settings-fx-toggle').forEach(function(cb) {
      cb.addEventListener('change', function() {
        SETTINGS.fx[this.dataset.fx] = this.checked;
        saveSettings();
      });
    });
    this._overlay.querySelector('.settings-secondary-toggle').addEventListener('change', function() {
      SETTINGS.secondaryAuto = this.checked;
      saveSettings();
    });
    this._overlay.querySelector('.settings-variance-toggle').addEventListener('change', function() {
      SETTINGS.noDamageVariance = this.checked;
      saveSettings();
    });
    // 辅助瞄准开关（2026-08-08）
    var aaToggle = this._overlay.querySelector('.settings-aimassist-toggle');
    if (aaToggle) {
      aaToggle.addEventListener('change', function() {
        SETTINGS.aimAssist = this.checked;
        saveSettings();
      });
    }
    // 相机始终跟随准星与我舰连线中点（2026-10-01）
    // ⚠ 顺序红线：smoothInput/smoothVal 必须在 camFollowToggle 回调绑定**之前**声明，
    // 否则回调闭包捕获到的是 undefined（var 只提升声明不提升赋值）。
    var smoothInput = this._overlay.querySelector('.settings-cam-smooth');
    var smoothVal = this._overlay.querySelector('.settings-cam-smooth-val');
    var camFollowToggle = this._overlay.querySelector('.settings-cam-follow-toggle');
    if (camFollowToggle) {
      camFollowToggle.addEventListener('change', function() {
        SETTINGS.cameraMidFollow = this.checked;
        // 跟随关闭 → 平滑度滑杆灰掉（跟随模式下才有意义）
        if (smoothInput) smoothInput.disabled = !this.checked;
        saveSettings();
      });
    }
    var sensInput = this._overlay.querySelector('.settings-cam-sens');
    if (sensInput) {
      var sensVal = this._overlay.querySelector('.settings-cam-sens-val');
      sensInput.addEventListener('input', function() {
        SETTINGS.cameraSensitivity = parseFloat(this.value);
        if (sensVal) sensVal.textContent = this.value + '×';
        saveSettings();
      });
    }
    // 相机跟随平滑度滑杆（2026-10-01 抗抖动）
    if (smoothInput) {
      smoothInput.addEventListener('input', function() {
        SETTINGS.cameraFollowSmooth = parseFloat(this.value);
        if (smoothVal) smoothVal.textContent = Math.round(parseFloat(this.value) * 100) + '%';
        saveSettings();
      });
      // 初始同步：跟随未开启时灰掉滑杆（跟随模式下才有意义）
      smoothInput.disabled = !SETTINGS.cameraMidFollow;
    }
    this._overlay.querySelectorAll('.settings-zoom-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        SETTINGS.zoomIndex = parseInt(this.dataset.zoom, 10);
        saveSettings();
        self._render();
      });
    });
    this._overlay.querySelectorAll('.settings-key-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        self._startCapture(this);
      });
    });
    this._overlay.querySelector('.settings-reset-btn').addEventListener('click', function() {
      resetSettings();
      self._render();
    });
    this._overlay.querySelector('.settings-back-btn').addEventListener('click', function() {
      self.hide();
    });
    // 检查更新（2026-09-26 Updater）
    // ⚠ 手动检查必须打标 Updater.markManualCheck()：本会话用户已看过公告后，
    //   启动自动检查不该再弹一次同样的窗（去重见 Updater._manualChecked）。
    var updBtn = this._overlay.querySelector('.settings-update-btn');
    if (updBtn) {
      updBtn.addEventListener('click', function() {
        updBtn.disabled = true;
        updBtn.textContent = '检查中…';
        if (Updater.markManualCheck) Updater.markManualCheck();
        Updater.check(function(res) {
          updBtn.disabled = false;
          updBtn.textContent = '检查';
          Updater.showResult(res);
        });
      });
    }
    // 查看更新公告（2026-10-02）：只看公告正文，无论线上是否比本地新
    // ⚠ 此处**不**调 markManualCheck()：用户看的是公告，还没看到「发现新版本 +
    //   update.bat 引导」，自动检查该弹仍要弹。（只有「检查」按钮算手动检查）
    var notesBtn = this._overlay.querySelector('.settings-notes-btn');
    if (notesBtn) {
      notesBtn.addEventListener('click', function() {
        notesBtn.disabled = true;
        notesBtn.textContent = '读取中…';
        Updater.check(function(res) {
          notesBtn.disabled = false;
          notesBtn.textContent = '公告';
          Updater.showResult(res, { mode: 'notes' });
        });
      });
    }
    var libBtn = this._overlay.querySelector('.settings-library-btn');
    if (libBtn) {
      libBtn.addEventListener('click', function() {
        self._termLib.show();
      });
    }
    var formulaBtn = this._overlay.querySelectorAll('.settings-library-btn');
    // 第二个资料按钮（公式库）——与词条库共用 .settings-library-btn 样式
    if (formulaBtn.length >= 2) {
      formulaBtn[1].addEventListener('click', function() {
        self._formulaLib.show();
      });
    }
  }

  _startCapture(btn) {
    var self = this;
    var action = btn.dataset.action;
    btn.textContent = '按任意键…';
    btn.classList.add('capturing');

    function finish(value) {
      if (value && value !== SETTINGS.keys[action]) {
        var conflict = findBindingConflict(SETTINGS.keys, action, value);
        if (conflict) {
          btn.textContent = '冲突: ' + ACTION_LABELS[conflict];
          btn.classList.remove('capturing');
          setTimeout(function() { btn.textContent = bindingLabel(SETTINGS.keys[action]); }, 1200);
          cleanup();
          return;
        }
        SETTINGS.keys[action] = value;
        saveSettings();
      }
      btn.textContent = bindingLabel(SETTINGS.keys[action]);
      btn.classList.remove('capturing');
      cleanup();
    }

    function cleanup() {
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener('mousedown', onMouse, true);
      window.removeEventListener('wheel', onWheel, true);
      window.removeEventListener('contextmenu', onCtx, true);
      self._activeCleanup = null;
    }

    function onKey(e) {
      e.preventDefault();
      e.stopPropagation();
      if (e.code === 'Escape') {
        btn.textContent = bindingLabel(SETTINGS.keys[action]);
        btn.classList.remove('capturing');
        cleanup();
        return;
      }
      finish('key:' + e.code);
    }    function onMouse(e) {
      e.preventDefault();
      e.stopPropagation();
      if (e.button === 0) finish('mouse:0');
      if (e.button === 1) finish('mouse:1');
      if (e.button === 2) finish('mouse:2');
    }
    function onWheel(e) {
      e.preventDefault();
      e.stopPropagation();
      finish('wheel');
    }
    function onCtx(e) { e.preventDefault(); }

    self._activeCleanup = cleanup;
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('mousedown', onMouse, true);
    window.addEventListener('wheel', onWheel, true);
    window.addEventListener('contextmenu', onCtx, true);
  }
}

