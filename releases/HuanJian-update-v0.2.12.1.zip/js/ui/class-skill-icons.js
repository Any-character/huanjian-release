/**
 * class-skill-icons.js — 舰种主动技能的 HUD 图标（2026-11-15，UIManager.prototype 扩展）
 *
 * 为什么单独一个文件：ui.js 本来就超 400 行（AGENTS §7.3），加机制不该继续往里塞；
 *   与 skill-glyphs.js 分工一致——那边负责「图形长什么样」，这边负责「舰种主动技能这一栏怎么画」。
 *
 * 契约：
 *   · 数据源唯一 `ClassSkills.getActiveStates(player, now)` —— 任何舰种/任何系的主动技能
 *     都会自动出现，**不得按技能名/技能 id 分支**（写死一个名字 = 新技能要改 UI）。
 *   · 图标追加到**同一个技能栏容器**（`elCommanderSkills`），与指挥官技能、战舰主动技能并排。
 *   · 复用既有样式类（`.cooldown-icon` / `.commander-icon` / `.cs-wrap` / `.cooldown-fill` /
 *     `.cooldown-text` / `.cs-name` / `.cs-key`），只多一个 `.class-skill-icon` 供每帧清理识别，
 *     不新造外观。
 *   · 冷却倒计时口径同战舰技能：`remaining` 是秒，冷却中显示一位小数。
 *   · ⚠️ 加载期就给 UIManager.prototype 挂方法，故整块包在 typeof 守卫里：
 *       Node 单测没有 UIManager → 跳过，不崩（同 skill-glyphs.js）。
 */

if (typeof UIManager !== 'undefined') {
  /**
   * 画舰种主动技能图标（每帧调；由 `_updateShipActiveSkills` 末尾统一调一次）。
   * @param {number} now
   * @param {Ship} player
   */
  UIManager.prototype._updateClassActiveSkills = function (now, player) {
    if (!player || !this.elCommanderSkills) return;
    var el = this.elCommanderSkills;
    // 清掉上次画的（容器每帧会被上层重建，这里是双保险：上层提前 return 时也不留残影）
    var olds = el.querySelectorAll('.class-skill-icon');
    for (var o = olds.length - 1; o >= 0; o--) {
      if (olds[o].parentNode) olds[o].parentNode.removeChild(olds[o]);
    }
    var st = ClassSkills.getActiveStates(player, now);
    if (!st.length) return;
    el.style.display = 'flex';   // 指挥官 / 战舰技能都不在时也要显示

    for (var i = 0; i < st.length; i++) {
      var s = st[i];
      var icon = document.createElement('div');
      icon.className = 'cooldown-icon commander-icon class-skill-icon';
      icon.innerHTML = this._skillGlyphSvg(s.name)
        + '<div class="cs-wrap"><div class="cooldown-fill"></div></div>'
        + '<span class="cooldown-text"></span>'
        + '<span class="cs-name"></span>'
        + '<span class="cs-key"></span>';
      el.appendChild(icon);

      var fill = icon.querySelector('.cooldown-fill');
      var text = icon.querySelector('.cooldown-text');
      if (!s.ready) {
        var pct = s.cooldownSec > 0 ? ((s.cooldownSec - s.remaining) / s.cooldownSec) * 100 : 100;
        fill.style.height = pct + '%';
        fill.style.backgroundColor = '#C9A227';
        fill.style.opacity = '0.22';   // 冷却进度是底纹，不是一块金砖（同战舰技能，2026-11-15）
        text.textContent = s.remaining.toFixed(1);
        icon.classList.add('cooling');
      } else {
        fill.style.height = '100%';
        fill.style.backgroundColor = '#C0934E';
        fill.style.opacity = '0.14';
        icon.classList.add('ready');
      }
      icon.querySelector('.cs-name').textContent = s.name;
      // 键位标签读 SETTINGS（改键即时生效），不写死 q/e/r
      icon.querySelector('.cs-key').textContent =
        (SETTINGS.keys[s.key] ? bindingLabel(SETTINGS.keys[s.key]) : '');
    }
  };
}
