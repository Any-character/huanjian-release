/**
 * ship-preview.js — 选船页的俯视舰体线图（StartScreen.prototype 扩展，2026-11-15 自 start-screen.js 拆出）
 *
 * 为什么单拆：start-screen.js 做完这次版面重做后超过 400 行（AGENTS §7.3 硬规则）。
 * 拆的是「画什么」——只读 ship.config，不碰版面、不碰交互，边界干净。
 *
 * 契约：
 *   · 画布**背景透明** —— 海图网格由 CSS 画在 #ss-preview-panel 上，两者叠起来才是一张图。
 *   · 船体轮廓由 cfg.length/width 推出；主炮按 mountArcs 分艏/艉（数据驱动，不写死门数）。
 *   · 只借 cfg.color 作船体色（与战斗里同一条船一致），其余全是刻线灰 —— 不让预览变成第二套配色。
 *
 * ⚠️ 加载期就执行 `StartScreen.prototype...`，所以整块包在 typeof 守卫里：
 *    浏览器（index.html 顺序加载）正常挂载；Node 单测没有 StartScreen → 跳过，不崩。
 */

if (typeof StartScreen !== 'undefined') {
  StartScreen.prototype._drawPreview = function() {
    var ctx = this.ctx;
    var W = this.canvas.width, H = this.canvas.height;
    var ship = SHIP_LIBRARY[this.selectedIndex];
    var cfg = ship.config;

    ctx.clearRect(0, 0, W, H);

    var hl = cfg.length * Math.min((H * 0.80) / cfg.length, (W * 0.80) / cfg.length) / 2;
    var hw = Math.max(8, cfg.width / cfg.length * hl);
    var arcList = (cfg.weapon.mainGun && cfg.weapon.mainGun.mountArcs) || [];

    ctx.save();
    ctx.translate(W / 2, H / 2);

    // 船体：尖艏 → 平行中体 → 收窄艉（w/l 参数化：同一条路径可画外壳与甲板）
    function hull(w, l) {
      ctx.beginPath();
      ctx.moveTo(0, -l);
      ctx.bezierCurveTo(w * 0.22, -l * 0.90, w * 0.78, -l * 0.66, w, -l * 0.50);
      ctx.lineTo(w, l * 0.72);
      ctx.bezierCurveTo(w, l * 0.92, w * 0.55, l, 0, l);
      ctx.bezierCurveTo(-w * 0.55, l, -w, l * 0.92, -w, l * 0.72);
      ctx.lineTo(-w, -l * 0.50);
      ctx.bezierCurveTo(-w * 0.78, -l * 0.66, -w * 0.22, -l * 0.90, 0, -l);
      ctx.closePath();
    }

    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = 20;
    ctx.shadowOffsetY = 8;
    hull(hw, hl);
    ctx.fillStyle = cfg.color;
    ctx.fill();
    ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;

    // 甲板（比船壳窄一圈、压暗一点）：船不再是一块纯色板
    hull(hw * 0.87, hl * 0.97);
    ctx.fillStyle = 'rgba(6, 14, 16, 0.26)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(231, 226, 212, 0.26)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // 中轴线（压在甲板上，像图纸上的艏艉线）
    ctx.setLineDash([3, 8]);
    ctx.strokeStyle = 'rgba(231,226,212,0.16)';
    ctx.beginPath(); ctx.moveTo(0, -hl - 24); ctx.lineTo(0, hl + 24); ctx.stroke();
    ctx.setLineDash([]);

    // 上层建筑：舰桥在前、烟囱在后（两块错开，避免一个大方块扣在甲板中间）
    ctx.fillStyle = 'rgba(10,20,23,0.55)';
    ctx.fillRect(-hw * 0.46, -hl * 0.13, hw * 0.92, hl * 0.17);
    ctx.strokeStyle = 'rgba(231,226,212,0.40)';
    ctx.strokeRect(-hw * 0.46, -hl * 0.13, hw * 0.92, hl * 0.17);
    ctx.fillStyle = 'rgba(10,20,23,0.62)';
    ctx.fillRect(-hw * 0.22, hl * 0.10, hw * 0.44, hl * 0.13);

    // 炮座：**先画炮管、后画圆座**——反过来炮管会横穿座体，看起来像两只眼睛
    function turret(x, y, r, dx, dy) {
      ctx.strokeStyle = 'rgba(231,226,212,0.72)';
      ctx.lineWidth = Math.max(1.4, r * 0.20);
      ctx.lineCap = 'butt';
      ctx.beginPath();
      for (var b = -1; b <= 1; b += 2) {
        ctx.moveTo(x + b * r * 0.30, y);
        ctx.lineTo(x + b * r * 0.30 + dx * r * 1.9, y + dy * r * 1.9);
      }
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(12,24,27,0.92)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(231,226,212,0.55)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    var mt = (ship.mainGunCount != null) ? ship.mainGunCount : 0;
    var fwd = 0, aft = 0;
    for (var i = 0; i < mt; i++) {
      if (arcList[i] === 'aft') { turret(0, hl * (0.46 + aft * 0.24), hw * 0.34, 0, 1); aft++; }
      else { turret(0, -hl * (0.66 - fwd * 0.24), hw * 0.34, 0, -1); fwd++; }
    }

    // 副炮（两舷小圆座，炮口朝外）
    var st = ship.secondaryCount || 0, per = Math.floor(st / 2);
    for (var s = 0; s < per; s++) {
      var sy = -hl * 0.36 + s * (hl * 0.62 / Math.max(1, per - 1));
      turret(-hw * 0.52, sy, hw * 0.16, -1, 0);
      turret( hw * 0.52, sy, hw * 0.16,  1, 0);
    }

    // 鱼雷发射管（两舷顺船身的短管）
    var tt = ship.torpedoCount || 0;
    for (var t = 0; t < tt; t++) {
      var side = (t % 2 === 0) ? -1 : 1;
      ctx.fillStyle = 'rgba(231,226,212,0.60)';
      ctx.fillRect(side * hw * 0.62 - hw * 0.09,
        hl * 0.06 + Math.floor(t / 2) * hl * 0.12,
        hw * 0.18, hl * 0.10);
    }

    // 水雷（艉部圆点）
    var mc = ship.mineCount || 0;
    for (var m = 0; m < mc; m++) {
      ctx.beginPath();
      ctx.arc((m - (mc - 1) / 2) * hw * 0.72, hl * 0.84, Math.max(2.5, hw * 0.10), 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(231,226,212,0.55)';
      ctx.fill();
    }

    // 艏向标记（黄铜小三角）
    ctx.fillStyle = 'rgba(192,147,78,0.9)';
    ctx.beginPath();
    ctx.moveTo(0, -hl - 18);
    ctx.lineTo(-5, -hl - 7);
    ctx.lineTo(5, -hl - 7);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  };
}
