/**
 * formula-library.js — 公式库全屏页面（设置页内「公式库」按钮打开）
 *
 * 数据源：js/data/formulas.js 的 FORMULA_LIBRARY（纯数据，用户可编辑）。
 * 层级：z-index 401，盖在设置页（400）上方；返回按钮只 hide 自己，设置页仍显示
 *       （与 TermLibraryScreen 相同模式）。
 */
class FormulaLibraryScreen {
  /**
   * @param {HTMLElement} container — 挂载节点（document.body）
   */
  constructor(container) {
    this._container = container;
    this._overlay = null;
    this._build();
  }

  _build() {
    var overlay = document.createElement('div');
    overlay.className = 'fl-overlay';
    overlay.style.display = 'none';
    this._container.appendChild(overlay);
    this._overlay = overlay;
    this._render();
  }

  show() { this._overlay.style.display = 'block'; }

  hide() { this._overlay.style.display = 'none'; }

  _render() {
    var lib = (typeof FORMULA_LIBRARY !== 'undefined') ? FORMULA_LIBRARY : [];
    var h = ''
      + '<div class="fl-page">'
      + '  <div class="fl-header">'
      + '    <div class="fl-title">公式库</div>'
      + '    <button class="fl-back-btn">返回设置</button>'
      + '  </div>'
      + '  <div class="fl-body">';
    if (!lib.length) {
      h += '<div class="fl-empty">公式库为空（未加载到公式数据）。</div>';
    } else {
      // 按 group 分组
      var groups = [];
      for (var i = 0; i < lib.length; i++) {
        var g = lib[i].group;
        if (groups.indexOf(g) === -1) groups.push(g);
      }
      for (var gi = 0; gi < groups.length; gi++) {
        var items = lib.filter(function(f) { return f.group === groups[gi]; });
        h += '<div class="fl-group-title">' + groups[gi] + '（' + items.length + '）</div>';
        for (var fi = 0; fi < items.length; fi++) {
          var f = items[fi];
          h += '<div class="fl-card">'
            + '<div class="fl-card-name">' + f.name + '</div>'
            + '<div class="fl-card-formula">' + this._escapeHtml(f.formula) + '</div>';
          if (f.vars && f.vars.length) {
            h += '<div class="fl-card-vars-title">变量说明</div>'
              + '<table class="fl-vars"><tbody>';
            for (var vi = 0; vi < f.vars.length; vi++) {
              h += '<tr><td class="fl-var-name">' + this._escapeHtml(f.vars[vi].name) + '</td>'
                + '<td class="fl-var-desc">' + this._escapeHtml(f.vars[vi].desc) + '</td></tr>';
            }
            h += '</tbody></table>';
          }
          if (f.notes) {
            h += '<div class="fl-card-notes">' + this._escapeHtml(f.notes) + '</div>';
          }
          h += '</div>';
        }
      }
    }
    h += '</div></div>';
    this._overlay.innerHTML = h;
    var self = this;
    var backBtn = this._overlay.querySelector('.fl-back-btn');
    if (backBtn) {
      backBtn.addEventListener('click', function() { self.hide(); });
    }
  }

  _escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br>');
  }
}
