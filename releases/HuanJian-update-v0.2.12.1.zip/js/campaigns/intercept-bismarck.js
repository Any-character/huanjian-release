/**
 * campaigns/intercept-bismarck.js — 战役「截击俾斯麦」（2026-08-07）
 *
 * 战役结构（唯一权威字段说明，新增战役照此写）：
 * - mapSizeKm        地图尺寸（公里）
 * - playerSpawn      'center'（地图中央，createPlayer 默认）| { x, y }（px）
 * - enemies[]        敌方配置（与自定义战斗敌人同构，追加战役专属字段）：
 *     behavior        'line'（直线不转向，战役新行为）| chase/random/kite/idle/zigzag
 *     heading         出生航向（弧度，0=北/屏幕上方 -Y；⚠️ x+=sin(h)、y-=cos(h)，135°=右下、315°(-45°)=左上）
 *     spawn           'bottom-right'（= 地图右下角）| { x, y }（px）
 *     overrides       覆写字段（同自定义战斗；含 length/width 船模尺寸，单位：秒/公里/节/武器速度单位）
 *     phases[]        阶段系统（按顺序检测血量阈值，进入新阶段 = 清旧阶段加成 + 应用新阶段，阶段互斥）
 *        below         血量低于此值进入该阶段
 *        mods          加成（delta 后缀 = 相对基础值增减；maxSpeedDelta/mainGunReloadDelta/.../evasionDelta/armorDelta）
 *
 * 字段单位约定（与 CustomEnemy 对齐，2026-08-07 修）：
 * - mainGunShellSpeed  主炮弹速（单位，×0.057 = px/s；8000 → 456px/s）
 * - torpedoSpeed       鱼雷航速（节，1 节 = 1 px/s；35 → 35px/s）
 * - secondaryShellSpeed 副炮弹速（单位，×0.057）
 * - mineReload       水雷间隔（秒；0 = 无水雷）
 * - maxSpeed           航速（节）
 */
registerCampaign({
  id: 'intercept-bismarck',
  name: '截击俾斯麦',
  desc: '俾斯麦号战列舰突破封锁线，向西北方向逃窜。截击并击沉它！',
  mapSizeKm: 50,
  playerSpawn: 'center',
  enemies: [
    {
      name: '俾斯麦',
      shipType: 'battleship',
      behavior: 'line',            // 直线前进不转向
      heading: 315 * Math.PI / 180, // 朝左上角（西北）走对角线
      spawn: 'bottom-right',
      overrides: {
        // 基础属性
        hp: 900000,                 // 90 万血
        armor: 4000,
        maxSpeed: 20,
        // 船模尺寸（战列舰默认 140×28，Boss 放大 1.5 倍，2026-08-07）
        length: 210,
        width: 42,
        // 武器配置（2026-08-08 人机改革）：4 主炮 3 副炮 1 鱼雷；装填 20/6/20s
        mainGunCount: 4,
        secondaryCount: 3,
        torpedoCount: 1,
        mainGunReload: 20,
        torpedoReload: 20,
        secondaryReload: 6,
        // 全部装备战-人机A（伤害/弹速从武器读，见 enemy-weapons.js）
        weapons: {
          mainGun: 'enemy-bb-mgA',
          torpedo: 'enemy-bb-tpA',
          secondary: 'enemy-bb-scA',
        },
        // 射程（公里）
        mainGunRange: 20,
        torpedoRange: 15,
        secondaryRange: 12,
        // 概率（0~1 小数）
        critChance: 0.20,
        penetrationChance: 0.10,
        shatterChance: 0.03,
        burnChance: 0.02,
        floodChance: 0.01,
        // 探测（公里）
        surfaceRange: 18,
        underwaterRange: 10,
        // 额外
        reduceTorpedoDmg: 0.20,     // 减免鱼雷伤害 20%
        // 口径规避用默认（battleship 战列舰默认值）
      },
      phases: [
        // 二阶段：血量 < 75w → 减速、射速加快、穿甲/碎甲增强（2026-08-08 新数值）
        {
          below: 750000,
          mods: {
            maxSpeedDelta: -10,        // 航速 20→10（减速）
            mainGunReloadDelta: -5,    // 装填 20→15s
            torpedoReloadDelta: -6,    // 装填 20→14s
            penetrationChanceDelta: 0.10,
            shatterChanceDelta: 0.10,
          },
        },
        // 三阶段：血量 < 60w（二阶段加成失效）→ 停车、射速更快、穿甲/暴击/碎甲大增
        {
          below: 600000,
          mods: {
            maxSpeedDelta: -20,        // 20→0（停止）
            mainGunReloadDelta: -10,   // 装填 20→10s
            torpedoReloadDelta: -10,   // 装填 20→10s
            penetrationChanceDelta: 0.20,
            critChanceDelta: 0.20,
            shatterChanceDelta: 0.10,
          },
        },
        // 四阶段：血量 < 20w（三阶段加成失效）→ 停车、全口径规避+15%、狂暴射速、装甲+2000
        {
          below: 200000,
          mods: {
            maxSpeedDelta: -20,        // 20→0（停止）
            evasionDelta: 0.15,        // 全口径规避 +15%（small/medium/large 三口径）
            mainGunReloadDelta: -12,   // 装填 20→8s
            secondaryReloadDelta: -2,  // 装填 6→4s
            torpedoReloadDelta: -18.5, // 装填 20→1.5s
            armorDelta: 2000,          // 4000→6000
          },
        },
      ],
      // 增援触发（2026-08-07）：每损失 15w 血触发一次（剩余 75w/60w/45w/30w/15w，共 5 次）。
      // 每次从左下角/右上角随机一处生成一艘增援（提尔皮茨 或 欧根亲王），按第 N 次编号。
      reinforcements: [
        { below: 750000 },
        { below: 600000 },
        { below: 450000 },
        { below: 300000 },
        { below: 150000 },
      ],
      reinforcementPool: [
        // 提尔皮茨（战列）：22km 内友军（含自己）暴击几率+20%、暴击伤害+20%（按船叠加）
        {
          shipType: 'battleship', name: '提尔皮茨',
          aura: { key: 'tirpitz', name: '提尔皮茨光环', radiusKm: 22, critChanceAdd: 0.20, critDmgAdd: 0.20 },
        },
        // 欧根亲王（巡洋）：22km 内友军（含自己）燃烧几率+10%、燃烧程度+20%（按船叠加）
        {
          shipType: 'cruiser', name: '欧根亲王',
          aura: { key: 'eugen', name: '欧根亲王光环', radiusKm: 22, burnChanceAdd: 0.10, burnPowerAdd: 0.20 },
        },
      ],
      reinforcementSpawns: ['bottom-left', 'top-right'],   // 出生点随机
    },
  ],
  allies: [],   // 单挑，无 AI 友军
  // 友军援助（2026-08-08）：每 2n 分钟（n≥0 整数，含开局）场上存活玩家方增援 < 2 → 左上角召唤，编号 n。
  // 胡德 / 威尔士亲王互斥（有胡德召威尔士亲王，反之亦然，都没有随机）；20km 光环（含自己）。
  allyAssist: [
    {
      kind: 'hood',
      name: '胡德',
      hp: 100000,
      armor: 3000,
      aura: { key: 'hood', name: '胡德光环', radiusKm: 20, ignoreArmorAdd: 2000, weaponAccuracyAdd: 0.15, cooldownReduceAdd: 0.15 },
    },
    {
      kind: 'wales',
      name: '威尔士亲王',
      hp: 120000,
      armor: 5000,
      aura: { key: 'wales', name: '威尔士亲王光环', radiusKm: 20, finalReduceAdd: 0.25, armorAdd: 2000 },
    },
  ],
});
