/**
 * campaigns/registry.js — 战役注册器（2026-08-07）
 *
 * 战役模式数据按「每战役一文件」组织在 js/campaigns/ 下：
 *   js/campaigns/registry.js          ← 本文件：CAMPAIGN_LIBRARY + registerCampaign（先加载）
 *   js/campaigns/intercept-bismarck.js ← 各战役定义（后加载，调用 registerCampaign）
 *
 * 新增战役步骤（主代码零改动）：
 *   1. 在 js/campaigns/ 新建 <战役id>.js，调用 registerCampaign({...})
 *   2. index.html 在 registry.js 之后加一行 <script src="js/campaigns/<战役id>.js">
 *   3. AGENTS.md §3 登记
 * 战役结构见 js/campaigns/intercept-bismarck.js 顶部注释（唯一权威字段说明）。
 */

const CAMPAIGN_LIBRARY = [];

/** 注册战役（id 唯一性校验：重复 id 抛错，防覆盖） */
function registerCampaign(campaign) {
  if (!campaign || !campaign.id) throw new Error('registerCampaign: 缺少 id');
  for (var i = 0; i < CAMPAIGN_LIBRARY.length; i++) {
    if (CAMPAIGN_LIBRARY[i].id === campaign.id) {
      throw new Error('registerCampaign: 战役 id 重复: ' + campaign.id);
    }
  }
  CAMPAIGN_LIBRARY.push(campaign);
  return campaign;
}
