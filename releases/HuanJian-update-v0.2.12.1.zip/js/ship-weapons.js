/**
 * ship-weapons.js — Ship 武器 mixin
 *
 * 自 ship.js 拆分（2026-08-03）：射界、瞄准、开火、冷却。
 * 必须后于 ship.js 加载。
 *
 * ⚠️ 攻击侧属性**不要在本文件手抄**：各武器的 baseStats 由
 *   `buildAttackStats(this, '<武器类型>')` 生成，唯一来源 = js/data/attack-stats.js 的表。
 *   加属性 = 改那张表（详见 docs/adding-content.md §8.6）；守卫 = 单测第 87 节（哨兵端到端）。
 */

  /**
   * Check if target direction is within a mount's arc.
   * @param {number} targetX, targetY — world coordinates
   * @param {string} arcKey           — 'forward' | 'aft' | 'port' | 'starboard' | 'centerline'
   * @returns {boolean}
   */
Ship.prototype._isTargetInArc = function(targetX, targetY, arcKey) {
    const targetAngle = Math.atan2(targetX - this.x, -(targetY - this.y));
    return this._isAngleInArc(targetAngle, arcKey);
  }

Ship.prototype._isAngleInArc = function(angle, arcKey) {
    const arcDefs = WEAPON_ARCS[arcKey];
    if (!arcDefs) return true;
    let relAngle = angle - this.heading;
    while (relAngle >  Math.PI) relAngle -= 2 * Math.PI;
    while (relAngle < -Math.PI) relAngle += 2 * Math.PI;
    for (let si = 0; si < arcDefs.length; si++) {
      const seg = arcDefs[si];
      let diff = relAngle - seg.center;
      while (diff >  Math.PI) diff -= 2 * Math.PI;
      while (diff < -Math.PI) diff += 2 * Math.PI;
      if (Math.abs(diff) <= seg.halfSpread) return true;
    }
    return false;
  }

  /** 武器冷却 buff 因子（胡德光环 cooldownReduceAdd -15%：因子 = 1 − 加成；2026-08-08） */
  Ship.prototype.getCooldownBuffFactor = function() {
    const v = this.getBuffMod ? this.getBuffMod('cooldownReduceAdd') : 0;
    return v > 0 ? (1 - v) : 1;
  }

  /**
   * 有效装填时间（2026-09-19 统一入口 · 字人规范）——所有武器共用，禁止各处自行计算。
   * 计算顺序（不可颠倒）：
   *   ① 百分比缩减：多来源**相加**（指挥官 getCdPct + cooldownReduceAdd 光环 + reloadPctReduce 类 buff
   *      + **舰种技能分武器装填百分比** torpedoReloadPct / mineReloadPct，2026-10-03 新增）
   *   ② 常数缩减：reloadFlatReduce（全武器，秒）+ reloadFlatReduce_<weaponKey>（该武器专属，秒）
   *      —— 例：A-140A 炮火风暴「主炮装填 -3s」= reloadFlatReduce_mainGun；
   *              「每层主动锁定 副炮装填 -0.3s」= reloadFlatReduce_secondary
   *   ③ 钳制：不得低于武器极限装填 MIN_RELOAD_SEC（1.5s）
   * ⚠️ 加法口径（设计文档 §4.1）：百分比**只作用于面板基础装填** base，固定秒数在百分比之后才减
   *    —— 即 `base × (1 − Σpct) − Σ固定秒`，**不是** `(base − 固定秒) × (1 − pct)`。
   * @param {string} weaponKey — 'mainGun' | 'secondary' | 'torpedo' | 'mine'
   * @returns {number} 秒
   */
  Ship.prototype.getWeaponReloadSec = function(weaponKey) {
    const cfg = this.weaponCfg && this.weaponCfg[weaponKey];
    const base = cfg && cfg.cooldownSec;
    if (!base) return 0;
    let pct = 0;
    if (this.commander && this.commander.getCdPct) pct += this.commander.getCdPct(weaponKey);
    if (this.getBuffMod) {
      pct += this.getBuffMod('cooldownReduceAdd') || 0;   // 胡德光环（等价原 getCooldownBuffFactor）
      pct += this.getBuffMod('reloadPctReduce') || 0;     // 装填缩减百分比类 buff（A-140A 炮火风暴等）
      // ── 舰种技能分武器装填百分比（2026-10-03 驱逐舰「鱼雷整备」/「水雷整备」）──
      //   与 reloadPctReduce 同池（同一「缩减百分比」量纲）但**按 weaponKey 分派**，
      //   两个通道必须各自带判断 —— 删掉任一个 = 两条通道互相串味。
      //   ⚠️ 语义是「减装填」百分比，故**加进** pct 池（0.10 = 冷却 −10%），不是减固定秒。
      if (weaponKey === 'torpedo') pct += this.getBuffMod('torpedoReloadPct') || 0;
      if (weaponKey === 'mine')     pct += this.getBuffMod('mineReloadPct') || 0;
    }
    let sec = base * Math.max(0, 1 - pct);
    if (this.getBuffMod) {
      sec -= (this.getBuffMod('reloadFlatReduce') || 0);                       // 常数减（秒，全武器）
      sec -= (this.getBuffMod('reloadFlatReduce_' + weaponKey) || 0);          // 常数减（秒，该武器专属）
    }
    // 武器极限装填下限：默认 MIN_RELOAD_SEC；「极限装填 +N 秒」（buff weaponMinReloadAdd，
    //   2026-11-08 重击弹减益）把下限抬高，故装填再快也压不到原来的 1.5s
    const minReload = MIN_RELOAD_SEC + ((this.getBuffMod && this.getBuffMod('weaponMinReloadAdd')) || 0);
    return Math.max(minReload, sec);
  }

  /**
   * 瞄准线朝目标角转动（武器转速限制 maxStep = weaponRotationSpeed × dt）。
   * ⚠️ `this.weaponRotationSpeed` 已经是**有效转速**：舰种技能「武器转速 +%」
   *    （class-skills.js 的 `weaponRotationSpeedPct`，mul 通道）在开局 applyTo 时
   *    已把基础值乘算进该字段 —— 这里**不要**再乘一次百分比，否则双重消费。
   */
  Ship.prototype.updateAimHeading = function(targetAngle, dt) {
    let diff = targetAngle - this.aimHeading;
    while (diff >  Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;
    const maxStep = this.weaponRotationSpeed * dt;
    if (Math.abs(diff) <= maxStep) {
      this.aimHeading = targetAngle;
    } else {
      this.aimHeading += Math.sign(diff) * maxStep;
    }
  }

  /**
   * Return an array of booleans: true if the i-th main-gun mount can fire at (targetX, targetY).
   * @param {number} targetX, targetY
   * @returns {Array<boolean>}
   */
Ship.prototype.getMainGunArcStates = function() {
    const angle = this.isPlayer ? this.aimHeading
      : Math.atan2(arguments[0] - this.x, -(arguments[1] - this.y));
    return this.mainGunMounts.map(function(m) {
      return this._isAngleInArc(angle, m.arcKey);
    }, this);
  }

Ship.prototype.getTorpedoArcStates = function() {
    const angle = this.isPlayer ? this.aimHeading
      : Math.atan2(arguments[0] - this.x, -(arguments[1] - this.y));
    return this.torpedoMounts.map(function(m) {
      return this._isAngleInArc(angle, m.arcKey);
    }, this);
  }

  /** 水雷无射界概念，恒可布放。 */
Ship.prototype.getMineArcStates = function() {
    return this.mineMounts.map(function() { return true; });
  }

  /**
   * Try to fire from the first available main-gun mount that can bear on the target.
   * Returns an Array of MainGunShell (length 0 if all mounts on cooldown or out of arc).
   * @param {number} targetX — world X of cursor / AI aim-point
   * @param {number} targetY
   * @param {number} now     — Date.now() timestamp
   */
Ship.prototype.fireMainGun = function(targetX, targetY, now) {
    var baseAngle = this.isPlayer ? this.aimHeading : Math.atan2(targetX - this.x, -(targetY - this.y));
    var baseDist = Math.hypot(targetX - this.x, targetY - this.y);
    for (var i = 0; i < this.mainGunMounts.length; i++) {
      if (this.isMountReady(this.mainGunMounts[i], now) && this._isAngleInArc(baseAngle, this.mainGunMounts[i].arcKey)) {
        var weapon = getWeaponById(this.mainGunMounts[i].weaponId);
        if (!weapon) weapon = getWeaponById('cruiser-burst-impact');
        // 攻击侧属性统一由 data/attack-stats.js 的表生成（2026-10-25 重构）：
        // 加属性只需在表里加一行，不要再手抄这个对象（漏抄 = 静默失效，已翻车 3 次）
        var baseStats = buildAttackStats(this, 'mainGun');
        var wcfg = weaponToMountConfig(weapon, this.weaponCfg.mainGun, baseStats);
        // 齐射模式（卢金斯 2026-09-13）：主炮炮速 +1000（炮速单位 ×0.057 → px/s）
        var _ljCmd = this.commander;
        if (_ljCmd && _ljCmd.lutjens && _ljCmd.lutjens.salvoOn) {
          wcfg.shellSpeed = (wcfg.shellSpeed || 0) + 1000 * 0.057;
        }

        if (this.commander) wcfg.shellSpeed += this.commander.getShellSpeedBonus();   // 指挥官被动：主炮弹速加成
        wcfg.shellSpeed += (this.mainShellSpeedBonus || 0);   // 技能炮速加成（px/s，2026-09-19 修复：此前未消费）
        // 有效装填统一入口（2026-09-19）：百分比相加 → 常数减 → 钳制武器极限装填 1.5s
        this.mainGunMounts[i].cooldownEnd = now + this.getWeaponReloadSec('mainGun') * 1000;

        var shells = [];
        for (var b = 0; b < wcfg.barrelsPerMount; b++) {
          var spread = (Math.random() - 0.5) * 2 * wcfg.spreadAngle;
          var angle = baseAngle + spread;
          var tgtX = this.x + Math.sin(angle) * baseDist;
          var tgtY = this.y - Math.cos(angle) * baseDist;
          // mountIndex 标记已删（2026-08-16 字人反馈：底炮图标闪烁取消）
          shells.push(new MainGunShell(this.x, this.y, tgtX, tgtY, this.isPlayer, wcfg));
        }
        for (var so = 0; so < shells.length; so++) {
          shells[so].owner = this; shells[so].team = this.team;  // 战绩/阵营归属
          if (this.commander) shells[so].flatDmgPct = this.commander.getDmgPct('mainGun');  // 指挥官武器伤害%
          if (this.commander && this.commander.getExecFlatDmg) { var ex1 = this.commander.getExecFlatDmg(); if (ex1) shells[so].execFlatDmg = ex1; }  // 战神附加伤害
          if (this.getBuffMod) {
            var _am = this.getBuffMod('shellSpeedMul'); if (_am) shells[so].shellSpeed = (shells[so].shellSpeed || 0) * _am;
            var _ap = this.getBuffMod('shotAccuracyPen'); if (_ap) shells[so].shotAccuracy = (shells[so].shotAccuracy != null ? shells[so].shotAccuracy : 1) - _ap;
            var _cp = this.getBuffMod('critDmgPen'); if (_cp) shells[so].critDmg = (shells[so].critDmg || 0) - _cp;
            var _wa = this.getBuffMod('weaponAccuracyAdd'); if (_wa) shells[so].shotAccuracy = (shells[so].shotAccuracy != null ? shells[so].shotAccuracy : 1) + _wa;
            var _td = this.getBuffMod('mainTrueDmgAdd'); if (_td) shells[so].trueDmg = (shells[so].trueDmg || 0) + _td;
            var _wp = this.getBuffMod('weaponDmgPen'); if (_wp) shells[so].weaponDmgPen = (shells[so].weaponDmgPen || 0) + _wp;  // 疲弱/防御矩阵（2026-08-07 修：此前主炮缺此消费）
            var _pd = this.getBuffMod('penDmgAdd'); if (_pd) shells[so].penDmg = (shells[so].penDmg || 0) + _pd;  // 战舰技能光环（穿甲尖兵 12km 穿甲伤害+12%，2026-08-08）
            var _ia = this.getBuffMod('ignoreArmorAdd'); if (_ia) shells[so].ignoreArmor = (shells[so].ignoreArmor || 0) + _ia;  // 胡德光环无视装甲+2000（2026-08-08）
            var _cda = this.getBuffMod('critDmgAdd'); if (_cda) shells[so].critDmg = (shells[so].critDmg || 0) + _cda;  // 沙皇血池暴击伤害加成（2026-08-09）
          }  // 畏惧光环 debuff（华晟）+ 层盾精度/真伤（杜尔曼）+ 疲弱/防御矩阵（2026-08-07）+ 技能光环（2026-08-08）
        }
        // 威斯康星 [重击炮弹]（2026-11-08）：该炮位已装填 → 本轮齐射**全部管数**都带重击弹效果并消费
        if (this.mainGunMounts[i]._heavy && typeof WisconsinHeavy !== 'undefined') {
          for (var shv = 0; shv < shells.length; shv++) shells[shv].isHeavyShell = true;
          WisconsinHeavy.consume(this, i, now);
        }
        // 战列舰「毁灭」主动弹种（2026-11-15）：碎甲/致命弹与重击弹同模型 ——
        //   挂弹在炮位上，开火时该轮齐射全部炮弹标记并消费（互斥关系在挂弹时已处理，两者可同挂）。
        if (typeof ClassSkillActives !== 'undefined') {
          ClassSkillActives.consumeMount(this.mainGunMounts[i], shells);
        }
        // A-140A「炮火风暴」主动：主炮每次**开火**即对所有被锁定敌舰各造成 1 次固定伤害（无距离限制，2026-09-19）
        if (typeof A140AStorm !== 'undefined' && A140AStorm.hasStorm(this)) A140AStorm.onMainGunFired(this, now);
        return shells;
      }
    }
    return [];
  }

  /**
   * 副炮开火：从第一个冷却好且射界内的副炮槽发射（无武器转速限制，直接朝目标）。
   * 返回 Array<MainGunShell>（无可用槽时长度 0）。
   */
Ship.prototype.fireSecondary = function(targetX, targetY, now) {
    var baseAngle = Math.atan2(targetX - this.x, -(targetY - this.y));
    for (var i = 0; i < this.secondaryMounts.length; i++) {
      if (this.isMountReady(this.secondaryMounts[i], now) && this._isAngleInArc(baseAngle, this.secondaryMounts[i].arcKey)) {
        return this._fireSecondaryMount(i, targetX, targetY, now);
      }
    }
    return [];
  }

  /** 从指定副炮槽发射（含冷却设置/弹丸创建/owner 归属）。 */
Ship.prototype._fireSecondaryMount = function(index, targetX, targetY, now) {
    var weapon = getWeaponById(this.secondaryMounts[index].weaponId);
    if (!weapon) return [];
    // 副炮不穿甲/不燃烧/不漏水/无配损武损 —— 这个「字段 × 武器类型」矩阵现在由
    // data/attack-stats.js 的 `weapons` 列声明（副炮恒小口径也由表生成）
    var baseStats = buildAttackStats(this, 'secondary');
    // A-140A「国度的雄心」火力层 buff（2026-09-19）：主炮命中累积 → 副炮真伤 +1%/层（炮速见下方 wcfg）
    if (this.getBuffMod) {
      baseStats.secTrueDmg = (baseStats.secTrueDmg || 0) + (this.getBuffMod('secTrueDmgAdd') || 0);
    }
    // 卢金斯副炮加成（2026-09-13；2026-09-19 规范化）：齐射模式 → 副炮真伤 +5%。
    //   作为「副炮真伤」词条与船自身 secTrueDmg 同类相加，汇入统一真伤通道
    //   （此前直接改 wcfg.trueDmg 绕过词条体系，且真伤基数用的是单管伤害，字人 2026-09-19 修正）
    var _ljCmd2 = this.commander;
    var _ljSalvo = !!(_ljCmd2 && _ljCmd2.lutjens && _ljCmd2.lutjens.salvoOn);
    if (_ljSalvo) baseStats.secTrueDmg = (baseStats.secTrueDmg || 0) + 0.05;
    // 卢金斯副炮加成：常规模式 → 副炮炮速 +1000
    var wcfg = weaponToMountConfig(weapon, this.weaponCfg.secondary, baseStats);
    if (_ljCmd2 && _ljCmd2.lutjens && !_ljSalvo) {
      wcfg.shellSpeed = (wcfg.shellSpeed || 0) + 1000 * 0.057;
    }
    // 副炮炮速加成（2026-09-19）：技能「射击大师」(px/s) + 「国度的雄心」火力层 buff（炮速单位 ×0.057）
    var _secSpdAdd = (this.secShellSpeedBonus || 0)
      + ((this.getBuffMod ? this.getBuffMod('secShellSpeedAdd') : 0) || 0) * 0.057;
    if (_secSpdAdd) wcfg.shellSpeed = (wcfg.shellSpeed || 0) + _secSpdAdd;
    this.secondaryMounts[index].cooldownEnd = now + this.getWeaponReloadSec('secondary') * 1000;   // 有效装填统一入口（2026-09-19）
    var baseAngle = Math.atan2(targetX - this.x, -(targetY - this.y));
    var baseDist  = Math.hypot(targetX - this.x, targetY - this.y);
    var shells = [];
    for (var b = 0; b < wcfg.barrelsPerMount; b++) {
      var spread = (Math.random() - 0.5) * 2 * wcfg.spreadAngle;
      var angle  = baseAngle + spread;
      var tgtX   = this.x + Math.sin(angle) * baseDist;
      var tgtY   = this.y - Math.cos(angle) * baseDist;
      var _shell = new MainGunShell(this.x, this.y, tgtX, tgtY, this.isPlayer, wcfg);
      // mountIndex 标记已删（2026-08-16 字人反馈：底炮图标闪烁取消）
      shells.push(_shell);
    }
    for (var so = 0; so < shells.length; so++) { shells[so].owner = this; shells[so].team = this.team; }  // 战绩/阵营归属
    for (var so2 = 0; so2 < shells.length; so2++) { if (this.commander && this.commander.getExecFlatDmg) { var ex2 = this.commander.getExecFlatDmg(); if (ex2) shells[so2].execFlatDmg = ex2; } }  // 战神附加伤害
    if (this.getBuffMod) {
      var _am2 = this.getBuffMod('shellSpeedMul'); if (_am2) for (var sm = 0; sm < shells.length; sm++) shells[sm].shellSpeed = (shells[sm].shellSpeed || 0) * _am2;
      var _ap2 = this.getBuffMod('shotAccuracyPen'); if (_ap2) for (var sa = 0; sa < shells.length; sa++) shells[sa].shotAccuracy = (shells[sa].shotAccuracy != null ? shells[sa].shotAccuracy : 1) - _ap2;
      var _cp2 = this.getBuffMod('critDmgPen'); if (_cp2) for (var scd = 0; scd < shells.length; scd++) shells[scd].critDmg = (shells[scd].critDmg || 0) - _cp2;
      var _wa2 = this.getBuffMod('weaponAccuracyAdd'); if (_wa2) for (var swa = 0; swa < shells.length; swa++) shells[swa].shotAccuracy = (shells[swa].shotAccuracy != null ? shells[swa].shotAccuracy : 1) + _wa2;
      var _td2 = this.getBuffMod('mainTrueDmgAdd'); if (_td2) for (var std2 = 0; std2 < shells.length; std2++) shells[std2].trueDmg = (shells[std2].trueDmg || 0) + _td2;
      var _wp2 = this.getBuffMod('weaponDmgPen'); if (_wp2) for (var swp2 = 0; swp2 < shells.length; swp2++) shells[swp2].weaponDmgPen = (shells[swp2].weaponDmgPen || 0) + _wp2;  // 疲弱/防御矩阵（2026-08-07 修：副炮缺此消费）
      var _ia2 = this.getBuffMod('ignoreArmorAdd'); if (_ia2) for (var sia2 = 0; sia2 < shells.length; sia2++) shells[sia2].ignoreArmor = (shells[sia2].ignoreArmor || 0) + _ia2;  // 胡德光环无视装甲+2000（2026-08-08）
      var _cda2 = this.getBuffMod('critDmgAdd'); if (_cda2) for (var scda2 = 0; scda2 < shells.length; scda2++) shells[scda2].critDmg = (shells[scda2].critDmg || 0) + _cda2;  // 沙皇血池暴击伤害加成（2026-08-09）
    }  // 畏惧光环 debuff（华晟）+ 层盾精度/真伤（杜尔曼）
    return shells;
  }

  /**
   * 副炮 AI 自动开火：每门独立冷却，射程内+射界内选最近敌舰开火。
   * @param {Array} enemies — 敌舰列表
   * @param {number} now
   * @returns {Array<MainGunShell>} 本帧所有新弹丸
   */
Ship.prototype.autoFireSecondaries = function(enemies, now) {
  // 副炮跟随主炮瞄准（2026-09-13 通用化）：不再自动开火。
  //   字段由齐射模式等来源设置（ship.secondaryFollowsMain），未来其它"跟随"入口复用同一开关
  if (this.isSecondaryFollowing()) return [];
    var shells = [];
    for (var i = 0; i < this.secondaryMounts.length; i++) {
      if (!this.isMountReady(this.secondaryMounts[i], now)) continue;   // 冷却未好 或 武损中（2026-09-13）
      var best = null, bestDist = Infinity;
      for (var ei = 0; ei < enemies.length; ei++) {
        var e = enemies[ei];
        if (!e || !e.isAlive) continue;
        if (!Detection.canSeeShip(this, e)) continue;
        var d = Math.hypot(e.x - this.x, e.y - this.y);
        if (d > this.getSecondaryRangePx()) continue;   // 动态射程（含卢金斯加成，2026-09-13）
        if (!this._isTargetInArc(e.x, e.y, this.secondaryMounts[i].arcKey)) continue;
        if (d < bestDist) { bestDist = d; best = e; }
      }
      if (best) {
        // 提前量预判（2026-08-06）：读目标航速含倒车/航向，直线假定，迭代 2 次；弹速取副炮武器定义
        var secWeapon = getWeaponById(this.secondaryMounts[i].weaponId);
        var apSc = aimAhead(best, this.x, this.y, secWeapon ? secWeapon.shellSpeed : 700);
        var s = this._fireSecondaryMount(i, apSc.x, apSc.y, now);
        shells.push.apply(shells, s);
      }
    }
    return shells;
  }

/**
 * 鱼雷速度加成合计（节）= 技能静态加成（ShipSkills APPLYERS.torpedoSpeed 写 torpedoSpeedBonus）
 * + buff mod（torpedoSpeedAdd，如「蜃光猎影」主动期层数加成）。
 * 供 fireTorpedo 构造 baseStats.torpedoSpeedAdd → weaponToMountConfig weapon.speed + add。
 * ⚠️ 单位是**节**，不做 ×0.057 换算（炮速换算只适用于主炮/副炮 shellSpeed）。
 */
Ship.prototype._torpedoSpeedAdd = function() {
  var v = this.torpedoSpeedBonus || 0;
  if (this.getBuffMod) v += (this.getBuffMod('torpedoSpeedAdd') || 0);
  return v;
};

/**
 * 主炮**实际**弹丸速度（px/s）——与 fireMainGun 的开火口径逐项一致：
 *   武器库基础 ×0.057 → 卢金斯齐射 +1000 → 指挥官被动 → 技能 mainShellSpeedBonus。
 *
 * ⚠️ 唯一用途是 AI 提前量预判（js/enemy.js aimAhead）。
 *    2026-10-25 起**不要再读** `ship.weaponCfg.mainGun.shellSpeed`：那是船配置里手抄的
 *    重复数字，武器库改炮速后不会跟着变（AI 会按旧弹速瞄准），已从船配置移除。
 */
Ship.prototype.getMainGunShellSpeedPx = function() {
  var mount = this.mainGunMounts && this.mainGunMounts[0];
  var weapon = mount && mount.weaponId ? getWeaponById(mount.weaponId) : null;
  var v = weapon ? weapon.shellSpeed * 0.057 : (this.weaponCfg.mainGun.shellSpeed || 0);
  if (this.commander && this.commander.lutjens && this.commander.lutjens.salvoOn) v += 1000 * 0.057;
  if (this.commander && this.commander.getShellSpeedBonus) v += this.commander.getShellSpeedBonus();
  v += (this.mainShellSpeedBonus || 0);
  return v;
};

/**
 * 鱼雷**实际**航速（节；本项目 1 节 = 1 px/s）——与 weaponToMountConfig 鱼雷分支一致：
 *   武器库面板 ×(1 + Σ百分比) + Σ固定值（固定值 = 船技能 torpedoSpeedBonus + buff）。
 * ⚠️ 同上：不再读 `weaponCfg.torpedo.speed`（已从船配置移除）。
 */
Ship.prototype.getTorpedoSpeedKn = function() {
  var mount = this.torpedoMounts && this.torpedoMounts[0];
  var weapon = mount && mount.weaponId ? getWeaponById(mount.weaponId) : null;
  var base = weapon ? weapon.speed : (this.weaponCfg.torpedo.speed || 0);
  var pct = this.getBuffMod ? (this.getBuffMod('torpedoSpeedPct') || 0) : 0;
  return base * (1 + pct) + this._torpedoSpeedAdd();
};

/**
 * Try to fire from the first available torpedo mount.
 * Returns an Array of TorpedoProjectile (length 0 if all mounts on cooldown).
 */
Ship.prototype.fireTorpedo = function(targetX, targetY, now) {
    var baseAngle = this.isPlayer ? this.aimHeading : Math.atan2(targetX - this.x, -(targetY - this.y));
    for (var i = 0; i < this.torpedoMounts.length; i++) {
      if (this.isMountReady(this.torpedoMounts[i], now) && this._isAngleInArc(baseAngle, this.torpedoMounts[i].arcKey)) {
        var weapon = getWeaponById(this.torpedoMounts[i].weaponId);
        if (!weapon) weapon = getWeaponById('cruiser-610mm-S');
        // 含鱼雷专属三通道（torpPanelDmgPct / torpedoSpeedAdd / torpedoSpeedPct）
        // 与 torpedoAccuracy，均由 data/attack-stats.js 的 read() 提供
        var baseStats = buildAttackStats(this, 'torpedo');
        var wcfg = weaponToMountConfig(weapon, this.weaponCfg.torpedo, baseStats);

        // 有效装填统一入口（2026-09-19）：百分比相加 → 常数减 → 钳制武器极限装填
        this.torpedoMounts[i].cooldownEnd = now + this.getWeaponReloadSec('torpedo') * 1000;

        var torps = [];
        for (var b = 0; b < wcfg.barrelsPerMount; b++) {
          var offset = wcfg.barrelsPerMount > 1
            ? -wcfg.scatterAngle + b * (2 * wcfg.scatterAngle) / (wcfg.barrelsPerMount - 1)
            : 0;
          torps.push(
            new TorpedoProjectile(this.x, this.y, baseAngle + offset, this.isPlayer, wcfg)
          );
        }
        for (var to = 0; to < torps.length; to++) {
          torps[to].owner = this; torps[to].team = this.team;  // 战绩/阵营归属
          if (this.commander) torps[to].flatDmgPct = this.commander.getDmgPct('torpedo');  // 指挥官武器伤害%
          if (this.commander && this.commander.getExecFlatDmg) { var ex3 = this.commander.getExecFlatDmg(); if (ex3) torps[to].execFlatDmg = ex3; }  // 战神附加伤害
          if (this.getBuffMod) {
            var _at = this.getBuffMod('shellSpeedMul'); if (_at) torps[to].speed = (torps[to].speed || 0) * _at;
            var _ct = this.getBuffMod('critDmgPen'); if (_ct) torps[to].critDmg = (torps[to].critDmg || 0) - _ct;
            var _waT = this.getBuffMod('weaponAccuracyAdd'); if (_waT) torps[to].shotAccuracy = (torps[to].shotAccuracy != null ? torps[to].shotAccuracy : 1) + _waT;
            var _wpT = this.getBuffMod('weaponDmgPen'); if (_wpT) torps[to].weaponDmgPen = (torps[to].weaponDmgPen || 0) + _wpT;  // 疲弱/防御矩阵（2026-08-07 修：鱼雷缺此消费）
            var _iaT = this.getBuffMod('ignoreArmorAdd'); if (_iaT) torps[to].ignoreArmor = (torps[to].ignoreArmor || 0) + _iaT;  // 胡德光环无视装甲+2000（2026-08-08）
            var _cdaT = this.getBuffMod('critDmgAdd'); if (_cdaT) torps[to].critDmg = (torps[to].critDmg || 0) + _cdaT;  // 沙皇血池暴击伤害加成（2026-08-09）
          }  // 畏惧光环 debuff（华晟）+ 层盾精度（杜尔曼，鱼雷无主炮真伤）+ 疲弱/防御矩阵（2026-08-07）
        }
        // 阳炎-利刃「鱼雷追击」：释放鱼雷（每轮齐射）→ 随机 4 选 1 给下一颗水雷附加强化
        //   （2026-10-01；_pendingMineBuff 由下一次 fireMine 消费）
        if (typeof YanyinPursuit !== 'undefined' && YanyinPursuit.hasPursuit(this)) YanyinPursuit.onTorpedoFired(this, now);
        if (typeof YanyinHunt !== 'undefined' && YanyinHunt.hasHunt && YanyinHunt.hasHunt(this)) YanyinHunt.onTorpedoFired(this, now);
        return torps;
      }
    }
    return [];
  }

  /**
   * 从第一个可用水雷槽布放一颗水雷到舰尾。
   * 返回 Array<SeaMine>（所有槽都在冷却中则长度 0）。
   * @param {number} now — Date.now() timestamp
   */
Ship.prototype.fireMine = function(now) {
    for (var i = 0; i < this.mineMounts.length; i++) {
      if (this.isMountReady(this.mineMounts[i], now)) {
        var weapon = getWeaponById(this.mineMounts[i].weaponId);
        if (!weapon) weapon = getWeaponById('destroyer-sea-mine-4-1A');
        var baseStats = buildAttackStats(this, 'mine');
        var wcfg = weaponToMountConfig(weapon, this.weaponCfg.mine, baseStats);

        this.mineMounts[i].cooldownEnd = now + this.getWeaponReloadSec('mine') * 1000;   // 有效装填统一入口（2026-09-19）

        // 舰尾坐标（与 updateWake 尾迹同侧）
        var sternX = this.x - Math.sin(this.heading) * this.length * 0.5;
        var sternY = this.y + Math.cos(this.heading) * this.length * 0.5;
        var mine = new SeaMine(sternX, sternY, this.isPlayer, wcfg);
        mine.owner = this;  // 战绩归属：记录布放者
        if (this.commander && this.commander.getExecFlatDmg) { var ex4 = this.commander.getExecFlatDmg(); if (ex4) mine.execFlatDmg = ex4; }  // 战神附加伤害
        if (this.getBuffMod) {
          var _cm = this.getBuffMod('critDmgPen'); if (_cm) mine.critDmg = (mine.critDmg || 0) - _cm;
          var _waM = this.getBuffMod('weaponAccuracyAdd'); if (_waM) mine.shotAccuracy = (mine.shotAccuracy != null ? mine.shotAccuracy : 1) + _waM;
          var _wpM = this.getBuffMod('weaponDmgPen'); if (_wpM) mine.weaponDmgPen = (mine.weaponDmgPen || 0) + _wpM;  // 疲弱/防御矩阵（2026-08-07 修：水雷缺此消费）
        }  // 畏惧光环 debuff（华晟）+ 层盾精度（杜尔曼）
        // 「下一颗水雷」待命 buff 消费（2026-10-01 阳炎-利刃基础设施）：
        //   _pendingMineBuff 由技能系统写入（Phase 3），形如
        //     { detonationAdd: 1000, explosionAdd: 2500, critChanceAdd: 0.5 }  // px / 小数
        //   一次性消费（消费后置 null，不跨多颗）。字段缺失跳过。
        if (this._pendingMineBuff) {
          var _pm = this._pendingMineBuff;
          if (_pm.detonationAdd)  mine.detonationRadius = (mine.detonationRadius || 0) + _pm.detonationAdd;
          if (_pm.explosionAdd)   mine.explosionRadius  = (mine.explosionRadius  || 0) + _pm.explosionAdd;
          if (_pm.critChanceAdd)  mine.critChance       = (mine.critChance       || 0) + _pm.critChanceAdd;
          this._pendingMineBuff = null;
        }
        mine.team = this.team;  // 阵营归属
        // 阳炎-利刃「鱼雷追击」：布雷（每颗）→ 立即装填最长装填的鱼雷炮位 + 反雷达干扰 + 机动性
        //   （2026-10-01；必须在 _pendingMineBuff 消费之后 —— 本次布的雷已定型）
        if (typeof YanyinPursuit !== 'undefined' && YanyinPursuit.hasPursuit(this)) YanyinPursuit.onMineFired(this, now);
        if (typeof YanyinHunt !== 'undefined' && YanyinHunt.hasHunt && YanyinHunt.hasHunt(this)) YanyinHunt.onMineFired(this, now);
        return [mine];
      }
    }
    return [];
  }

  /**
   * Returns an array of { remaining, total, ready } for each main-gun mount.
   */
Ship.prototype.getMainGunCooldowns = function(now) {
    return this.mainGunMounts.map(m => {
      // 武损（2026-09-13）：damaged=true 时 UI 显示损坏标记
      const damaged = this.isMountWeaponDamaged(m, now);
      // ★装填进度冻结：武损中的剩余时间必须**恒定** = 武损施加那一刻的剩余量
      //   （此前写 m.cooldownEnd - now 是绝对时间戳递减 → UI 冷却条继续走，
      //     字人 2026-09-13 反馈「损坏的武器仍能装填」，本行为修复）
      //   武损结束后由 getMountCooldownEnd 顺延 cooldownEnd，装填从冻结点继续
      const remaining = damaged
        ? Math.max(0, (m.cooldownEnd - m.wepDamageStart) / 1000)
        : Math.max(0, (this.getMountCooldownEnd(m, now) - now) / 1000);
      return {
        remaining,
        total: this.weaponCfg.mainGun.cooldownSec,
        ready: !damaged && remaining <= 0,
        damaged: damaged,
      };
    });
  }

  /** Same for torpedo mounts. */
Ship.prototype.getTorpedoCooldowns = function(now) {
    return this.torpedoMounts.map(m => {
      // 武损（2026-09-13）：damaged=true 时 UI 显示损坏标记
      const damaged = this.isMountWeaponDamaged(m, now);
      // ★装填进度冻结：武损中的剩余时间必须**恒定** = 武损施加那一刻的剩余量
      //   （此前写 m.cooldownEnd - now 是绝对时间戳递减 → UI 冷却条继续走，
      //     字人 2026-09-13 反馈「损坏的武器仍能装填」，本行为修复）
      //   武损结束后由 getMountCooldownEnd 顺延 cooldownEnd，装填从冻结点继续
      const remaining = damaged
        ? Math.max(0, (m.cooldownEnd - m.wepDamageStart) / 1000)
        : Math.max(0, (this.getMountCooldownEnd(m, now) - now) / 1000);
      return {
        remaining,
        total: this.weaponCfg.torpedo.cooldownSec,
        ready: !damaged && remaining <= 0,
        damaged: damaged,
      };
    });
  }

  /** Same for mine mounts. */
Ship.prototype.getMineCooldowns = function(now) {
    return this.mineMounts.map(m => {
      // 武损（2026-09-13）：damaged=true 时 UI 显示损坏标记
      const damaged = this.isMountWeaponDamaged(m, now);
      // ★装填进度冻结：武损中的剩余时间必须**恒定** = 武损施加那一刻的剩余量
      //   （此前写 m.cooldownEnd - now 是绝对时间戳递减 → UI 冷却条继续走，
      //     字人 2026-09-13 反馈「损坏的武器仍能装填」，本行为修复）
      //   武损结束后由 getMountCooldownEnd 顺延 cooldownEnd，装填从冻结点继续
      const remaining = damaged
        ? Math.max(0, (m.cooldownEnd - m.wepDamageStart) / 1000)
        : Math.max(0, (this.getMountCooldownEnd(m, now) - now) / 1000);
      return {
        remaining,
        total: this.weaponCfg.mine.cooldownSec,
        ready: !damaged && remaining <= 0,
        damaged: damaged,
      };
    });
  }

  /* ── 卢金斯副炮扩展（2026-09-13）───────────────────────────────────── */

  /** 副炮有效射程（px）：基础 + 极限副炮 +2km + 齐射模式 +2.5km（动态消费，不改 weaponCfg） */
  Ship.prototype.getSecondaryRangePx = function() {
    // A-140A「国度的雄心」：副炮射程始终跟随主炮射程（含主动期 +5km；2026-09-19）
    if (this.secondaryRangeFollowsMain && this.getMainGunRangePx) return this.getMainGunRangePx();
    var r = this.weaponCfg.secondary.range;
    var cmd = this.commander;
    if (cmd && cmd.lutjens) {
      r += 2 * PX_PER_KM;
      if (cmd.lutjens.salvoOn) r += 2.5 * PX_PER_KM;
    }
    if (this.getBuffMod) r += (this.getBuffMod('secRangeAddPx') || 0);   // 不动堡垒：副炮射程 +5km（2026-11-08）
    return r;
  };

  /** 主炮有效射程（px）：基础 +（卢金斯常规模式 +1km；齐射模式不加）+ 光环/主动 buff（mainRangeAddPx，如炮火风暴 +5km） */
  Ship.prototype.getMainGunRangePx = function() {
    var r = this.weaponCfg.mainGun.range;
    var cmd = this.commander;
    if (cmd && cmd.lutjens && !cmd.lutjens.salvoOn) r += 1 * PX_PER_KM;
    if (this.getBuffMod) r += (this.getBuffMod('mainRangeAddPx') || 0);   // A-140A 炮火风暴主动：主炮射程 +5km（2026-09-19）
    return r;
  };

  /**
   * 齐射模式同步副炮（卢金斯 2026-09-13）：主炮每次开火时调用。
   * 发射「编号最靠前且就绪」的副炮（就绪 = 冷却好 + 未武损 + 瞄准方向在射界内 + 目标在副炮射程内）。
   * @returns {Array} 副炮弹丸（可能为空：全部未就绪/射界外/超射程）
   */
  Ship.prototype.fireSecondaryWithMainGun = function(targetX, targetY, now) {
    if (!this.isSecondaryFollowing()) return [];   // 跟随主炮瞄准状态（卢金斯齐射 OR A-140A 常驻标记；统一走 isSecondaryFollowing）
    var fireAngle = Math.atan2(targetX - this.x, -(targetY - this.y));
    var rangePx = this.getSecondaryRangePx();
    var dist = Math.hypot(targetX - this.x, targetY - this.y);
    if (dist > rangePx) return [];                                  // 目标超出副炮射程 → 本次不发射
    for (var i = 0; i < this.secondaryMounts.length; i++) {
      if (!this.isMountReady(this.secondaryMounts[i], now)) continue;
      if (!this._isAngleInArc(fireAngle, this.secondaryMounts[i].arcKey)) continue;
      return this._fireSecondaryMount(i, targetX, targetY, now);
    }
    return [];
  };

  /** 副炮冷却信息（底部副炮图标行用，2026-09-13）：格式同主炮（含 damaged） */
  Ship.prototype.getSecondaryCooldowns = function(now) {    return this.secondaryMounts.map(m => {
      const damaged = this.isMountWeaponDamaged(m, now);
      // 装填进度冻结：武损中剩余恒定 = 施加时刻的剩余量（同主炮，见 60.9）
      const remaining = damaged
        ? Math.max(0, (m.cooldownEnd - m.wepDamageStart) / 1000)
        : Math.max(0, (this.getMountCooldownEnd(m, now) - now) / 1000);
      return {
        remaining,
        total: this.weaponCfg.secondary.cooldownSec,
        ready: !damaged && remaining <= 0,
        damaged: damaged,
      };
    });
  }

  /**
   * 副炮射界状态（副炮图标行 can-fire 高亮用，2026-09-13 字人反馈"要和主炮一致"）：
   * 与主炮 getMainGunArcStates 同语义 —— 玩家读 aimHeading（跟随主炮瞄准），AI 读目标坐标。
   * @returns {Array<boolean>} 每门副炮：瞄准方向是否在该炮射界内
   */
  Ship.prototype.getSecondaryArcStates = function() {
    const angle = this.isPlayer ? this.aimHeading
      : Math.atan2(arguments[0] - this.x, -(arguments[1] - this.y));
    return this.secondaryMounts.map(function(m) {
      return this._isAngleInArc(angle, m.arcKey);
    }, this);
  }
