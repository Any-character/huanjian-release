/**
 * constants-custom.js — 自定义战斗模式专用常量
 *
 * 舰种默认值、手动覆写范围、行为模式枚举、地图规格选项
 */

// ── 行为模式枚举 ──────────────────────────────────────────────────────────
const BEHAVIOR = Object.freeze({
  CHASE:  'chase',   // 全速追踪
  RANDOM: 'random',  // 随机行动
  KITE:   'kite',    // 远程游走
  IDLE:   'idle',    // 原地不动
});

// ── 出生模式 ───────────────────────────────────────────────────────────────
const SPAWN_MODE = Object.freeze({
  RANDOM: 'random',   // 随机位置
  FIXED:  'fixed',    // 固定排布（玩家一角，敌人另一角）
});

// ── 地图规格选项 (km) ─────────────────────────────────────────────────────
const MAP_OPTIONS = [20, 30, 40, 50, 60, 70];

// ── 最大敌人数量 ──────────────────────────────────────────────────────────
const MAX_CUSTOM_ENEMIES = 12;

// ── 最大 AI 友军数量 ─────────────────────────────────────────────────────
const MAX_CUSTOM_ALLIES = 6;

// ── 最大预设方案数 ───────────────────────────────────────────────────────
const MAX_PRESETS = 10;

// ── 舰种默认值（2026-08-08 人机武器改革）────────────────────────────────
// 伤害/速度**不再在基础属性**——全部从人机武器（ENEMY_WEAPONS）读取；
// 数量 + 装填（武器冷却）由基础属性决定，自定义战斗可调（OVERRIDE_RANGES）
const SHIP_TYPE_DEFAULTS = Object.freeze({
  cruiser: Object.freeze({
    hp: 30000, armor: 2000, maxSpeed: 35,
    length: 100, width: 20,
    surfaceRange: 15,   underwaterRange: 9,    // 水上/水下探测 km（比玩家高）
    smallCaliberEvasion: 0.2,   // 小口径炮弹规避 20%（巡洋默认）
    mediumCaliberEvasion: 0.1,  // 中口径 10%
    mainGunCount: 4,    mainGunReload: 8,      // 4 主炮，装填 8s
    torpedoCount: 2,    torpedoReload: 20,     // 2 鱼雷，装填 20s
    secondaryCount: 0,  mineCount: 0,
    mainGunRange: 17,       torpedoRange: 12,        // 公里
    critChance: 0.05,       shatterChance: 0.05,   penetrationChance: 0.1,
    burnChance: 0.05,
    accessoryChance: 0.03,
    weaponDamageChance: 0.03,   // 武损几率 3%（2026-09-13）
    floodChance: 0.05,          // 漏水几率 5%（2026-09-19 补：此前缺失 → 敌方鱼雷/水雷永不造成漏水）
    trueDmg: 0, mainTrueDmg: 0, torpTrueDmg: 0, mineTrueDmg: 0, secTrueDmg: 0,
    resistTrueDmg: 0,   // 抵抗武器真伤（对冲，2026-09-19）
    repairEff: 0,       // 维修效率（回血加成%，2026-10-01）
    unyielding: 0,      // 不屈（每次受主炮/鱼雷/水雷伤害回固定血量，2026-11-08）
    takePenDmgAdd: 0, takeWeaponDmgAdd: 0, flatDamageReduce: 0,   // 防御侧修正（2026-11-08）
    engagementRange: 17,                              // 公里（=主炮射程）
    color: '#D94040', bowColor: '#F06060', outlineColor: '#FF8888',
    rotationSpeed: 45 * Math.PI / 180,
  }),
  battleship: Object.freeze({
    hp: 45000, armor: 4000, maxSpeed: 25,
    length: 140, width: 28,
    surfaceRange: 10,   underwaterRange: 5,    // 水上/水下探测 km（比玩家高）
    smallCaliberEvasion: 0.25,  // 小口径炮弹规避 25%（战列默认）
    mediumCaliberEvasion: 0.15, // 中口径 15%
    largeCaliberEvasion: 0.1,   // 大口径 10%
    mainGunCount: 3,    mainGunReload: 15,     // 3 主炮，装填 15s
    torpedoCount: 1,    torpedoReload: 20,     // 1 鱼雷，装填 20s
    secondaryCount: 3,  secondaryReload: 6,    // 3 副炮，装填 6s
    mineCount: 0,
    mainGunRange: 20,       torpedoRange: 8,         // 公里
    secondaryRange: 10,
    critChance: 0.15,       shatterChance: 0.05,   penetrationChance: 0.10,
    burnChance: 0.03,
    accessoryChance: 0.03,
    weaponDamageChance: 0.03,   // 武损几率 3%（2026-09-13）
    floodChance: 0.05,          // 漏水几率 5%（2026-09-19 补：此前缺失 → 敌方鱼雷/水雷永不造成漏水）
    trueDmg: 0, mainTrueDmg: 0, torpTrueDmg: 0, mineTrueDmg: 0, secTrueDmg: 0,
    resistTrueDmg: 0,   // 抵抗武器真伤（对冲，2026-09-19）
    repairEff: 0,       // 维修效率（回血加成%，2026-10-01）
    unyielding: 0,      // 不屈（每次受主炮/鱼雷/水雷伤害回固定血量，2026-11-08）
    takePenDmgAdd: 0, takeWeaponDmgAdd: 0, flatDamageReduce: 0,   // 防御侧修正（2026-11-08）
    engagementRange: 20,                              // 公里（=主炮射程）
    color: '#8855AA', bowColor: '#AA77CC', outlineColor: '#CCAAEE',
    rotationSpeed: 25 * Math.PI / 180,
  }),
  destroyer: Object.freeze({
    hp: 15000, armor: 800, maxSpeed: 45,
    length: 70, width: 14,
    surfaceRange: 18,   underwaterRange: 12,   // 水上/水下探测 km（比玩家高）
    smallCaliberEvasion: 0.1,   // 小口径炮弹规避 10%（驱逐默认）
    mainGunCount: 3,    mainGunReload: 5,      // 3 主炮，装填 5s
    torpedoCount: 3,    torpedoReload: 20,     // 3 鱼雷，装填 20s
    secondaryCount: 0,  mineCount: 3,          // 3 水雷
    mineReload: 20,                             // 水雷装填 20s
    mainGunRange: 16,       torpedoRange: 18,        // 公里
    critChance: 0.05,       shatterChance: 0.08,   penetrationChance: 0.05,
    burnChance: 0.08,
    accessoryChance: 0.03,
    weaponDamageChance: 0.03,   // 武损几率 3%（2026-09-13）
    floodChance: 0.05,          // 漏水几率 5%（2026-09-19 补：此前缺失 → 敌方鱼雷/水雷永不造成漏水）
    trueDmg: 0, mainTrueDmg: 0, torpTrueDmg: 0, mineTrueDmg: 0, secTrueDmg: 0,
    resistTrueDmg: 0,   // 抵抗武器真伤（对冲，2026-09-19）
    repairEff: 0,       // 维修效率（回血加成%，2026-10-01）
    unyielding: 0,      // 不屈（每次受主炮/鱼雷/水雷伤害回固定血量，2026-11-08）
    takePenDmgAdd: 0, takeWeaponDmgAdd: 0, flatDamageReduce: 0,   // 防御侧修正（2026-11-08）
    engagementRange: 16,                              // 公里（=主炮射程）
    color: '#44AA66', bowColor: '#66CC88', outlineColor: '#88EEAA',
    rotationSpeed: 60 * Math.PI / 180,
  }),
});

// ── 舰种选项（用于 UI 下拉） ──────────────────────────────────────────────
const SHIP_TYPES = ['cruiser', 'battleship', 'destroyer'];
const SHIP_TYPE_LABELS = { cruiser: '巡洋舰', battleship: '战列舰', destroyer: '驱逐舰' };

// ── 行动模式选项 ──────────────────────────────────────────────────────────
const BEHAVIOR_LABELS = { chase: '全速追踪', random: '随机行动', kite: '远程游走', idle: '原地不动', zigzag: '迂回接近' };

// ── 手动覆写范围限制（2026-08-08 人机武器改革）────────────────────────────
// 注意：UI 层单位为秒/公里，底层存储也是秒/公里，CustomEnemy 构造时自动转换
// 伤害/速度字段已移除（从人机武器读）；数量/装填可调
//
// ⚠️ **本表 = 「基础属性」并列表**（卡片上直接铺开的那一列输入框）
//   **只放舰船的基础数值**（血量/装甲/航速/武器数量/装填/射程/各类几率）。
//   **机制类词条一律不进本表**，只走「自定义加成」弹窗（TERM_OVERRIDES，见 js/data/term-overrides.js）。
//   理由（2026-11-08 字人要求）：基础属性与词条混在一列，玩家分不清「改数值」和「加机制」。
//   守卫：单测第 98 节（TERM_ONLY_OVERRIDE_KEYS 里的词条不得出现在本表）。
const OVERRIDE_RANGES = Object.freeze({
  hp:               { min: 1,        max: 1000000000, step: 1 },
  armor:            { min: 0,        max: 100000,     step: 1 },
  maxSpeed:         { min: 0,        max: 110,        step: 0.1 },
  mainGunCount:     { min: 0,        max: 20,         step: 1 },
  mainGunReload:    { min: 0.5,      max: 1000,       step: 0.5 },    // 秒
  torpedoCount:     { min: 0,        max: 20,         step: 1 },
  torpedoReload:    { min: 0.5,      max: 1000,       step: 0.5 },    // 秒
  secondaryCount:   { min: 0,        max: 20,         step: 1 },
  secondaryReload:  { min: 0.5,      max: 1000,       step: 0.5 },    // 秒
  mineCount:        { min: 0,        max: 20,         step: 1 },
  mineReload:       { min: 0.5,      max: 1000,       step: 0.5 },    // 秒
  mainGunRange:     { min: 0,        max: 100,        step: 1 },      // 公里
  torpedoRange:     { min: 0,        max: 100,        step: 1 },      // 公里
  secondaryRange:   { min: 0,        max: 100,        step: 1 },      // 公里
  critChance:       { min: 0,        max: 2,          step: 0.01 },
  shatterChance:    { min: 0,        max: 2,          step: 0.01 },
  penetrationChance:{ min: 0,        max: 2,          step: 0.01 },
  burnChance:       { min: 0,        max: 2,          step: 0.01 },
  floodChance:      { min: 0,        max: 2,          step: 0.01 },
  accessoryChance:  { min: 0,        max: 2,          step: 0.01 },   // 配损几率（2026-09-13 补：此前面板无此项，敌舰配损几率无法直接调）
  weaponDamageChance: { min: 0,      max: 2,          step: 0.01 },   // 武损几率（2026-09-13）
  surfaceRange:     { min: 0,        max: 50,         step: 0.5 },    // km（水上探测）
  underwaterRange:  { min: 0,        max: 50,         step: 0.5 },    // km（水下探测）
  // ⚠️ 武器真伤（trueDmg 系列）/ 真伤抵抗（resistTrueDmg）/ 维修效率（repairEff）/
  //   雷达干扰（radarJamming）/ 反雷达干扰（antiRadarJamming）已于 2026-11-08 挪到「自定义加成」，
  //   **不在本表**（它们是机制词条，不是基础数值）。范围见 js/data/term-overrides.js。
});

// ── 机制词条：**只走「自定义加成」，不得进基础属性并列表**（2026-11-08 字人要求）──
// 用途：① 旧存档迁移（overrides → termOverrides）② 单测第 98 节守卫
const TERM_ONLY_OVERRIDE_KEYS = Object.freeze([
  'trueDmg', 'mainTrueDmg', 'torpTrueDmg', 'mineTrueDmg', 'secTrueDmg',   // 武器真伤（通用 + 各武器专属）
  'resistTrueDmg',                                                            // 抵抗武器真伤（对冲）
  'repairEff',                                                                // 维修效率
  'radarJamming', 'antiRadarJamming',                                        // 雷达干扰 / 反雷达干扰
]);


// ── 显示用字段名（2026-08-08：伤害字段移除，加数量字段）────────────────────
const OVERRIDE_LABELS = {
  hp:                '血量',
  armor:             '装甲强度',
  maxSpeed:          '最大航速(节)',
  mainGunCount:      '主炮数量',
  mainGunReload:     '主炮装填(秒)',
  torpedoCount:      '鱼雷数量',
  torpedoReload:     '鱼雷装填(秒)',
  secondaryCount:    '副炮数量',
  secondaryReload:   '副炮装填(秒)',
  mineCount:         '水雷数量',
  mineReload:        '水雷装填(秒)',
  mainGunRange:      '主炮射程(km)',
  torpedoRange:      '鱼雷射程(km)',
  secondaryRange:    '副炮射程(km)',
  critChance:        '暴击几率(%)',
  shatterChance:     '碎甲几率(%)',
  penetrationChance: '穿甲几率(%)',
  surfaceRange:      '水上探测(km)',
  underwaterRange:   '水下探测(km)',
  burnChance:        '燃烧几率(%)',
  floodChance:       '漏水几率(%)',
  accessoryChance:   '配损几率(%)',   // 2026-09-13 补
  weaponDamageChance: '武损几率(%)',  // 2026-09-13
  // ⚠️ 武器真伤 / 抵抗武器真伤 / 维修效率 / 雷达干扰 / 反雷达干扰已于 2026-11-08 挪到
  //   「自定义加成」弹窗（js/data/term-overrides.js），不再在这里与基础属性并列。
};

// ── 百分比字段（UI 存储÷100，显示×100） ──────────────────────────────────
// ⚠️ 只登记「基础属性并列表」里的百分比字段；自定义加成词条自带 isPct，不在此表。
const PCT_KEYS = ['critChance', 'shatterChance', 'penetrationChance', 'burnChance', 'floodChance', 'accessoryChance', 'weaponDamageChance'];

// ── 默认战斗配置 ──────────────────────────────────────────────────────────
const DEFAULT_BATTLE_CONFIG = {
  mapSizeKm: 50,
  spawnMode: 'random',
  campaign: false,   // 视同战役（2026-08-08）：开启后战舰技能"战役"属性生效，当作战役模式处理
  enemies: [
    {
      id: 'enemy-1', name: '敌人-1', shipType: 'cruiser',
      behavior: 'zigzag', spawnMode: 'random',   // 默认迂回接近（2026-08-06）
      overrides: null,
    },
  ],
  allies: [],
};

// ── 预设持久化 ────────────────────────────────────────────────────────────
function loadPresets() {
  try {
    var raw = localStorage.getItem('huanjian.customPresets');
    if (raw) {
      var presets = JSON.parse(raw);
      // 旧存档兼容：无 allies 字段补空数组
      for (var i = 0; i < presets.length; i++) {
        if (presets[i] && presets[i].config && !presets[i].config.allies) {
          presets[i].config.allies = [];
        }
        // 旧存档兼容：机制词条从「基础属性覆写」挪到「自定义加成」（2026-11-08）
        if (presets[i] && presets[i].config) migrateCustomConfig(presets[i].config);
      }
      return presets;
    }
  } catch (e) {}
  return [];
}

/**
 * 旧存档迁移（2026-11-08 字人要求）：机制词条从「基础属性覆写」挪到「自定义加成」
 *
 * 背景：这批词条（武器真伤 / 抵抗武器真伤 / 维修效率 / 雷达干扰 / 反雷达干扰）原先
 *   **同时**出现在基础属性并列表和自定义加成弹窗里；2026-11-08 起只留「自定义加成」。
 *   老玩家（朋友）已经填在 overrides 里的值不能凭空消失 —— 迁移到 termOverrides，
 *   在新界面里仍可见、可改。
 *
 * 语义差异无影响：overrides = 替换语义、termOverrides = 「基础 + 加算」语义，
 *   而这批词条的舰种基础值都是 0（radarJamming 基础是 undefined→按 0 处理），
 *   所以迁移前后最终值完全一致。
 *
 * @param {Object} config — 自定义战斗配置（enemies / allies 数组）
 * @returns {Object} 同一个 config（就地修改）
 */
function migrateCustomConfig(config) {
  if (!config) return config;
  var lists = [config.enemies, config.allies];
  for (var li = 0; li < lists.length; li++) {
    var arr = lists[li];
    if (!arr || !arr.length) continue;
    for (var i = 0; i < arr.length; i++) {
      var ecfg = arr[i];
      if (!ecfg || !ecfg.overrides) continue;
      var moved = false;
      for (var ki = 0; ki < TERM_ONLY_OVERRIDE_KEYS.length; ki++) {
        var key = TERM_ONLY_OVERRIDE_KEYS[ki];
        var v = ecfg.overrides[key];
        if (v === undefined || v === null) continue;
        if (!ecfg.termOverrides) ecfg.termOverrides = {};
        // 目标位置已有值（玩家自己填过）→ 保留目标值，不覆盖
        if (ecfg.termOverrides[key] === undefined || ecfg.termOverrides[key] === null) {
          ecfg.termOverrides[key] = v;
        }
        delete ecfg.overrides[key];
        moved = true;
      }
      if (moved && Object.keys(ecfg.overrides).length === 0) ecfg.overrides = null;
    }
  }
  return config;
}

function savePresets(presets) {
  try {
    // strip null overrides to save space
    var cleaned = presets.map(function(p) {
      var copy = JSON.parse(JSON.stringify(p));
      if (copy.config && copy.config.enemies) {
        copy.config.enemies.forEach(function(e) {
          if (e.overrides) {
            for (var k in e.overrides) {
              if (e.overrides[k] === null) delete e.overrides[k];
            }
            if (Object.keys(e.overrides).length === 0) e.overrides = null;
          }
        });
      }
      if (copy.config && copy.config.allies) {
        copy.config.allies.forEach(function(a) {
          if (a.overrides) {
            for (var k2 in a.overrides) {
              if (a.overrides[k2] === null) delete a.overrides[k2];
            }
            if (Object.keys(a.overrides).length === 0) a.overrides = null;
          }
        });
      }
      return copy;
    });
    localStorage.setItem('huanjian.customPresets', JSON.stringify(cleaned));
  } catch (e) {}
}

// ── 配置合并：舰种默认 + 用户覆写 ─────────────────────────────────────────
function mergeEnemyConfig(shipTypeDefaults, overrides, termOverrides) {
  var result = {};
  for (var k in shipTypeDefaults) {
    result[k] = shipTypeDefaults[k];
  }
  if (overrides) {
    // 旧存档兼容（2026-08-08 间隔→装填改名）：旧字段存在且新字段未设 → 迁移
    if (overrides.mainGunInterval != null && overrides.mainGunReload == null) overrides.mainGunReload = overrides.mainGunInterval;
    if (overrides.torpedoInterval != null && overrides.torpedoReload == null) overrides.torpedoReload = overrides.torpedoInterval;
    if (overrides.secondaryInterval != null && overrides.secondaryReload == null) overrides.secondaryReload = overrides.secondaryInterval;
    if (overrides.mineInterval != null && overrides.mineReload == null) overrides.mineReload = overrides.mineInterval;
    for (var k in overrides) {
      if (overrides[k] !== null && overrides[k] !== undefined) {
        result[k] = overrides[k];
      }
    }
  }
  // 叠加式「自定义加成」：TERM_OVERRIDES 词条 = 基础 + 加成（与古鹰一致，2026-08-05）
  if (termOverrides) {
    for (var t3 = 0; t3 < TERM_OVERRIDES.length; t3++) {
      var to3 = TERM_OVERRIDES[t3];
      var v3 = termOverrides[to3.id];
      if (v3 === undefined || v3 === null) continue;
      var base3 = (result[to3.id] !== undefined && result[to3.id] !== null) ? result[to3.id] : 0;
      result[to3.id] = to3.rad ? base3 + v3 * Math.PI / 180   // 基础弧度 + 加成度数→弧度
                               : base3 + v3;
    }
  }
  // 钳制表：基础覆写区 OVERRIDE_RANGES ∪ 词条调节 TERM_OVERRIDES
  //   机制词条（武器真伤/抵抗/维修效率/雷达干扰…）2026-11-08 起只存在于 TERM_OVERRIDES，
  //   钳制范围与百分比口径都由词条表自带（isPct / step），不再依赖 PCT_KEYS。
  var clampTable = {};
  for (var rk in OVERRIDE_RANGES) {
    clampTable[rk] = OVERRIDE_RANGES[rk];
    clampTable[rk].isPct = PCT_KEYS.indexOf(rk) !== -1;  // 基础区百分比标记（词条表自带 isPct）
  }
  for (var ti = 0; ti < TERM_OVERRIDES.length; ti++) {
    var to = TERM_OVERRIDES[ti];
    if (!clampTable[to.id]) clampTable[to.id] = to;
  }
  // 强制限制到允许范围 + 精度归一
  var intKeys = ['hp', 'armor', 'mainGunDamage', 'torpedoDamage', 'mineDamage', 'secondaryDamage'];
  for (var k in clampTable) {
    if (result[k] !== undefined) {
      var range = clampTable[k];
      result[k] = Math.max(range.min, Math.min(range.max, result[k]));
      if (intKeys.indexOf(k) !== -1) {
        result[k] = Math.round(result[k]);
      } else if (range.isPct === true) {
        result[k] = Math.round(result[k] * 100) / 100;   // 百分比词条：两位小数（step 0.01）
      } else if (range.rad === true) {
        result[k] = Math.round(result[k] * 10000) / 10000;  // 弧度词条：保留 4 位小数（不按度数取整）
      } else if (range.step >= 1) {
        result[k] = Math.round(result[k]);               // 整数数值词条
      } else {
        result[k] = Math.round(result[k] * 10) / 10;     // 小数数值（step 0.1，如 maxSpeed）
      }
      // 角度词条（rad: true）：仅基础覆写区显式填度数→弧度（叠加来源已在叠加段转好弧度）
      if (range.rad === true
          && !(termOverrides && termOverrides[k] !== undefined && termOverrides[k] !== null)
          && overrides && overrides[k] !== undefined && overrides[k] !== null) {
        result[k] = result[k] * Math.PI / 180;
      }
    }
  }
  return result;
}
