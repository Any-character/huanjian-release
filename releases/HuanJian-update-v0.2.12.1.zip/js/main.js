/**
 * main.js — Game initialisation and main loop.
 *
 * This is the entry point.  It wires together all modules and runs the
 * requestAnimationFrame loop at ~60 fps.
 *
 * InputHandler class → js/input/input.js
 */

/* ========================================================================== */
/*  Game State & Loop                                                         */
/* ========================================================================== */

(function () {
  'use strict';

  // ── DOM refs ─────────────────────────────────────────────────────────
  const gameCanvas    = document.getElementById('game-canvas');
  const minimapCanvas = document.getElementById('minimap-canvas');
  const compassCanvas = document.getElementById('compass-canvas');

  // ── mode selection overlay ────────────────────────────────────────────
  let modeSelect = null;
  let customBattleScreen = null;
  let campaignScreen = null;   // 战役模式选择（2026-08-07）

  // ── start screen (blocks game start until "开始战斗" clicked) ─────────
  let gameStarted = false;
  let battleStartTime = 0;    // 战斗开始时间戳（顶部中央计时器用，2026-08-06）
  let battleEndTime = 0;      // 战斗结束时间戳（gameOver 时冻结，计时器/战绩用，2026-08-06）
  let player;
  let enemies = [];
  let allies = [];   // AI 友军（仅自定义战斗）
  let battleMode = 'quick';  // 'quick' | 'custom'
  let isCampaign = false;    // 战役环境（真战役 / 自定义+视同战役）：战舰技能"战役"属性生效判定（2026-08-08）
  let activeCampaign = null; // 当前战役对象（胜负判定用：Boss 击沉=胜 / 玩家死或 Boss 到左上角=负，2026-08-08）
  let campaignAllyPool = null;  // 战役友军援助池（campaign.allyAssist：胡德/威尔士亲王，2026-08-08）
  let allySpawnLastMin = -1;    // 已召唤的分钟标记（每 2n 分钟检查一次）

  /** 战役环境统一切换（2026-09-19 规范，AGENTS §5.30）：
   *  isCampaign（本文件内沿用）与全局 BattleRules.isCampaign **同步**——
   *  战役差异类逻辑（百分比扣血基数等）统一读 BattleRules.isCampaign，禁止各自维护布尔。 */
  function setCampaignContext(v) {
    isCampaign = v;
    BattleRules.isCampaign = v;
  }

  // shared ship config reference (set by start screen callback)
  let _selectedShip = null;
  let _selectedLoadout = null;

  new StartScreen('start-screen', 'ss-preview-canvas', function(ship) {
    _selectedShip = ship;
    _selectedLoadout = loadLoadout(ship.id);
    // 打开模式选择，而非直接开始战斗
    if (!modeSelect) {
      modeSelect = new ModeSelectScreen(
        function() { startQuickBattle(); },
        function() { showCustomBattle(); },
        function() { document.getElementById('start-screen').style.display = 'flex'; },
        function() { showCampaignSelect(); }   // 战役模式（2026-08-07）
      );
    }
    modeSelect.show();
  });

  // ── 启动静默检查更新（2026-10-02，AGENTS §5.31）────────────────────────
  //  为什么不放战斗里：自动检查**只在有新版本时**弹窗，最坏情况是在战斗中
  //  盖一层全屏遮罩（z-index 450）打断操作。选船界面是全局唯一「玩家空闲、
  //  CPU 忙着画预览、随时可以中断」的时刻，弹窗放在这里打扰成本最低。
  //  为什么推迟 2s：check 走网络（最坏 8s 超时），t=0 发起会和首屏渲染/预览
  //  动画抢主线程；2s 足够选船界面稳定呈现，且用户通常还没点进模式选择。
  //  为什么不阻塞首屏：setTimeout 本身就异步，check() 更是回调式，全程不 await。
  //  去重在 Updater.autoCheck 内部（_autoCheckStarted，一会话只查一次），
  //  本处只决定「时机」；静默判定见 Updater._autoPopupDecision。
  //  ⚠ 加载顺序：index.html 中 systems/updater.js（L182）早于 main.js（L227），
  //    故此处可安全引用全局 Updater（脚本按序同步加载，updater.js 执行完毕才轮到 main.js）。
  setTimeout(function() {
    if (typeof Updater !== 'undefined' && Updater.autoCheck) Updater.autoCheck();
  }, 2000);

  // ── 战役模式（2026-08-07）────────────────────────────────────────
  function showCampaignSelect() {
    if (!campaignScreen) {
      campaignScreen = new CampaignScreen(
        function(campaignId) { startCampaign(campaignId); },
        function() { if (modeSelect) modeSelect.show(); }
      );
    }
    if (modeSelect) modeSelect.hide();
    campaignScreen.show();
  }

  // ── 快速战斗 ──────────────────────────────────────────────────────
  function startQuickBattle() {
    battleMode = 'quick';
    setCampaignContext(false);   // 快速战斗非战役（同步 BattleRules，2026-09-19）
    activeCampaign = null;   // 非战役（2026-08-08）
    Collision.setNoDamageVariance(SETTINGS.noDamageVariance);
    if (modeSelect) modeSelect.hide();
    MAP_SIZE_PX = QUICK_BATTLE_MAP_KM * PX_PER_KM; // 20×20 km
    createPlayer();
    startCommander();
    battleStartTime = Date.now();   // 计时器起点（2026-08-06）
    // 固定排布：玩家在地图中央，敌人在右上角
    var ex = Math.max(MAP_EDGE_MARGIN, MAP_SIZE_PX - ENEMY_SPAWN_GAP);
    var ey = Math.min(MAP_SIZE_PX - MAP_EDGE_MARGIN, ENEMY_SPAWN_GAP);
    enemies.length = 0;              // 保留引用（避免 window.__enemies 等测试引用断开，2026-08-06）
    enemies.push(new EnemyShip(ex, ey));
    allies.length  = 0;              // 同上
    gameStarted = true;
    document.getElementById('btn-exit-battle').style.display = 'block';
    document.getElementById('btn-trophy').style.display = 'block';
    battleStats.init(player, enemies, allies);
    requestAnimationFrame(gameLoop);
  }

  // ── 自定义战斗 ──────────────────────────────────────────────────────
  function showCustomBattle() {
    if (modeSelect) modeSelect.hide();
    if (!customBattleScreen) {
      customBattleScreen = new CustomBattleScreen(
        function(battleConfig) { startCustomBattle(battleConfig); },
        function() { if (modeSelect) modeSelect.show(); }
      );
    }
    customBattleScreen.show();
  }

  function createPlayer() {
    player = new PlayerShip(MAP_SIZE_PX / 2, MAP_SIZE_PX / 2, _selectedShip.config);
    // 古鹰（测试舰）专属词条：出战自动生效（快速战斗/自定义战斗共用此入口）
    if (_selectedShip.id === 'guying') {
      applyTermOverridesToShip(player, loadGuyingTermOverrides());
    }
    for (var gi = 0; gi < _selectedLoadout.mainGun.length; gi++) {
      player.mountMainGun(gi, _selectedLoadout.mainGun[gi]);
    }
    for (var ti = 0; ti < _selectedLoadout.torpedo.length; ti++) {
      player.mountTorpedo(ti, _selectedLoadout.torpedo[ti]);
    }
    var mineLoadout = _selectedLoadout.mine || [];
    for (var mi = 0; mi < mineLoadout.length; mi++) {
      player.mountMine(mi, mineLoadout[mi]);
    }
    var secLoadout = _selectedLoadout.secondary || [];
    for (var si = 0; si < secLoadout.length; si++) {
      player.mountSecondary(si, secLoadout[si]);
    }
    // 战舰技能静态生效（2026-08-08）：mode:'always' 全模式；mode:'battle' 仅战役环境（isCampaign）
    ShipSkills.applyStatic(player, _selectedShip.config, isCampaign);
    // 舰种技能静态生效（2026-10-03）：整个舰种共有的那套（数据 js/data/ship-class-skills.js，
    // 系统 js/systems/class-skills.js）。⚠️ **只对玩家自己的船调**——AI 友军与敌舰不吃
    // （设计文档 §二.2 字人确认）。时机与 ShipSkills.applyStatic 同点（createPlayer 内，
    // 快速战斗/自定义战斗/战役都经这里），且 applyTo 自带 _classSkillsApplied 幂等保护。
    ClassSkills.applyTo(player);
    // 系统注册表（2026-10-01）：独特机制系统（血池/炮火风暴/...）自登记，
    // main.js 不再认识具体系统。ctx 把闭包里的 renderer/Popups/battleStats 传给系统 init。
    GameSystems.initAll(player, _selectedShip.config, Date.now(), {
      renderer: renderer, popups: Popups, battleStats: battleStats
    });
  }

  // 指挥官实例化（全局唯一激活；无激活指挥官 → null）
  function startCommander() {
    var cid = getActiveCommanderId();
    commander = cid ? new CommanderRuntime(cid, player) : null;
    if (commander) commander.applyPassives();
    player.commander = commander;
    renderer.commander = commander;
    ui.commander = commander;
  }

  function startCustomBattle(battleConfig) {
    battleMode = 'custom';
    setCampaignContext(!!(battleConfig && battleConfig.campaign));   // 自定义战斗「视同战役」开关（同步 BattleRules，2026-09-19）
    activeCampaign = null;   // 自定义战斗非真战役（2026-08-08）
    if (customBattleScreen) customBattleScreen.hide();

    // 伤害浮动开关（全局设置，快速/自定义都生效）
    Collision.setNoDamageVariance(SETTINGS.noDamageVariance);

    // 设置地图尺寸
    MAP_SIZE_PX = battleConfig.mapSizeKm * PX_PER_KM;

    createPlayer();
    startCommander();
    battleStartTime = Date.now();   // 计时器起点（2026-08-06）
    enemies.length = 0;              // 保留引用（避免 window.__enemies 等测试引用断开，2026-08-06）
    allies.length  = 0;              // 同上

    var spawnMode = battleConfig.spawnMode || 'random';

    for (var ei = 0; ei < battleConfig.enemies.length; ei++) {
      var ecfg = battleConfig.enemies[ei];
      var defaults = SHIP_TYPE_DEFAULTS[ecfg.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
      var effectiveConfig = mergeEnemyConfig(defaults, ecfg.overrides, ecfg.termOverrides);
      effectiveConfig.shipType = ecfg.shipType;  // 副炮仅战列舰启用
      effectiveConfig.weapons = ecfg.weapons;   // 人机武器装配（2026-08-08：同类统一槽，缺省走人机A）
      effectiveConfig.name = ecfg.name || ('敌人-' + (ei + 1));
      effectiveConfig.length = defaults.length;
      effectiveConfig.width = defaults.width;
      effectiveConfig.color = defaults.color;
      effectiveConfig.bowColor = defaults.bowColor;
      effectiveConfig.outlineColor = defaults.outlineColor;
      effectiveConfig.mainGunInterval = ecfg.overrides && ecfg.overrides.mainGunInterval != null ? ecfg.overrides.mainGunInterval : defaults.mainGunInterval;

      // 不需要 weapon 嵌套（CustomEnemy 不使用 mount 系统）
      effectiveConfig.weapon = {
        mainGun:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
        torpedo:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
      };

      var pos;
      if (spawnMode === 'fixed') {
        // 玩家在地图左下角，敌人排布在右上角
        var cols = Math.ceil(Math.sqrt(battleConfig.enemies.length));
        var spacing = ENEMY_SPAWN_GAP;
        var col = ei % cols;
        var row = Math.floor(ei / cols);
        var px = MAP_SIZE_PX - ENEMY_SPAWN_GAP - col * spacing;
        var py = ENEMY_SPAWN_GAP + row * spacing;
        pos = { x: Math.max(MAP_EDGE_MARGIN, px), y: Math.min(MAP_SIZE_PX - MAP_EDGE_MARGIN, py) };
      } else {
        pos = spawnEnemyPosition(player.x, player.y, enemies, MAP_SIZE_PX);
      }

      var enemy = new CustomEnemy(effectiveConfig, pos.x, pos.y, ecfg.behavior || 'chase', effectiveConfig.name);
      enemies.push(enemy);
    }

    // ── AI 友军（青色，与敌军同构配置）──
    var allyList = battleConfig.allies || [];
    for (var ai = 0; ai < allyList.length; ai++) {
      var acfg = allyList[ai];
      var adefaults = SHIP_TYPE_DEFAULTS[acfg.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
      var aEffective = mergeEnemyConfig(adefaults, acfg.overrides, acfg.termOverrides);
      aEffective.shipType = acfg.shipType;
      aEffective.weapons = acfg.weapons;   // 人机武器装配（2026-08-08）
      aEffective.name = acfg.name || ('友军-' + (ai + 1));
      aEffective.length = adefaults.length;
      aEffective.width = adefaults.width;
      aEffective.color = '#2EC4B6';
      aEffective.bowColor = '#4EE3D4';
      aEffective.outlineColor = '#9FF5EB';
      aEffective.mainGunInterval = acfg.overrides && acfg.overrides.mainGunInterval != null ? acfg.overrides.mainGunInterval : adefaults.mainGunInterval;
      aEffective.weapon = {
        mainGun:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
        torpedo:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
      };

      var apos;
      if (spawnMode === 'fixed') {
        // 友军排布在玩家左侧（与敌军对称）
        var acols = Math.ceil(Math.sqrt(Math.max(1, allyList.length)));
        var aspacing = ENEMY_SPAWN_GAP;
        var acol = ai % acols;
        var arow = Math.floor(ai / acols);
        var apx = ENEMY_SPAWN_GAP + acol * aspacing;
        var apy = MAP_SIZE_PX - ENEMY_SPAWN_GAP - arow * aspacing;
        apos = { x: Math.max(MAP_EDGE_MARGIN, apx), y: Math.min(MAP_SIZE_PX - MAP_EDGE_MARGIN, apy) };
      } else {
        apos = spawnEnemyPosition(player.x, player.y, enemies.concat(allies), MAP_SIZE_PX);
      }

      var allyShip = new CustomEnemy(aEffective, apos.x, apos.y, acfg.behavior || 'chase', aEffective.name, 'friend');
      allies.push(allyShip);
    }

    gameStarted = true;
    document.getElementById('btn-exit-battle').style.display = 'block';
    document.getElementById('btn-trophy').style.display = 'block';
    battleStats.init(player, enemies, allies);
    requestAnimationFrame(gameLoop);
  }

  /**
   * 战役模式启动（2026-08-07）：读取 CAMPAIGN_LIBRARY 预设 → 配置战场。
   * 玩家出生：'center'（地图中央，createPlayer 默认）；敌人生成/航向/阶段走战役数据。
   */
  function startCampaign(campaignId) {
    var campaign = null;
    for (var c = 0; c < CAMPAIGN_LIBRARY.length; c++) {
      if (CAMPAIGN_LIBRARY[c].id === campaignId) { campaign = CAMPAIGN_LIBRARY[c]; break; }
    }
    if (!campaign) return;

    battleMode = 'custom';
    setCampaignContext(true);   // 真战役（同步 BattleRules，2026-09-19）
    activeCampaign = campaign;   // 战役胜负判定（Boss 击沉=胜 / 玩家死或 Boss 到左上角=负，2026-08-08）
    campaignAllyPool = campaign.allyAssist || null;   // 友军援助池（胡德/威尔士亲王，2026-08-08）
    allySpawnLastMin = -1;                            // 召唤分钟标记重置
    if (campaignScreen) campaignScreen.hide();
    Collision.setNoDamageVariance(SETTINGS.noDamageVariance);
    MAP_SIZE_PX = campaign.mapSizeKm * PX_PER_KM;

    createPlayer();
    startCommander();
    battleStartTime = Date.now();
    enemies.length = 0;
    allies.length  = 0;

    // 玩家出生：'center' = 地图中央（createPlayer 已默认）；自定义坐标则覆盖
    if (campaign.playerSpawn && typeof campaign.playerSpawn === 'object') {
      player.x = campaign.playerSpawn.x;
      player.y = campaign.playerSpawn.y;
    }

    for (var ei = 0; ei < campaign.enemies.length; ei++) {
      var ecfg = campaign.enemies[ei];
      var defaults = SHIP_TYPE_DEFAULTS[ecfg.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
      var effectiveConfig = mergeEnemyConfig(defaults, ecfg.overrides, ecfg.termOverrides);
      effectiveConfig.shipType = ecfg.shipType;
      effectiveConfig.weapons = ecfg.weapons;   // 人机武器装配（2026-08-08：俾斯麦装战-人机A）
      effectiveConfig.name = ecfg.name || ('敌人-' + (ei + 1));
      // 船模尺寸：战役配置优先，缺省用舰种默认（2026-08-07 修：原硬编码 defaults 覆盖战役 length/width）
      effectiveConfig.length = ecfg.overrides && ecfg.overrides.length != null ? ecfg.overrides.length : defaults.length;
      effectiveConfig.width  = ecfg.overrides && ecfg.overrides.width  != null ? ecfg.overrides.width  : defaults.width;
      effectiveConfig.color = defaults.color;
      effectiveConfig.bowColor = defaults.bowColor;
      effectiveConfig.outlineColor = defaults.outlineColor;
      effectiveConfig.mainGunInterval = ecfg.overrides && ecfg.overrides.mainGunInterval != null ? ecfg.overrides.mainGunInterval : defaults.mainGunInterval;
      effectiveConfig.heading = ecfg.heading != null ? ecfg.heading : 0;   // 出生航向（战役直线航行）
      effectiveConfig.phases = ecfg.phases || [];                           // 阶段系统（血量阈值）
      effectiveConfig.reinforcements = ecfg.reinforcements || [];           // 增援触发（血量阈值，2026-08-07）
      effectiveConfig.weapon = {
        mainGun:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
        torpedo:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
      };

      // 出生位置：'bottom-right' 预设 = 地图右下角（俾斯麦从右下逃往左上）；自定义坐标则用
      var pos;
      if (typeof ecfg.spawn === 'object') {
        pos = ecfg.spawn;
      } else if (ecfg.spawn === 'bottom-right') {
        pos = { x: MAP_SIZE_PX - ENEMY_SPAWN_GAP, y: MAP_SIZE_PX - ENEMY_SPAWN_GAP };
      } else {
        pos = spawnEnemyPosition(player.x, player.y, enemies, MAP_SIZE_PX);
      }

      var enemy = new CustomEnemy(effectiveConfig, pos.x, pos.y, ecfg.behavior || 'chase', effectiveConfig.name);
      if (ei === 0) enemy.isCampaignBoss = true;   // 战役 Boss 标记（胜负判定：Boss 击沉=胜利，2026-08-08）
      // 增援生成回调（2026-08-07）：cfg 带 reinforcements 时挂上；main.js 生成船并 push enemies
      if (ecfg.reinforcements && ecfg.reinforcements.length > 0 && ecfg.reinforcementPool) {
        var pool = ecfg.reinforcementPool;
        var spawns = ecfg.reinforcementSpawns || ['bottom-left', 'top-right'];
        enemy._spawnReinforcement = function(spawnCfg) {
          // 随机船型 + 随机出生点
          var pick = pool[Math.floor(Math.random() * pool.length)];
          var spName = spawns[Math.floor(Math.random() * spawns.length)];
          var spPos = spName === 'bottom-left'
            ? { x: ENEMY_SPAWN_GAP, y: MAP_SIZE_PX - ENEMY_SPAWN_GAP }
            : { x: MAP_SIZE_PX - ENEMY_SPAWN_GAP, y: ENEMY_SPAWN_GAP };
          var rDefaults = SHIP_TYPE_DEFAULTS[pick.shipType] || SHIP_TYPE_DEFAULTS.cruiser;
          var rCfg = mergeEnemyConfig(rDefaults, {});
          rCfg.shipType = pick.shipType;
          rCfg.name = pick.name + '-' + (spawnCfg.index + 1);   // 按第 N 次触发编号
          rCfg.length = rDefaults.length;
          rCfg.width = rDefaults.width;
          rCfg.color = rDefaults.color;
          rCfg.bowColor = rDefaults.bowColor;
          rCfg.outlineColor = rDefaults.outlineColor;
          rCfg.aura = pick.aura;                                // 友军增益光环
          rCfg.weapon = {
            mainGun:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
            torpedo:  { mountCount: 0, cooldownSec: 0, damage: 0, range: 0 },
          };
          var reinf = new CustomEnemy(rCfg, spPos.x, spPos.y, 'zigzag', rCfg.name);  // 迂回接近
          enemies.push(reinf);
          battleStats.track(reinf);   // 战绩实时注册（2026-08-08：增援须显示在战场战绩里）
          return true;
        };
      }
      enemies.push(enemy);
    }

    gameStarted = true;
    document.getElementById('btn-exit-battle').style.display = 'block';
    document.getElementById('btn-trophy').style.display = 'block';
    battleStats.init(player, enemies, allies);
    requestAnimationFrame(gameLoop);
  }

  // ── 辅助瞄准（软锁定，2026-08-08 重构）──────────────────────────────────
  // 思路（字人拍板）：不降转速——鼠标靠近「被发现敌舰」→ 锁定该敌舰：
  // 瞄准线以正常武器转速自动转向敌舰（预判点）、开火目标吸附到敌舰、鼠标小幅移动不解除（防抖）。
  const AIM_GRAB_R = 50;      // 锁定吸附带：鼠标距敌舰（船模外 50px）内 → 尝试锁定
  const AIM_RELEASE_R = 95;   // 释放半径：锁定后鼠标要移出（船模外 95px）才解除（防抖）
  let aimLock = null;         // 当前锁定的敌舰（跨帧保持；每帧 updateAimLock 维护）

  /**
   * 软锁定状态机：返回本帧应锁定的敌舰（或 null）。
   * - 已有锁定且鼠标还在释放半径内 → 保持（防抖，小幅移动不解除）
   * - 否则在吸附带内找「已被我方探测」的最近敌舰重新锁定
   */
  function updateAimLock(mwx, mwy, player, enemies) {
    var observers = [player].concat(allies);
    if (aimLock && aimLock.isAlive) {
      var relR = (aimLock.width || 20) * 0.6 + AIM_RELEASE_R;
      if (Math.hypot(mwx - aimLock.x, mwy - aimLock.y) <= relR) return aimLock;
    }
    aimLock = null;
    var best = null, bestD = Infinity;
    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      if (!e || !e.isAlive) continue;
      if (!Detection.canSeeShipByAny(observers, e)) continue;   // 未被发现的敌舰不锁
      var grabR = (e.width || 20) * 0.6 + AIM_GRAB_R;
      var d = Math.hypot(mwx - e.x, mwy - e.y);
      if (d <= grabR && d < bestD) { bestD = d; best = e; }
    }
    aimLock = best;
    return best;
  }

  /** 锁定期间的开火目标：对敌舰做提前量预判（aimAhead），弹速读挂载主炮武器 */
  function aimLockTarget(player, target) {
    var sp = 500;
    if (player.mainGunMounts && player.mainGunMounts.length > 0 && player.mainGunMounts[0].weaponId) {
      var w = getWeaponById(player.mainGunMounts[0].weaponId);
      if (w && w.shellSpeed) sp = w.shellSpeed * 0.057;
    }
    return aimAhead(target, player.x, player.y, sp);
  }

  /** 敌人生成位置：距玩家 ≥ ENEMY_SPAWN_MIN_DIST，距其他敌人 ≥ ENEMY_SPAWN_SEP_DIST */
  function spawnEnemyPosition(px, py, existing, mapSize) {
    var ex, ey;
    for (var a = 0; a < ENEMY_SPAWN_MAX_TRIES; a++) {
      ex = MAP_EDGE_MARGIN + Math.random() * (mapSize - 2 * MAP_EDGE_MARGIN);
      ey = MAP_EDGE_MARGIN + Math.random() * (mapSize - 2 * MAP_EDGE_MARGIN);
      if (Math.hypot(ex - px, ey - py) < ENEMY_SPAWN_MIN_DIST) continue;
      var ok = true;
      for (var i = 0; i < existing.length; i++) {
        if (Math.hypot(ex - existing[i].x, ey - existing[i].y) < ENEMY_SPAWN_SEP_DIST) { ok = false; break; }
      }
      if (ok) return { x: ex, y: ey };
    }
    return { x: ex, y: ey };
  }

  /** 战役友军援助（2026-08-08）：左上角召唤胡德/威尔士亲王（互斥，编号 n）；keeprange 保持 5km */
  function spawnCampaignAlly(n) {
    if (!campaignAllyPool || campaignAllyPool.length === 0) return;
    var curKinds = [];
    for (var ci = 0; ci < allies.length; ci++) {
      if (allies[ci] && allies[ci].isAlive && allies[ci]._allyKind) curKinds.push(allies[ci]._allyKind);
    }
    var def = null;
    if (curKinds.indexOf('hood') !== -1) def = findAllyDef('wales');        // 有胡德 → 威尔士亲王
    else if (curKinds.indexOf('wales') !== -1) def = findAllyDef('hood');   // 有威尔士亲王 → 胡德
    else def = campaignAllyPool[Math.random() < 0.5 ? 0 : 1];               // 都没有 → 随机
    if (!def) return;
    // 左上角召唤（地图左上区域 MAP_EDGE_MARGIN ~ MAP_EDGE_MARGIN+CAMPAIGN_ALLY_SPAWN_RANGE 内随机）
    var sx = MAP_EDGE_MARGIN + Math.random() * CAMPAIGN_ALLY_SPAWN_RANGE;
    var sy = MAP_EDGE_MARGIN + Math.random() * CAMPAIGN_ALLY_SPAWN_RANGE;
    var cfg = mergeEnemyConfig(SHIP_TYPE_DEFAULTS.battleship, { hp: def.hp, armor: def.armor }, null);
    cfg.shipType = 'battleship';
    cfg.weapons = { mainGun: 'enemy-bb-mgA', torpedo: 'enemy-bb-tpA', secondary: 'enemy-bb-scA' };  // 战-人机A（其余同默认）
    cfg.aura = def.aura;          // 20km 光环（含自己，main.js allies 循环 updateAllyAura）
    cfg.keepRangeKm = CAMPAIGN_ALLY_KEEP_RANGE_KM;          // 趋向与玩家保持 5km
    // 友军青色（与自定义战斗友军一致，2026-08-09 修：此前用战列默认紫 → 敌我视觉混淆）
    cfg.color = '#2EC4B6'; cfg.bowColor = '#4EE3D4'; cfg.outlineColor = '#9FF5EB';
    var ally = new CustomEnemy(cfg, sx, sy, 'keeprange', def.name + '-' + n, 'friend');
    ally._allyKind = def.kind;
    ally._keepRangeTarget = player;   // keeprange 锚点 = 玩家（2026-08-09 修：此前按敌人距离 → 行动错乱）
    allies.push(ally);
    battleStats.track(ally);      // 战绩实时注册（按 team 分流，进 allies）
  }

  function findAllyDef(kind) {
    for (var fi = 0; fi < campaignAllyPool.length; fi++) {
      if (campaignAllyPool[fi].kind === kind) return campaignAllyPool[fi];
    }
    return null;
  }

  // ── subsystems ────────────────────────────────────────────────────────
  const input    = new InputHandler(gameCanvas);
  const renderer = new Renderer(gameCanvas, minimapCanvas, compassCanvas);
  const ui       = new UIManager();
  const battleStats = new BattleStats();
  const statsScreen = new BattleStatsScreen();
  const finalStatsScreen = new FinalStatsScreen();

  // ── shared projectiles array ──────────────────────────────────────────
  const projectiles = [];

  // ── 测试钩子统一挂载点（2026-09-18 Phase 1 M1）────────────────────────
  // 所有 window.__* 全局变量收归 window.__testHooks 单一对象，减少全局命名空间污染。
  // getter 确保始终返回闭包变量的当前值（player 在 createPlayer 中赋值后自动生效）。
  // 旧属性名通过 defineProperty 保持向后兼容（冒烟脚本可继续读 window.__player 等）。
  window.__testHooks = {
    get player() { return player; },
    get bs() { return battleStats; },
    get enemies() { return enemies; },
    get allies() { return allies; },
    get renderer() { return renderer; },
    get ui() { return ui; },
    get projectiles() { return projectiles; },
    getCam: function() { return { x: (player.isAlive ? player.x : 0) + Camera.offsetX, y: (player.isAlive ? player.y : 0) + Camera.offsetY, zoom: currentZoom }; },
    camOffset: function() { return { x: Camera.offsetX, y: Camera.offsetY, tx: Camera.targetX, ty: Camera.targetY }; },
  };
  // 向后兼容别名（逐步迁移冒烟脚本后删除）
  ['player','bs','enemies','allies','renderer','ui','projectiles'].forEach(function(k) {
    Object.defineProperty(window, '__' + k, { get: function() { return window.__testHooks[k]; }, configurable: true });
  });
  ['getCam','camOffset'].forEach(function(k) {
    Object.defineProperty(window, '__' + k, { get: function() { return window.__testHooks[k]; }, configurable: true });
  });

  // ── 指挥官（全局唯一激活；战斗开始时实例化，见 startCommander）──
  let commander = null;

  // ── damage popups (floating text) ────────────────────────────────────
  // 2026-08-07：飘字子系统拆至 rendering/popups.js（Popups 对象），此处只保留数组引用供 renderer 绘制
  const damagePopups = Popups.list;

  // ── hit counters ──────────────────────────────────────────────────────
  const mainGunHitStat  = { count: 0, expireTime: 0 };
  const torpedoHitStat  = { count: 0, expireTime: 0 };
  const shatterHitStat  = { count: 0, expireTime: 0 };
  const burnHitStat     = { count: 0, expireTime: 0 };
  const floodHitStat    = { count: 0, expireTime: 0 };
  const accessoryHitStat = { count: 0, expireTime: 0, lastType: null };   // 配损命中统计（1 个共用药丸，图标随最近类型变，2026-09-05）
  const wepDamageHitStat = { count: 0, expireTime: 0 };   // 武损命中统计（红色药丸，2026-09-13）
  const mineHitStat     = { count: 0, expireTime: 0 };
  const ricochetHitStat = { count: 0, expireTime: 0 };   // 跳弹计数（灰色胶囊，左上）
  const torpRicHitStat  = { count: 0, expireTime: 0 };   // 鱼雷规避计数（独立灰色胶囊，2026-08-06）
  const mineRicHitStat  = { count: 0, expireTime: 0 };   // 水雷规避计数（独立灰色胶囊，2026-08-06）

  /* ----- damage-popup helpers（移入 Popups，2026-08-07）---- */

  // ── zoom state ────────────────────────────────────────────────────────
  // 缩放档初始化（2026-10-01 修：旧写法 `SETTINGS.zoomIndex || DEFAULT` 会把显式选的第 0 档
  // （falsy 的 0）吞成默认档——教训分册「0 || 默认值」同类；改显式 null/undefined 判断）
  const savedZoomIdx = SETTINGS.zoomIndex;
  let zoomIndex = (savedZoomIdx != null && savedZoomIdx >= 0)
    ? Math.max(0, Math.min(ZOOM_LEVELS.length - 1, savedZoomIdx))
    : DEFAULT_ZOOM_INDEX;
  let currentZoom = ZOOM_LEVELS[DEFAULT_ZOOM_INDEX];

  // ── game-over flag ────────────────────────────────────────────────────
  let gameOver   = false;
  let playerWon  = false;

  // ── 战斗结束唯一出口（2026-10-25）────────────────────────────────────
  // 以前「结束」在 6 个分支里各写一遍 5 行（gameOver / playerWon / battleEndTime /
  // battleStats.endBattle / ui.showGameOver），相机冻结还单独挂在循环末尾补一句。
  // 现在只有这一个出口：以后加「平局 / 撤退 / 战役失败但可继续」只改这里。
  function finishBattle(won, now) {
    gameOver      = true;
    playerWon     = won;
    battleEndTime = now;            // 冻结计时（2026-08-06）
    battleStats.endBattle(now);     // 冻结战绩时长
    ui.showGameOver(won);
    Camera.freeze();                // 停跟随、偏移保持原地（2026-10-18）
  }

  // ── observer camera（玩家阵亡后的旁观视角，仅自定义战斗）──
  //    旁观速度常量已搬至 camera.js（单一来源 OBSERVER_CAM_SPEED），此处只取引用。
  let observerCam = { x: 0, y: 0 };

  // ── 相机偏移：玩家活着时相机 = 玩家 + Camera.offsetX/Y ──
  // 状态与逐帧逻辑已搬至 js/systems/camera.js（可单测）；此处只初始化一次
  // （重开关卡走 location.reload() → 每次战斗干净初始），每帧依赖由 gameLoop 现传。
  Camera.init(input);

  // ── timing ────────────────────────────────────────────────────────────
  let lastTime = performance.now();
  let lastMainGunFireTime = 0;
  let lastSalvoSyncTime = 0;   // 齐射副炮独立节流（2026-09-13 字人修订：主炮冷却不影响副炮尝试）
  let lastTorpedoFireTime = 0;
  let lastMineFireTime    = 0;

  // ── restart handler ───────────────────────────────────────────────────
  document.getElementById('btn-restart').addEventListener('click', function() {
    location.reload();
  });

  // ── 最终战绩（战斗结束结算界面查看玩家个人数据）──────────────────────
  document.getElementById('btn-final-stats').addEventListener('click', function() {
    finalStatsScreen.show(battleStats.playerFinal());
  });

  // ── exit battle button (top-right) ───────────────────────────────────────
  document.getElementById('btn-exit-battle').addEventListener('click', function() {
    location.reload();
  });

  // ── trophy button (top-left) — 查看战绩 ──────────────────────────────────
  function openStatsScreen() {
    statsScreen.show(function() {
      var snap = battleStats.snapshot();
      return { left: [snap.player].concat(snap.allies || []), right: snap.enemies };
    }, null);
  }
  document.getElementById('btn-trophy').addEventListener('click', function() {
    if (statsScreen.isOpen()) return;
    openStatsScreen();
  });

  // ── Z 键按住显示战绩，松开关闭 ───────────────────────────────────────────
  let statsOpenedByKey = false;

  /* ====================================================================== */
  /*  Main Loop                                                              */
  /* ====================================================================== */
  function gameLoop(timestamp) {
    if (!gameStarted) { requestAnimationFrame(gameLoop); return; }
    requestAnimationFrame(gameLoop);

    var dt = (timestamp - lastTime) / 1000;
    lastTime = timestamp;
    if (dt <= 0) dt = 0.016;
    if (dt > 0.1) dt = 0.1;

    var now = Date.now();

    // ── zoom (M/N keys) ──────────────────────────────────────────────
    if (input.isActionJustPressed('zoomIn') && zoomIndex < ZOOM_LEVELS.length - 1) {
      zoomIndex++;
    }
    if (input.isActionJustPressed('zoomOut') && zoomIndex > 0) {
      zoomIndex--;
    }
    var targetZoom = ZOOM_LEVELS[zoomIndex];
    var zoomGap = targetZoom - currentZoom;
    if (Math.abs(zoomGap) < 0.001) {
      currentZoom = targetZoom;
    } else {
      currentZoom += zoomGap * (1 - Math.exp(-dt / ZOOM_SMOOTH_TAU));
    }
    renderer.setZoom(currentZoom);

    // ── camera ────────────────────────────────────────────────────────
    // 战斗结束：相机冻结（不跟随、鼠标甩不动），仅方向键可移（2026-10-18 字人要求）
    // 玩家活着：相机 = 玩家 + 手动偏移（方向键移动、L 还原，2026-08-07）；跟随模式下偏移常驻中点
    // 旁观（自定义战斗 + 玩家阵亡）：WSAD 自由移动镜头（沿用 observerCam）
    if (gameOver) {
      Camera.updateEnded(dt, player.isAlive ? player : observerCam, currentZoom, MAP_SIZE_PX);
    } else if (player.isAlive) {
      observerCam.x = player.x;
      observerCam.y = player.y;
      Camera.updateAlive(dt, player, currentZoom, MAP_SIZE_PX);
    } else {
      // 阵亡：目标立即归零、当前值沿 lerp 滑回中点（~0.3s，理由见 camera.js updateDead）
      Camera.updateDead(dt);
      if (battleMode === 'custom') {
        var ospd = Camera.OBSERVER_SPEED * dt;
        if (input.isActionHeld('moveUp')) observerCam.y -= ospd;
        if (input.isActionHeld('moveDown')) observerCam.y += ospd;
        if (input.isActionHeld('turnLeft')) observerCam.x -= ospd;
        if (input.isActionHeld('turnRight')) observerCam.x += ospd;
        observerCam.x = Math.max(0, Math.min(MAP_SIZE_PX, observerCam.x));
        observerCam.y = Math.max(0, Math.min(MAP_SIZE_PX, observerCam.y));
      }
    }
    var camX = (player.isAlive ? player.x : observerCam.x) + Camera.offsetX;
    var camY = (player.isAlive ? player.y : observerCam.y) + Camera.offsetY;
    renderer.setCamera(camX, camY);
    input.updateMouseWorld(camX, camY, renderer.width, renderer.height, currentZoom);

    // ── Z 键按住显示战绩（松开关闭）──────────────────────────────────────
    if (input.isActionHeld('stats')) {
      if (!statsOpenedByKey && !statsScreen.isOpen()) {
        statsOpenedByKey = true;
        openStatsScreen();
      }
    } else if (statsOpenedByKey) {
      statsOpenedByKey = false;
      if (statsScreen.isOpen()) statsScreen.hide();
    }

    // ── update (skip if game over) ────────────────────────────────────
    if (!gameOver) {
      // 红方 = 敌军 + AI 友军（统一处理状态/特效/烧水）
      var redShips = enemies.concat(allies);

      // player（玩家阵亡后不再驱动，交旁观镜头）
      if (player.isAlive) {
        player.update(dt, input);
        player.updateWake();
      }

      // 战舰主动技能触发（2026-08-09 沙皇「红场之魂」：按键 C，冷却 110s；玩家存活时）
      if (player.isAlive && !statsScreen.isOpen()) {
        ShipSkills.triggerActive(player, now, input);
        // 舰种主动技能触发（2026-11-15）：q/e/r 三个，冷却各自独立；条件同上（玩家存活 + 战绩屏关闭）。
        // ⚠️ 只对 player 调（舰种技能只对玩家生效，与 applyTo 同一口径；单测第 85 节有反向守卫）
        ClassSkills.triggerActive(player, now, input);
      }

      // 指挥官每帧更新（buff 过期 / Z计划净化节拍 / 窗口重置；华晟畏惧光环需 enemies；玩家阵亡后停止）
      if (commander && player.isAlive) {
        commander.update(dt, now, enemies);
      }

      // 战舰技能光环（2026-08-08）：本方战舰（玩家+友军）的 aura 技能给 12km 内本方挂 buff
      ShipSkills.updateAuras(now, [player].concat(allies), isCampaign);
      // A-140A 锁定系统（2026-09-19）：随机锁定 / 配额归还 / 主动锁定降级 / 我舰图标 / 扇形判定增益
      LockSystem.update(player, enemies, now, isCampaign);
      // A-140A 特殊武损命中统计（2026-10-18 字人要求与普通武损同一药丸）：锁定触发的特殊武损次数
      //   由 LockSystem 经 per-caster 计数器（_lockSpecWepCount）回传；只统计玩家（友军不计，口径同「只统计我方弹丸」）
      var specWepN = player._lockSpecWepCount || 0;
      player._lockSpecWepCount = 0;
      if (specWepN > 0) {
        if (now > wepDamageHitStat.expireTime) wepDamageHitStat.count = 0;
        wepDamageHitStat.count += specWepN;
        wepDamageHitStat.expireTime = now + HIT_STAT.duration;
      }
      for (var lk = 0; lk < allies.length; lk++) LockSystem.update(allies[lk], enemies, now, isCampaign);
      // 独特机制系统每帧（2026-10-01）：系统自登记，main.js 统一调 updateAll（含炮火风暴/血池/...）
      GameSystems.updateAll([player].concat(allies), dt, now, allies, enemies);
      // 限时护盾到期清理（红场之魂 2026-08-09）：玩家 + 友军（只减限时部分，不动普通盾）
      if (player.cleanupTimedShields) player.cleanupTimedShields(now);
      for (var ts2 = 0; ts2 < allies.length; ts2++) {
        if (allies[ts2] && allies[ts2].cleanupTimedShields) allies[ts2].cleanupTimedShields(now);
      }

      // 敌人（多敌遍历；目标 = 玩家 + 友军）
      var hostileForEnemies = [player].concat(allies);
      for (var ei = 0; ei < enemies.length; ei++) {
        var e = enemies[ei];
        if (!e || !e.isAlive) continue;

        if (e instanceof CustomEnemy) {
          if (e.checkPhase) e.checkPhase();   // 战役 Boss 阶段检测（血量阈值，2026-08-07）
          // 增援触发（2026-08-07）：血量降至阈值 → 生成增援船进 enemies
          if (e.checkReinforcements && e._spawnReinforcement) {
            e.checkReinforcements(now, e._spawnReinforcement);
          }
          // 友军增益光环（2026-08-07）：提尔皮茨/欧根亲王给 22km 内友军 addBuff
          if (e.updateAllyAura) e.updateAllyAura(now, enemies);
          e.aiUpdate(dt, hostileForEnemies, now);
          e.updateWake();
          e.aiAttack(hostileForEnemies, projectiles, now, enemies);  // 红方共享视野 = enemies
        } else {
          // 快速战斗的 EnemyShip
          e.update(dt, player, projectiles, now, enemies);  // 红方共享视野 = enemies
          e.updateWake();
        }
      }

      // 战役友军援助（2026-08-08）：每 2n 分钟（n≥0 整数，含开局）存活玩家方增援 < 2 → 左上角召唤，编号 n
      if (activeCampaign && campaignAllyPool && !gameOver) {
        var elapsedMin = Math.floor((now - battleStartTime) / 60000);
        if (elapsedMin % 2 === 0 && elapsedMin !== allySpawnLastMin) {
          allySpawnLastMin = elapsedMin;
          var aliveAllies = 0;
          for (var ac = 0; ac < allies.length; ac++) if (allies[ac] && allies[ac].isAlive) aliveAllies++;
          if (aliveAllies < 2) spawnCampaignAlly(elapsedMin / 2);
        }
      }

      // AI 友军（目标 = 敌军）
      for (var al = 0; al < allies.length; al++) {
        var ally = allies[al];
        if (!ally || !ally.isAlive) continue;
        if (ally.cleanBuffs) ally.cleanBuffs(now);                       // buff 过期清理（2026-08-08）
        if (ally.updateAllyAura) ally.updateAllyAura(now, [player].concat(allies));  // 蓝方光环（含自己，2026-08-08）
        ally.aiUpdate(dt, enemies, now);
        ally.updateWake();
        ally.aiAttack(enemies, projectiles, now, [player].concat(allies));  // 蓝方共享视野
      }

      // wake particles (ship)
      if (SETTINGS.fx.wakeParticles && player.isAlive) renderer.spawnWakeParticles(player);
      for (var ei2 = 0; ei2 < redShips.length; ei2++) {
        var e2 = redShips[ei2];
        if (e2 && e2.isAlive && Detection.canSeeShip(player, e2)
            && SETTINGS.fx.wakeParticles) {
          renderer.spawnWakeParticles(e2);
        }
      }
      renderer.updateWakeParticles(dt);

      // wake particles (torpedo) — 只对可见的鱼雷生成尾迹粒子
      for (var tpi = 0; tpi < projectiles.length; tpi++) {
        var tp = projectiles[tpi];
        if (tp && tp.alive && tp instanceof TorpedoProjectile
            && Detection.canSeeProjectile(player, tp)) {
          renderer.spawnTorpedoWakeParticles(tp);
        }
      }
      renderer.updateTorpedoParticles(dt);

      // fire particles (burn)
      renderer.spawnFireParticles(player, redShips);
      renderer.updateFireParticles(dt);

      // projectiles
      for (var pi = 0; pi < projectiles.length; pi++) {
        projectiles[pi].update(dt);
      }

      // ── player firing（放在碰撞之前，使新布雷当帧即可引爆判定）──
      // 战绩窗口打开期间禁止开火（移动/转向/缩放不受影响）；玩家阵亡后不响应
      if (!statsScreen.isOpen() && player.isAlive) {
        var mwx = input.mouseWorldX;
        var mwy = input.mouseWorldY;
        // 瞄准方向使用未钳位的准星坐标（避免边界外偏离）
        var aimAngle = Math.atan2(mwx - player.x, -(mwy - player.y));
        // 辅助瞄准（软锁定，2026-08-08 重构）：鼠标靠近被发现敌舰 → 锁定；
        // 瞄准线目标 = 敌舰预判点（正常武器转速自动转过去），开火目标吸附到敌舰
        if (SETTINGS.aimAssist) {
          var locked = updateAimLock(mwx, mwy, player, enemies);
          if (locked) {
            var lt = aimLockTarget(player, locked);
            mwx = lt.x; mwy = lt.y;          // 开火目标 = 敌舰预判点（准星距离吸附）
            aimAngle = Math.atan2(mwx - player.x, -(mwy - player.y));
          }
        }
        player.updateAimHeading(aimAngle, dt);
        var cmx = Math.max(0, Math.min(MAP_SIZE_PX, mwx));
        var cmy = Math.max(0, Math.min(MAP_SIZE_PX, mwy));
        var distToClick = Math.hypot(cmx - player.x, cmy - player.y);

        if (input.isActionJustPressed('mainGun')) {
          // 主炮尝试（射程内才打；冷却/射界由 mount 自判）——动态射程（卢金斯，2026-09-13）
          var shells = distToClick <= player.getMainGunRangePx() ? player.fireMainGun(cmx, cmy, now) : [];
          if (shells.length > 0) {
            projectiles.push.apply(projectiles, shells); lastMainGunFireTime = now;
            // 开火震动已删（2026-08-30 字人反馈）
          }
          // 齐射模式（卢金斯 2026-09-13 字人修订）：副炮与主炮**共用发射键、各自独立判定**——
          //   每次按发射键尝试发射一次主炮和一次副炮；主炮冷却/射程不影响副炮（副炮自判射程/射界/装填）
          var salvoShells = player.fireSecondaryWithMainGun(cmx, cmy, now);
          if (salvoShells.length > 0) projectiles.push.apply(projectiles, salvoShells);
        }
        if (input.isActionJustPressed('torpedo')) {
          var torps = player.fireTorpedo(cmx, cmy, now);
          if (torps.length > 0) { projectiles.push.apply(projectiles, torps); lastTorpedoFireTime = now; }
        }
        if (input.isActionHeld('mainGun') && now - lastMainGunFireTime >= player.weaponCfg.mainGun.holdInterval) {
          // 主炮尝试（射程内才打）——动态射程（卢金斯，2026-09-13）
          if (distToClick <= player.getMainGunRangePx()) {
            var shells2 = player.fireMainGun(cmx, cmy, now);
            if (shells2.length > 0) {
              projectiles.push.apply(projectiles, shells2); lastMainGunFireTime = now;
            }
          }
          // 齐射副炮尝试（与主炮同频 = holdInterval 节流，lastSalvoSyncTime 独立计时：
          //   主炮冷却中副炮仍按节奏尝试，主炮失败不拖累副炮）
          if (now - lastSalvoSyncTime >= player.weaponCfg.mainGun.holdInterval) {
            lastSalvoSyncTime = now;
            var salvoShells2 = player.fireSecondaryWithMainGun(cmx, cmy, now);
            if (salvoShells2.length > 0) projectiles.push.apply(projectiles, salvoShells2);
          }
        }
        if (input.isActionHeld('torpedo') && now - lastTorpedoFireTime >= player.weaponCfg.torpedo.holdInterval) {
          var torps2 = player.fireTorpedo(cmx, cmy, now);
          if (torps2.length > 0) { projectiles.push.apply(projectiles, torps2); lastTorpedoFireTime = now; }
        }

        // 滚轮布雷（每格布一颗，受 0.5s 布雷间隔节流）
        var minePulse = input.getActionPulse('mine');
        for (var wi = 0; wi < minePulse; wi++) {
          if (now - lastMineFireTime < player.weaponCfg.mine.holdInterval) break;
          var mines = player.fireMine(now);
          if (mines.length > 0) { projectiles.push.apply(projectiles, mines); lastMineFireTime = now; }
          else break;
        }

        // 指挥官主动技能（T=主动，G=副主动；无副主动时 useActive(1) 静默无效）
        if (commander) {
          if (input.isActionJustPressed('commanderMain')) commander.useActive(0, now, allies);
          if (input.isActionJustPressed('commanderSecondary')) commander.useActive(1, now);
        }
      }

      // 副炮自动开火（AI 行为，不受战绩窗口暂停限制；设置可关闭；玩家阵亡后不响应）
      if (SETTINGS.secondaryAuto && player.isAlive) {
        var secShells = player.autoFireSecondaries(enemies, now);
        if (secShells.length > 0) {
          projectiles.push.apply(projectiles, secShells);
          // 副炮开火震动已删（2026-08-30 字人反馈）
        }
      }

      // collisions
      var hitEvents = [];
      Collision.checkAll(player, enemies, allies, projectiles, hitEvents, now);
      Collision.checkShipBump(player, enemies.concat(allies), dt);
      Collision.checkMines(player, enemies, allies, projectiles, hitEvents, now);
      Collision.cullDead(projectiles);

      // process hit events
      for (var hi = 0; hi < hitEvents.length; hi++) {
        var ev = hitEvents[hi];
        // 跳弹（主炮/鱼雷/水雷被规避）：等效没命中（不计战绩/飘字/命中统计），独立灰色胶囊计数
        //   ricochet=主炮副炮 / torpedoRicochet=鱼雷 / mineRicochet=水雷（2026-08-06）
        if (ev.type === 'ricochet' || ev.type === 'torpedoRicochet' || ev.type === 'mineRicochet') {
          var ricStat = ev.type === 'torpedoRicochet' ? torpRicHitStat
            : ev.type === 'mineRicochet' ? mineRicHitStat : ricochetHitStat;
          // 只统计我方弹丸被规避（2026-08-06 字人确认：敌弹打我方被规避不计入，避免误导）
          if (ev.isPlayerProjectile) {
            if (now > ricStat.expireTime) ricStat.count = 0;
            ricStat.count += 1;
            ricStat.expireTime = now + HIT_STAT.duration;
          }
          // 2026-08-06：我方被敌弹命中但触发跳弹 → 玩家处飘「规避」灰字（即时反馈，非统计）
          if (!ev.isPlayerProjectile && ev.target === player && player.isAlive) {
            var rcPos = renderer.worldToScreen(ev.x, ev.y);
            Popups.spawnDamagePopup(rcPos.x, rcPos.y, 0, false, false, false, true);
          }
          continue;
        }
        battleStats.onHit(ev);  // 战绩统计
        // A-140A 锁定系统（2026-09-19）：副炮命中 → 主动锁定切换（15s 保持）；主炮命中 → 火力层 +1
        if (ev.attacker && LockSystem.hasLock(ev.attacker)) {
          if (ev.type === 'secondary') LockSystem.onSecondaryHit(ev.attacker, ev.target, now);
          else if (ev.type === 'mainGun') LockSystem.onMainHit(ev.attacker, ev.target, now);
        }
        var evTarget = ev.target;
        if (evTarget && evTarget.team === 'enemy' && evTarget.isAlive) {
          // 蓝方弹丸命中敌舰 → 敌舰处飘字
          var screenPos = renderer.worldToScreen(ev.x, ev.y);
          Popups.spawnDamagePopup(screenPos.x, screenPos.y, ev.damage, ev.isCritical, ev.isPenetration, ev.isExecute);
        } else if (evTarget === player && player.isAlive) {
          // 敌弹命中玩家 → 受击摇晃 + 飘字
          renderer.triggerHitFeedback(ev.x, ev.y);
          var screenPos2 = renderer.worldToScreen(ev.x, ev.y);
          Popups.spawnDamagePopup(screenPos2.x, screenPos2.y, ev.damage, ev.isCritical, ev.isPenetration, ev.isExecute);
        } else if (evTarget && evTarget.team === 'friend' && evTarget.isAlive) {
          // 敌弹命中友军 → 友军处飘字（无屏幕摇晃）
          var screenPos3 = renderer.worldToScreen(ev.x, ev.y);
          Popups.spawnDamagePopup(screenPos3.x, screenPos3.y, ev.damage, ev.isCritical, ev.isPenetration, ev.isExecute);
        }
        if (ev.isPlayerProjectile) {
          var stat = ev.type === 'mainGun' ? mainGunHitStat
            : ev.type === 'torpedo' ? torpedoHitStat
            : ev.type === 'mine' ? mineHitStat : null;
          if (stat) {
            if (now > stat.expireTime) stat.count = 0;
            stat.count += 1;
            stat.expireTime = now + HIT_STAT.duration;
          }
        }
        if (ev.isPlayerProjectile && ev.isShatter) {
          if (now > shatterHitStat.expireTime) shatterHitStat.count = 0;
          shatterHitStat.count += 1;
          shatterHitStat.expireTime = now + HIT_STAT.duration;
        }
        if (ev.isPlayerProjectile && ev.isBurn) {
          if (now > burnHitStat.expireTime) burnHitStat.count = 0;
          burnHitStat.count += 1;
          burnHitStat.expireTime = now + HIT_STAT.duration;
        }
        if (ev.isPlayerProjectile && ev.isFlood) {
          if (now > floodHitStat.expireTime) floodHitStat.count = 0;
          floodHitStat.count += 1;
          floodHitStat.expireTime = now + HIT_STAT.duration;
        }
        if (ev.isPlayerProjectile && ev.isAccessory) {
          // 配损命中统计（2026-09-05）：1 个共用橙红药丸，图标随最近触发类型变
          if (now > accessoryHitStat.expireTime) accessoryHitStat.count = 0;
          accessoryHitStat.count += 1;
          accessoryHitStat.expireTime = now + HIT_STAT.duration;
          accessoryHitStat.lastType = ev.accessoryType || 'rudderDamage';
        }
        // 武损命中统计（2026-09-13）：玩家弹丸触发武损时 +1（红色药丸，同燃烧色）
        if (ev.isPlayerProjectile && ev.isWeaponDamage) {
          if (now > wepDamageHitStat.expireTime) wepDamageHitStat.count = 0;
          wepDamageHitStat.count += 1;
          wepDamageHitStat.expireTime = now + HIT_STAT.duration;
        }
      }

      // 指挥官命中处理（战争局势触发 + Z计划计数/回血）
      if (commander && player.isAlive) {
        commander.onHitEvents(hitEvents, now);
        var heals = commander.drainHealEvents();
        for (var hl = 0; hl < heals.length; hl++) {
          var screenH = renderer.worldToScreen(player.x, player.y);
          // 2026-08-07：飘字显示请求量（display，含溢出），战绩只统计实际回复量（amount）
          Popups.spawnHealPopup(screenH.x, screenH.y, heals[hl].display != null ? heals[hl].display : heals[hl].amount);
          battleStats.onHeal(heals[hl].amount);  // 最终战绩：回复量
        }
        // 技能伤害红字飘字（杜尔曼水镜盾爆炸 2026-08-06）
        var skillHits = commander.drainSkillHits ? commander.drainSkillHits() : [];
        for (var shi = 0; shi < skillHits.length; shi++) {
          var shPos = renderer.worldToScreen(skillHits[shi].x, skillHits[shi].y);
          Popups.spawnDamagePopup(shPos.x, shPos.y, skillHits[shi].damage, false, false, false);
        }
      }

      // 玩家回血统一飘字（2026-11-08 字人要求「玩家所有回血都要飘字」）：
      //   所有走 Ship.gainHp 的回血（不屈 / 血池返还 / 后续新增）都在这里出绿字，不依赖各系统自觉。
      if (player.isAlive && player._healLog && player._healLog.length) {
        var healPos = renderer.worldToScreen(player.x, player.y);
        for (var hli = 0; hli < player._healLog.length; hli++) {
          var hlEntry = player._healLog[hli];
          // 飘字用**理论回复量**（含溢出）；战绩只记实际回血（2026-11-08 字人要求）
          var hlDisplay = hlEntry.display != null ? hlEntry.display : hlEntry;
          var hlAmount = hlEntry.amount != null ? hlEntry.amount : hlEntry;
          Popups.spawnHealPopup(healPos.x, healPos.y, hlDisplay);
          if (hlAmount > 0) battleStats.onHeal(hlAmount);
        }
        player._healLog.length = 0;
      }

      // 玩家侧技能伤害跳字（2026-10-18 字人要求「玩家造成的所有伤害都应当跳字」）：
      //   A-140A 炮火风暴附加伤害 + 阳炎-利刃水雷固定伤害。此前走 takeDamage('skill') 不经
      //   hitEvents → 无飘字。机制系统拿不到 renderer，世界坐标由这里转屏幕坐标。
      var skillPops = [];
      if (typeof A140AStorm !== 'undefined' && A140AStorm.drainPopups) skillPops = skillPops.concat(A140AStorm.drainPopups());
      if (typeof YanyinHunt !== 'undefined' && YanyinHunt.drainPopups) skillPops = skillPops.concat(YanyinHunt.drainPopups());
      if (typeof WisconsinHeavy !== 'undefined' && WisconsinHeavy.drainPopups) skillPops = skillPops.concat(WisconsinHeavy.drainPopups());
      for (var spi = 0; spi < skillPops.length; spi++) {
        var spPos = renderer.worldToScreen(skillPops[spi].x, skillPops[spi].y);
        Popups.spawnDamagePopup(spPos.x, spPos.y, skillPops[spi].damage, false, false, false);
      }

      // shatter state update
      if (player.isAlive) Armor.updateShatter(player, now);
      for (var ei3 = 0; ei3 < redShips.length; ei3++) {
        if (redShips[ei3] && redShips[ei3].isAlive) {
          Armor.updateShatter(redShips[ei3], now);
        }
      }

      // burn update (process ticks, spawn popups)
      if (player.isAlive) {
        var burnEvents = player.updateBurn(now);
        for (var bi = 0; bi < burnEvents.length; bi++) {
          var be = burnEvents[bi];
          battleStats.onDot(be.damage, player, be.attacker, 'burn');  // 战绩：玩家承伤（燃烧分类）
          var screenB = renderer.worldToScreen(player.x, player.y);
          Popups.spawnBurnPopup(screenB.x, screenB.y, be.damage);
        }
      }
      for (var bi2 = 0; bi2 < redShips.length; bi2++) {
        var eBurn = redShips[bi2];
        if (eBurn && eBurn.isAlive) {
          var eBurnEvents = eBurn.updateBurn(now);
          for (var bi3 = 0; bi3 < eBurnEvents.length; bi3++) {
            var ebe = eBurnEvents[bi3];
            battleStats.onDot(ebe.damage, eBurn, ebe.attacker, 'burn');  // 战绩：敌/友舰承伤（燃烧分类）
            var screenE = renderer.worldToScreen(eBurn.x, eBurn.y);
            Popups.spawnBurnPopup(screenE.x, screenE.y, ebe.damage);
          }
        }
      }

      // flood update (process ticks, spawn popups)
      if (player.isAlive) {
        var floodEvents = player.updateFlood(now);
        for (var fi = 0; fi < floodEvents.length; fi++) {
          var fe = floodEvents[fi];
          battleStats.onDot(fe.damage, player, fe.attacker, 'flood');  // 战绩：玩家承伤（漏水分类）
          var screenF = renderer.worldToScreen(player.x, player.y);
          Popups.spawnFloodPopup(screenF.x, screenF.y, fe.damage);
        }
      }
      for (var fi2 = 0; fi2 < redShips.length; fi2++) {
        var eFlood = redShips[fi2];
        if (eFlood && eFlood.isAlive) {
          var eFloodEvents = eFlood.updateFlood(now);
          for (var fi3 = 0; fi3 < eFloodEvents.length; fi3++) {
            var efe = eFloodEvents[fi3];
            battleStats.onDot(efe.damage, eFlood, efe.attacker, 'flood');  // 战绩：敌/友舰承伤（漏水分类）
            var screenF = renderer.worldToScreen(eFlood.x, eFlood.y);
            Popups.spawnFloodPopup(screenF.x, screenF.y, efe.damage);
          }
        }
      }

      // 战绩：帧末检测新死亡（胜利判定之前）
      battleStats.checkDeaths([player].concat(allies, enemies));
      // 阳炎-利刃「鱼雷追击」：击沉/助攻 → 永久水雷装填加速层（2026-10-01）
      //   击沉者取 target._stats.lastAttacker（battleStats 已在每次承伤时写入，帧末即最后一击来源）。
      //   幂等：每艘被击沉的舰只结算一次（_yanyinKillScanned），与 GameSystems 路径重复调用安全。
      if (typeof YanyinPursuit !== 'undefined' && YanyinPursuit.scanKills) YanyinPursuit.scanKills([player].concat(allies, enemies), now);

      // game-over check（战役：Boss 击沉=胜、玩家死或 Boss 到左上角=负；自定义战斗：一方全灭；快速战斗：旧规则）
      if (battleMode === 'custom') {
        if (activeCampaign) {
          // ── 战役胜负（2026-08-08）：无需清所有敌舰（增援不挡胜利）──
          var boss = null;
          for (var bi = 0; bi < enemies.length; bi++) {
            if (enemies[bi] && enemies[bi].isCampaignBoss) { boss = enemies[bi]; break; }
          }
          if (boss && !boss.isAlive) {
            finishBattle(true, now);         // Boss 被击沉 → 胜利
          } else if (!player.isAlive) {
            finishBattle(false, now);        // 玩家被击沉 → 失败
          } else if (boss && boss.isAlive && boss.x <= MAP_SIZE_PX * 0.15 && boss.y <= MAP_SIZE_PX * 0.15) {
            finishBattle(false, now);        // Boss 抵达左上角（逃出封锁）→ 失败
          }
        } else {
          var blueAlive = [player].concat(allies).some(function(s) { return s && s.isAlive; });
          var redAlive = enemies.some(function(e) { return e && e.isAlive; });
          if (!redAlive) {
            finishBattle(true, now);
          } else if (!blueAlive) {
            finishBattle(false, now);
          }
        }
      } else if (!player.isAlive) {
        finishBattle(false, now);
      } else if (enemies.every(function(e) { return !e.isAlive; })) {
        finishBattle(true, now);
      }
      // 相机冻结已收进 finishBattle（2026-10-25）：不再在循环末尾逐帧补一句。
      //   旧实现 Camera.reset() 归零后下一帧 updateAlive 又拉起跟随 → 结算画面相机持续漂移（2026-10-18 修）。
    }

    // ── damage popup update ────────────────────────────────────────────
    Popups.update(dt);
    Popups.updateKillToasts(dt, battleStats);          // 击杀飞入特效数组清理（"你击沉了 XXX"，2026-08-06）
    ui.updateKillToasts(battleStats.getKillToasts());   // DOM 层同步（盖过 game-over 遮罩）
    renderer.updateHitFeedback(dt);
    // 开火震动 updateFireRecoil 已删（2026-08-30 字人反馈）

    // ── render ──────────────────────────────────────────────────────────
    renderer._mx = input.mouseX;
    renderer._my = input.mouseY;
    renderer._aimLock = SETTINGS.aimAssist ? aimLock : null;   // 辅助瞄准锁定标记（2026-08-08）
    renderer._observeAll = (!player.isAlive && battleMode === 'custom') || false;
    renderer._allies = allies;  // 蓝方共享视野观察者（renderer 内 obs = [player].concat(_allies)）
    var mouseWorld = { x: input.mouseWorldX, y: input.mouseWorldY };
    renderer.render(
      player, enemies.concat(allies), projectiles, mouseWorld,
      damagePopups,
      { mainGun: mainGunHitStat, torpedo: torpedoHitStat, shatter: shatterHitStat, burn: burnHitStat, flood: floodHitStat, mine: mineHitStat, ricochet: ricochetHitStat, torpedoRicochet: torpRicHitStat, mineRicochet: mineRicHitStat, accessory: accessoryHitStat, weaponDamage: wepDamageHitStat },
      now
    );
    renderer.renderMinimap(player, enemies, allies);
    renderer.renderCompass(player);

    // ── 被发现警示（红方任一敌舰水上探测到玩家 → 小地图右侧黄底标签亮起）──
    var detected = !!(player && player.isAlive) && Detection.isDetectedBy(enemies, player);
    var dw = document.getElementById('detected-warning');
    if (dw) dw.style.display = detected ? 'block' : 'none';

    // ── 战斗计时（屏幕顶部中央，xx:xx 分:秒，2026-08-06；战斗结束后冻结不再增长）──
    var clockNow = battleEndTime > 0 ? battleEndTime : now;
    var elapsedSec = Math.max(0, Math.floor((clockNow - battleStartTime) / 1000));
    var elTimer = document.getElementById('battle-timer');
    if (elTimer) {
      var mmT = Math.floor(elapsedSec / 60);
      var ssT = elapsedSec % 60;
      elTimer.textContent = (mmT < 10 ? '0' + mmT : mmT) + ':' + (ssT < 10 ? '0' + ssT : ssT);
    }

    // ── HUD update ──────────────────────────────────────────────────────
    ui.update(player, now, cmx, cmy);
    if (ui.updateBossBar) ui.updateBossBar(enemies);   // 战役 Boss 血条（2026-08-07）
    renderer._bossBarVisible = ui.elBossWrap ? ui.elBossWrap.style.display !== 'none' : false;   // 增益图标避让（2026-08-09）

    // ── end-of-frame cleanup ────────────────────────────────────────────
    input.endFrame();
  }

  // ── idle render before game starts ───────────────────────────────────
  function idleRender() {
    if (gameStarted) return;
    if (!player) { requestAnimationFrame(idleRender); return; }
    renderer.setCamera(player.x, player.y);
    renderer.render(player, enemies, projectiles, null, [], null, Date.now());
    renderer.renderMinimap(player, enemies);
    requestAnimationFrame(idleRender);
  }
  requestAnimationFrame(idleRender);
})();
