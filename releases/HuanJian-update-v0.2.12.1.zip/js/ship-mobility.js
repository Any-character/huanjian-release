/**
 * ship-mobility.js — Ship 机动/档位 mixin（Renderer.prototype 同款扩展模式）
 *
 * 自 ship.js 拆分（2026-08-03）：档位、转向、速度平滑、地图边界。
 * 必须后于 ship.js 加载（运行时挂在 Ship.prototype）。
 */

  /** 直线航行预判：给定飞行时间（秒），返回目标按当前航向+航速推进后的位置（2026-08-06）。
   *  speed 带符号（负 = 倒车），heading 弧度（0 = 北，顺时针）。假定目标不转向。 */
Ship.prototype.getFuturePosition = function(flightTimeSec) {
    var vx = Math.sin(this.heading) * this.speed;
    var vy = -Math.cos(this.heading) * this.speed;
    return { x: this.x + vx * flightTimeSec, y: this.y + vy * flightTimeSec };
  }

  /** AI 攻击提前量瞄准点（2026-08-06）：迭代 2 次逼近直线航行交点。
   *  @param {Object} target    — 目标舰船（读 x/y/heading/speed）
   *  @param {number} fromX, fromY — 发射点（攻击者位置）
   *  @param {number} projSpeed — 弹丸速度 px/s（主炮/副炮 shellSpeed、鱼雷 speed）
   *  @returns {{x:number, y:number}} 瞄准点（目标未来位置；目标静止/死亡则返回当前位置） */
  function aimAhead(target, fromX, fromY, projSpeed) {
    if (!target || !target.isAlive) {
      return { x: target ? target.x : fromX, y: target ? target.y : fromY };
    }
    var p = target;
    for (var i = 0; i < 2; i++) {
      var dist = Math.hypot(p.x - fromX, p.y - fromY);
      var t = Math.max(0.05, dist / Math.max(1, projSpeed));
      p = target.getFuturePosition(t);
    }
    return p;
  }

  /** 由 maxSpeed 重建速力档位（maxSpeed 加成后调用——移动读 speedGears 而非 maxSpeed）。 */
Ship.prototype._rebuildSpeedGears = function() {
    this.speedGears = [
      { name: '半速后退', speed: -this.maxSpeed / 2 },
      { name: '停止',     speed: 0 },
      { name: '半速',     speed: this.maxSpeed / 2 },
      { name: '全速',     speed: this.maxSpeed },
    ];
  }

  /** Increase gear one notch (W).  Returns true if changed. */
Ship.prototype.increaseGear = function() {
    if (this.gearIndex < this.speedGears.length - 1) {
      this.gearIndex++;
      return true;
    }
    return false;
  }

  /** Decrease gear one notch (S).  Returns true if changed. */
Ship.prototype.decreaseGear = function() {
    if (this.gearIndex > 0) {
      this.gearIndex--;
      return true;
    }
    return false;
  }

  /** Rotate CCW (A key).  dt in seconds. */
Ship.prototype.rotateLeft = function(dt) { this.heading -= this.rotationSpeed * dt; };

  /** Rotate CW (D key).  dt in seconds. */
Ship.prototype.rotateRight = function(dt) { this.heading += this.rotationSpeed * dt; };

  /**
   * Smoothly approach the gear target speed.
   * dv/dt = (target - currentSpeed) × ACCEL_POWER / ACCEL_NORMALIZER
   */
  Ship.prototype.smoothSpeed = function(dt) {
    // 引擎损毁（noGear，2026-09-13 下沉到基类统一消费）：
    //   档位强制「停止」→ 目标速度 0，航速自然衰减到 0；W/S 按键侧拦截见 player.js（双重保险）。
    //   ★一般性：原实现只在 player.js / custom-enemy.js 各自处理 → 快速战斗 EnemyShip（enemy.js）
    //   无消费点，引擎损毁对快速战斗敌舰完全无效（字人 2026-09-13 反馈"配损在快速战斗没生效"）。
    //   放共用机动入口后，任何船型（玩家/AI/友军/战役）任何战斗模式自动生效。
    if (this.getBuffMod && this.getBuffMod('noGear') > 0) {
      this.gearIndex = INITIAL_GEAR_INDEX;
    }
    var speedMult = this.floodState ? (1 - FLOOD_SPEED_PENALTY) : 1;
    // 航速 buff（红场之魂结算：友军+5% / 敌军−15%，2026-08-09）
    if (this.getBuffMod) {
      var sa = this.getBuffMod('speedMulAdd'); if (sa) speedMult *= (1 + sa);
      var sp = this.getBuffMod('speedMulPen'); if (sp) speedMult *= (1 - sp);
    }
    var rawTarget = this.speedGears[this.gearIndex].speed * speedMult;
    // 实际航速上限 110 节：减速可让 currentSpeed 从超 110 降下，但加速时不能超 110
    let target = Math.max(-MAX_SHIP_SPEED_KN, Math.min(MAX_SHIP_SPEED_KN, rawTarget));
    // 航速硬上限（2026-11-08 威斯康星不动堡垒「无法移动，保留 1 节」）：
    //   档位不锁（W/S 照常用），只把目标速度钳到 cap —— 比 noGear（强制停车）轻，且不与其他配损冲突
    var _speedCap = (this.getBuffMod && this.getBuffMod('speedClampMax')) || 0;
    if (_speedCap > 0) target = Math.max(-_speedCap, Math.min(_speedCap, target));
    const gap = target - this.currentSpeed;
    if (Math.abs(gap) < 0.01) { this.currentSpeed = target; return; }
    // 加速功率 buff（2026-10-01「机动性」综合词条的第 ② 条通道）：
    //   accelPowerAdd 是**加法百分比**通道（仿 speedMulAdd），getBuffMod 跨来源求和后
    //   以 (1 + sum) 一次性乘算 → +10% 是"加速功率 ×1.10"，不是"加速功率 +10"（单位不同）。
    //   无 buff 时 (1 + 0) === 1，× 1 逐字节等价于原 this.accelPower。
    const accelEff = this.accelPower * (1 + ((this.getBuffMod && this.getBuffMod('accelPowerAdd')) || 0));
    const factor = 1 - Math.exp(-accelEff * dt / ACCEL_NORMALIZER);
    this.currentSpeed += gap * factor;
  }

  /**
   * Smoothly approach the target angular velocity set by rudderInput.
   * dω/dt = (targetAngVel - currentAngVel) × TURN_POWER / TURN_NORMALIZER
   */
  Ship.prototype.smoothTurn = function(dt) {
    // 舵机损毁 / 引擎损毁（noTurn，2026-09-13 下沉到基类统一消费）：
    //   忽略舵输入 → 角速度按原有平滑自然衰减（不强制清零，符合 Q7 设计）；
    //   玩家转向键 / AI 转向行为侧的拦截（player.js、custom-enemy.js _aiMoveTail）保留为双重保险。
    //   ★一般性：放共用机动入口后，任何船型的 noTurn 都自动生效。
    if (this.getBuffMod && this.getBuffMod('noTurn') > 0) {
      this.rudderInput = 0;
    }
    // 航速为0时不可转向
    if (Math.abs(this.currentSpeed) < 0.01) {
      this.currentAngVel = 0;
      return;
    }

    // 转向转速 buff（2026-10-01「机动性」综合词条第 ③ 条通道）：加法百分比（仿 speedMulAdd）。
    //   ★覆盖范围：玩家 A/D（player.js → rudderInput）与全部 AI（enemy.js / custom-enemy.js →
    //   rudderInput）都经由本函数，**全部受益**。rotateLeft/rotateRight（L63/L66）是遗留直转函数，
    //   全仓库无任何游戏代码调用（仅单测 4.01/4.02 引用），故不需在此加 buff。
    const rotAdd = (this.getBuffMod && this.getBuffMod('rotationSpeedAdd')) || 0;
    const targetAngVel = this.rudderInput * this.rotationSpeed * (1 + rotAdd);

    // snap to 0 when reversing direction for crisp response
    if (this.rudderInput !== 0 &&
        this.currentAngVel !== 0 &&
        Math.sign(this.rudderInput) !== Math.sign(this.currentAngVel)) {
      this.currentAngVel = 0;
    }

    const gap = targetAngVel - this.currentAngVel;
    if (Math.abs(gap) < 0.0001) { this.currentAngVel = targetAngVel; }
    else {
      // 转向功率 buff（2026-10-01「机动性」综合词条第 ④ 条通道）：加法百分比（仿 speedMulAdd）。
      //   与加速功率同理：乘算百分比而非加算绝对值；无 buff 时 ×1 逐字节等价原值。
      const turnEff = this.turnPower * (1 + ((this.getBuffMod && this.getBuffMod('turnPowerAdd')) || 0));
      const factor = 1 - Math.exp(-turnEff * dt / TURN_NORMALIZER);
      this.currentAngVel += gap * factor;
    }
    this.heading += this.currentAngVel * dt;
  }

  /**
   * Advance position by speed·dt along current heading.
   * heading = 0 → north (world -Y).
   */
Ship.prototype.move = function(dt) {
    const spd = this.speed;
    if (spd === 0) return;
    this.x += Math.sin(this.heading) * spd * dt;
    this.y -= Math.cos(this.heading) * spd * dt;
  }

  /**
   * Clamp position within map bounds.
   * If clamping actually changed position → set gear to STOP
   * (simulates "hit the wall" behaviour).
   */
Ship.prototype.clampToMap = function() {
    const halfW = this.width / 2;
    const halfL = this.length / 2;
    const oldX = this.x;
    const oldY = this.y;
    this.x = Math.max(halfW, Math.min(MAP_SIZE_PX - halfW, this.x));
    this.y = Math.max(halfL, Math.min(MAP_SIZE_PX - halfL, this.y));
    if (oldX !== this.x || oldY !== this.y) {
      this.gearIndex = INITIAL_GEAR_INDEX;
    }
  }

