/**
 * ship-collision.js — 舰船 ↔ 舰船 实体碰撞（OBB / SAT 分离，2026-11-08 重写）
 *
 * 为什么重写（旧实现见 git 历史 Collision.checkShipBump）：
 *   ① 旧判定半径 = (我宽 + 他宽) / 2 —— 对 100×20 的船只有 20px，而真实半长是 50px，
 *      舰首方向要插进对方船体约 30px 才算「碰到」；侧舷方向又刚好碰不到，几何完全不对。
 *   ② 旧推离条件 vx*dx + vy*dy > 0 里 (dx,dy) 是「对方 → 我」方向，点积 > 0 实际表示
 *      我在**远离**对方（与旧注释相反）→ 真撞上去不响应（穿模），倒车离开反而被推停。
 *   ③ 旧实现只处理玩家：AI 舰船之间、敌舰主动撞玩家都直接穿模。
 *
 * 现在：任何两艘活舰都按真实船体轮廓（length × width 的有向包围盒）判定，
 *   用分离轴定理（SAT）求最小分离向量，按排水量（长×宽）比例分摊推移。
 *   ⚠ 只做几何分离 + 接触减速，**不产生撞船伤害**（撞船伤害未设计，勿擅自加）。
 *
 * 坐标约定：heading = 0 指北（世界 -Y），顺时针为正。
 */
const ShipCollision = {

  /** 分离后多留的缝隙（px）：抵消浮点误差，避免下一帧又判定为重叠 */
  SLOP: 0.5,

  /** 分离速度上限（px/s）：出生/传送造成深度重叠时分多帧挤开，不瞬移 */
  PUSH_SPEED: 600,

  /** 每帧每对最小推移（px）：慢速挤压时也向前推进，不会永久卡在重叠状态 */
  MIN_PUSH: 1,

  /** 求解迭代轮数：玩家被两艘船夹住时，一轮只能解开一对 */
  ITERATIONS: 3,

  /**
   * 舰船的有向包围盒：中心 + 舰首/右舷单位向量 + 半长半宽。
   * @param {Ship} ship
   * @returns {{x:number,y:number,fx:number,fy:number,rx:number,ry:number,hl:number,hw:number,r:number}}
   */
  _box(ship) {
    var c = Math.cos(ship.heading);
    var s = Math.sin(ship.heading);
    var len = ship.length > 0 ? ship.length : 1;
    var wid = ship.width > 0 ? ship.width : 1;
    return {
      x: ship.x, y: ship.y,
      fx: s,       fy: -c,      // 舰首方向（heading 0 → 北 = -Y）
      rx: c,       ry: s,       // 右舷方向
      hl: len * 0.5,
      hw: wid * 0.5,
      r:  Math.hypot(len, wid) * 0.5,   // 粗筛用外接圆半径
    };
  },

  /**
   * SAT 相交判定，返回把 a、b 分开所需的最小平移向量。
   * @param {Ship} a
   * @param {Ship} b
   * @returns {{depth:number, nx:number, ny:number}|null}
   *          depth = 重叠深度；n = 单位法线，**由 a 指向 b**（把 a 反向推、b 正向推即可分开）。
   *          不相交（含刚好相切）返回 null。
   */
  overlap(a, b) {
    var A = this._box(a);
    var B = this._box(b);
    var dx = B.x - A.x;
    var dy = B.y - A.y;

    // 粗筛：外接圆不相交则必然分离
    var rr = A.r + B.r;
    if (dx * dx + dy * dy > rr * rr) return null;

    // 四个候选轴：两个盒子的舰首轴 + 右舷轴
    var axes = [A.fx, A.fy, A.rx, A.ry, B.fx, B.fy, B.rx, B.ry];
    var bestDepth = Infinity;
    var bestNx = 0, bestNy = 0;

    for (var i = 0; i < axes.length; i += 2) {
      var ux = axes[i];
      var uy = axes[i + 1];
      // 盒子在该轴上的投影半径
      var ra = Math.abs(ux * A.fx + uy * A.fy) * A.hl + Math.abs(ux * A.rx + uy * A.ry) * A.hw;
      var rb = Math.abs(ux * B.fx + uy * B.fy) * B.hl + Math.abs(ux * B.rx + uy * B.ry) * B.hw;
      var d = dx * ux + dy * uy;
      var depth = ra + rb - Math.abs(d);
      if (depth <= 0) return null;                 // 找到分离轴 → 不相交
      if (depth < bestDepth) {
        bestDepth = depth;
        // 法线统一指向 b（d = 0 时取正方向，保证结果确定、不抖动）
        var sign = d < 0 ? -1 : 1;
        bestNx = ux * sign;
        bestNy = uy * sign;
      }
    }

    return { depth: bestDepth, nx: bestNx, ny: bestNy };
  },

  /** 排水量代理（长×宽）：只用来决定「谁被推得多」，重的船几乎不动 */
  _mass(ship) {
    var m = (ship.length > 0 ? ship.length : 1) * (ship.width > 0 ? ship.width : 1);
    return m > 0 ? m : 1;
  },

  /**
   * 接触减速：只扣掉「压向对方」的速度分量在舰首方向上的投影。
   *   顶头 → 归零；擦碰 → 只掉一部分；被侧撞 → 速度不变（只被推开）。
   *   玩家顶头撞船时档位回「停止」——保留旧手感：撞船 = 停船，需重新挂档。
   * @param {Ship} ship
   * @param {number} nx, ny — 该船的推离方向（单位向量）
   * @returns {number} 本船损失的速度比例 0..1
   */
  _brake(ship, nx, ny) {
    var spd = ship.currentSpeed || 0;
    if (spd === 0) return 0;

    var hx = Math.sin(ship.heading);
    var hy = -Math.cos(ship.heading);
    var vx = hx * spd;
    var vy = hy * spd;
    var vn = vx * nx + vy * ny;     // < 0 = 正在压向对方
    if (vn >= 0) return 0;

    // 速度向量减去法向分量后，再投影回舰首方向 = 这艘船还能保持的航速
    var hn = hx * nx + hy * ny;
    var next = spd - vn * hn;

    // 数值兜底：只允许减速，不允许把「前进」变成「倒退」
    next = spd > 0 ? Math.max(0, Math.min(spd, next))
                   : Math.min(0, Math.max(spd, next));

    var lost = Math.abs(spd - next) / Math.max(1e-6, Math.abs(spd));
    ship.currentSpeed = next;

    // 玩家顶头撞击：档位回停止（擦碰 / 被侧撞不打断档位，避免蹭一下就失去动力）
    if (ship.isPlayer && lost >= 0.5) ship.gearIndex = INITIAL_GEAR_INDEX;
    return lost;
  },

  /**
   * 解开一组舰船的所有重叠（两两）。
   * @param {Array<Ship>} ships
   * @param {number} [dt] — 秒；缺省按 60fps 计
   * @returns {number} 本帧检测到的重叠对数
   */
  resolve(ships, dt) {
    if (!ships || ships.length < 2) return 0;
    dt = (dt > 0 ? dt : 1 / 60);
    var maxPush = Math.max(this.MIN_PUSH, this.PUSH_SPEED * dt);
    var contacts = 0;
    // 每对每帧的推移预算（"i:j" → 已用 px）：迭代只负责把「被两艘船夹住」的船分开，
    // 不许把同一对在一次调用里反复推 → 深度重叠也要分帧挤开，不瞬移
    var spent = {};

    for (var iter = 0; iter < this.ITERATIONS; iter++) {
      var moved = false;
      for (var i = 0; i < ships.length; i++) {
        var a = ships[i];
        if (!a || !a.isAlive) continue;
        for (var j = i + 1; j < ships.length; j++) {
          var b = ships[j];
          if (!b || !b.isAlive) continue;

          var hit = this.overlap(a, b);
          if (!hit) continue;

          if (iter === 0) contacts++;
          moved = true;

          // 按质量反比分摊：轻的船被推得多，重的船几乎不动
          var ma = this._mass(a), mb = this._mass(b);
          var wa = mb / (ma + mb);
          var wb = ma / (ma + mb);
          var key = i + ':' + j;
          var left = maxPush - (spent[key] || 0);
          if (left <= 0.01) continue;                 // 本帧预算用完 → 下一帧继续挤
          var push = Math.min(hit.depth + this.SLOP, left);
          spent[key] = (spent[key] || 0) + push;

          a.x -= hit.nx * push * wa;
          a.y -= hit.ny * push * wa;
          b.x += hit.nx * push * wb;
          b.y += hit.ny * push * wb;

          // 减速每对每帧只结算一次（迭代只负责把位置推开，不重复扣速度）
          if (iter === 0) {
            this._brake(a, -hit.nx, -hit.ny);
            this._brake(b,  hit.nx,  hit.ny);
          }
        }
      }
      if (!moved) break;   // 一轮下来没有重叠 → 提前结束
    }

    return contacts;
  },
};
