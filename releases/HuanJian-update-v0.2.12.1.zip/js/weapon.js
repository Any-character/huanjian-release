/**
 * weapon.js — Projectile classes: MainGunShell and TorpedoProjectile.
 *
 * MainGunShell  — flies to a target point at high speed; on arrival applies
 *                 ±30 px random landing deviation, then self-destructs.
 * TorpedoProjectile — flies in a straight line at 55 px/s; collides with
 *                      enemy ships on contact and disappears immediately.
 */

/* ========================================================================== */
/*  MainGunShell                                                              */
/* ========================================================================== */
class MainGunShell {
  /**
   * @param {number}  x, y     — spawn world position
   * @param {number}  targetX, targetY — world position to fly toward
   * @param {boolean} isPlayer — affects colour palette
   * @param {Object}  cfg      — weapon config (mainGun) from ship.weaponCfg
   */
  constructor(x, y, targetX, targetY, isPlayer, cfg) {
    this.x = x;
    this.y = y;
    this.targetX = targetX;
    this.targetY = targetY;
    this.isPlayer = isPlayer;
    this.speed   = cfg.shellSpeed;
    this.damage  = cfg.damage;
    this.radius  = cfg.shellRadius;
    this.color   = isPlayer
      ? cfg.playerColor
      : cfg.enemyColor;
    this.alive   = true;
    this.hasLanded = false;           // set to true on arrival

    // per-mount weapon bonus: crit/shatter/penetration/burn (ship base + weapon bonus)
    this.critChance        = cfg.critChance        || 0;
    this.shatterChance     = cfg.shatterChance     || 0;
    this.critDmg           = cfg.critDmg           || 0;  // 暴击伤害加成（0=默认×2.0，0.1=×2.2）
    this.penetrationChance = cfg.penetrationChance || 0;  // 穿甲几率
    this.burnChance        = cfg.burnChance        || 0;  // 燃烧几率
    this.accessoryChance   = cfg.accessoryChance   || 0;  // 配损几率（2026-09-05：主炮命中触发配损）
    this.weaponDamageChance = cfg.weaponDamageChance || 0;  // 武损几率（2026-09-13：主炮命中触发武器损毁）
    this.burnPower         = cfg.burnPower         || 0;  // 燃烧程度
    this.burnSpeed         = cfg.burnSpeed         || 0;  // 燃烧加速
    this.burnDuration      = cfg.burnDuration      || 0;  // 燃烧时长
    this.penDmg            = cfg.penDmg            || 0;  // 穿甲伤害
    this.bonusVsBurning    = cfg.bonusVsBurning    || 0;  // 对燃烧目标增伤
    this.finalDmg          = cfg.finalDmg          || 0;  // 最终增伤
    this.shatterPower      = cfg.shatterPower      || 0;  // 碎甲程度
    this.mainPen           = cfg.mainPen           || 0;  // 主炮穿透（对冲减免主炮伤害，数值 0~100）
    this.shieldShred      = cfg.shieldShred      || 0;  // 护盾撕裂（对有护盾目标增伤）
    this.executeChance   = cfg.executeChance   || 0;  // 收割几率
    this.executeDmg      = cfg.executeDmg      || 0;  // 收割伤害（额外，基础 10% 内置）
    this.executeThreshold = cfg.executeThreshold || 0;  // 收割血限（额外，基础 25% 内置）
    this.shellCaliber   = cfg.shellCaliber   || 'medium';  // 炮弹口径（small/medium/large，跳弹判定）
    this.shotAccuracy   = cfg.shotAccuracy   != null ? cfg.shotAccuracy : 1;  // 射击精度（默认 100%）
    this.ignoreArmor    = cfg.ignoreArmor    || 0;  // 无视装甲（对冲装甲强度，collision ② 消费；2026-08-08 弹丸补字段，原玩家词条未生效）
    this.trueDmg            = cfg.trueDmg            || 0;  // 武器真伤（公式末尾加法：panelDamage×trueDmg）
    this.trueDmgFlat        = cfg.trueDmgFlat        || 0;  // 数值真伤（固定值，无视减伤，排在百分比真伤之后；2026-11-08 威斯康星）
    this.panelDamage        = cfg.panelDamage != null ? cfg.panelDamage : this.damage;  // 真伤基数 = 武器总面板（联装总伤害，2026-09-19）
    this.weaponDmgPen       = cfg.weaponDmgPen       || 0;  // 武器减益（疲弱/防御矩阵，×1−pen）
    this.ignoreFinalReduce  = cfg.ignoreFinalReduce  || 0;  // 无视减伤（链式对冲最终减伤）


    // pre-compute direction & total distance
    const dx = targetX - x;
    const dy = targetY - y;
    this.totalDist = Math.hypot(dx, dy);
    if (this.totalDist < 0.001) {
      // degenerate case — spawn at self; mark dead immediately
      this.alive = false;
      this.dirX = 0;
      this.dirY = 0;
      this.traveled = 0;
    } else {
      this.dirX = dx / this.totalDist;
      this.dirY = dy / this.totalDist;
      this.traveled = 0;
    }

    // trail history (circular buffer style via Array)
    this.trail = [];
    this.trailMax = cfg.trailFrames;

    // 副炮标记：半透明白色渲染（alpha 为透明度）
    this.alpha       = cfg.alpha       || 1;
    this.isSecondary = !!cfg.isSecondary;

    // landing deviation — populated on arrival
    this._landingDeviation = cfg.landingDeviation;
    this.landingOffX = 0;
    this.landingOffY = 0;
  }

  /* ── update (called once per frame) ──────────────────────────────────── */

  /**
   * @param {number} dt — delta-time in seconds
   */
  update(dt) {
    if (!this.alive) return;

    // If already landed last frame, die now (collision had its chance).
    if (this.hasLanded) {
      this.alive = false;
      return;
    }

    // record trail
    this.trail.push({ x: this.x, y: this.y });
    if (this.trail.length > this.trailMax) this.trail.shift();

    // advance
    const step = this.speed * dt;
    this.traveled += step;
    this.x += this.dirX * step;
    this.y += this.dirY * step;

    // arrival?
    if (this.traveled >= this.totalDist) {
      this.x = this.targetX;
      this.y = this.targetY;
      this.hasLanded = true;
      this.landingOffX =
        (Math.random() - 0.5) * 2 * this._landingDeviation;
      this.landingOffY =
        (Math.random() - 0.5) * 2 * this._landingDeviation;
      // alive stays true — collision check needs one frame to process
    }

    // out-of-bounds safety
    if (this.x < -100 || this.x > MAP_SIZE_PX + 100 ||
        this.y < -100 || this.y > MAP_SIZE_PX + 100) {
      this.alive = false;
    }
  }

  /** The final world position used for damage radius check. */
  getHitPosition() {
    return {
      x: this.targetX + this.landingOffX,
      y: this.targetY + this.landingOffY,
    };
  }
}


/* ========================================================================== */
/*  SeaMine (静态水雷)                                                         */
/* ========================================================================== */
class SeaMine {
  /**
   * @param {number}  x, y   — spawn world position (舰尾)
   * @param {boolean} isPlayer
   * @param {Object}  cfg    — weapon config (mine) from ship.weaponCfg
   */
  constructor(x, y, isPlayer, cfg) {
    this.x = x;
    this.y = y;
    this.isPlayer = isPlayer;
    this.damage = cfg.damage;
    this.detonationRadius = cfg.detonationRadius;   // px 引爆半径
    this.explosionRadius  = cfg.explosionRadius;    // px 爆炸半径
    this.lifeLeft = cfg.lifetimeSec || 0;
    this.alive = true;

    // 可触发：暴击 / 碎甲 / 漏水（无穿甲、无燃烧）
    this.critChance    = cfg.critChance    || 0;
    this.shatterChance = cfg.shatterChance || 0;
    this.critDmg       = cfg.critDmg       || 0;
    this.floodChance   = cfg.floodChance   || 0;
    this.floodPower    = cfg.floodPower    || 0;
    this.floodSpeed    = cfg.floodSpeed    || 0;
    this.floodDuration = cfg.floodDuration || 0;
    this.finalDmg      = cfg.finalDmg      || 0;
    this.bonusVsBurning = cfg.bonusVsBurning || 0;   // 对燃烧目标增伤（2026-10-25 补：此前 wcfg 有值、
    //   但 SeaMine 未拷贝 → 该词条对水雷从未生效，属静默失效；由单测 87.12 哨兵守卫发现）
    this.shatterPower  = cfg.shatterPower  || 0;
    this.accessoryChance = cfg.accessoryChance || 0;  // 配损几率（2026-09-05：水雷命中触发配损）
    this.weaponDamageChance = cfg.weaponDamageChance || 0;  // 武损几率（2026-09-13：水雷命中触发武器损毁）
    this.executeChance   = cfg.executeChance   || 0;  // 收割几率
    this.executeDmg      = cfg.executeDmg      || 0;  // 收割伤害（额外，基础 10% 内置）
    this.executeThreshold = cfg.executeThreshold || 0;  // 收割血限（额外，基础 25% 内置）
    this.shieldShred      = cfg.shieldShred      || 0;  // 护盾撕裂（对有护盾目标增伤）
    this.shotAccuracy       = cfg.shotAccuracy       != null ? cfg.shotAccuracy : 1;  // 武器精度（鱼雷/水雷跳弹判定，默认 100%）
    this.ignoreArmor        = cfg.ignoreArmor        || 0;  // 无视装甲（2026-08-08 弹丸补字段）
    this.trueDmg            = cfg.trueDmg            || 0;  // 武器真伤（末尾加法：panelDamage×trueDmg）
    this.panelDamage        = cfg.panelDamage != null ? cfg.panelDamage : this.damage;  // 真伤基数 = 武器总面板（2026-09-19）
    this.weaponDmgPen       = cfg.weaponDmgPen       || 0;  // 武器减益
    this.ignoreFinalReduce  = cfg.ignoreFinalReduce  || 0;  // 无视减伤
  }

  /* ── update (once per frame) ─────────────────────────────────────────── */

  /**
   * 水雷静止不动；存活时间到点直接消失（不爆炸）。
   * @param {number} dt — seconds
   */
  update(dt) {
    if (!this.alive) return;
    this.lifeLeft -= dt;
    if (this.lifeLeft <= 0) {
      this.alive = false;
    }
  }
}

/* ========================================================================== */
/*  TorpedoProjectile                                                         */
/* ========================================================================== */
class TorpedoProjectile {
  /**
   * @param {number}  x, y   — spawn world position
   * @param {number}  angle  — travel direction (radians, 0 = north)
   * @param {boolean} isPlayer
   * @param {Object}  cfg    — weapon config (torpedo) from ship.weaponCfg
   */
  constructor(x, y, angle, isPlayer, cfg) {
    this.x = x;
    this.y = y;
    this.spawnX = x;               // remember for range check
    this.spawnY = y;
    this.angle = angle;
    this.isPlayer = isPlayer;
    this.speed  = cfg.speed;
    this.damage = cfg.damage;
    this.radius = cfg.torpedoRadius;
    this.color  = isPlayer
      ? cfg.playerColor
      : cfg.enemyColor;
    this.alive  = true;

    // per-mount weapon bonus: crit/shatter/penetration (ship base + weapon bonus)
    this.critChance        = cfg.critChance        || 0;
    this.shatterChance     = cfg.shatterChance     || 0;
    this.critDmg           = cfg.critDmg           || 0;
    this.penetrationChance = cfg.penetrationChance || 0;
    this.accessoryChance   = cfg.accessoryChance   || 0;  // 配损几率（2026-09-05：鱼雷命中触发配损）
    this.weaponDamageChance = cfg.weaponDamageChance || 0;  // 武损几率（2026-09-13：鱼雷命中触发武器损毁）
    this.floodChance       = cfg.floodChance       || 0;
    this.floodPower        = cfg.floodPower        || 0;
    this.floodSpeed        = cfg.floodSpeed        || 0;
    this.floodDuration     = cfg.floodDuration     || 0;
    this.finalDmg          = cfg.finalDmg          || 0;
    this.shatterPower      = cfg.shatterPower      || 0;
    this.bonusVsBurning    = cfg.bonusVsBurning    || 0;  // 对燃烧目标增伤
    this.torpPen           = cfg.torpPen           || 0;  // 鱼雷穿透（对冲减免鱼雷伤害，数值 0~100）
    this.shieldShred      = cfg.shieldShred      || 0;  // 护盾撕裂（对有护盾目标增伤）
    this.shotAccuracy       = cfg.shotAccuracy       != null ? cfg.shotAccuracy : 1;  // 武器精度（鱼雷/水雷跳弹判定，默认 100%）
    this.ignoreArmor        = cfg.ignoreArmor        || 0;  // 无视装甲（2026-08-08 弹丸补字段）
    this.trueDmg            = cfg.trueDmg            || 0;  // 武器真伤（末尾加法：panelDamage×trueDmg）
    this.panelDamage        = cfg.panelDamage != null ? cfg.panelDamage : this.damage;  // 真伤基数 = 武器总面板（2026-09-19）
    this.weaponDmgPen       = cfg.weaponDmgPen       || 0;  // 武器减益
    this.ignoreFinalReduce  = cfg.ignoreFinalReduce  || 0;  // 无视减伤
    this.executeChance   = cfg.executeChance   || 0;  // 收割几率
    this.executeDmg      = cfg.executeDmg      || 0;  // 收割伤害（额外，基础 10% 内置）
    this.executeThreshold = cfg.executeThreshold || 0;  // 收割血限（额外，基础 25% 内置）


    // pre-compute direction unit vector
    this.dirX = Math.sin(angle);
    this.dirY = -Math.cos(angle);

    // trail
    this.trail = [];
    this.trailMax = cfg.trailFrames;

    // range limit
    this._weaponCfg = cfg;
  }

  /* ── update (once per frame) ─────────────────────────────────────────── */

  update(dt) {
    if (!this.alive) return;

    // trail
    this.trail.push({ x: this.x, y: this.y });
    if (this.trail.length > this.trailMax) this.trail.shift();

    // move
    const step = this.speed * dt;
    this.x += this.dirX * step;
    this.y += this.dirY * step;

    // out-of-bounds cull
    if (this.x < -50 || this.x > MAP_SIZE_PX + 50 ||
        this.y < -50 || this.y > MAP_SIZE_PX + 50) {
      this.alive = false;
    }

    // range limit
    if (Math.hypot(this.x - this.spawnX, this.y - this.spawnY) >= this._weaponCfg.range) {
      this.alive = false;
    }
  }
}
