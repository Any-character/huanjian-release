/**
 * ship-weapon-damage.js — 武器损毁（武损）状态 + 装填冻结（Ship.prototype 扩展，2026-09-13）
 *
 * 字人需求：新增异常状态「武器损毁」（武损）
 *   - 持续 10s，**对单个武器（炮位）生效**（4 类炮位全量：主炮/鱼雷/水雷/副炮，含副炮）
 *   - 被武损的武器：无法开火 + **无法装填（装填进度冻结，减益消失后继续装填）**
 *   - 主炮/鱼雷/水雷命中触发（副炮不触发）；触发率 = max(0, 武损几率 − 抵抗武损)
 *   - 触发时在所有**未被损毁**的武器中随机一个；全部损毁 → 不触发
 *
 * 装填冻结实现（关键，避免散落各 AI）：
 *   - 武损施加时记 mount.wepDamageStart / wepDamageEnd
 *   - 冷却读取统一走 getMountCooldownEnd(mount, now)：
 *       武损进行中 → Infinity（不可开火，装填进度**保持冻结**）
 *       武损已结束 → lazy 顺延 cooldownEnd += (end − start) —— 数学上等价于"冻结整段武损时长"
 *   - 5 处开火判定 + 3 处冷却读取全部走这个方法 → 一处逻辑，任何船型/战斗模式自动生效
 *
 * ★ 特殊武损（2026-09-19，A-140A「炮火风暴」）——与普通武损同一冻结机制，但：
 *   - 时长 20s（普通 10s）；用独立字段 mount.specWepDamageStart / specWepDamageEnd
 *   - **不可清除**（无任何移除异常状态的手段能去掉它）
 *   - **与普通武损互斥**：已损毁（任一类）的炮位不会再被选中
 *   - **不属于普通异常状态**（见词条「普通异常状态」）
 *   - 战役模式不触发（由调用方 isCampaign 控制）
 *   → 冻结/顺延逻辑与普通武损完全共用（getMountCooldownEnd 取两者并集），不另开一套
 *
 * 加载顺序：后于 ship-weapons.js（mount 结构与冷却读取同源）。
 */

/** 武损持续时间（ms）；与配损 10s 一致 */
const WEAPON_DAMAGE_DURATION_MS = 10000;
/** 特殊武损持续时间（ms）：A-140A「炮火风暴」20s，不可清除、战役不触发 */
const SPECIAL_WEAPON_DAMAGE_MS = 20000;

  /** 全部炮位汇总（4 类，含副炮）：[{ type, index, mount }] */
Ship.prototype.getAllMounts = function() {
    var out = [];
    var groups = [
      ['mainGun',   this.mainGunMounts],
      ['torpedo',   this.torpedoMounts],
      ['mine',      this.mineMounts],
      ['secondary', this.secondaryMounts],
    ];
    for (var g = 0; g < groups.length; g++) {
      var type = groups[g][0];
      var arr = groups[g][1] || [];
      for (var i = 0; i < arr.length; i++) out.push({ type: type, index: i, mount: arr[i] });
    }
    return out;
  }

  /** 单个炮位是否处于武损中（普通或特殊任一类；now < 对应 end） */
Ship.prototype.isMountWeaponDamaged = function(mount, now) {
    if (!mount) return false;
    if (mount.wepDamageEnd && now < mount.wepDamageEnd) return true;
    if (mount.specWepDamageEnd && now < mount.specWepDamageEnd) return true;
    return false;
  }

  /**
   * 施加武器损毁（普通，2026-09-13）：在**未被损毁**的武器中随机一个（含副炮）；
   * 全部武器已损毁则返回 null（本次不触发，不刷新已有）。
   *
   * 免疫下沉（2026-09-19）：`immuneBaseWeaponDamage` buff 存在时**完全免疫普通武损**
   *   （A-140A「炮火风暴」主动期）。放在本共用底层而非命中触发处 → 任何来源的普通武损都失效。
   * @param {number} [now]
   * @returns {{type:string,index:number}|null} 被损毁武器的类型与序号
   */
Ship.prototype.applyWeaponDamage = function(now) {
    now = (now != null ? now : Date.now());
    if (this.getBuffMod && this.getBuffMod('immuneBaseWeaponDamage') > 0) return null;   // 免疫基础武损
    var all = this.getAllMounts();
    var free = [];
    for (var i = 0; i < all.length; i++) {
      if (!this.isMountWeaponDamaged(all[i].mount, now)) free.push(all[i]);
    }
    if (free.length === 0) return null;   // 全部武器已损毁 → 不触发
    var pick = free[Math.floor(Math.random() * free.length)];
    pick.mount.wepDamageStart = now;
    pick.mount.wepDamageEnd = now + WEAPON_DAMAGE_DURATION_MS;
    return { type: pick.type, index: pick.index };
  }

  /**
   * 施加**特殊武损**（2026-09-19，A-140A「炮火风暴」）：
   * 在**未被损毁**（普通/特殊皆未损毁）的武器中随机一个，损毁 20s。
   *   - 不可清除；与普通武损互斥；不属于普通异常状态
   *   - 战役模式不触发 → 由调用方判断 isCampaign 后决定是否调用（此处不重复判断）
   *   - 全部武器已损毁 → 返回 null（不刷新已有）
   * @param {number} [now]
   * @returns {{type:string,index:number}|null}
   */
Ship.prototype.applySpecialWeaponDamage = function(now) {
    now = (now != null ? now : Date.now());
    var all = this.getAllMounts();
    var free = [];
    for (var i = 0; i < all.length; i++) {
      if (!this.isMountWeaponDamaged(all[i].mount, now)) free.push(all[i]);
    }
    if (free.length === 0) return null;
    var pick = free[Math.floor(Math.random() * free.length)];
    pick.mount.specWepDamageStart = now;
    pick.mount.specWepDamageEnd = now + SPECIAL_WEAPON_DAMAGE_MS;
    return { type: pick.type, index: pick.index };
  }

  /** 当前被损毁武器数（顶部图标 ×N 角标用） */
Ship.prototype.getWeaponDamageCount = function(now) {
    var all = this.getAllMounts();
    var n = 0;
    for (var i = 0; i < all.length; i++) {
      if (this.isMountWeaponDamaged(all[i].mount, now)) n++;
    }
    return n;
  }

  /** 所有武损中炮位的**最晚**结束时间（图标倒计时用；无武损 → 0）；含特殊武损 */
Ship.prototype.getWeaponDamageEndTime = function(now) {
    var all = this.getAllMounts();
    var t = 0;
    for (var i = 0; i < all.length; i++) {
      var m = all[i].mount;
      if (m.wepDamageEnd && now < m.wepDamageEnd && m.wepDamageEnd > t) t = m.wepDamageEnd;
      if (m.specWepDamageEnd && now < m.specWepDamageEnd && m.specWepDamageEnd > t) t = m.specWepDamageEnd;
    }
    return t;
  }

  /**
   * 取炮位"有效冷却结束时间"（含武损影响）—— 统一入口，见文件头说明。
   * 武损进行中（普通或特殊任一）返回 Infinity（不可开火 + 装填冻结）；
   * 全部结束后 lazy 顺延 cooldownEnd += (最晚结束 − 最早开始) —— 两类并存时取**并集**，不重复计时。
   */
Ship.prototype.getMountCooldownEnd = function(mount, now) {
    if (!mount) return 0;
    var normEnd = mount.wepDamageEnd || 0;
    var specEnd = mount.specWepDamageEnd || 0;
    if (normEnd && now < normEnd) return Infinity;          // 普通武损中：不可开火，装填进度冻结
    if (specEnd && now < specEnd) return Infinity;          // 特殊武损中：同上
    if (normEnd || specEnd) {
      var start = Math.min(mount.wepDamageStart || Infinity, mount.specWepDamageStart || Infinity);
      mount.cooldownEnd += (Math.max(normEnd, specEnd) - start);   // 冻结等价：结束时间顺延整段损毁时长
      mount.wepDamageEnd = 0; mount.wepDamageStart = 0;
      mount.specWepDamageEnd = 0; mount.specWepDamageStart = 0;
    }
    return mount.cooldownEnd;
  }

  /** 炮位是否可开火（冷却好 + 未武损）—— 开火判定统一走此方法 */
Ship.prototype.isMountReady = function(mount, now) {
    return now >= this.getMountCooldownEnd(mount, now);
  }
