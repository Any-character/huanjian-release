/**
 * ship.js — Base Ship class shared by PlayerShip and EnemyShip.
 *
 * 构造器 + 武器挂载（机动/状态/武器方法见 ship-mobility.js / ship-status.js / ship-weapons.js）
 *
 * ⚠️ 属性读取（AGENTS.md §8.6）：
 *   - **攻击侧**属性不必改本文件——构造器末尾按 js/data/attack-stats.js 的表兜底读取；
 *   - **防御侧/其它**属性仍需在此 `this.x = cfg.x ?? 0` 登记，否则船配置里写了也读不到
 *     （守卫：单测第 63 节）。
 */

class Ship {

  /**
   * @param {Object}  cfg     — configuration object (PLAYER_CONFIG / ENEMY_CONFIG)
   * @param {number}  x       — initial world X (px)
   * @param {number}  y       — initial world Y (px)
   * @param {number}  heading — initial heading (radians, 0 = north)
   * @param {boolean} isPlayer
   * @param {string}  [team]  — 'player' | 'friend' | 'enemy'（缺省按 isPlayer 推导）
   */
  constructor(cfg, x, y, heading, isPlayer, team) {
    this.x = x;
    this.y = y;
    this.heading = heading || 0;
    this.aimHeading = this.heading;
    this.gearIndex = INITIAL_GEAR_INDEX;
    this.team = team || (isPlayer ? 'player' : 'enemy');

    // visual / identity
    this.name     = cfg.name;
    this.hp       = cfg.hp;
    this.maxHp    = cfg.hp;
    this.length   = cfg.length;
    this.width    = cfg.width;
    this.color    = cfg.color;
    this.bowColor = cfg.bowColor;
    this.outlineColor = cfg.outlineColor;
    this.rotationSpeed = cfg.rotationSpeed;
    this.weaponRotationSpeed = cfg.weaponRotationSpeed || this.rotationSpeed;
    this.isPlayer = isPlayer;

    // ── 战斗核心属性（来自 cfg，带 fallback 兼容旧的测试环境）──
    this.maxSpeed   = cfg.maxSpeed   ?? 35;
    this.accelPower = cfg.accelPower ?? ACCEL_POWER;
    this.armor      = cfg.armor      ?? ARMOR_BASE;
    this.shipType   = cfg.shipType   || 'cruiser';
    this.turnPower  = cfg.turnPower  ?? TURN_POWER;

    // ── 逐舰探测距离（水上/水下，km → px）──
    this.surfaceRange    = (cfg.surfaceRange    ?? 12) * PX_PER_KM;
    this.underwaterRange = (cfg.underwaterRange ?? 6)  * PX_PER_KM;

    // ── 雷达干扰 / 反雷达干扰（2026-10-01 阳炎-利刃；单位 km，Detection 比较时 ×PX_PER_KM）──
    // ⚠️ 三态：这里**必须原样保留 cfg 的 undefined/null**，绝不能写 `?? 0` 或 `|| 0`：
    //    undefined = 无此词条（跳过检查，行为与改动前完全一致）
    //    0         = 永久隐身（任何距离都无法雷达点亮）
    //    >0        = 距离 > x km 时不可见
    //   补默认值会让「没有这个词条的现有舰船」全部变成永久隐身。
    this.radarJamming      = cfg.radarJamming;        // km｜防御侧
    this.antiRadarJamming  = cfg.antiRadarJamming;    // km｜进攻侧，对冲 radarJamming（+ buff mod）

    // ── 水雷参数（km/秒，可词条覆写；布雷处 ×PX_PER_KM）──
    this.detonationRadius = cfg.detonationRadius ?? MINE_DETONATION_KM;  // 引爆半径 km
    this.explosionRadius  = cfg.explosionRadius  ?? MINE_EXPLOSION_KM;   // 爆炸半径 km
    this.lifetimeSec      = cfg.lifetimeSec      ?? MINE_LIFETIME_SEC;    // 存在时间 s

    // ── 速力档位（由 maxSpeed 动态计算；maxSpeed 变化后调 _rebuildSpeedGears 重建）──
    this._rebuildSpeedGears();

    // ── weapon config (per-ship, fallback to globals) ──────────
    this.weaponCfg = {
      mainGun: Object.assign({
        mountCount: MAIN_GUN_CONFIG.mountCount,
        barrelsPerMount: MAIN_GUN_CONFIG.barrelsPerMount,
        cooldownSec: MAIN_GUN_CONFIG.cooldownSec,
        damage: MAIN_GUN_CONFIG.damage,
        shellSpeed: MAIN_GUN_CONFIG.shellSpeed,
        spreadAngle: MAIN_GUN_CONFIG.spreadAngle,
        landingDeviation: MAIN_GUN_CONFIG.landingDeviation,
        shellRadius: MAIN_GUN_CONFIG.shellRadius,
        trailFrames: MAIN_GUN_CONFIG.trailFrames,
        playerColor: MAIN_GUN_CONFIG.playerColor,
        enemyColor: MAIN_GUN_CONFIG.enemyColor,
        range: MAIN_GUN_RANGE,
        holdInterval: MAIN_GUN_HOLD_INTERVAL,
      }, cfg.weapon?.mainGun),
      torpedo: Object.assign({
        mountCount: TORPEDO_CONFIG.mountCount,
        barrelsPerMount: TORPEDO_CONFIG.barrelsPerMount,
        cooldownSec: TORPEDO_CONFIG.cooldownSec,
        damage: TORPEDO_CONFIG.damage,
        speed: TORPEDO_CONFIG.speed,
        scatterAngle: TORPEDO_CONFIG.scatterAngle,
        torpedoRadius: TORPEDO_CONFIG.torpedoRadius,
        trailFrames: TORPEDO_CONFIG.trailFrames,
        playerColor: TORPEDO_CONFIG.playerColor,
        enemyColor: TORPEDO_CONFIG.enemyColor,
        range: TORPEDO_RANGE,
        holdInterval: TORPEDO_HOLD_INTERVAL,
      }, cfg.weapon?.torpedo),
      mine: Object.assign({
        mountCount: MINE_CONFIG.mountCount,
        cooldownSec: MINE_CONFIG.cooldownSec,
        holdInterval: MINE_CONFIG.holdInterval,
      }, cfg.weapon?.mine),
      secondary: Object.assign({
        mountCount: 0,
        barrelsPerMount: 2,
        cooldownSec: 0,
        damage: 0,
        shellSpeed: 0,
        spreadAngle: 1 * Math.PI / 180,
        landingDeviation: 15,
        shellRadius: 3,
        trailFrames: 8,
        playerColor: '#FFFFFF',
        enemyColor: '#DD1111',
        range: 0,
        holdInterval: 100,
        mountArcs: [],
      }, cfg.weapon?.secondary),
    };
    // crit / shatter / critDmg — per-ship, fallback to globals
    this.critChance = cfg.critChance ?? CRIT_CHANCE;
    this.shatterChance = cfg.shatterChance ?? SHATTER_CHANCE;
    this.critDmg = cfg.critDmg ?? 0;  // 暴击伤害加成（0=默认×2.0）
    this.reduceCritDmg = cfg.reduceCritDmg ?? 0;  // 减免暴击伤害（逆属性：与敌方 critDmg 直接相减）
    this.reducePenDmg  = cfg.reducePenDmg  ?? 0;  // 减免穿甲伤害（逆属性：与敌方 penDmg 直接相减）
    // 护盾（2026-08-05）：1 点挡 1 点伤害，优先于血量；maxShield 记录初始值（无恢复途径）
    this.shield    = cfg.shield ?? 0;
    this.maxShield = this.shield;
    // 限时护盾（2026-08-09 红场之魂）：[{ amount, expireAt }]——到期自动消失、受击时剩余时间短的优先消耗；不影响普通护盾
    this.timedShields = [];
    // 增益/减益系统（2026-08-06）：{ key: { name, endTime, mods } }，API 在 ship-status.js
    this.buffs = {};
    // 对抗词条（2026-08-06）：护盾撕裂（攻击侧）/ 伤害变1 / 免暴击（目标侧）
    this.shieldShred     = cfg.shieldShred     ?? 0;  // 护盾撕裂（对有护盾目标增伤）
    this.dmgToOneChance  = cfg.dmgToOneChance  ?? 0;  // 受到武器伤害为1几率（武器直接伤害）
    this.negateCritChance = cfg.negateCritChance ?? 0; // 被普通暴击豁免概率（华晟被动）
    // 收割（2026-08-05）：命中血量 ≤ 血限敌人概率触发增伤
    this.executeChance   = cfg.executeChance   ?? 0.1;  // 收割几率（默认 10%；古鹰显式 0 保留）
    this.executeDmg      = cfg.executeDmg      ?? 0;    // 收割伤害（额外增伤，基础 10% 内置）
    this.executeThreshold = cfg.executeThreshold ?? 0;   // 收割血限（额外，基础 25% 内置）
    // 规避机制（2026-08-05）：射击精度 + 口径炮弹规避（跳弹）
    this.shotAccuracy        = cfg.shotAccuracy        ?? 1;   // 射击精度（默认 100%）
    this.smallCaliberEvasion  = cfg.smallCaliberEvasion  ?? 0;  // 小口径炮弹规避
    this.mediumCaliberEvasion = cfg.mediumCaliberEvasion ?? 0;  // 中口径炮弹规避
    this.largeCaliberEvasion  = cfg.largeCaliberEvasion  ?? 0;  // 大口径炮弹规避
    // 鱼雷/水雷规避（2026-08-06）：精度固定 100%，跳弹率 = 目标规避（无口径划分）
    this.torpedoEvasion      = cfg.torpedoEvasion      ?? 0;  // 鱼雷规避
    this.mineEvasion         = cfg.mineEvasion         ?? 0;  // 水雷规避
    // 杜尔曼链式对冲（2026-08-06）：舰体保护↔无视减伤↔最终减伤
    this.hullProtect         = cfg.hullProtect         ?? 0;  // 舰体保护（目标侧，抵消攻击方无视减伤）
    this.ignoreFinalReduce   = cfg.ignoreFinalReduce   ?? 0;  // 无视减伤（攻击侧，对冲目标最终减伤）
    this.resistShatterDegree = cfg.resistShatterDegree ?? 0;  // 抵抗碎甲程度（目标侧，对冲碎甲减甲）
    this.reduceMineDmg = cfg.reduceMineDmg ?? 0;  // 减免水雷伤害（对冲水雷穿透）
    this.minePen       = cfg.minePen       ?? 0;  // 水雷穿透（对冲减免水雷伤害）
    // 弹丸口径标记（跳弹判定用）：驱逐→小 / 巡洋→中 / 战列→大（副炮恒小）
    this.shellCaliber = cfg.shipType === 'destroyer' ? 'small'
      : cfg.shipType === 'battleship' ? 'large' : 'medium';
    // 抵抗类（目标侧防御，2026-08-05）
    this.resistCritChance    = cfg.resistCritChance    ?? 0;  // 抵抗暴击（对冲敌方暴击几率，直接相减下限 0）
    this.resistPenetration   = cfg.resistPenetration   ?? 0;  // 抵抗穿甲（对冲敌方穿甲几率）
    this.resistBurnChance    = cfg.resistBurnChance    ?? 0;  // 抵抗燃烧（对冲敌方燃烧几率）
    this.resistFloodChance   = cfg.resistFloodChance   ?? 0;  // 抵抗漏水（对冲敌方漏水几率）
    this.resistShatterChance = cfg.resistShatterChance ?? 0;  // 抵抗碎甲（对冲敌方碎甲几率）
    this.resistAccessoryChance = cfg.resistAccessoryChance ?? 0;  // 抵抗配损（对冲敌方配损几率，2026-09-05）
    this.resistWeaponDamageChance = cfg.resistWeaponDamageChance ?? 0;  // 抵抗武损（对冲敌方武损几率，2026-09-13）
    this.resistBurnPower     = cfg.resistBurnPower     ?? 0;  // 抵抗燃烧程度（逆属性：与敌方 burnPower 直接相减）
    this.resistFloodPower    = cfg.resistFloodPower    ?? 0;  // 抵抗漏水程度（逆属性：与敌方 floodPower 直接相减）
    this.resistFinalDmg      = cfg.resistFinalDmg      ?? 0;  // 最终减伤（独立因子，2026-08-06 取消与 finalDmg 逆属性）
    this.penetrationChance = cfg.penetrationChance ?? PENETRATION_CHANCE;  // 穿甲几率

    // ── 燃烧基础属性（来自 cfg，武器加成在 weaponToMountConfig 中叠加）──
    this.burnChance    = cfg.burnChance    ?? 0;
    this.accessoryChance = cfg.accessoryChance ?? 0;  // 配损几率（2026-09-05：主炮/鱼雷/水雷命中触发配损的概率）
    this.weaponDamageChance = cfg.weaponDamageChance ?? 0;  // 武损几率（2026-09-13：主炮/鱼雷/水雷命中触发武器损毁的概率）
    this.burnPower     = cfg.burnPower     ?? 0;  // 燃烧程度
    this.burnSpeed     = cfg.burnSpeed     ?? 0;  // 燃烧加速
    this.burnDuration  = cfg.burnDuration  ?? 0;  // 燃烧时长（0=使用 BURN_DURATION）

    // ── 漏水基础属性 ──
    this.floodChance    = cfg.floodChance    ?? 0;
    this.floodPower     = cfg.floodPower     ?? 0;
    this.floodSpeed     = cfg.floodSpeed     ?? 0;
    this.floodDuration  = cfg.floodDuration  ?? 0;

    // ── 最终增伤 / 碎甲程度 ──
    this.finalDmg       = cfg.finalDmg       ?? 0;
    this.shatterPower   = cfg.shatterPower   ?? 0;
    // ── 穿甲伤害 / 对燃烧目标增伤（舰船基础，武器词条在 weaponToMountConfig 叠加）──
    this.penDmg         = cfg.penDmg         ?? 0;
    this.bonusVsBurning = cfg.bonusVsBurning ?? 0;

    // ── 防御/穿透属性（逆属性/对冲属性）──
    this.burnDelay      = cfg.burnDelay      ?? 0;  // 延缓燃烧（逆属性，作用于敌方burnSpeed）
    this.floodDelay     = cfg.floodDelay     ?? 0;  // 延缓漏水（逆属性，作用于敌方floodSpeed）
    this.reduceMainDmg  = cfg.reduceMainDmg  ?? 0;  // 减免主炮伤害%（对冲主炮穿透）
    this.reduceTorpedoDmg = cfg.reduceTorpedoDmg ?? 0;  // 减免鱼雷伤害%
    this.mainPen        = cfg.mainPen        ?? 0;  // 主炮穿透%（对冲减免主炮伤害）
    this.torpPen        = cfg.torpPen        ?? 0;  // 鱼雷穿透%（对冲减免鱼雷伤害）

    // ── 武器真伤（2026-09-19 字人规格，同类词条数值简单相加）──
    //   trueDmg     = 「武器真伤」：对所有武器生效
    //   mainTrueDmg / torpTrueDmg / mineTrueDmg / secTrueDmg = 特定武器真伤，只对对应武器生效
    //   ⚠️ 真伤基数 = 武器总面板伤害（weapon.damage，联装总伤害），不是单管伤害
    //   消费链：ship 字段 → baseStats → weaponToMountConfig 汇总为弹丸 trueDmg → collision-hit 末尾加法
    this.trueDmg        = cfg.trueDmg        ?? 0;  // 武器真伤（通用，所有武器）
    this.mainTrueDmg    = cfg.mainTrueDmg    ?? 0;  // 主炮真伤
    this.torpTrueDmg    = cfg.torpTrueDmg    ?? 0;  // 鱼雷真伤
    this.mineTrueDmg    = cfg.mineTrueDmg    ?? 0;  // 水雷真伤
    this.secTrueDmg     = cfg.secTrueDmg     ?? 0;  // 副炮真伤
    this.resistTrueDmg  = cfg.resistTrueDmg  ?? 0;  // 抵抗武器真伤（对冲武器真伤，不能增伤）
    this.repairEff      = cfg.repairEff      ?? 0;  // 维修效率（回血加成%，2026-10-01）
    // 不屈（2026-11-08 威斯康星「威慑重击」）：每次受主炮/鱼雷/水雷伤害回固定点数血量
    //   词条是「额外加成」性质 → 自定义战斗的「自定义加成」弹窗可调（js/data/term-overrides.js）
    this.unyielding     = cfg.unyielding     ?? 0;  // 点数（× 维修效率）
    // 受到穿甲伤害 / 受到武器伤害 / 固定伤害减免（2026-11-08 威斯康星「不动堡垒」等）
    //   三条都是**舰体固有字段**（不是 buff 通道名），故可进「自定义加成」清单
    this.takePenDmgAdd    = cfg.takePenDmgAdd    ?? 0;  // 被穿甲时额外承受的伤害比例
    this.takeWeaponDmgAdd = cfg.takeWeaponDmgAdd ?? 0;  // 受到四类武器直伤的伤害比例修正（负 = 减伤）
    this.flatDamageReduce = cfg.flatDamageReduce ?? 0;  // 非武器伤害（燃烧/漏水/技能）减免比例

    // ── 攻击侧属性兜底读取（2026-10-25 单体来源重构）──
    // data/attack-stats.js 里新增的属性，若上面没有手写读取，在这里自动从 cfg 取值。
    // 只补「还没被赋值」的键（`=== undefined`），不覆盖上面的显式读取与默认常量。
    // 有了这段，新增攻击侧属性不必再改 ship.js。
    for (var _asI = 0; _asI < ATTACK_STATS.length; _asI++) {
      var _asRow = ATTACK_STATS[_asI];
      if (this[_asRow.key] === undefined) {
        this[_asRow.key] = cfg[_asRow.key] !== undefined ? cfg[_asRow.key] : attackStatDefault(_asRow);
      }
    }

    // weapon mounts — each stores cooldownEnd, weaponId, and arc key
    // 武损字段（2026-09-13）：wepDamageStart/End = 武器损毁起止时间戳（0 = 未损毁）
    var mgArcs = this.weaponCfg.mainGun.mountArcs || [];
    this.mainGunMounts = Array.from(
      { length: this.weaponCfg.mainGun.mountCount },
      function(_, i) { return { cooldownEnd: 0, weaponId: null, arcKey: mgArcs[i] || 'forward', wepDamageStart: 0, wepDamageEnd: 0 }; }
    );
    var tpArcs = this.weaponCfg.torpedo.mountArcs || [];
    this.torpedoMounts = Array.from(
      { length: this.weaponCfg.torpedo.mountCount },
      function(_, i) { return { cooldownEnd: 0, weaponId: null, arcKey: tpArcs[i] || 'port', wepDamageStart: 0, wepDamageEnd: 0 }; }
    );
    // 水雷槽：无射界概念，恒可布放
    this.mineMounts = Array.from(
      { length: this.weaponCfg.mine.mountCount },
      function() { return { cooldownEnd: 0, weaponId: null, wepDamageStart: 0, wepDamageEnd: 0 }; }
    );
    // 副炮槽：AI 自动开火（无武器转速限制，冷却好且角度内即打最近目标）
    var scArcs = this.weaponCfg.secondary.mountArcs || [];
    this.secondaryMounts = Array.from(
      { length: this.weaponCfg.secondary.mountCount },
      function(_, i) { return { cooldownEnd: 0, weaponId: null, arcKey: scArcs[i] || 'port', wepDamageStart: 0, wepDamageEnd: 0 }; }
    );
    // 副炮跟随主炮瞄准（2026-09-13 通用机制开关，当前唯一入口 = 卢金斯齐射模式）：
    //   true 时 → 副炮不再自动开火（autoFireSecondaries 返回空）+ 主炮每次开火同步发射一门副炮
    //           + 底部副炮图标行显示（含 can-fire 射界高亮）
    //   未来其它"副炮跟随"来源直接设置本字段即可，全链自动生效
    this.secondaryFollowsMain = false;

    // ── wake / trajectory tracking ──────────────────────────────────────
    // Records the last few seconds of world positions so the renderer can
    // draw a real trail behind the ship (not just a static stern graphic).
    this.wake       = [];     // [{x, y}, ...] in world space, oldest first
    this.wakeMaxLen = 180;    // ≈ 3 s at 60 fps

    // ── movement smoothing state ──────────────────────────────────────
    this.currentSpeed  = 0;   // smoothed actual speed (px/s)
    this.currentAngVel = 0;   // smoothed angular velocity (rad/s)
    this.rudderInput   = 0;   // -1 = left, 0 = neutral, 1 = right

    // ── armor & shatter state ────────────────────────────────────────
    this.shattered      = false;        // whether shatter debuff is active
    this.shatterEndTime = 0;            // Date.now() when shatter expires

    // ── 燃烧层 ──────────────────────────────────────────────────────
    this.burnStacks = [];   // [{endTime, nextTickTime, damagePerTick, tickInterval, firePos}]

    // ── 漏水状态 ────────────────────────────────────────────────────
    this.floodState = null; // { endTime, nextTickTime, damagePerTick, tickInterval }

    // ── 血条损伤条（P2-2 命中反馈，2026-08-16）──
    this.damageTicks = [];   // [{delta, expireAt}] —— takeDamage 时 push，1s 内显示白色短条
  }

  mountMainGun(slotIndex, weaponId) {
    if (slotIndex >= 0 && slotIndex < this.mainGunMounts.length) {
      this.mainGunMounts[slotIndex].weaponId = weaponId;
    }
  }

  mountTorpedo(slotIndex, weaponId) {
    if (slotIndex >= 0 && slotIndex < this.torpedoMounts.length) {
      this.torpedoMounts[slotIndex].weaponId = weaponId;
    }
  }

  mountMine(slotIndex, weaponId) {
    if (slotIndex >= 0 && slotIndex < this.mineMounts.length) {
      this.mineMounts[slotIndex].weaponId = weaponId;
    }
  }

  mountSecondary(slotIndex, weaponId) {
    if (slotIndex >= 0 && slotIndex < this.secondaryMounts.length) {
      this.secondaryMounts[slotIndex].weaponId = weaponId;
    }
  }

  /**
   * Push the ship's CURRENT world position into the wake queue.
   * Must be called AFTER update() so the recorded position reflects the
   * latest movement.  Oldest entries are dropped once the queue overflows.
   */
  updateWake() {
    // Record the trailing end of the ship.
    // Forward  (speed >= 0): trailing end = stern  (rear of ship).
    // Backward (speed <  0): trailing end = bow   (front of ship, because
    //   the ship is moving backward and the "wake" should appear behind
    //   the actual direction of travel).
    const dir = this.speed >= 0 ? 1 : -1;
    const wx = this.x - Math.sin(this.heading) * this.length * 0.5 * dir;
    const wy = this.y + Math.cos(this.heading) * this.length * 0.5 * dir;
    this.wake.push({ x: wx, y: wy });
    if (this.wake.length > this.wakeMaxLen) {
      this.wake.shift();
    }
  }

}
