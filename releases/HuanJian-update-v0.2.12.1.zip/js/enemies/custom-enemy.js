/**
 * custom-enemy.js — CustomEnemy 类
 *
 * 继承 Ship，但不使用武器槽位系统：
 *   - 无 mount 数组、无 weaponId
 *   - 以固定频率直接构造弹丸，绕过 mount 系统
 *   - 无加速功率（始终全速 gearIndex=3）
 *   - AI 转向由 enemy-ai.js 驱动（直接设置 heading）
 *   - 无限探测
 *
 * ⚠️ 改动前必读（AGENTS.md §8.6 攻击侧属性清单）：
 *   本文件是**第二条弹丸构造路径**（不经 weaponToMountConfig）：新增攻击侧属性必须同时改
 *   _baseAttackStats（公共池）+ 各 fire 的 extra（专属字段）+ _weaponWcfg（真伤汇总 / panelDamage）。
 *   历史：配损（accessoryChance）、武损、武器真伤都曾因只改 ship-weapons.js 漏改此处而失效。
 */
class CustomEnemy extends Ship {
  /**
   * @param {Object} cfg         — 已合并的完整配置（含 weapon 嵌套对象供 Ship 基类）
   * @param {number} x, y        — 出生坐标
   * @param {string} behavior    — 'chase' | 'random' | 'kite'
   * @param {string} displayName — 战场上显示的名字
   * @param {string} [team]      — 'enemy'（缺省）| 'friend'
   */
  constructor(cfg, x, y, behavior, displayName, team) {
    // 出生航向：cfg.heading（弧度，0=北；战役直线航行用，2026-08-07）
    super(cfg, x, y, (cfg.heading != null ? cfg.heading : 0), false, team || 'enemy');

    // ── 自定义属性 ──────────────────────────────────────────────────────
    this.displayName    = displayName || cfg.name || '敌人';
    this.name           = this.displayName;   // 头顶/浮血条显示名（2026-08-09 修：此前用 cfg.name，动态生成船常为 undefined）
    this._behavior      = behavior || 'chase';

    // ── 武器系统（2026-08-08 人机改革）─────────────────────────────────────
    // 冷却 = 装填（cfg 存秒→ms）；伤害/速度从人机武器（ENEMY_WEAPONS）读取，基础属性作废
    // 每炮独立冷却（mount 数组）；无发射角度限制、无武器转速限制
    this._mgReload    = (cfg.mainGunReload != null ? cfg.mainGunReload : 8)   * 1000;   // s→ms
    this._torpReload  = (cfg.torpedoReload != null ? cfg.torpedoReload : 20)  * 1000;   // s→ms
    this._secondaryReload = (cfg.secondaryReload != null ? cfg.secondaryReload : 6) * 1000;
    this._mineReload  = (cfg.mineReload != null ? cfg.mineReload : 0) * 1000;   // 0 = 无水雷
    this._mgRange     = (cfg.mainGunRange    != null ? cfg.mainGunRange    : 15)  * PX_PER_KM;   // km→px
    this._torpRange   = (cfg.torpedoRange    != null ? cfg.torpedoRange    : 12)  * PX_PER_KM;   // km→px
    this._secondaryRange = (cfg.secondaryRange != null ? cfg.secondaryRange : 0) * PX_PER_KM;
    this._engageRange = (cfg.engagementRange != null ? cfg.engagementRange : 15) * PX_PER_KM;

    // 数量（舰种默认由 SHIP_TYPE_DEFAULTS 带；可 override）
    var st = cfg.shipType || 'cruiser';
    this._mgCount   = cfg.mainGunCount != null ? cfg.mainGunCount : (st === 'battleship' ? 3 : st === 'destroyer' ? 3 : 4);
    this._tpCount   = cfg.torpedoCount != null ? cfg.torpedoCount : (st === 'battleship' ? 1 : st === 'destroyer' ? 3 : 2);
    this._scCount   = cfg.secondaryCount != null ? cfg.secondaryCount : (st === 'battleship' ? 3 : 0);
    this._mineCount = cfg.mineCount != null ? cfg.mineCount : (st === 'destroyer' ? 3 : 0);

    // 武器装配（cfg.weapons 或默认：人机A 优先，缺类型复制玩家武器兜底）
    this._weapons = {
      mainGun:   getEnemyWeaponById(cfg.weapons && cfg.weapons.mainGun)   || getEnemyDefaultWeapon('mainGun', st),
      torpedo:   getEnemyWeaponById(cfg.weapons && cfg.weapons.torpedo)   || getEnemyDefaultWeapon('torpedo', st),
      secondary: getEnemyWeaponById(cfg.weapons && cfg.weapons.secondary) || getEnemyDefaultWeapon('secondary', st),
      mine:      getEnemyWeaponById(cfg.weapons && cfg.weapons.mine)      || getEnemyDefaultWeapon('mine', st),
    };
    this._mgW  = this._weapons.mainGun;
    this._tpW  = this._weapons.torpedo;
    this._scW  = this._weapons.secondary;
    this._mineW = this._weapons.mine;

    // 便捷弹速（aiAttack 提前量预判用）：炮速单位 ×0.057，鱼雷 节
    this._mgShellSpeed    = this._mgW  ? this._mgW.shellSpeed * 0.057 : 513;
    this._torpSpeed       = this._tpW  ? this._tpW.speed : 55;
    this._secondaryShellSpeed = this._scW ? this._scW.shellSpeed * 0.057 : 0;

    // 每炮/管/槽独立冷却（mount 数组）
    this._mgMounts   = this._buildMounts(this._mgCount, this._weapons.mainGun, this._mgReload);
    this._tpMounts   = this._buildMounts(this._tpCount, this._weapons.torpedo, this._torpReload);
    this._scMounts   = this._buildMounts(this._scCount, this._weapons.secondary, this._secondaryReload || 1000000);
    this._mineMounts = this._buildMounts(this._mineCount, this._weapons.mine, this._mineReload || 1000000);

    // AI 状态
    this._aiTimer         = 8; // chase 模式立即首次对准
    this._aiTargetHeading = this.heading;
    this._aiNextTurnTime  = 3 + Math.random() * 5;  // 3~8s 随机
    // 索敌状态：目标 + 每 8s 刷新
    this._target         = null;
    this._nextTargetTime = 0;

    // ── 阶段系统（战役 Boss 用，2026-08-07）──
    // cfg.phases = [{ below: 血量阈值, mods: { maxSpeedDelta, mainGunReloadDelta, ... } }]
    // 进新阶段：清旧阶段加成（回到基础）→ 应用新阶段 mods。阶段互斥（非叠加）。
    this._phases = cfg.phases || [];
    this._phaseIndex = -1;
    if (this._phases.length > 0) {
      this._phaseBase = {
        maxSpeed: this.maxSpeed,
        armor: this.armor,
        _mgReload: this._mgReload,
        _torpReload: this._torpReload,
        _secondaryReload: this._secondaryReload,
        penetrationChance: this.penetrationChance || 0,
        critChance: this.critChance || 0,
        shatterChance: this.shatterChance || 0,
        smallCaliberEvasion: this.smallCaliberEvasion || 0,
        mediumCaliberEvasion: this.mediumCaliberEvasion || 0,
        largeCaliberEvasion: this.largeCaliberEvasion || 0,
      };
    }

    // ── 增援触发（战役 Boss，2026-08-07）──
    // cfg.reinforcements = [{ below: 血量阈值 }, ...] 按顺序每档触发一次；
    // 触发时回调 spawnFn({ index, poolIndex })，index 为 0 基档位（编号 = index + 1）。
    this._reinforcements = cfg.reinforcements || [];
    this._reinfIndex = 0;

    // ── 友军增益光环（2026-08-07）──
    // cfg.aura = { key, radiusKm, critChanceAdd?, critDmgAdd?, burnChanceAdd?, burnPowerAdd? }
    // 22km 内同阵营友军（含自己）获得增益；getBuffMod 按 mod 名跨 buff 求和 → 多艘叠加。
    // 每艘用唯一 key（含 this._uid）防覆盖（同类型多艘各自挂 buff）。
    this._aura = cfg.aura || null;
    this._uid = 'ce' + (++CustomEnemy._uidCounter);
    if (this._aura && !this._aura.radiusKm) this._aura.radiusKm = 22;
  }

  /** @returns {number} interval ± 25% 随机化 */
  _randInterval(baseMs) {
    return baseMs * (0.75 + Math.random() * 0.5);
  }

  /** 构造 mount 数组（每门/管/槽独立冷却；2026-08-08 每炮独立冷却） */
  _buildMounts(count, weapon, reloadMs) {
    var arr = [];
    for (var i = 0; i < count; i++) {
      arr.push({
        cooldownEnd: Date.now() + this._randInterval(reloadMs || 1000000),
        weaponId: weapon ? weapon.id : null,
      });
    }
    return arr;
  }

  /** 武器属性 → wcfg（伤害÷联装、弹速、bonuses 叠加到舰体基础词条 + buff 消费） */
  _weaponWcfg(weapon, extra) {
    var wcfg = Object.assign(this._baseAttackStats(), extra || {});
    // 武器 bonuses 叠加（critChance/penDmg/burn 等，与舰体基础词条同 key）
    var b = (weapon && weapon.bonuses) || {};
    for (var bk in b) {
      if (wcfg[bk] !== undefined) wcfg[bk] = (wcfg[bk] || 0) + b[bk];
    }
    // 弹丸 buff 全消费（增益光环 + 畏惧光环/疲弱 debuff，2026-08-07）
    this._applyAllBuffs(wcfg);
    // 武器真伤汇总（2026-09-19 字人规格）：通用「武器真伤」+ 该武器类型专属真伤，同类简单相加。
    //   ★公共池由 js/data/attack-stats.js 的表生成（勿在此手抄字段；守卫：单测第 87 节）
    var _tdKey = weapon && weapon.type === 'mainGun' ? 'mainTrueDmg'
      : weapon && weapon.type === 'torpedo' ? 'torpTrueDmg'
        : weapon && weapon.type === 'mine' ? 'mineTrueDmg' : 'secTrueDmg';
    wcfg.trueDmg = (wcfg.trueDmg || 0) + (wcfg[_tdKey] || 0);
    // 真伤基数 = 武器总面板（联装总伤害；各 fire 处的 wcfg.damage 仍是单管伤害）
    if (weapon) wcfg.panelDamage = weapon.damage;
    return wcfg;
  }

  /** 武器冷却 buff 因子（胡德光环 cooldownReduceAdd -15%，2026-08-08）：友军也吃光环 */
  _cdFactor() {
    var v = this.getBuffMod ? this.getBuffMod('cooldownReduceAdd') : 0;
    return v > 0 ? (1 - v) : 1;
  }

  /** 遍历 mounts：冷却好的每门/管/槽打一次（createFn(weapon, index) 创建弹丸），返回全部弹丸（2026-08-08 每炮独立冷却） */
  _fireMounts(mounts, reloadMs, now, createFn) {
    var out = [];
    for (var i = 0; i < mounts.length; i++) {
      var m = mounts[i];
      if (now < m.cooldownEnd) continue;
      m.cooldownEnd = now + this._randInterval(reloadMs);
      var w = getEnemyWeaponById(m.weaponId);
      if (!w) continue;
      var added = createFn(w, i);
      if (added && added.length) {
        for (var k = 0; k < added.length; k++) out.push(added[k]);
      }
    }
    return out;
  }

  /** 主炮开火（每门独立冷却；无射界/转速限制；伤害速度从武器读） */
  fireMainGunSimple(targetX, targetY, now) {
    var self = this;
    return this._fireMounts(this._mgMounts, this._mgReload * this._cdFactor(), now, function(w) {
      var wcfg = self._weaponWcfg(w, {
        shellSpeed: w.shellSpeed * 0.057,
        shellRadius: 3,
        playerColor: '#FF6B35',
        enemyColor: self.team === 'friend' ? '#2EC4B6' : '#DD1111',
        landingDeviation: 15,
        trailFrames: 8,
        spreadAngle: 1 * Math.PI / 180,
        penetrationChance: self.penetrationChance || 0,
        burnChance: self.burnChance || 0,
        burnPower: self.burnPower || 0,
        burnSpeed: self.burnSpeed || 0,
        burnDuration: self.burnDuration || 0,
        penDmg: self.penDmg || 0,
        mainPen: self.mainPen || 0,
        shellCaliber: self.shipType === 'destroyer' ? 'small' : self.shipType === 'battleship' ? 'large' : 'medium',
        shotAccuracy: self.shotAccuracy != null ? self.shotAccuracy : 1,
      });
      wcfg.damage = Math.round(w.damage / w.barrelsPerMount);   // 面板÷联装 = 每发
      var baseAngle = Math.atan2(targetX - self.x, -(targetY - self.y));
      var baseDist  = Math.hypot(targetX - self.x, targetY - self.y);
      var shells = [];
      for (var b = 0; b < w.barrelsPerMount; b++) {
        var spread = (Math.random() - 0.5) * 2 * wcfg.spreadAngle;
        var angle  = baseAngle + spread;
        var tgtX   = self.x + Math.sin(angle) * baseDist;
        var tgtY   = self.y - Math.cos(angle) * baseDist;
        var shell = new MainGunShell(self.x, self.y, tgtX, tgtY, false, wcfg);
        shell.owner = self;  // 战绩归属：记录发射者
        shell.team = self.team;  // 阵营归属
        shells.push(shell);
      }
      return shells;
    });
  }

  /** 鱼雷开火（每管独立冷却） */
  fireTorpedoSimple(targetX, targetY, now) {
    var self = this;
    return this._fireMounts(this._tpMounts, this._torpReload * this._cdFactor(), now, function(w) {
      var wcfg = self._weaponWcfg(w, {
        speed: w.speed,
        torpedoRadius: 4,
        playerColor: '#1E5FBF',
        enemyColor: self.team === 'friend' ? '#2EC4B6' : '#AA1111',
        trailFrames: 8,
        scatterAngle: 5 * Math.PI / 180,
        penetrationChance: self.penetrationChance || 0,
        floodChance: self.floodChance || 0,
        floodPower: self.floodPower || 0,
        floodSpeed: self.floodSpeed || 0,
        floodDuration: self.floodDuration || 0,
        torpPen: self.torpPen || 0,
        range: self._torpRange,
      });
      // 鱼雷专属通道消费（2026-10-01 阳炎-利刃基础设施；与 weapon-config.js 鱼雷分支同一算法）
      //   speed 单位是「节」直接加（不是炮速 ×0.057）；damage 加的是「面板总伤害 × pct」整笔、不分摊，
      //   且加在**基础伤害**上（吃减伤）——这是它与真伤（末尾加法、绕过减伤）的本质区别。
      wcfg.speed = w.speed + (wcfg.torpedoSpeedAdd || 0);
      wcfg.damage = Math.round(w.damage / w.barrelsPerMount)
                  + Math.round(w.damage * (wcfg.torpPanelDmgPct || 0));
      var baseAngle = Math.atan2(targetX - self.x, -(targetY - self.y));
      var torps = [];
      for (var b = 0; b < w.barrelsPerMount; b++) {
        var offset = w.barrelsPerMount > 1
          ? -wcfg.scatterAngle + b * (2 * wcfg.scatterAngle) / (w.barrelsPerMount - 1)
          : 0;
        var torp = new TorpedoProjectile(self.x, self.y, baseAngle + offset, false, wcfg);
        torp.owner = self;  // 战绩归属：记录发射者
        torp.team = self.team;  // 阵营归属
        torps.push(torp);
      }
      return torps;
    });
  }

  /** 副炮开火（每门独立冷却） */
  fireSecondarySimple(targetX, targetY, now) {
    var self = this;
    return this._fireMounts(this._scMounts, this._secondaryReload * this._cdFactor(), now, function(w) {
      var wcfg = self._weaponWcfg(w, {
        shellSpeed: w.shellSpeed * 0.057,
        shellRadius: 3,
        playerColor: '#FFFFFF',
        enemyColor: self.team === 'friend' ? '#2EC4B6' : '#FFFFFF',
        landingDeviation: 15,
        trailFrames: 8,
        spreadAngle: 1 * Math.PI / 180,
        burnChance: self.burnChance || 0,
        burnPower: self.burnPower || 0,
        burnSpeed: self.burnSpeed || 0,
        burnDuration: self.burnDuration || 0,
        shellCaliber: 'small',   // 副炮恒小口径
        shotAccuracy: self.shotAccuracy != null ? self.shotAccuracy : 1,
        alpha: 0.7,
        isSecondary: true,
      });
      wcfg.damage = Math.round(w.damage / w.barrelsPerMount);
      var baseAngle = Math.atan2(targetX - self.x, -(targetY - self.y));
      var baseDist  = Math.hypot(targetX - self.x, targetY - self.y);
      var shells = [];
      for (var b = 0; b < w.barrelsPerMount; b++) {
        var spread = (Math.random() - 0.5) * 2 * wcfg.spreadAngle;
        var angle  = baseAngle + spread;
        var tgtX   = self.x + Math.sin(angle) * baseDist;
        var tgtY   = self.y - Math.cos(angle) * baseDist;
        var shell  = new MainGunShell(self.x, self.y, tgtX, tgtY, false, wcfg);
        shell.owner = self;  // 战绩归属：记录发射者
        shell.team = self.team;  // 阵营归属
        shells.push(shell);
      }
      return shells;
    });
  }

  /**
   * 每帧决策：索敌 + AI 转向 + 移动
   * @param {number} dt
   * @param {Array|Object} hostileShips — 敌对舰数组（或单个舰船对象，兼容旧调用）
   * @param {number} [now]
   */
  aiUpdate(dt, hostileShips, now) {
    now = now || Date.now();
    var list = Array.isArray(hostileShips) ? hostileShips : (hostileShips ? [hostileShips] : []);
    this._acquireTarget(list, now);

    // 配件损毁（2026-09-05）：舵机/引擎损毁 → 不转向（行为运行后还原航向）；引擎损毁 → 档位停止
    var noTurnNow = this.getBuffMod && this.getBuffMod('noTurn') > 0;
    var headingBefore = noTurnNow ? this.heading : null;

    var target = this._target;
    if (!target || !target.isAlive) {
      // line 行为（战役 Boss）：无目标也保持直线全速前进（不转向不停止）
      if (this._behavior === 'line') {
        this.gearIndex = 3;
      } else if (this._behavior === 'keeprange' && this._keepRangeTarget && this._keepRangeTarget.isAlive) {
        // keeprange 无索敌目标：仍朝玩家锚点保持距离（2026-08-09 修：此前无目标即停船）
        var ta2 = Math.atan2(this._keepRangeTarget.x - this.x, -(this._keepRangeTarget.y - this.y));
        var d2 = Math.hypot(this._keepRangeTarget.x - this.x, this._keepRangeTarget.y - this.y);
        this._aiKeepRange(dt, ta2, d2);
        this.gearIndex = 3;
      } else {
        this._aiIdle();
      }
      this._aiTimer = 0;
      this._aiMoveTail(dt, noTurnNow, headingBefore);
      return;
    }

    // keeprange 行为：转向/距离以「保持距离锚点」（玩家）为基准，索敌/攻击仍用 _target（2026-08-09 修）
    var ref = (this._behavior === 'keeprange' && this._keepRangeTarget) ? this._keepRangeTarget : target;
    var targetAngle = Math.atan2(ref.x - this.x, -(ref.y - this.y));
    var dist = Math.hypot(ref.x - this.x, ref.y - this.y);

    if (this._behavior === 'idle') {
      this._aiIdle();
    } else if (this._behavior === 'line') {
      // 直线航行（战役 Boss，2026-08-07）：保持出生航向不转向，全速前进；索敌/开火照常
      this.gearIndex = 3;
    } else {
      if (this._behavior === 'chase') {
        this._aiChase(dt, targetAngle, dist);
      } else if (this._behavior === 'random') {
        this._aiRandom(dt, targetAngle, dist);
      } else if (this._behavior === 'kite') {
        this._aiKite(dt, targetAngle, dist);
      } else if (this._behavior === 'zigzag') {
        this._aiZigzag(dt, targetAngle, dist);
      } else if (this._behavior === 'keeprange') {
        this._aiKeepRange(dt, targetAngle, dist);   // 保持距离（友军援助，2026-08-08）
      }
      this.gearIndex = 3;
    }
    this._aiMoveTail(dt, noTurnNow, headingBefore);
  }

  /**
   * 阶段检测（战役 Boss，2026-08-07）：每帧按 hp 阈值检查，进入新阶段时
   * 清旧阶段加成（回到基础）→ 应用新阶段 mods。阶段互斥，非叠加。
   * mods 字段（相对基础值）：maxSpeedDelta / mainGunReloadDelta / torpedoReloadDelta /
   * secondaryReloadDelta / penetrationChanceDelta / critChanceDelta / shatterChanceDelta /
   * evasionDelta（全口径规避） / armorDelta
   */
  checkPhase() {
    if (this._phases.length === 0 || !this._phaseBase) return;
    // 找当前应处的阶段（血量低于多个阈值时取最后一个，即阶段互斥）
    var targetIdx = -1;
    for (var i = 0; i < this._phases.length; i++) {
      if (this.hp < this._phases[i].below) targetIdx = i;
    }
    if (targetIdx <= this._phaseIndex) return;   // 已在该阶段或更后
    // 进入 targetIdx 阶段：先回基础，再应用该阶段 mods
    this._phaseIndex = targetIdx;
    var base = this._phaseBase;
    this.maxSpeed = base.maxSpeed;
    this.armor = base.armor;
    this._mgReload = base._mgReload;
    this._torpReload = base._torpReload;
    this._secondaryReload = base._secondaryReload;
    this.penetrationChance = base.penetrationChance;
    this.critChance = base.critChance;
    this.shatterChance = base.shatterChance;
    this.smallCaliberEvasion = base.smallCaliberEvasion;
    this.mediumCaliberEvasion = base.mediumCaliberEvasion;
    this.largeCaliberEvasion = base.largeCaliberEvasion;

    var m = this._phases[targetIdx].mods || {};
    if (m.maxSpeedDelta) this.maxSpeed = Math.max(0, this.maxSpeed + m.maxSpeedDelta);
    if (m.mainGunReloadDelta) this._mgReload = Math.max(0.5 * 1000, this._mgReload + m.mainGunReloadDelta * 1000);
    if (m.torpedoReloadDelta) this._torpReload = Math.max(0.5 * 1000, this._torpReload + m.torpedoReloadDelta * 1000);
    if (m.secondaryReloadDelta != null) this._secondaryReload = Math.max(0.5 * 1000, this._secondaryReload + m.secondaryReloadDelta * 1000);
    if (m.penetrationChanceDelta) this.penetrationChance = this.penetrationChance + m.penetrationChanceDelta;
    if (m.critChanceDelta) this.critChance = this.critChance + m.critChanceDelta;
    if (m.shatterChanceDelta) this.shatterChance = this.shatterChance + m.shatterChanceDelta;
    if (m.armorDelta) this.armor = this.armor + m.armorDelta;
    if (m.evasionDelta) {
      this.smallCaliberEvasion  = this.smallCaliberEvasion  + m.evasionDelta;
      this.mediumCaliberEvasion = this.mediumCaliberEvasion + m.evasionDelta;
      this.largeCaliberEvasion  = this.largeCaliberEvasion  + m.evasionDelta;
    }
    // maxSpeed 变化后重建速力档位（ship-mobility.js 读 speedGears 而非 maxSpeed）
    if (this._rebuildSpeedGears) this._rebuildSpeedGears();
    return this._phaseIndex + 1;   // 返回 1 基阶段号（1/2/3）
  }

  /**
   * 增援触发（战役 Boss，2026-08-07）：cfg.reinforcements = [{ below }] 按顺序每档触发一次。
   * 血量低于当前档 → 调 spawnFn({ index, poolIndex })，index 为 0 基档位（编号 = index+1）。
   * 触发后 _reinfIndex++，防重复；连续掉血多档 → 依次触发。
   * @param {number} now
   * @param {function} spawnFn — 外部生成增援船的回调（main.js 传，返回 true 表示成功生成）
   * @returns {boolean} 本次是否触发了新的增援
   */
  checkReinforcements(now, spawnFn) {
    if (this._reinforcements.length === 0 || !spawnFn) return false;
    var triggered = false;
    while (this._reinfIndex < this._reinforcements.length && this.hp <= this._reinforcements[this._reinfIndex].below) {
      var ok = spawnFn({ index: this._reinfIndex, poolIndex: Math.floor(Math.random() * 3) });
      this._reinfIndex++;
      if (ok) triggered = true;
    }
    return triggered;
  }

  /**
   * 友军增益光环（2026-08-07）：cfg.aura = { key, radiusKm, critChanceAdd?, critDmgAdd?, burnChanceAdd?, burnPowerAdd? }。
   * 每帧给 allies（同阵营数组，含自己）中 radiusKm 内者 addBuff（key 含船唯一 id → 多艘可叠加）。
   * 出圈/死亡 → buff 过期自动消失；弹丸构造时 getBuffMod 消费。
   * @param {number} now
   * @param {Array} allies — 同阵营船数组（main.js 传 enemies）
   */
  updateAllyAura(now, allies) {
    if (!this._aura || !allies) return;
    var rangePx = this._aura.radiusKm * PX_PER_KM;
    var buffKey = 'aura_' + this._aura.key + '_' + this._uid;
    // 条件性光环（每帧刷新、出圈即消失）→ 无持续时间，不显示倒计时（2026-09-19 字人要求）
    if (!this._auraModsCache) this._auraModsCache = Object.assign({ noDuration: true }, this._aura);
    for (var i = 0; i < allies.length; i++) {
      var a = allies[i];
      if (!a || !a.isAlive) continue;
      if (Math.hypot(a.x - this.x, a.y - this.y) > rangePx) continue;
      if (a.addBuff) a.addBuff(buffKey, this._aura.name || this._aura.key, now + 1000, this._auraModsCache);
    }
  }

  /**
   * 弹丸增益快照（友军光环 2026-08-07）：把 getBuffMod 的**加成型** mod 叠加进 wcfg。
   * 提尔皮茨（critChanceAdd/critDmgAdd）+ 欧根亲王（burnChanceAdd/burnPowerAdd）
   * + 鱼雷专属通道（torpPanelDmgPct / torpedoSpeedAdd，2026-10-01）；
   * wcfg 里没有的字段跳过（鱼雷无燃烧 → burn 系自动忽略；主炮 wcfg 无 torpedoSpeedAdd 消费点 → 无副作用）。
   * @param {Object} wcfg — 弹丸配置（原地修改）
   */
  _applyAuraBuffs(wcfg) {
    if (!this.getBuffMod) return;
    var adders = {
      critChance: 'critChanceAdd',
      critDmg: 'critDmgAdd',
      burnChance: 'burnChanceAdd',
      burnPower: 'burnPowerAdd',
      penDmg: 'penDmgAdd',          // 战舰技能光环（穿甲尖兵 2026-08-08）；仅主炮 wcfg 有 penDmg 字段
      shotAccuracy: 'weaponAccuracyAdd',   // 胡德光环精度 +15%（2026-08-08）
      // 鱼雷专属通道（2026-10-01 阳炎-利刃基础设施）：buff mod 名与词条同名，getBuffMod 跨 buff 求和
      torpPanelDmgPct: 'torpPanelDmgPct',
      torpedoSpeedAdd: 'torpedoSpeedAdd',
    };
    for (var k in adders) {
      if (wcfg[k] === undefined) continue;
      var v = this.getBuffMod(adders[k]);
      if (v) wcfg[k] = (wcfg[k] || 0) + v;
    }
    // 胡德光环「无视装甲 +2000」（攻击侧，2026-08-08）：无基础字段也强制叠加（collision ② 消费 proj.ignoreArmor）
    var ia = this.getBuffMod('ignoreArmorAdd');
    if (ia) wcfg.ignoreArmor = (wcfg.ignoreArmor || 0) + ia;
  }

  /**
   * 攻击侧公共词条（4 处 fire 复用，2026-08-07 去重）：各 wcfg 用 Object.assign 合并后覆盖差异字段。
   * 主炮/鱼雷/副炮/水雷都带的攻击词条集合。
   */
  _baseAttackStats() {
    // 2026-10-25 重构：由 data/attack-stats.js 的 `enemy:true` 行统一生成。
    // 原来这里是一份手抄的 20 键对象 —— 配损曾因只改 ship-weapons 漏改此处而永久失效。
    return buildEnemyAttackStats(this);
  }

  /**
   * 弹丸 buff 全消费（2026-08-07 去重）：增益光环（_applyAuraBuffs）+ 畏惧光环/疲弱 debuff 一次搞定。
   * 畏惧光环（华晟 2026-08-06）：敌舰带 debuff 时弹丸减益（弹丸速度/射击精度/暴击伤害）
   * 防御矩阵/疲弱（杜尔曼 2026-08-06）：武器伤害减益
   * @param {Object} wcfg — 弹丸配置（原地修改）
   */
  _applyAllBuffs(wcfg) {
    this._applyAuraBuffs(wcfg);
    if (!this.getBuffMod) return;
    var auraMul = this.getBuffMod('shellSpeedMul');
    if (auraMul) wcfg.shellSpeed = (wcfg.shellSpeed || 0) * auraMul;
    var accPen = this.getBuffMod('shotAccuracyPen');
    if (accPen) wcfg.shotAccuracy = (wcfg.shotAccuracy != null ? wcfg.shotAccuracy : 1) - accPen;
    var cdPen = this.getBuffMod('critDmgPen');
    if (cdPen) wcfg.critDmg = (wcfg.critDmg || 0) - cdPen;
    var wdPen = this.getBuffMod('weaponDmgPen');
    if (wdPen) wcfg.weaponDmgPen = (wcfg.weaponDmgPen || 0) + wdPen;
  }

  /**
   * 索敌：每 8 秒在存活敌对舰中选最近；目标死亡立即重选。
   * @param {Array} hostileShips
   * @param {number} now
   */
  _acquireTarget(hostileShips, now) {
    if (this._target && this._target.isAlive && now < this._nextTargetTime) return;
    var best = null, bestD = Infinity;
    for (var i = 0; i < hostileShips.length; i++) {
      var s = hostileShips[i];
      if (!s || !s.isAlive) continue;
      var d = (s.x - this.x) * (s.x - this.x) + (s.y - this.y) * (s.y - this.y);
      if (d < bestD) { bestD = d; best = s; }
    }
    this._target = best;
    this._nextTargetTime = now + 8000;
  }

  /**
   * 每帧攻击决策（以 _acquireTarget 的目标开火；无目标则不开火不布雷）
   * @param {Array|Object} hostileShips — 兼容旧调用（单个舰船）
   * @param {Array}  projectiles
   * @param {number} [now]
   * @param {Array}  [friendlies] — 己方阵营船数组（含自己）；目标必须被己方共享水上探测到才开火
   */
  aiAttack(hostileShips, projectiles, now, friendlies) {
    now = now || Date.now();
    var self = this;
    var target = (this._target && this._target.isAlive) ? this._target : null;
    if (!target) {
      var list = Array.isArray(hostileShips) ? hostileShips : (hostileShips ? [hostileShips] : []);
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].isAlive) { target = list[i]; break; }
      }
    }
    if (!target) return;
    // 探测限制：目标必须被己方阵营共享水上探测到，否则只追不打（寻路在 aiUpdate 不受影响）
    if (!Detection.canSeeShipByAny(friendlies || [this], target)) return;
    var dist = Math.hypot(target.x - this.x, target.y - this.y);

    if (dist < this._mgRange) {
      // 提前量预判（2026-08-06）：假定目标直线航行（读航速含倒车/航向），迭代 2 次；弹速与 fireMainGunSimple 内 wcfg.shellSpeed 一致
      var apMg = aimAhead(target, this.x, this.y, this._mgShellSpeed);
      var shells = this.fireMainGunSimple(apMg.x, apMg.y, now);
      for (var si = 0; si < shells.length; si++) {
        projectiles.push(shells[si]);
      }
    }
    if (dist < this._torpRange) {
      var apTp = aimAhead(target, this.x, this.y, this._torpSpeed);   // 鱼雷航速（fireTorpedoSimple wcfg.speed）
      var torps = this.fireTorpedoSimple(apTp.x, apTp.y, now);
      for (var ti = 0; ti < torps.length; ti++) {
        projectiles.push(torps[ti]);
      }
    }
    if (dist < this._secondaryRange) {
      var apSc = aimAhead(target, this.x, this.y, this._secondaryShellSpeed);   // 副炮弹速（fireSecondarySimple wcfg.shellSpeed）
      var secs = this.fireSecondarySimple(apSc.x, apSc.y, now);
      for (var si2 = 0; si2 < secs.length; si2++) {
        projectiles.push(secs[si2]);
      }
    }

    // 定时在舰尾布雷（无射程概念；每槽独立冷却；无武器/0 槽 → 不布雷，2026-08-08）
    if (this._mineW && this._mineMounts.length > 0) {
      var mines = this._fireMounts(this._mineMounts, this._mineReload * this._cdFactor(), now, function(w) {
        var wcfg = self._weaponWcfg(w, {
          detonationRadius: (w.detonationRadiusKM != null ? w.detonationRadiusKM : 0.75) * PX_PER_KM,
          explosionRadius:  (w.explosionRadiusKM  != null ? w.explosionRadiusKM  : 2.45) * PX_PER_KM,
          lifetimeSec: w.lifetimeSec != null ? w.lifetimeSec : 135,
        });
        wcfg.damage = w.damage;
        var sternX = self.x - Math.sin(self.heading) * self.length * 0.5;
        var sternY = self.y + Math.cos(self.heading) * self.length * 0.5;
        var mine = new SeaMine(sternX, sternY, false, wcfg);
        mine.owner = self;  // 战绩归属：记录布放者
        mine.team = self.team;  // 阵营归属
        return [mine];
      });
      for (var mi2 = 0; mi2 < mines.length; mi2++) projectiles.push(mines[mi2]);
    }
  }

  /* ── 三种 AI 行为 ──────────────────────────────────────────────────── */

  /** 全速追踪：直线前进，每 8 秒重新对准玩家方向（避免贴脸时疯狂旋转） */
  _aiChase(dt, targetAngle, dist) {
    this._aiTimer += dt;
    if (this._aiTimer >= 8) {
      this._aiTargetHeading = targetAngle;
      this._aiTimer = 0;
    }
    this.rudderInput = 0;
    var diff = this._aiTargetHeading - this.heading;
    while (diff >  Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.heading += diff * Math.min(1, dt * 6);
    while (this.heading >  Math.PI * 2) this.heading -= Math.PI * 2;
    while (this.heading <  0)          this.heading += Math.PI * 2;
  }

  /** 迂回接近：航向与目标方向保持 <90° 随机夹角，每 8 秒重新随机（2026-08-05） */
  _aiZigzag(dt, targetAngle, dist) {
    this._aiTimer += dt;
    if (this._aiTimer >= 8) {
      // 随机夹角 (-90°, +90°)：始终不直冲目标，迂回靠近
      this._aiTargetHeading = targetAngle + (Math.random() * Math.PI - Math.PI / 2);
      this._aiTimer = 0;
    }
    this.rudderInput = 0;
    var diff = this._aiTargetHeading - this.heading;
    while (diff >  Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.heading += diff * Math.min(1, dt * 6);
    while (this.heading >  Math.PI * 2) this.heading -= Math.PI * 2;
    while (this.heading <  0)          this.heading += Math.PI * 2;
  }

  /** 随机行动：直行 + 随机时间后转向 */
  _aiRandom(dt, targetAngle, dist) {    this._aiTimer += dt;
    if (this._aiTimer >= this._aiNextTurnTime) {
      this._aiTargetHeading += (Math.random() - 0.5) * Math.PI;
      this._aiNextTurnTime = 3 + Math.random() * 5;
      this._aiTimer = 0;
    }
    this.rudderInput = 0;
    var diff = this._aiTargetHeading - this.heading;
    while (diff > Math.PI)  diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.heading += diff * Math.min(1, dt * 6);
    while (this.heading > Math.PI * 2) this.heading -= Math.PI * 2;
    while (this.heading < 0)           this.heading += Math.PI * 2;
  }

  /** 原地不动：不移动、不转向 */
  _aiIdle() {
    this.gearIndex = 1;
    this.rudderInput = 0;
  }

  /**
   * AI 移动尾段（2026-09-05 抽取）：档位/航向配损后处理 + 平滑/移动/边界。
   * 配件损毁：引擎损毁 → 档位强制停止（smoothSpeed 前覆盖行为设的 gear=3，航速自然衰减到 0）；
   * 舵机/引擎损毁 → 不转向（行为方法直接改 heading，move 前还原航向，保持直线前行/停车）。
   * @param {number} dt
   * @param {boolean} noTurnNow — 本帧是否不可转向
   * @param {number|null} headingBefore — 行为运行前的航向（noTurnNow 时用于还原）
   */
  _aiMoveTail(dt, noTurnNow, headingBefore) {
    if (this.getBuffMod && this.getBuffMod('noGear') > 0) this.gearIndex = 1;
    this.smoothSpeed(dt);
    this.smoothTurn(dt);
    if (noTurnNow) this.heading = headingBefore;
    this.move(dt);
    this.clampToMap();
  }

  /** 远程游走：保持主炮射程 70% 的距离 */
  _aiKite(dt, targetAngle, dist) {
    var optimal = this._mgRange * 0.7;
    if (dist < optimal) {
      this._aiTargetHeading = targetAngle + Math.PI;  // 远离
    } else if (dist > optimal * 1.3) {
      this._aiTargetHeading = targetAngle;            // 靠近
    } else {
      this._aiTargetHeading = targetAngle + Math.PI / 2;  // 横向
    }
    this.rudderInput = 0;
    var diff = this._aiTargetHeading - this.heading;
    while (diff > Math.PI)  diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.heading += diff * Math.min(1, dt * 6);
    while (this.heading > Math.PI * 2) this.heading -= Math.PI * 2;
    while (this.heading < 0)           this.heading += Math.PI * 2;
  }

  /**
   * 保持距离（友军援助，2026-08-08）：趋向与目标保持 cfg.keepRangeKm（默认 5km）。
   * 决策节流（2026-08-09 修）：大偏差（>1.15× 或 <0.85× 保持距离）**立即**重选航向（防玩家贴脸/远离时迟钝），
   * 只有巡航段（距离在区间内）才 8s 节流一次（防贴脸乱转）。
   */
  _aiKeepRange(dt, targetAngle, dist) {
    this._aiTimer += dt;
    var keepR = (this._keepRangeKm != null ? this._keepRangeKm : 5) * PX_PER_KM;
    var far = dist > keepR * 1.15;
    var near = dist < keepR * 0.85;
    if (this._aiTimer >= 8 || far || near) {
      if (far) {
        this._aiTargetHeading = targetAngle;              // 太远 → 靠近
      } else if (near) {
        this._aiTargetHeading = targetAngle + Math.PI;    // 太近 → 远离
      }
      // 巡航段（区间内）到 8s → 保持当前航向（不加不减）
      this._aiTimer = 0;
    }
    this.rudderInput = 0;
    var diff = this._aiTargetHeading - this.heading;
    while (diff > Math.PI)  diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.heading += diff * Math.min(1, dt * 6);
    while (this.heading > Math.PI * 2) this.heading -= Math.PI * 2;
    while (this.heading < 0)           this.heading += Math.PI * 2;
  }
}

// 实例唯一 id 计数器（友军光环 buff key 防覆盖用，2026-08-07）
CustomEnemy._uidCounter = 0;
