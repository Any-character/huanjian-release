/**
 * input.js — Keyboard + mouse input handler.
 *
 * Tracks held keys, just-pressed keys, mouse position (screen & world),
 * click flags, and hold flags.  Used by the main game loop.
 *
 * Extracted from main.js to keep the game-loop file lean.
 */

class InputHandler {
  /**
   * 解析绑定值：'key:KeyW' | 'mouse:0' | 'mouse:1' | 'mouse:2' | 'wheel'
   * @returns {{type:string, code?:string, button?:number}|null}
   */
  static parseBinding(binding) {
    if (binding === 'wheel') return { type: 'wheel' };
    var m = /^key:(.+)$/.exec(binding || '');
    if (m) return { type: 'key', code: m[1] };
    m = /^mouse:([012])$/.exec(binding || '');
    if (m) return { type: 'mouse', button: parseInt(m[1], 10) };
    return null;
  }

  constructor(canvas) {
    this.canvas = canvas;

    /** @type {Set<string>} currently held keys (physical codes) */
    this._held = new Set();

    /** @type {Set<string>} keys pressed this frame (cleared each tick) */
    this._justPressed = new Set();

    /** Mouse screen coordinates (relative to canvas). */
    this.mouseX = 0;
    this.mouseY = 0;

    /** Mouse world coordinates (updated each frame). */
    this.mouseWorldX = 0;
    this.mouseWorldY = 0;

    /** Click flags — consumed once per frame. */
    this.leftClick  = false;
    this.rightClick = false;
    this.middleClick = false;

    /** Held flags — controlled by mouseup/mousedown, not cleared per frame. */
    this.leftHeld  = false;
    this.rightHeld = false;
    this.middleHeld = false;

    /** Wheel scroll steps accumulated this frame (mine laying). */
    this.wheelDelta = 0;

    this._bind();
  }

  _bind() {
    // keyboard
    window.addEventListener('keydown', e => {
      var isBoundKey = false;
      for (var ak in SETTINGS.keys) {
        if (SETTINGS.keys[ak] === 'key:' + e.code) { isBoundKey = true; break; }
      }
      if (isBoundKey) {
        e.preventDefault();
      }
      if (!this._held.has(e.code)) {
        this._justPressed.add(e.code);
      }
      this._held.add(e.code);
    });
    window.addEventListener('keyup', e => {
      this._held.delete(e.code);
    });

    // mouse move
    this.canvas.addEventListener('mousemove', e => {
      const rect = this.canvas.getBoundingClientRect();
      this.mouseX = e.clientX - rect.left;
      this.mouseY = e.clientY - rect.top;
    });

    // mouse buttons
    this.canvas.addEventListener('mousedown', e => {
      e.preventDefault();
      if (e.button === 0) { this.leftClick = true; this.leftHeld = true; }
      if (e.button === 1) { this.middleClick = true; this.middleHeld = true; }
      if (e.button === 2) { this.rightClick = true; this.rightHeld = true; }
    });

    // mouse release — clear held flags so hold-to-fire stops
    window.addEventListener('mouseup', e => {
      if (e.button === 0) this.leftHeld = false;
      if (e.button === 1) this.middleHeld = false;
      if (e.button === 2) this.rightHeld = false;
    });

    // suppress context menu
    this.canvas.addEventListener('contextmenu', e => e.preventDefault());

    // wheel — 滚动即布雷（任意方向都算一格）
    this.canvas.addEventListener('wheel', e => {
      e.preventDefault();
      this.wheelDelta += 1;
    }, { passive: false });
  }

  /** True if `code` is currently held. */
  isHeld(code) { return this._held.has(code); }

  /** True if `code` was just pressed this frame. */
  isJustPressed(code) { return this._justPressed.has(code); }

  /** 动作是否处于按住状态（滚轮恒 false）——动态读 SETTINGS.keys，改键即时生效 */
  isActionHeld(action) {
    var b = InputHandler.parseBinding(SETTINGS.keys[action]);
    if (!b) return false;
    if (b.type === 'key') return this._held.has(b.code);
    if (b.type === 'mouse') {
      return b.button === 0 ? this.leftHeld : (b.button === 1 ? this.middleHeld : this.rightHeld);
    }
    return false;
  }

  /** 动作本帧是否刚触发（滚轮=本帧滚过） */
  isActionJustPressed(action) {
    var b = InputHandler.parseBinding(SETTINGS.keys[action]);
    if (!b) return false;
    if (b.type === 'key') return this._justPressed.has(b.code);
    if (b.type === 'mouse') {
      return b.button === 0 ? this.leftClick : (b.button === 1 ? this.middleClick : this.rightClick);
    }
    return this.wheelDelta > 0;
  }

  /** 动作本帧脉冲计数（滚轮=滚格数，其它=0或1） */
  getActionPulse(action) {
    var b = InputHandler.parseBinding(SETTINGS.keys[action]);
    if (!b) return 0;
    if (b.type === 'wheel') return this.wheelDelta;
    return this.isActionJustPressed(action) ? 1 : 0;
  }

  /**
   * Recompute mouse world position based on current camera and zoom.
   */
  updateMouseWorld(camX, camY, canvasW, canvasH, zoom) {
    const invZoom = 1 / zoom;
    this.mouseWorldX = (this.mouseX - canvasW / 2) * invZoom + camX;
    this.mouseWorldY = (this.mouseY - canvasH / 2) * invZoom + camY;
  }

  /** Call at end of every frame. */
  endFrame() {
    this._justPressed.clear();
    this.leftClick  = false;
    this.rightClick = false;
    this.middleClick = false;
    this.wheelDelta = 0;
  }
}
