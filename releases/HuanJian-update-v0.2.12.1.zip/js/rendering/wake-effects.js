/**
 * wake-effects.js — 舰船/鱼雷尾迹效果（Renderer.prototype 扩展）
 *
 * 自 effects.js 拆分（2026-08-03）：尾迹带渲染 + 尾迹粒子系统。
 * 加载顺序：renderer.js 之后、hit-feedback.js 之前。
 */

/**
 * effects.js — Visual-effect methods attached to Renderer.prototype.
 *
 * Extracted from renderer.js to keep core rendering lean (~400 lines).
 * Loaded AFTER renderer.js so the Renderer class already exists.
 *
 * Contents:
 *   _drawShipWake, spawnWakeParticles, updateWakeParticles, _drawWakeParticles,
 *   _drawDamagePopups, _drawHitStats, _drawHitPill
 *
 * Dependencies: Renderer (renderer.js), Constants (constants.js)
 */

/* ========================================================================== */
/*  Wake trail (banded gradient)                                              */
/* ========================================================================== */

/**
 * Draw the ship wake as 4 bands from thick/opaque (newest) → thin/transparent (oldest).
 * @param {Ship} ship
 */
Renderer.prototype._drawShipWake = function (ship) {
  if (!ship.wake || ship.wake.length < 2) return;
  const ctx  = this.ctx;
  const wake = ship.wake;
  const len  = wake.length;

  const bands = [
    { fromLen: len - 25,  toLen: len,     alpha: 0.35, width: 3.5 },
    { fromLen: len - 60,  toLen: len - 25, alpha: 0.20, width: 2.2 },
    { fromLen: len - 110, toLen: len - 60, alpha: 0.10, width: 1.2 },
    { fromLen: 0,          toLen: len - 110,alpha: 0.04, width: 0.5 },
  ];

  ctx.lineCap  = 'round';
  ctx.lineJoin = 'round';

  for (const band of bands) {
    const start = Math.max(0, band.fromLen);
    const end   = Math.max(0, band.toLen);
    if (end - start < 2) continue;

    ctx.globalAlpha = band.alpha;
    // 尾迹泡沫：骨白（2026-11-15；原来的浅蓝在夜海上偏冷，像另一套 UI 色）
    ctx.strokeStyle = 'rgba(231,226,212,1)';
    ctx.lineWidth   = band.width;
    ctx.beginPath();
    const first = this.worldToScreen(wake[start].x, wake[start].y);
    ctx.moveTo(first.x, first.y);
    for (let i = start + 1; i < end; i++) {
      const p = this.worldToScreen(wake[i].x, wake[i].y);
      ctx.lineTo(p.x, p.y);
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
};

/* ========================================================================== */
/*  Torpedo wake particles                                                    */
/* ========================================================================== */

/**
 * Spawn drifting particles near the newest torpedo trail positions.
 * @param {TorpedoProjectile} torpedo
 */
Renderer.prototype.spawnTorpedoWakeParticles = function (torpedo) {
  if (!torpedo || !torpedo.alive) return;
  const trail = torpedo.trail;
  if (!trail || trail.length < 4) return;
  if (Math.random() > 0.4) return;

  const count = 1 + Math.floor(Math.random() * 2); // 1–2
  const spawnStart = Math.max(0, trail.length - 6);
  for (let c = 0; c < count; c++) {
    const idx = spawnStart + Math.floor(Math.random() * (trail.length - spawnStart));
    const pos = trail[idx];
    this.torpedoParticles.push({
      x: pos.x + (Math.random() - 0.5) * 6,
      y: pos.y + (Math.random() - 0.5) * 6,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4,
      life: 0,
      maxLife: 0.3 + Math.random() * 0.5,
      radius: 0.6 + Math.random() * 1.0,
    });
  }

  if (this.torpedoParticles.length > 200) {
    this.torpedoParticles.splice(0, this.torpedoParticles.length - 150);
  }
};

/**
 * Draw all active torpedo wake particles (smaller, slightly different shade).
 */
Renderer.prototype._drawTorpedoParticles = function () {
  if (this.torpedoParticles.length === 0) return;
  const ctx = this.ctx;
  for (const p of this.torpedoParticles) {
    const alpha = (1 - p.life / p.maxLife) * 0.45;
    if (alpha < 0.01) continue;
    const s = this.worldToScreen(p.x, p.y);
    const r = p.radius * (1 - p.life / p.maxLife * 0.4);
    ctx.fillStyle = `rgba(214,220,208,${alpha.toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
    ctx.fill();
  }
};

/* ========================================================================== */
/*  Wake particles                                                            */
/* ========================================================================== */

/**
 * Spawn a few drifting particles near the newest wake positions.
 * @param {Ship} ship
 */
Renderer.prototype.spawnWakeParticles = function (ship) {
  if (!SETTINGS.fx.wakeParticles) return;
  if (!ship || !ship.isAlive) return;
  const wake = ship.wake;
  if (!wake || wake.length < 8) return;
  if (Math.random() > 0.4) return;   // ~40 % of frames

  const count = 2 + Math.floor(Math.random() * 3); // 2–4
  const spawnStart = Math.max(0, wake.length - 10);
  for (let c = 0; c < count; c++) {
    const idx = spawnStart + Math.floor(Math.random() * (wake.length - spawnStart));
    const pos = wake[idx];
    this.wakeParticles.push({
      x: pos.x + (Math.random() - 0.5) * 12,
      y: pos.y + (Math.random() - 0.5) * 12,
      vx: (Math.random() - 0.5) * 6,
      vy: (Math.random() - 0.5) * 6 - 3,
      life: 0,
      maxLife: 0.5 + Math.random() * 0.8,
      radius: 0.8 + Math.random() * 1.4,
    });
  }

  if (this.wakeParticles.length > 300) {
    this.wakeParticles.splice(0, this.wakeParticles.length - 250);
  }
};

/**
 * Advance every particle's life and world position.
 * @param {number} dt — seconds
 */
Renderer.prototype.updateWakeParticles = function (dt) {
  for (let i = this.wakeParticles.length - 1; i >= 0; i--) {
    const p = this.wakeParticles[i];
    p.life += dt;
    if (p.life >= p.maxLife) { this.wakeParticles.splice(i, 1); continue; }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.98;
    p.vy *= 0.98;
  }
};

/**
 * Advance every torpedo particle's life and world position.
 * @param {number} dt — seconds
 */
Renderer.prototype.updateTorpedoParticles = function (dt) {
  for (let i = this.torpedoParticles.length - 1; i >= 0; i--) {
    const p = this.torpedoParticles[i];
    p.life += dt;
    if (p.life >= p.maxLife) { this.torpedoParticles.splice(i, 1); continue; }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.98;
    p.vy *= 0.98;
  }
};

/**
 * Draw all active wake particles.
 */
Renderer.prototype._drawWakeParticles = function () {
  if (!SETTINGS.fx.wakeParticles) return;
  if (this.wakeParticles.length === 0) return;
  const ctx = this.ctx;
  for (const p of this.wakeParticles) {
    const alpha = (1 - p.life / p.maxLife) * 0.55;
    if (alpha < 0.01) continue;
    const s = this.worldToScreen(p.x, p.y);
    const r = p.radius * (1 - p.life / p.maxLife * 0.4);
    ctx.fillStyle = `rgba(214,220,208,${alpha.toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
    ctx.fill();
  }
};
