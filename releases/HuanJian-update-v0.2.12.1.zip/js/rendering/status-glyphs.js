/**
 * status-glyphs.js — 状态图标的**画笔**（2026-11-15，与 status-icons.js 的表分开）
 *
 * 为什么拆：图标一多，表 + 画笔放一个文件会超过 400 行硬规则（AGENTS §7.3）。
 *   status-icons.js = 「谁用哪枚图标」的数据 + resolve/draw；
 *   本文件 = 「每枚图标长什么样」的几何。
 *
 * 契约：
 *   · 只往 StatusIcons.GLYPHS 上挂对象，不定义新全局。
 *   · 函数签名 (ctx, cx, cy, r, bg)；`this` 是 StatusIcons（可调 this._poly）。
 *   · 白色实心/描边画在调用方给的有色方块上；bg = 方块底色，用于挖洞/裂纹。
 *   · 14px 见方设计：细节别再加了，加完在 28px 格子里会糊。
 */

StatusIcons.GLYPHS = {
  /* ── 通用增益（兜底）── */
  buff(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.7);
    ctx.lineTo(cx - r * 0.55, cy + r * 0.05);
    ctx.lineTo(cx - r * 0.2, cy + r * 0.05);
    ctx.lineTo(cx - r * 0.2, cy + r * 0.65);
    ctx.lineTo(cx + r * 0.2, cy + r * 0.65);
    ctx.lineTo(cx + r * 0.2, cy + r * 0.05);
    ctx.lineTo(cx + r * 0.55, cy + r * 0.05);
    ctx.closePath();
    ctx.fill();
  },

  /* ── 防护 ── */
  shield(ctx, cx, cy, r, bg) {
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.95);
    ctx.lineTo(cx + r * 0.80, cy - r * 0.55);
    ctx.lineTo(cx + r * 0.68, cy + r * 0.20);
    ctx.quadraticCurveTo(cx + r * 0.50, cy + r * 0.80, cx, cy + r * 0.95);
    ctx.quadraticCurveTo(cx - r * 0.50, cy + r * 0.80, cx - r * 0.68, cy + r * 0.20);
    ctx.lineTo(cx - r * 0.80, cy - r * 0.55);
    ctx.closePath();
    ctx.fill();
    // 中缝（挖空）：让轮廓像盾牌而不是一团白
    ctx.strokeStyle = bg;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.80);
    ctx.lineTo(cx, cy + r * 0.72);
    ctx.stroke();
  },

  armor(ctx, cx, cy, r, bg) {
    this._poly(ctx, [
      [cx, cy - r * 0.95], [cx + r * 0.86, cy - r * 0.46], [cx + r * 0.86, cy + r * 0.46],
      [cx, cy + r * 0.95], [cx - r * 0.86, cy + r * 0.46], [cx - r * 0.86, cy - r * 0.46],
    ]);
    // 横向分缝 + 两颗铆钉
    ctx.fillStyle = bg;
    ctx.fillRect(cx - r * 0.86, cy - r * 0.11, r * 1.72, r * 0.22);
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath(); ctx.arc(cx - r * 0.42, cy + r * 0.52, r * 0.15, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx + r * 0.42, cy + r * 0.52, r * 0.15, 0, Math.PI * 2); ctx.fill();
  },

  evasion(ctx, cx, cy, r) {
    // 规避：一条甩尾的机动弧 + 箭头
    ctx.lineWidth = Math.max(1.4, r * 0.24);
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.90, cy + r * 0.60);
    ctx.quadraticCurveTo(cx - r * 0.10, cy + r * 0.95, cx + r * 0.15, cy + r * 0.12);
    ctx.quadraticCurveTo(cx + r * 0.38, cy - r * 0.65, cx + r * 0.55, cy - r * 0.62);
    ctx.stroke();
    this._poly(ctx, [
      [cx + r * 0.95, cy - r * 0.62],
      [cx + r * 0.40, cy - r * 0.98],
      [cx + r * 0.40, cy - r * 0.26],
    ]);
  },

  /* ── 进攻 ── */
  accuracy(ctx, cx, cy, r) {
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.50, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.95, cy); ctx.lineTo(cx - r * 0.62, cy);
    ctx.moveTo(cx + r * 0.62, cy); ctx.lineTo(cx + r * 0.95, cy);
    ctx.moveTo(cx, cy - r * 0.95); ctx.lineTo(cx, cy - r * 0.62);
    ctx.moveTo(cx, cy + r * 0.62); ctx.lineTo(cx, cy + r * 0.95);
    ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.15, 0, Math.PI * 2); ctx.fill();
  },

  lock(ctx, cx, cy, r) {
    const L = r * 0.95, A = r * 0.40;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx - L, cy - L + A); ctx.lineTo(cx - L, cy - L); ctx.lineTo(cx - L + A, cy - L);
    ctx.moveTo(cx + L - A, cy - L); ctx.lineTo(cx + L, cy - L); ctx.lineTo(cx + L, cy - L + A);
    ctx.moveTo(cx + L, cy + L - A); ctx.lineTo(cx + L, cy + L); ctx.lineTo(cx + L - A, cy + L);
    ctx.moveTo(cx - L + A, cy + L); ctx.lineTo(cx - L, cy + L); ctx.lineTo(cx - L, cy + L - A);
    ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.18, 0, Math.PI * 2); ctx.fill();
  },

  power(ctx, cx, cy, r, bg) {
    // 炮弹（尖头朝上 + 弹带 + 底部火光）—— 横向炮管在 14px 里会读成"哑铃"
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.98);
    ctx.quadraticCurveTo(cx + r * 0.50, cy - r * 0.30, cx + r * 0.42, cy + r * 0.25);
    ctx.lineTo(cx + r * 0.42, cy + r * 0.55);
    ctx.lineTo(cx - r * 0.42, cy + r * 0.55);
    ctx.lineTo(cx - r * 0.42, cy + r * 0.25);
    ctx.quadraticCurveTo(cx - r * 0.50, cy - r * 0.30, cx, cy - r * 0.98);
    ctx.closePath();
    ctx.fill();
    // 弹带（挖空，和底色一致）
    ctx.fillStyle = bg;
    ctx.fillRect(cx - r * 0.46, cy + r * 0.14, r * 0.92, r * 0.16);
    // 底部两撇尾焰
    ctx.fillStyle = '#FFFFFF';
    this._poly(ctx, [[cx - r * 0.50, cy + r * 0.86], [cx - r * 0.20, cy + r * 0.58], [cx - r * 0.10, cy + r * 0.92]]);
    this._poly(ctx, [[cx + r * 0.50, cy + r * 0.86], [cx + r * 0.20, cy + r * 0.58], [cx + r * 0.10, cy + r * 0.92]]);
  },

  reload(ctx, cx, cy, r) {
    // 装填：顺时针回环箭头 + 中间弹丸
    ctx.lineWidth = Math.max(1.4, r * 0.20);
    ctx.beginPath();
    ctx.arc(cx, cy, r * 0.76, Math.PI * 0.45, Math.PI * 1.80);
    ctx.stroke();
    this._poly(ctx, [
      [cx + r * 0.50, cy - r * 0.92],
      [cx + r * 0.98, cy - r * 0.22],
      [cx + r * 0.30, cy - r * 0.16],
    ]);
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.24, 0, Math.PI * 2); ctx.fill();
  },

  trueDmg(ctx, cx, cy, r) {
    // 八芒星（真伤 / 爆发）
    ctx.beginPath();
    for (let i = 0; i < 16; i++) {
      const a = (i * Math.PI) / 8 - Math.PI / 2;
      const rr = (i % 2 === 0) ? r * 0.95 : r * 0.34;
      const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  },

  star(ctx, cx, cy, r) {
    // 五角星（全属性强化）
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      const rr = (i % 2 === 0) ? r * 0.95 : r * 0.42;
      const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  },

  /* ── 鱼雷 / 机动 / 探测 / 隐蔽 ── */
  torpedo(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.moveTo(cx + r * 0.98, cy);
    ctx.quadraticCurveTo(cx + r * 0.30, cy - r * 0.40, cx - r * 0.45, cy - r * 0.28);
    ctx.lineTo(cx - r * 0.78, cy - r * 0.78);
    ctx.lineTo(cx - r * 0.60, cy);
    ctx.lineTo(cx - r * 0.78, cy + r * 0.78);
    ctx.lineTo(cx - r * 0.45, cy + r * 0.28);
    ctx.quadraticCurveTo(cx + r * 0.30, cy + r * 0.40, cx + r * 0.98, cy);
    ctx.closePath();
    ctx.fill();
  },

  mobility(ctx, cx, cy, r) {
    ctx.lineWidth = Math.max(1.5, r * 0.26);
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.62, cy - r * 0.66); ctx.lineTo(cx - r * 0.02, cy); ctx.lineTo(cx - r * 0.62, cy + r * 0.66);
    ctx.moveTo(cx + r * 0.10, cy - r * 0.66); ctx.lineTo(cx + r * 0.70, cy); ctx.lineTo(cx + r * 0.10, cy + r * 0.66);
    ctx.stroke();
  },

  radar(ctx, cx, cy, r) {
    // 三段同心弧 + 扫描线（底部圆心）
    ctx.lineWidth = 1.4;
    const by = cy + r * 0.42;
    ctx.beginPath(); ctx.arc(cx, by, r * 0.36, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, by, r * 0.66, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, by, r * 0.94, Math.PI * 1.18, Math.PI * 1.82); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, by); ctx.lineTo(cx + r * 0.62, cy - r * 0.58); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, by, r * 0.14, 0, Math.PI * 2); ctx.fill();
  },

  radarDamage(ctx, cx, cy, r) {
    // 雷达 + 一道断线（配损）：原来画 X，在 13px 里跟救生圈似的
    ctx.lineWidth = 1.4;
    const by = cy + r * 0.42;
    ctx.beginPath(); ctx.arc(cx, by, r * 0.44, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, by, r * 0.82, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, by); ctx.lineTo(cx + r * 0.55, cy - r * 0.55); ctx.stroke();
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.58, cy - r * 0.92); ctx.lineTo(cx + r * 0.58, cy + r * 0.34);
    ctx.stroke();
  },

  stealth(ctx, cx, cy, r, bg) {
    // 新月 + 一点星光（蜃光猎影）
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.92, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.arc(cx + r * 0.44, cy - r * 0.20, r * 0.78, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath(); ctx.arc(cx - r * 0.58, cy - r * 0.58, r * 0.14, 0, Math.PI * 2); ctx.fill();
  },

  /* ── 减益 ── */
  slow(ctx, cx, cy, r) {
    // 减速 = 锚（海军语境里最直观的"被拖住"；用箭头会和 weaken 撞脸）
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(cx, cy - r * 0.72, r * 0.17, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.54); ctx.lineTo(cx, cy + r * 0.60);
    ctx.moveTo(cx - r * 0.40, cy - r * 0.24); ctx.lineTo(cx + r * 0.40, cy - r * 0.24);
    ctx.stroke();
    // 底部锚爪
    ctx.beginPath(); ctx.arc(cx, cy + r * 0.26, r * 0.62, Math.PI * 0.18, Math.PI * 0.82); ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.62, cy + r * 0.68); ctx.lineTo(cx - r * 0.46, cy + r * 0.40);
    ctx.moveTo(cx + r * 0.62, cy + r * 0.68); ctx.lineTo(cx + r * 0.46, cy + r * 0.40);
    ctx.stroke();
  },

  weaken(ctx, cx, cy, r, bg) {
    // 向下的箭头 + 中段断口：伤害/输出被削弱
    ctx.beginPath();
    ctx.moveTo(cx, cy + r * 0.92);
    ctx.lineTo(cx - r * 0.52, cy + r * 0.10);
    ctx.lineTo(cx - r * 0.18, cy + r * 0.10);
    ctx.lineTo(cx - r * 0.18, cy - r * 0.88);
    ctx.lineTo(cx + r * 0.18, cy - r * 0.88);
    ctx.lineTo(cx + r * 0.18, cy + r * 0.10);
    ctx.lineTo(cx + r * 0.52, cy + r * 0.10);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = bg;
    ctx.fillRect(cx - r * 0.55, cy - r * 0.18, r * 1.10, r * 0.16);
  },

  /* ── 既有减益（从 fire-effects / accessory-debuffs 收编）── */
  shatter(ctx, cx, cy, r, bg) {
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.72, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = bg;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.50, cy - r * 0.50); ctx.lineTo(cx, cy); ctx.lineTo(cx + r * 0.40, cy + r * 0.60);
    ctx.moveTo(cx + r * 0.10, cy - r * 0.30); ctx.lineTo(cx + r * 0.62, cy - r * 0.10);
    ctx.stroke();
  },

  burn(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.70, cy + r * 0.50);
    ctx.quadraticCurveTo(cx - r * 1.10, cy + r * 0.10, cx - r * 0.35, cy - r * 1.00);
    ctx.quadraticCurveTo(cx - r * 0.15, cy - r * 0.95, cx + r * 0.05, cy - r * 0.30);
    ctx.quadraticCurveTo(cx + r * 0.25, cy - r * 0.85, cx + r * 0.55, cy - r * 0.50);
    ctx.quadraticCurveTo(cx + r * 1.00, cy + r * 0.20, cx + r * 0.60, cy + r * 0.50);
    ctx.quadraticCurveTo(cx, cy + r * 0.75, cx - r * 0.70, cy + r * 0.50);
    ctx.closePath();
    ctx.fill();
  },

  flood(ctx, cx, cy, r) {
    const drops = [[-r * 0.50, 0], [0, -r * 0.15], [r * 0.50, 0]];
    for (let i = 0; i < drops.length; i++) {
      const dcx = cx + drops[i][0], dcy = cy + drops[i][1];
      ctx.beginPath();
      ctx.moveTo(dcx, dcy - r * 0.60);
      ctx.quadraticCurveTo(dcx + r * 0.45, dcy + r * 0.10, dcx + r * 0.20, dcy + r * 0.55);
      ctx.quadraticCurveTo(dcx, dcy + r * 0.65, dcx - r * 0.20, dcy + r * 0.55);
      ctx.quadraticCurveTo(dcx - r * 0.45, dcy + r * 0.10, dcx, dcy - r * 0.60);
      ctx.closePath();
      ctx.fill();
    }
  },

  rudder(ctx, cx, cy, r) {
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.75, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.75, cy); ctx.lineTo(cx + r * 0.75, cy);
    ctx.moveTo(cx, cy - r * 0.75); ctx.lineTo(cx, cy + r * 0.75);
    ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.20, 0, Math.PI * 2); ctx.fill();
  },

  engine(ctx, cx, cy, r, bg) {
    // 齿轮：8 齿（6 齿在 13px 里会读成"皇冠"），中心孔挖得大一点
    const teeth = 8;
    ctx.beginPath();
    for (let i = 0; i < teeth * 2; i++) {
      const a = (i * Math.PI) / teeth;
      const rr = (i % 2 === 0) ? r * 0.90 : r * 0.58;
      const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.34, 0, Math.PI * 2); ctx.fill();
  },

  weaponBroken(ctx, cx, cy, r) {
    ctx.fillRect(cx - r * 1.05, cy - r * 0.58, r * 0.85, r * 0.44);
    ctx.fillRect(cx + r * 0.22, cy + r * 0.14, r * 0.85, r * 0.44);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.30, cy - r * 0.90); ctx.lineTo(cx + r * 0.12, cy - r * 0.28);
    ctx.moveTo(cx - r * 0.02, cy + r * 0.24); ctx.lineTo(cx + r * 0.40, cy + r * 0.92);
    ctx.stroke();
  },
};
