/**
 * damage-popups.js — 飘字 + 命中统计（Renderer.prototype 扩展）
 *
 * 自 effects.js 拆分（2026-08-03）：伤害飘字、右上角命中统计胶囊。
 * 加载顺序：wake-effects.js 之后、fire-effects.js 之前。
 */

/* ========================================================================== */
/*  Damage popups (floating "-XXX" text)                                      */
/* ========================================================================== */

/**
 * Draw all active floating damage popups.
 * Coordinates are in screen space (pre-converted to avoid zoom skew).
 * 2026-08-16 字人反馈"超出屏幕" → clamp 到屏幕可见区域 [margin, width-margin] 内，避免飘字飞出屏幕。
 *
 * @param {Array<{x:number,y:number,text:string,color:string,strokeColor:string,alpha:number}>} popups
 */
Renderer.prototype._drawDamagePopups = function (popups) {
  if (!SETTINGS.fx.damagePopups) return;
  if (!popups || popups.length === 0) return;
  const ctx = this.ctx;
  ctx.save();
  ctx.font = DAMAGE_POPUP.font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 4;
  ctx.lineJoin = 'round';

  // 飘字屏幕夹紧（2026-08-16 字人反馈"飘字超出屏幕"）
  // margin 14px：留边距避免飘字完全贴边导致背景看不清
  const margin = 14;
  const minX = margin;
  const maxX = this.width - margin;
  const minY = margin;
  const maxY = this.height - margin;

  for (const p of popups) {
    const cx = Math.max(minX, Math.min(maxX, p.x));
    const cy = Math.max(minY, Math.min(maxY, p.y));
    ctx.globalAlpha = p.alpha;
    ctx.strokeStyle = p.strokeColor;
    ctx.strokeText(p.text, cx, cy);
    ctx.fillStyle = p.color;
    ctx.fillText(p.text, cx, cy);
  }

  ctx.restore();
};

/* ========================================================================== */
/*  Hit-stat pills (top-right HUD)                                            */
/* ========================================================================== */

/**
 * Draw the two top-right hit-counter pills.
 * Each pill is shown only while the current time is before its expireTime.
 *
 * @param {{count:number,expireTime:number}} mainGunStat
 * @param {{count:number,expireTime:number}} torpedoStat
 * @param {number} now — current timestamp (ms)
 */
Renderer.prototype._drawHitStats = function (mainGunStat, torpedoStat, shatterStat, burnStat, floodStat, mineStat, now, ricochetStat, torpedoRicochetStat, mineRicochetStat, accessoryStat, wepDamageStat) {
  if (!SETTINGS.fx.hitStats) return;
  if (!mainGunStat || !torpedoStat) return;
  const ctx  = this.ctx;
  const cfg  = HIT_STAT;
  const rightX = this.width - cfg.marginRight;
  const mainGunActive = mainGunStat.count > 0 && now < mainGunStat.expireTime;
  const torpedoActive = torpedoStat.count > 0 && now < torpedoStat.expireTime;
  const shatterActive = shatterStat && shatterStat.count > 0 && now < shatterStat.expireTime;
  const burnActive    = burnStat   && burnStat.count > 0   && now < burnStat.expireTime;
  const floodActive   = floodStat  && floodStat.count > 0  && now < floodStat.expireTime;
  const mineActive    = mineStat   && mineStat.count > 0   && now < mineStat.expireTime;
  const ricochetActive = ricochetStat && ricochetStat.count > 0 && now < ricochetStat.expireTime;
  const torpRicActive = torpedoRicochetStat && torpedoRicochetStat.count > 0 && now < torpedoRicochetStat.expireTime;
  const mineRicActive = mineRicochetStat && mineRicochetStat.count > 0 && now < mineRicochetStat.expireTime;
  const accessoryActive = accessoryStat && accessoryStat.count > 0 && now < accessoryStat.expireTime;   // 配损（2026-09-05，橙红同碎甲色）
  const wepDamageActive = wepDamageStat && wepDamageStat.count > 0 && now < wepDamageStat.expireTime;   // 武损（2026-09-13，红色同燃烧）

  if (!mainGunActive && !torpedoActive && !shatterActive && !burnActive && !floodActive && !mineActive && !ricochetActive && !torpRicActive && !mineRicActive && !accessoryActive && !wepDamageActive) return;

  // 规避胶囊（灰底，小地图右侧外部 x=224，2026-08-06 鱼雷/水雷独立）：主炮 228 / 鱼雷 276 / 水雷 324 纵向排
  var ricRow = 16 + 200 + 12;
  if (ricochetActive) {
    this._drawHitPill(224, ricRow, cfg.width, cfg.height, '#555A60', ricochetStat.count, 'ricochet');
    ricRow += cfg.height + 8;
  }
  if (torpRicActive) {
    this._drawHitPill(224, ricRow, cfg.width, cfg.height, '#555A60', torpedoRicochetStat.count, 'ricochet');
    ricRow += cfg.height + 8;
  }
  if (mineRicActive) {
    this._drawHitPill(224, ricRow, cfg.width, cfg.height, '#555A60', mineRicochetStat.count, 'ricochet');
  }

  var row = 0;
  if (mainGunActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, cfg.mainGunBgColor,
                      mainGunStat.count, 'mainGun');
    row++;
  }
  if (torpedoActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, cfg.torpedoBgColor,
                      torpedoStat.count, 'torpedo');
    row++;
  }
  if (shatterActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, SHATTER_HIT_BG,
                      shatterStat.count, 'shatter');
    row++;
  }
  if (burnActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, BURN_HIT_BG,
                      burnStat.count, 'burn');
    row++;
  }
  if (floodActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, FLOOD_HIT_BG,
                      floodStat.count, 'flood');
    row++;
  }
  if (mineActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, MINE_HIT_BG,
                      mineStat.count, 'mine');
    row++;
  }
  // 配损：1 个共用橙红药丸（颜色同碎甲），图标随最近触发的配损类型变（2026-09-05）
  if (accessoryActive) {
    var accType = accessoryStat.lastType === 'engineDamage' ? 'engine'
      : accessoryStat.lastType === 'radarDamage' ? 'radar' : 'rudder';
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, SHATTER_HIT_BG,
                      accessoryStat.count, accType);
    row++;
  }
  // 武损：1 个红色药丸（字人"命中统计显示为红色，和燃烧一样"；2026-09-13）
  if (wepDamageActive) {
    this._drawHitPill(rightX - cfg.width, cfg.marginTop + row * (cfg.height + 12),
                      cfg.width, cfg.height, WEP_DAMAGE_HIT_BG,
                      wepDamageStat.count, 'weaponDamage');
  }
};

/**
 * Draw a single rounded-pill hit counter.
 *
 * @param {number} x            — top-left x (screen px)
 * @param {number} y            — top-left y (screen px)
 * @param {number} w            — pill width
 * @param {number} h            — pill height
 * @param {string} bgColor      — pill fill colour
 * @param {number} count        — hit count
 * @param {'mainGun'|'torpedo'|'shatter'|'burn'|'flood'} type — icon variant
 */
Renderer.prototype._drawHitPill = function (x, y, w, h, bgColor, count, type) {
  const ctx = this.ctx;

  // ⚠ 本函数改 textBaseline('middle')/textAlign('left')/font/fillStyle/strokeStyle/lineWidth。
  //   调用方 _drawHitStats 在 renderer.js L166（**舰船循环之后**），残留值跨帧渗到下一帧的
  //   _drawFloatingHP → 敌舰名字压血条（2026-10-03 截击俾斯麦战役复现）。
  //   这其实是**触发频率最高**的一条污染路径：只要打过一下（药丸存活 3s）就一直在，
  //   比"多层减益才出现的 'top'"常见得多 → 玩家看到的是"最近挨打了/打了之后名字就糊"。
  ctx.save();

  // rounded-rectangle background
  ctx.fillStyle = bgColor;
  const r = h / 2;
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arc(x + w - r, y + r, r, -Math.PI / 2, Math.PI / 2);
  ctx.lineTo(x + r, y + h);
  ctx.arc(x + r, y + r, r, Math.PI / 2, -Math.PI / 2);
  ctx.closePath();
  ctx.fill();

  // "×N" text
  ctx.fillStyle = HIT_STAT.textColor;
  ctx.font = HIT_STAT.font;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText('×' + count, x + 18, y + h / 2);

  // icon on the right
  const iconCx = x + w - 24;
  const iconCy = y + h / 2;
  const iconR  = HIT_STAT.iconSize / 2;

  if (type === 'mainGun') {
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.7, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = bgColor;
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(iconCx - 2, iconCy - iconR, 4, iconR * 1.2);
  } else if (type === 'torpedo') {
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.ellipse(iconCx, iconCy, iconR * 1.0, iconR * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.8, iconCy);
    ctx.lineTo(iconCx - iconR * 1.1, iconCy - iconR * 0.3);
    ctx.lineTo(iconCx - iconR * 1.1, iconCy + iconR * 0.3);
    ctx.closePath();
    ctx.fill();
  } else if (type === 'shatter') {
    // cracked shield / broken armour icon
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.7, 0, Math.PI * 2);
    ctx.fill();
    // crack lines
    ctx.strokeStyle = bgColor;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.5, iconCy - iconR * 0.5);
    ctx.lineTo(iconCx, iconCy);
    ctx.lineTo(iconCx + iconR * 0.4, iconCy + iconR * 0.6);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(iconCx + iconR * 0.1, iconCy - iconR * 0.3);
    ctx.lineTo(iconCx + iconR * 0.6, iconCy - iconR * 0.1);
    ctx.stroke();
  } else if (type === 'burn') {
    // 火焰轮廓：水滴底 + 左高右低两个不对称的火苗尖（与减益图标同步）
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.70, iconCy + iconR * 0.50);
    ctx.quadraticCurveTo(iconCx - iconR * 1.10, iconCy + iconR * 0.10, iconCx - iconR * 0.35, iconCy - iconR * 1.00);
    ctx.quadraticCurveTo(iconCx - iconR * 0.15, iconCy - iconR * 0.95, iconCx + iconR * 0.05, iconCy - iconR * 0.30);
    ctx.quadraticCurveTo(iconCx + iconR * 0.25, iconCy - iconR * 0.85, iconCx + iconR * 0.55, iconCy - iconR * 0.50);
    ctx.quadraticCurveTo(iconCx + iconR * 1.00, iconCy + iconR * 0.20, iconCx + iconR * 0.60, iconCy + iconR * 0.50);
    ctx.quadraticCurveTo(iconCx, iconCy + iconR * 0.75, iconCx - iconR * 0.70, iconCy + iconR * 0.50);
    ctx.closePath();
    ctx.fill();
  } else if (type === 'flood') {
    // 三个水滴
    ctx.fillStyle = '#FFFFFF';
    var drops = [
      { dx: -iconR * 0.50, dy: 0 },
      { dx:  iconR * 0.00, dy: -iconR * 0.15 },
      { dx:  iconR * 0.50, dy: 0 },
    ];
    for (var di = 0; di < drops.length; di++) {
      var dcx = iconCx + drops[di].dx;
      var dcy = iconCy + drops[di].dy;
      ctx.beginPath();
      ctx.moveTo(dcx, dcy - iconR * 0.60);
      ctx.quadraticCurveTo(dcx + iconR * 0.45, dcy + iconR * 0.10, dcx + iconR * 0.20, dcy + iconR * 0.55);
      ctx.quadraticCurveTo(dcx, dcy + iconR * 0.65, dcx - iconR * 0.20, dcy + iconR * 0.55);
      ctx.quadraticCurveTo(dcx - iconR * 0.45, dcy + iconR * 0.10, dcx, dcy - iconR * 0.60);
      ctx.closePath();
      ctx.fill();
    }
  } else if (type === 'mine') {
    // 带刺水雷球（白色刺球）
    ctx.fillStyle = '#FFFFFF';
    var spikes = 6;
    var outerR = iconR * 1.0;
    var innerR = iconR * 0.45;
    ctx.beginPath();
    for (var si = 0; si < spikes * 2; si++) {
      var sAng = (si * Math.PI) / spikes;
      var sRad = (si % 2 === 0) ? outerR : innerR;
      var spx = iconCx + Math.cos(sAng) * sRad;
      var spy = iconCy + Math.sin(sAng) * sRad;
      if (si === 0) ctx.moveTo(spx, spy); else ctx.lineTo(spx, spy);
    }
    ctx.closePath();
    ctx.fill();
    // 中心球心
    ctx.fillStyle = bgColor;
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, innerR * 0.6, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 'ricochet') {
    // 跳弹：长方形炮弹在装甲线（一条直线）上断成两半
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.beginPath();                       // 装甲线（水平直线）
    ctx.moveTo(iconCx - iconR * 1.1, iconCy + iconR * 0.55);
    ctx.lineTo(iconCx + iconR * 1.1, iconCy + iconR * 0.55);
    ctx.stroke();
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(iconCx - iconR * 0.95, iconCy - iconR * 0.45, iconR * 0.95, iconR * 0.55);   // 左半炮弹
    ctx.fillRect(iconCx + iconR * 0.15, iconCy - iconR * 0.45, iconR * 0.75, iconR * 0.55);   // 右半炮弹（错开=断成两半）
  } else if (type === 'rudder') {
    // 舵机损毁：舵轮（外圈 + 十字辐条 + 中心点）
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.72, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.72, iconCy);
    ctx.lineTo(iconCx + iconR * 0.72, iconCy);
    ctx.moveTo(iconCx, iconCy - iconR * 0.72);
    ctx.lineTo(iconCx, iconCy + iconR * 0.72);
    ctx.stroke();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.2, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 'engine') {
    // 引擎损毁：齿轮（6 齿 + 中心孔）
    ctx.fillStyle = '#FFFFFF';
    var te2 = 6;
    ctx.beginPath();
    for (var ti2 = 0; ti2 < te2 * 2; ti2++) {
      var ta2 = (ti2 * Math.PI) / te2;
      var tr2 = (ti2 % 2 === 0) ? iconR * 0.85 : iconR * 0.55;
      var tx2 = iconCx + Math.cos(ta2) * tr2;
      var ty2 = iconCy + Math.sin(ta2) * tr2;
      if (ti2 === 0) ctx.moveTo(tx2, ty2); else ctx.lineTo(tx2, ty2);
    }
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = bgColor;
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.3, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 'radar') {
    // 雷达损毁：上半圆扫描盘 + 交叉断裂线
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(iconCx, iconCy, iconR * 0.72, Math.PI, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.72, iconCy);
    ctx.lineTo(iconCx + iconR * 0.72, iconCy);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.45, iconCy - iconR * 0.45);
    ctx.lineTo(iconCx + iconR * 0.45, iconCy + iconR * 0.45);
    ctx.moveTo(iconCx + iconR * 0.45, iconCy - iconR * 0.45);
    ctx.lineTo(iconCx - iconR * 0.45, iconCy + iconR * 0.45);
    ctx.stroke();
  } else if (type === 'weaponDamage') {
    // 武器损毁（武损，2026-09-13）：断成两截的炮管（左右错位）+ 断裂处爆裂线
    // 与顶部减益图标同款符号，保持识别一致
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(iconCx - iconR * 1.05, iconCy - iconR * 0.58, iconR * 0.85, iconR * 0.44);
    ctx.fillRect(iconCx + iconR * 0.22, iconCy + iconR * 0.14, iconR * 0.85, iconR * 0.44);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(iconCx - iconR * 0.30, iconCy - iconR * 0.90);
    ctx.lineTo(iconCx + iconR * 0.12, iconCy - iconR * 0.28);
    ctx.moveTo(iconCx - iconR * 0.02, iconCy + iconR * 0.24);
    ctx.lineTo(iconCx + iconR * 0.40, iconCy + iconR * 0.92);
    ctx.stroke();
  }

  ctx.restore();   // ★ 不把 textBaseline='middle' 留给下一帧的 _drawFloatingHP
};
