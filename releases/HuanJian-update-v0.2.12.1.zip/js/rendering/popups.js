/**
 * popups.js — 飘字子系统（2026-08-07 从 main.js 拆出）
 *
 * 职责：维护 damagePopups 数组（世界坐标漂浮文字）并提供 4 个 spawn + 2 个 update。
 * 数据：renderer.render(..., damagePopups, ...) 每帧绘制（传入数组引用）；
 *       battleStats.getKillToasts() 由 updateKillToasts 驱动生命周期（DOM 层在 ui.js）。
 * 常量：DAMAGE_POPUP（constants.js，飘字样式/物理参数）。
 */
const Popups = {
  /** 激活中的飘字数组（main.js 持引用传给 renderer） */
  list: [],

  /** 通用：构造一个飘字对象（散落位置 + 上抛物理） */
  _make(screenX, screenY, text, color, strokeColor) {
    var scatter = DAMAGE_POPUP.scatterRadius;
    return {
      x: screenX + (Math.random() - 0.5) * scatter * 2,
      y: screenY + (Math.random() - 0.5) * scatter,
      vy: DAMAGE_POPUP.initialVy,
      life: 0,
      maxLife: DAMAGE_POPUP.lifetime,
      text: text,
      color: color,
      strokeColor: strokeColor,
      alpha: 1,
    };
  },

  spawnBurnPopup(screenX, screenY, damage) {
    this.list.push(this._make(screenX, screenY, '燃烧' + damage, DAMAGE_POPUP.color, DAMAGE_POPUP.strokeColor));
  },

  spawnFloodPopup(screenX, screenY, damage) {
    this.list.push(this._make(screenX, screenY, '漏水' + damage, '#66CCFF', '#004466'));
  },

  spawnHealPopup(screenX, screenY, amount) {
    if (!SETTINGS.fx.damagePopups) return;
    this.list.push(this._make(screenX, screenY, '+' + amount, '#33CC66', '#003322'));
  },

  /** 通用文本飘字（自定义文案/颜色，2026-08-09：血池熔铸·免疫提示） */
  spawnTextPopup(screenX, screenY, text, color, strokeColor) {
    if (!SETTINGS.fx.damagePopups) return;
    this.list.push(this._make(screenX, screenY, text, color || '#FFFFFF', strokeColor || '#333333'));
  },

  /**
   * 伤害飘字（按命中类型着色/文案）。
   * @param {number} damage — 数值（无负号，内部拼 '-'）
   */
  spawnDamagePopup(screenX, screenY, damage, isCrit, isPenetration, isExecute, isRicochet) {
    if (!SETTINGS.fx.damagePopups) return;
    isCrit = isCrit || false;
    isPenetration = isPenetration || false;
    isExecute = isExecute || false;
    isRicochet = isRicochet || false;
    var text, color, strokeColor;
    if (isRicochet) {
      // 跳弹/规避：灰色「规避」字（2026-08-06 我方被敌弹命中但触发跳弹时的反馈）
      text = '规避';
      color = '#7FA8C9';
      strokeColor = 'rgba(10,20,35,0.9)';
    } else if (isCrit) {
      text = '暴击' + damage;
      color = DAMAGE_POPUP.critColor;
      strokeColor = DAMAGE_POPUP.critStrokeColor;
    } else if (isPenetration) {
      text = '穿甲' + damage;
      color = DAMAGE_POPUP.penetrationColor;
      strokeColor = DAMAGE_POPUP.penetrationStrokeColor;
    } else if (isExecute) {
      text = '收割' + damage;
      color = DAMAGE_POPUP.executeColor;
      strokeColor = DAMAGE_POPUP.executeStrokeColor;
    } else {
      text = '-' + damage;
      color = DAMAGE_POPUP.color;
      strokeColor = DAMAGE_POPUP.strokeColor;
    }
    this.list.push(this._make(screenX, screenY, text, color, strokeColor));
  },

  /** 每帧更新（上抛 + 淡出 + 过期移除） */
  update(dt) {
    var arr = this.list;
    for (var i = arr.length - 1; i >= 0; i--) {
      var p = arr[i];
      p.life += dt;
      p.vy  += DAMAGE_POPUP.gravity * dt;
      p.y   += p.vy * dt;
      var phase = p.life / p.maxLife;
      p.alpha = phase < 0.5 ? 1 : 1 - (phase - 0.5) * 2;
      if (p.life >= p.maxLife) arr.splice(i, 1);
    }
  },

  /** 击杀飞入特效更新（battleStats.checkDeaths push 时挂上，2026-08-06）：2.4s 后自动消失（与 CSS 动画 2.2s 对齐，留 0.2s 裕量） */
  updateKillToasts(dt, battleStats) {
    var toasts = battleStats.getKillToasts();
    for (var i = toasts.length - 1; i >= 0; i--) {
      toasts[i].life += dt;
      if (toasts[i].life >= 2400) toasts.splice(i, 1);
    }
  },
};
