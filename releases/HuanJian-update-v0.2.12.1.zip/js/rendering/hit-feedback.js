/**
 * hit-feedback.js — 受击屏幕反馈（Renderer 原型扩展）
 *
 * 两种特效：
 *   1. 屏幕摇晃 —— 正弦衰减波形（连贯有惯性，不是每帧白噪声）：
 *        offset = 方向 × 幅度峰值 × 强度系数 × e^(-t/τ) × sin(2π·f·t)
 *        方向 = 命中点指向屏幕中心的反向（炮弹从哪边打来就往哪边震）。
 *        强度系数按连击叠加（齐射 6 发 → 封顶 2 倍），每次受击重置
 *        波形相位 → 有"猛震一下 → 余震 → 平息"的层次和节奏感。
 *   2. 边缘泛红 —— 纯红径向渐变遮罩，0.3s 快速淡出。
 *
 * 只做纯平移、不做旋转：相机 roll 会让平直的地图边界在低缩放时
 * 倾斜扭曲，观感奇怪（见 constants.js 调参经验）。
 *
 * 触发：main.js 命中事件循环中"玩家被敌方武器命中"分支调用
 *       renderer.triggerHitFeedback(ev.x, ev.y)。燃烧/漏水等 DOT 不产生
 *       命中事件，因此不会触发本模块。
 *
 * 摇晃只作用在世界坐标变换（worldToScreen）上：海面网格/船只/弹道/
 * 尾迹一起动，而命中统计药丸、减益图标等屏幕坐标 HUD 保持稳定；
 * 小地图用独立 transform，也不受影响。
 *
 * 泛红遮罩"不影响游戏"的保证：
 *   - 渐变中心（inner 半径内）透明度恒为 0，玩家船与准星区域永远清晰；
 *   - 边缘透明度封顶 flashAlpha；
 *   - 只是 Canvas 绘制，不拦截任何输入。
 */

Renderer.prototype.initHitFeedback = function() {
  this.shakeAmp  = 0;   // 强度系数 0..shakeMaxStreak（1 = 单发受击）
  this.shakeDirX = 0;   // 位移方向（归一化，命中点 → 屏幕中心 的反向）
  this.shakeDirY = 0;
  this.hitShakeT = 0;   // 波形累计时间（秒），驱动 sin 相位与指数衰减
  this.hitFlash  = 0;   // 0..1，边缘泛红强度
  this.hitStreak = 0;   // 连击计数（streakWindow 内连续受击）
  this.timeSinceLastHit = 0;
  this.shakeOffX = 0;   // 本帧世界摇晃偏移（屏幕 px）
  this.shakeOffY = 0;
};

/**
 * 触发受击反馈。wx/wy 为命中点世界坐标。
 * - 连击：窗口内再次受击 → 强度叠加（封顶 shakeMaxStreak）；
 * - 方向：首击定方向（窗口内连击沿用，同帧多弹方向近似一致）；
 * - 相位：重置到第一波峰值，受击当帧就"猛震"而不是延迟一帧。
 */
Renderer.prototype.triggerHitFeedback = function(wx, wy) {
  if (SETTINGS.fx.shake) {
    if (this.timeSinceLastHit <= HIT_FEEDBACK.streakWindow) this.hitStreak++;
    else this.hitStreak = 1;
    this.timeSinceLastHit = 0;
    this.shakeAmp = Math.min(HIT_FEEDBACK.shakeMaxStreak, this.hitStreak);

    if (this.hitStreak === 1) {
      var p = this.worldToScreen(wx, wy);
      var dx = p.x - this.width / 2;
      var dy = p.y - this.height / 2;
      var len = Math.hypot(dx, dy);
      this.shakeDirX = len > 1 ? dx / len : 0;
      this.shakeDirY = len > 1 ? dy / len : 0;
    }

    // 相位重置到正弦峰值（t = 1/4 周期）：受击当帧立即有最大位移
    this.hitShakeT = 1 / (4 * HIT_FEEDBACK.shakeFreq);
  }
  if (SETTINGS.fx.flash) {
    this.hitFlash = 1;
  }
};

/**
 * 每帧更新：推进波形并计算本帧摇晃偏移。
 * 波形在 shakeEndTime 后结束，位移归零（指数尾巴不可见，无需继续算）。
 */
Renderer.prototype.updateHitFeedback = function(dt) {
  this.timeSinceLastHit += dt;
  this.hitShakeT += dt;

  if (this.hitFlash > 0) {
    this.hitFlash *= Math.exp(-dt / HIT_FEEDBACK.flashTau);
    if (this.hitFlash < 0.001) this.hitFlash = 0;
  }

  if (this.shakeAmp > 0 && this.hitShakeT < HIT_FEEDBACK.shakeEndTime) {
    var d = Math.exp(-this.hitShakeT / HIT_FEEDBACK.shakeTau);
    var amp = HIT_FEEDBACK.shakeAmp * this.shakeAmp * d
            * Math.sin(2 * Math.PI * HIT_FEEDBACK.shakeFreq * this.hitShakeT);
    this.shakeOffX = this.shakeDirX * amp;
    this.shakeOffY = this.shakeDirY * amp;
  } else {
    this.shakeOffX = 0;
    this.shakeOffY = 0;
  }
};

/** 屏幕边缘红色遮罩（在 render() 最后绘制，覆盖整个世界） */
Renderer.prototype.drawHitVignette = function() {
  if (!SETTINGS.fx.flash) return;
  if (this.hitFlash <= 0.01) return;
  var ctx = this.ctx;
  var w = this.width;
  var h = this.height;
  var alpha = this.hitFlash * HIT_FEEDBACK.flashAlpha;
  var inner = Math.min(w, h) * 0.45;
  var outer = Math.max(w, h) * 0.72;
  var g = ctx.createRadialGradient(w / 2, h / 2, inner, w / 2, h / 2, outer);
  g.addColorStop(0, 'rgba(255,0,0,0)');
  g.addColorStop(1, 'rgba(255,0,0,' + alpha.toFixed(3) + ')');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
};
