/**
 * rendering/projectiles.js — 弹丸绘制（Renderer.prototype 扩展，2026-08-09 从 renderer.js 拆出）
 *
 * _drawProjectile 分发 + 主炮/鱼雷/水雷各绘制（含尾迹）。
 */

  /* ── projectile ─────────────────────────────────────────────────────── */

  Renderer.prototype._drawProjectile = function(proj) {
    var ctx = this.ctx;
    var s = this.worldToScreen(proj.x, proj.y);

    if (proj instanceof MainGunShell) {
      this._drawMainGunShell(proj, s);
    } else if (proj instanceof SeaMine) {
      this._drawSeaMine(proj, s);
    } else {
      this._drawTorpedoProjectile(proj, s);
    }
  };

  /** 水雷 — 黑点 + 引爆半径圈（我方绿 / 敌方红，友军同我方） */
  Renderer.prototype._drawSeaMine = function(proj, s) {
    var ctx = this.ctx;
    var friendly = proj.team ? proj.team !== 'enemy' : proj.isPlayer;

    // 引爆半径圈
    ctx.strokeStyle = friendly ? 'rgba(80,220,120,0.55)' : 'rgba(255,80,80,0.55)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.arc(s.x, s.y, Math.max(4, proj.detonationRadius * this.zoom), 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // 黑点
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(s.x, s.y, Math.max(3, 4 * this.zoom), 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1;
    ctx.stroke();
  };

  /** Main gun shell — fire trail + bright core（副炮为半透明白） */
  Renderer.prototype._drawMainGunShell = function(proj, s) {
    var ctx = this.ctx;
    var trail = proj.trail;
    var isSec = !!proj.isSecondary;

    // fire trail particles (fading behind the shell)
    if (trail && trail.length >= 2) {
      var len = trail.length;
      for (var i = 0; i < len; i++) {
        var age = (len - i) / len;  // 0 (newest) → 1 (oldest)
        var pt = this.worldToScreen(trail[i].x, trail[i].y);
        var r = proj.radius * (1.2 - age * 0.8);  // bigger → smaller
        if (r < 0.3) continue;

        if (isSec) {
          // 副炮：半透明白色尾迹
          ctx.fillStyle = 'rgba(255,255,255,' + (0.5 * (1 - age) * proj.alpha).toFixed(2) + ')';
        } else {
          // color: orange → red → fade
          var alpha = 0.7 * (1 - age);
          var g = Math.round(100 * (1 - age));
          ctx.fillStyle = 'rgba(255,' + g + ',0,' + alpha.toFixed(2) + ')';
        }
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // shell body
    if (isSec) {
      ctx.globalAlpha = proj.alpha;
      ctx.fillStyle = proj.color;
      ctx.beginPath();
      ctx.arc(s.x, s.y, proj.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    } else {
      ctx.fillStyle = proj.color;
      ctx.beginPath();
      ctx.arc(s.x, s.y, proj.radius, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  /** Torpedo — water wake trail (same principle as ship wake) */
  Renderer.prototype._drawTorpedoProjectile = function(proj, s) {
    var ctx = this.ctx;
    var trail = proj.trail;

    // wake trail — multi-band fading line following torpedo path
    if (trail && trail.length >= 2) {
      var len = trail.length;
      var bands = [
        { fromLen: len - 5,  toLen: len,     alpha: 0.30, width: 2.5 },
        { fromLen: len - 12, toLen: len - 5,  alpha: 0.15, width: 1.5 },
        { fromLen: 0,         toLen: len - 12, alpha: 0.06, width: 0.8 },
      ];

      ctx.lineCap  = 'round';
      ctx.lineJoin = 'round';

      for (var bi = 0; bi < bands.length; bi++) {
        var band = bands[bi];
        var start = Math.max(0, band.fromLen);
        var end   = Math.max(0, band.toLen);
        if (end - start < 2) continue;

        ctx.globalAlpha = band.alpha;
        ctx.strokeStyle = 'rgba(160,210,255,1)';
        ctx.lineWidth   = band.width;
        ctx.beginPath();
        var firstPt = this.worldToScreen(trail[start].x, trail[start].y);
        ctx.moveTo(firstPt.x, firstPt.y);
        for (var i = start + 1; i < end; i++) {
          var pi = this.worldToScreen(trail[i].x, trail[i].y);
          ctx.lineTo(pi.x, pi.y);
        }
        ctx.lineTo(s.x, s.y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }

    // torpedo body
    ctx.fillStyle = proj.color;
    ctx.beginPath();
    ctx.arc(s.x, s.y, proj.radius * 0.9, 0, Math.PI * 2);
    ctx.fill();
  };
