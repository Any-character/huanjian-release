/**
 * minimap.js — Minimap rendering (prototype extension for Renderer).
 * allies 为可选参数（AI 友军，青色点）。玩家死亡（旁观）时不过滤视野。
 */
Renderer.prototype.renderMinimap = function (player, enemies, allies) {
  const ctx = this.mmCtx;
  const s = MINIMAP_SIZE;
  const scale = s / MAP_SIZE_PX;
  enemies = enemies || [];
  allies = allies || [];
  const seeAll = !player || !player.isAlive;
  // 蓝方共享视野观察者（玩家 + 友军）
  const obs = [player].concat(allies);

  ctx.clearRect(0, 0, s, s);

  // background（夜海底色，2026-11-15 与选船页海图同一色系）
  ctx.fillStyle = 'rgba(10, 20, 23, 0.82)';
  ctx.fillRect(0, 0, s, s);

  // border（刻线；外框的 1px 由 CSS 画，这里只留一条内线）
  ctx.strokeStyle = '#24383C';
  ctx.lineWidth = 1;
  ctx.strokeRect(0.5, 0.5, s - 1, s - 1);

  // enemy dots (detection-gated, colour by ship type)
  for (var ei = 0; ei < enemies.length; ei++) {
    var e = enemies[ei];
    if (e && e.isAlive && (seeAll || Detection.canSeeShipByAny(obs, e) || (e.hasBuff && e.hasBuff('lit')))) {
      ctx.fillStyle = e.color || '#FF4444';
      ctx.beginPath();
      ctx.arc(e.x * scale, e.y * scale, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // ally dots（青，比原来压暗一档，避免比玩家点更抢眼）
  for (var ai = 0; ai < allies.length; ai++) {
    var a = allies[ai];
    if (a && a.isAlive && (seeAll || Detection.canSeeShipByAny(obs, a))) {
      ctx.fillStyle = '#6FA5A0';
      ctx.beginPath();
      ctx.arc(a.x * scale, a.y * scale, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // player dot（黄铜：全场唯一"我"的标记）
  if (player && player.isAlive) {
    ctx.fillStyle = '#C0934E';
    ctx.beginPath();
    ctx.arc(player.x * scale, player.y * scale, 4, 0, Math.PI * 2);
    ctx.fill();
    // direction indicator
    const px = player.x * scale;
    const py = player.y * scale;
    const tipX = px + Math.sin(player.heading) * 8;
    const tipY = py - Math.cos(player.heading) * 8;
    ctx.strokeStyle = '#DDB36C';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(tipX, tipY);
    ctx.stroke();
  }

  // main-gun range ring on minimap
  if (player && player.isAlive) {
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 0.8;
    ctx.setLineDash([3, 5]);
    ctx.beginPath();
    ctx.arc(player.x * scale, player.y * scale, player.weaponCfg.mainGun.range * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // view-rectangle
  if (player && player.isAlive) {
    const vw = (this.width / this.zoom) * scale;
    const vh = (this.height / this.zoom) * scale;
    const vx = player.x * scale - vw / 2;
    const vy = player.y * scale - vh / 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1;
    ctx.strokeRect(vx, vy, vw, vh);
  }
};
