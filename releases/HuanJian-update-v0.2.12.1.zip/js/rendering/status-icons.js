/**
 * status-icons.js — 战斗状态图标库：**分配表**（2026-11-15）
 *
 * 为什么要有「库」：
 *   原来增益区所有 buff 都画同一个向上箭头，玩家看不出「这是加了护甲」还是「加了射速」。
 *   但也不该给每个 buff 单独画图标（美术量爆炸、且新 buff 一加就得补）。
 *   折中：**按「主要增益的方面」分配** —— 护盾 / 装甲 / 机动 / 火力 / 装填 / 精度 / 鱼雷 / 雷达 / 隐蔽 / 真伤……
 *   同一类效果共用一枚图标，具体是什么 buff 由 tooltip（名字）和角标（层数）说清。
 *
 * 文件分工：
 *   · 本文件 = 「谁用哪枚图标」（KEY_ICON / MOD_ICON / DEBUFF_KEYS）+ resolve / draw
 *   · status-glyphs.js = 「每枚图标长什么样」（几何画笔）
 *   拆开的理由：一个文件装不下（AGENTS §7.3 的 400 行硬规则）。
 *
 * 契约：
 *   · 纯函数表 + Canvas 调度，不依赖 Renderer / DOM —— Node 单测可直接调用（第 100 节）。
 *   · 白色图形画在调用方给的有色方块上；`bg` 参数是**方块底色**，用于挖洞/裂纹。
 *   · 图形按 14px 见方设计（r≈6.4），笔画 ≥1.4px；细节多了在 28px 图标里会糊成一团。
 *   · 新增 buff：先在 KEY_ICON 里登记；没登记的会按 mods 落到 MOD_ICON；再没有就是 'buff'（向上箭头）。
 */

const StatusIcons = {
  /**
   * 精确分配：key → 图标 id。
   * 命名原则 = 玩家一眼能懂的主要效果，不是"这个 buff 的名字"。
   */
  KEY_ICON: {
    // 防护类
    invincible: 'shield',          // 无敌 / 濒死无敌
    shatterImmune: 'shield',       // 免疫碎甲
    mirrorHullProtect: 'shield',   // 水镜之盾
    layerShield: 'shield',         // 防御矩阵（叠层盾）
    armorBuff: 'armor',            // 装甲强化
    evasionBuff: 'evasion',        // 全口径规避
    ambitionArc: 'evasion',        // 国度的雄心（最终减伤 + 炮弹规避）
    // 进攻类
    loaderAccuracy: 'accuracy',    // 装填大师·精度
    perfectArmor: 'accuracy',      // 完美装甲（命中率层）
    ambitionLockIcon: 'lock',      // 锁定层数
    ambitionFireLayer: 'power',    // 雄心·火力
    wiHeavyStacks: 'trueDmg',      // 重击·真伤
    desperateChant: 'star',        // 绝望讴歌（暴击伤害/穿甲伤害综合增益）
    bloodPoolBonus: 'star',        // 血池熔铸（全属性）
    // 鱼雷 / 水雷
    yanyinHuntTorp: 'torpedo',     // 鱼雷加速
    yanyinHuntDebuff: 'torpedo',   // 鱼雷水雷减伤降低（减益）
    yanyinReloadStack: 'reload',   // 水雷装填加速
    // 机动 / 探测 / 隐蔽
    yanyinMobility: 'mobility',    // 机动性 +10%
    redsquareAlly: 'mobility',     // 红场庇护（友军加速）
    yanyinAntiRadar: 'radar',      // 反雷达干扰
    yanyinHuntActive: 'stealth',   // 蜃光猎影
    // 减益（走 buff 体系但画在减益区）
    weary: 'weaken',               // 疲弱（武器伤害 -20%）
    fearAura: 'weaken',            // 畏惧光环
    defenseMatrix: 'weaken',       // 防御矩阵（对敌：武器伤害 -8%）
    lutjensSlow: 'slow',           // 最大航速 -5%
    redsquareEnemy: 'slow',        // 红场压制
    wiHeavyDebuff: 'slow',         // 重击·压制（机动/装填变慢）
    // 配损 / 武损（图形与 accessory-debuffs 共用）
    engineDamage: 'engine',
    rudderDamage: 'rudder',
    radarDamage: 'radarDamage',
  },

  /**
   * 兜底分配：没登记 key 的 buff（典型 = 舰船技能光环 shipskill_*），按 mods 的主要效果认。
   * 顺序 = 优先级：先判减益/防护，再判进攻与机动。
   */
  MOD_ICON: [
    ['weaponDmgPen', 'weaken'], ['shotAccuracyPen', 'weaken'],
    ['critDmgPen', 'weaken'], ['shellSpeedMul', 'weaken'],
    ['speedMulPen', 'slow'], ['speedClampMax', 'slow'],
    ['reduceWeaponDmgAdd', 'shield'], ['resistPenetrationAdd', 'shield'],
    ['resistCritChanceAdd', 'shield'], ['finalReduceAdd', 'shield'],
    ['hullProtectAdd', 'shield'], ['immuneCrit', 'shield'],
    ['immuneBaseWeaponDamage', 'shield'], ['hpAdd', 'shield'],
    ['armorAdd', 'armor'],
    ['evasionAllAdd', 'evasion'], ['torpedoEvasionAdd', 'evasion'], ['mineEvasionAdd', 'evasion'],
    ['weaponAccuracyAdd', 'accuracy'],
    ['reloadFlatReduce_mainGun', 'reload'], ['reloadFlatReduce_secondary', 'reload'],
    ['reloadFlatReduce_mine', 'reload'], ['reloadPctReduce', 'reload'],
    ['torpedoSpeedAdd', 'torpedo'], ['torpPanelDmgPct', 'torpedo'], ['huntDebuff', 'torpedo'],
    ['mainTrueDmgAdd', 'trueDmg'], ['secTrueDmgAdd', 'trueDmg'],
    ['penDmgAdd', 'power'], ['critDmgAdd', 'power'], ['secShellSpeedAdd', 'power'],
    ['antiRadarJamming', 'radar'],
    ['lockLayers', 'lock'],
    ['huntActive', 'stealth'],
    ['speedMulAdd', 'mobility'], ['accelPowerAdd', 'mobility'],
    ['rotationSpeedAdd', 'mobility'], ['turnPowerAdd', 'mobility'],
  ],

  /**
   * 走 buff 体系、但属于**减益**的 key（renderer 用它把减益挡在增益区之外）。
   * `lit`（被点亮）是标记型，不画图标，但仍要挡住。
   */
  DEBUFF_KEYS: {
    engineDamage: 1, rudderDamage: 1, radarDamage: 1,
    weary: 1, fearAura: 1, redsquareEnemy: 1, lit: 1,
    lutjensSlow: 1, wiHeavyDebuff: 1, yanyinHuntDebuff: 1, defenseMatrix: 1,
  },

  /** 由 _drawDebuffs 补画的通用减益（配损/武损另有专门排布，不在此列） */
  GENERIC_DEBUFF_KEYS: [
    'weary', 'lutjensSlow', 'wiHeavyDebuff', 'yanyinHuntDebuff',
    'fearAura', 'redsquareEnemy', 'defenseMatrix',
  ],

  /** 当前库里的全部图标 id（单测用它检查「表里写的 id 都画得出来」） */
  IDS: [
    'buff', 'shield', 'armor', 'evasion', 'accuracy', 'lock', 'power',
    'reload', 'torpedo', 'mobility', 'radar', 'radarDamage', 'stealth',
    'trueDmg', 'star', 'slow', 'weaken',
    'shatter', 'burn', 'flood', 'rudder', 'engine', 'weaponBroken',
  ],

  /** 画笔表：由 status-glyphs.js 挂上来（加载顺序见 index.html） */
  GLYPHS: {},

  /**
   * 解析一个 buff 该用哪枚图标。
   * @param {string} key  — buff key（addBuff 的第一个参数）
   * @param {object} buff — { mods }
   * @returns {string} 图标 id（保底 'buff'）
   */
  resolve(key, buff) {
    if (key && this.KEY_ICON[key]) return this.KEY_ICON[key];
    const mods = (buff && buff.mods) || {};
    for (let i = 0; i < this.MOD_ICON.length; i++) {
      const k = this.MOD_ICON[i][0];
      if (mods[k] !== undefined && mods[k] !== 0) return this.MOD_ICON[i][1];
    }
    return 'buff';
  },

  /**
   * 画一枚图标。
   * @param {CanvasRenderingContext2D} ctx
   * @param {string} id — 图标 id；未知 id 落到 'buff'
   * @param {number} cx,cy — 图标中心
   * @param {number} r — 半径（约 6.4px）
   * @param {string} [bg] — 方块底色（挖洞/裂纹用）
   */
  draw(ctx, id, cx, cy, r, bg) {
    // 图形统一白色；底色用于"挖"出负形
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineCap = 'butt';
    ctx.lineJoin = 'miter';
    const g = this.GLYPHS[id] || this.GLYPHS.buff;
    if (!g) return;
    // 用 call 绑定 this：画笔里会调 this._poly（直接 g(...) 时 this 是 undefined/全局）
    g.call(this, ctx, cx, cy, r, bg || '#000000');
  },

  _poly(ctx, pts) {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
    ctx.fill();
  },
};
