/**
 * rendering/ships.js — 舰船绘制（Renderer.prototype 扩展，2026-08-09 从 renderer.js 拆出）
 *
 * _drawShip：玩家/敌/友舰船模（含船头方向/名称）；_drawFloatingHP：头顶血条+盾形标志。
 */

  /* ── ship drawing ───────────────────────────────────────────────────── */

  Renderer.prototype._drawShip = function(ship) {
    const ctx = this.ctx;
    const s = this.worldToScreen(ship.x, ship.y);

    ctx.save();
    ctx.translate(s.x, s.y);
    ctx.rotate(ship.heading);

    const hw = ship.width * this.zoom / 2;
    const hl = ship.length * this.zoom / 2;

    // hull
    ctx.fillStyle = ship.color;
    ctx.fillRect(-hw, -hl, ship.width * this.zoom, ship.length * this.zoom);

    // bow triangle
    ctx.fillStyle = ship.bowColor;
    ctx.beginPath();
    ctx.moveTo(0, -hl);              // tip
    ctx.lineTo(-hw, -hl * 0.5);     // port
    ctx.lineTo( hw, -hl * 0.5);     // starboard
    ctx.closePath();
    ctx.fill();

    // outline
    ctx.strokeStyle = ship.outlineColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(-hw, -hl, ship.width * this.zoom, ship.length * this.zoom);

    // (Wake / stern-trail rendering moved to _drawShipWake so the trail
    //  reflects the ship's actual world path, not a static ship-local line.)

    ctx.restore();
  };



  /* ── floating HP bar above ship ─────────────────────────────────────── */

  Renderer.prototype._drawFloatingHP = function(ship, player) {
    const ctx = this.ctx;
    const s = this.worldToScreen(ship.x, ship.y);

    // ⚠ 本函数是敌人/友军浮条的**唯一公共入口**，且是全项目唯一「靠默认基线定位」的文字
    //   （textBaseline 不设 = alphabetic：名字占 y-12~y-2，血条占 y~y+6，两者分离）。
    //   canvas 状态是**全局**且跨帧保留的：任何上游绘制函数改了 textBaseline 又没恢复，
    //   下一帧就会渗到这里 → 名字压血条（2026-10-03 截击俾斯麦战役复现）。
    //   故此处：① 整体 save/restore（本函数自身也污染 font/textAlign/fillStyle/lineWidth）
    //         ② **显式**声明自己的基线，不依赖外部状态。
    ctx.save();

    const barW = ship.length * this.zoom;
    const barH = 6;
    const x = s.x - barW / 2;
    const y = s.y - ship.length * this.zoom / 2 - 14;

    // name
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '10px "Microsoft YaHei", Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';   // ★ 显式，不吃上游污染（名字须在血条**上方**）
    ctx.fillText(ship.name, s.x, y - 2);

    // background bar
    ctx.fillStyle = ship.team === 'enemy' ? '#7A2222' : '#225588';
    ctx.fillRect(x, y, barW, barH);

    // current HP —— 阵营固定色（2026-08-09 字人要求）：敌人恒红 / 友军恒蓝 / 玩家不变（玩家走 HUD 血条不画浮条）
    const ratio = ship.hp / ship.maxHp;
    const hpColor = ship.team === 'enemy' ? '#EE4444' : (ship.team === 'friend' ? '#3388FF' : (ratio > 0.5 ? '#33CC33' : ratio > 0.25 ? '#CCCC33' : '#CC3333'));
    ctx.fillStyle = hpColor;
    ctx.fillRect(x, y, barW * ratio, barH);

    // border
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, barW, barH);

    // 血条损伤条（P2-2 2026-08-16 字人"血条损伤条可以有"）：
    //   每帧被命中推一条白色短条 = 本次扣血（含护盾吸收），1s 内淡掉
    if (ship.damageTicks && ship.damageTicks.length > 0 && ship.maxHp) {
      var now = Date.now();
      var aliveTicks = [];
      for (var ti = 0; ti < ship.damageTicks.length; ti++) {
        var tick = ship.damageTicks[ti];
        if (tick.expireAt <= now) continue;   // 过期不画也不保留
        aliveTicks.push(tick);
        var tPhase = 1 - (tick.expireAt - now) / 1000;   // 0=新出现，1=消失
        if (tPhase < 0) tPhase = 0;
        if (tPhase >= 1) continue;
        var tickAlpha = (1 - tPhase) * 0.9;             // 1s 内从 0.9 线性淡到 0
        var tickW = (tick.delta / ship.maxHp) * barW;   // 短条宽度 = 扣血量/最大血量
        // 锚定在血条右端（当前血位置），向左延伸（动画向"已损失"方向累积）
        var ratioNow = ship.hp / ship.maxHp;
        var tickX = x + barW * ratioNow - tickW;
        ctx.fillStyle = 'rgba(255,255,255,' + tickAlpha.toFixed(3) + ')';
        ctx.fillRect(tickX, y, tickW, barH);
      }
      ship.damageTicks = aliveTicks;   // 清理过期（每帧）
    }

    // 护盾标志（血条左侧，浅蓝盾牌 + 正上方剩余量，2026-08-05；含限时盾 2026-08-09）
    const totalShield = (ship.shield || 0) + (ship.getTimedShieldTotal ? ship.getTimedShieldTotal() : 0);
    if (totalShield > 0) {
      const shX = x - 16;               // 血条左端左侧
      const shY = y + barH / 2;         // 与血条同高中心
      const r = 6;
      ctx.fillStyle = 'rgba(102,204,255,0.85)';
      ctx.strokeStyle = '#BBE6FF';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(shX - r, shY - r * 0.8);
      ctx.lineTo(shX + r, shY - r * 0.8);
      ctx.lineTo(shX + r, shY);
      ctx.quadraticCurveTo(shX + r, shY + r * 1.2, shX, shY + r * 1.4);
      ctx.quadraticCurveTo(shX - r, shY + r * 1.2, shX - r, shY);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // 标志正上方剩余护盾量
      ctx.fillStyle = '#BBE6FF';
      ctx.font = '8px "Microsoft YaHei", Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(String(Math.round(totalShield)), shX, shY - r * 0.8 - 3);
    }

    // numbers
    ctx.fillStyle = '#FFF';
    ctx.font = '9px "Microsoft YaHei", Arial, sans-serif';
    ctx.fillText(`${ship.hp}/${ship.maxHp}`, s.x, y + barH + 10);

    // distance to player
    const distPx = Math.hypot(player.x - ship.x, player.y - ship.y);
    const distKm = (distPx / PX_PER_KM).toFixed(1);
    ctx.fillStyle = '#AABBCC';
    ctx.font = '9px "Microsoft YaHei", Arial, sans-serif';
    ctx.fillText(distKm + ' km', s.x, y + barH + 22);

    ctx.restore();   // 不把 font/textAlign/textBaseline/fillStyle 留给后面的绘制
  };
