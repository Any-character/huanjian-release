/**
 * wisconsin.js — 威斯康星 战列舰（2026-11-08）
 *
 * 武器槽位（字人规格）：
 *   主炮 ×3  —— 前 2 / 后 1（'forward','forward','aft'）
 *   副炮 ×8  —— 左舷 4 / 右舷 4
 *   水雷 ×2
 *   无鱼雷
 *
 * 战舰技能 ×4（按顺序并列于强化界面）：
 *   ① 生存专家  —— 静态属性
 *   ② 射击大师  —— 静态属性
 *   ③ 威慑重击  —— 机制类（重击炮弹 / 护盾 / 真伤叠层 / 濒死不死 / 不屈）
 *                  实现见 js/systems/wisconsin-combat.js
 *   ④ 不动堡垒  —— 切换型主动（卢金斯式）姿态
 *                  实现见 js/systems/wisconsin-fortress.js
 *
 * 完整规格（字人原文 + 确认口径）：docs/superpowers/specs/2026-11-08-wisconsin-design.md
 * desc 字段照抄字人原文（规范：技能描述不改写）。
 *
 * ⚠️ 未指定项：暴击/碎甲/穿甲/燃烧/漏水/配损/武损等基础几率沿用战列舰基线（同 A-140A）。
 */
const WISCONSIN_CONFIG = Object.freeze({
  name: '威斯康星',
  shipType: 'battleship',
  hp: 65268,
  length: 140,
  width: 28,
  color: '#3E4A5A',
  bowColor: '#5A6C82',
  outlineColor: '#8FA3B8',
  rotationSpeed: 23.3 * Math.PI / 180,        // 转向转速 23.3 °/s
  weaponRotationSpeed: 28.2 * Math.PI / 180,  // 武器转速 28.2 °/s
  maxSpeed: 30.0,                             // 最大航速 30.0 节
  accelPower: 980,
  turnPower: 236,
  armor: 3528,
  smallCaliberEvasion: 0.25,                  // 规避小口径炮弹 25%
  mediumCaliberEvasion: 0.15,                 // 规避中口径炮弹 15%
  largeCaliberEvasion: 0.10,                  // 规避大口径炮弹 10%
  surfaceRange: 9.0,                          // 水上探测 9.0 km
  underwaterRange: 7.5,                       // 水下探测 7.5 km
  resistAccessoryChance: 0.06,                // 抵抗配件损毁 6%
  // ── 未指定，沿用战列舰基线 ──
  critChance: 0.10,
  shatterChance: 0.08,
  critDmg: 0,
  penetrationChance: 0.05,
  burnChance: 0.02,
  accessoryChance: 0.03,
  weaponDamageChance: 0.03,
  floodChance: 0.02,
  weapon: {
    mainGun: {
      mountCount: 3,
      cooldownSec: 13.0,          // 主炮装填 13.0s
      enemyColor: '#DD1111',
      range: 19.9 * PX_PER_KM,    // 主火炮射程 19.9km
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'aft'],   // 前 2 后 1
    },
    secondary: {
      mountCount: 8,
      cooldownSec: 7.6,           // 副炮装填 7.6s
      damage: 1393,
      enemyColor: '#DD1111',
      range: 13.1 * PX_PER_KM,    // 副火炮射程 13.1km
      holdInterval: 100,
      mountArcs: ['port', 'port', 'port', 'port', 'starboard', 'starboard', 'starboard', 'starboard'],
    },
    torpedo: { mountCount: 0 },
    mine: {
      mountCount: 2,
      cooldownSec: 27.3,          // 水雷装填 27.3s
      range: 0,
      holdInterval: 100,
    },
  },
  skills: Object.freeze([
    Object.freeze({
      id: 'wisconsin-survival',
      name: '生存专家',
      desc: '炮弹规避 +5% 减免暴击伤害 +10% 延缓燃烧漏水 +10%',
      // 尺度：shellEvasion/reduceCritDmg = 小数；burnDelay/floodDelay = 点数
      effects: Object.freeze([
        { mode: 'always', stat: 'shellEvasion', value: 0.05 },
        { mode: 'always', stat: 'reduceCritDmg', value: 0.10 },
        { mode: 'always', stat: 'burnDelay', value: 10 },
        { mode: 'always', stat: 'floodDelay', value: 10 },
      ]),
    }),
    Object.freeze({
      id: 'wisconsin-shooting',
      name: '射击大师',
      desc: '主炮炮弹速度 +1000 副炮炮弹速度 +1000 暴击穿甲几率 +10% 暴击穿甲伤害 +20%',
      // 「暴击穿甲」拆成两条通道：暴击几率/伤害 + 穿甲几率/伤害 各 +（字人原文合并写法）
      effects: Object.freeze([
        { mode: 'always', stat: 'mainGunShellSpeed', value: 1000 },
        { mode: 'always', stat: 'secondaryShellSpeed', value: 1000 },
        { mode: 'always', stat: 'critChance', value: 0.10 },
        { mode: 'always', stat: 'penetrationChance', value: 0.10 },
        { mode: 'always', stat: 'critDmg', value: 0.20 },
        { mode: 'always', stat: 'penDmg', value: 0.20 },
      ]),
    }),
    Object.freeze({
      id: 'wisconsin-heavy',
      name: '威慑重击',
      desc: '每命中 4 次 [重击炮弹]，获得最大血量 5% 的护盾，从该效果获得的护盾量不超过40%最大血量 每命中 1 次 [重击炮弹]，增加 20 主炮真伤，最高 50 层 濒死时，无敌 5s，[重击炮弹] 无冷却，持续 10s，每场战斗限触发 1 次 不屈 +200',
      // 机制实现：js/systems/wisconsin-combat.js（弹种 / 护盾 / 真伤叠层 / 濒死 / 不屈）
      effects: Object.freeze([
        { mode: 'always', stat: 'unyielding', value: 200 },   // 不屈：每次受主炮/鱼雷/水雷伤害回 200 血（受维修效率加成）
      ]),
    }),
    Object.freeze({
      id: 'wisconsin-fortress',
      name: '不动堡垒',
      desc: '主动使用，进入堡垒姿态：主炮装填 -1s，射击精度 +10%，装甲 +1500，抵抗碎甲程度 +50%，主炮副炮射程 +5km，主炮副炮速度 +2000，减免鱼雷伤害 +150%，自身受到穿甲伤害+100%。堡垒姿态期间无法移动。受到武器伤害 -90%，免疫暴击、武损 进入堡垒姿态后，开始每 5s 为1门主炮装填 [重击炮弹]：[重击炮弹]命中敌舰，额外造成4%最大血量的固定伤害，造成一次普通武损，并获得减益：机动性降低 15%，武器装填时间增加 15%，武器极限装填 +3s，持续 10s。[重击炮弹] 最高存在 1 门。再次使用技能可退出堡垒姿态，切换冷却 10s',
      // 切换型主动（卢金斯式）：冷却从使用时刻起算，进入/退出共用
      active: Object.freeze({ key: 'shipActiveSkill', cooldownSec: 10 }),
      effects: Object.freeze([]),   // 机制实现见 js/systems/wisconsin-fortress.js
    }),
  ]),
});

SHIP_LIBRARY.push({
  id: 'wisconsin',
  name: '威斯康星',
  desc: '战列舰',
  shipType: 'battleship',
  config: WISCONSIN_CONFIG,
  mainGunCount: 3,
  secondaryCount: 8,
  torpedoCount: 0,
  mineCount: 2,
  stats: {
    // 字人 2026-11-08：只有这些在属性栏显示
    '血量':              '65268',
    '装甲强度':          '3528',
    '最大航速':          '30.0 节',
    '加速功率':          '980',
    '转向转速':          '23.3 °/s',
    '转向功率':          '236',
    '水上探测':          '9.0 km',
    '水下探测':          '7.5 km',
    '主炮装填':          '13.0 s',
    '主炮射程':          '19.9 km',
    '副炮装填':          '7.6 s',
    '副炮射程':          '13.1 km',
    '水雷装填':          '27.3 s',
    '武器转速':          '28.2 °/s',
    '小口径炮弹规避':     '25 %',
    '中口径炮弹规避':     '15 %',
    '大口径炮弹规避':     '10 %',
    '抵抗配件损毁':       '6 %',
  },
});
