/**
 * cleveland.js — 克利夫兰巡洋舰
 */

const CLEVELAND_CONFIG = Object.freeze({
  name: '克利夫兰',
  hp: 23031,
  length: 100,
  width: 20,
  color: '#5B8DC4',
  bowColor: '#7DADF0',
  outlineColor: '#AAC8F5',
  rotationSpeed: 31.3 * Math.PI / 180,
  weaponRotationSpeed: 31.2 * Math.PI / 180,
  maxSpeed: 32.4,
  smallCaliberEvasion: 0.2,   // 小口径炮弹规避 20%（巡洋默认）
  mediumCaliberEvasion: 0.1,  // 中口径炮弹规避 10%
  accelPower: 1120,
  armor: 1765,
  critChance: 0.1,
  shatterChance: 0.03,
  critDmg: 0,          // 暴击伤害加成（0=默认×2.0）
  penetrationChance: 0.03,  // 穿甲几率 3%
  burnChance: 0.08,         // 基础燃烧几率 8%
  accessoryChance: 0.03,    // 基础配损几率 3%（2026-09-05）
  weaponDamageChance: 0.03,    // 基础武损几率 3%（2026-09-13）
  floodChance: 0.05,        // 基础漏水几率 5%
  weapon: {
    mainGun: {
      mountCount: 6,
      cooldownSec: 9.4,
      enemyColor: '#DD1111',
      range: 15.6 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'forward', 'aft', 'aft', 'aft'],
    },
    torpedo: {
      mountCount: 4,
      cooldownSec: 24.9,
      enemyColor: '#CC3333',
      range: 10.95 * PX_PER_KM,
      holdInterval: 300,
      mountArcs: ['port', 'starboard', 'port', 'starboard'],
    },
  },
});

SHIP_LIBRARY.push({
  id: 'cleveland',
  name: '克利夫兰',
  desc: '巡洋舰',
  shipType: 'cruiser',
  config: CLEVELAND_CONFIG,
  mainGunCount: 6,
  torpedoCount: 4,
  stats: {
    '血量':              '23031',
    '装甲强度':            '1765',
    '最大航速':          '32.4 节',
    '加速功率':          '1120',
    '转向转速':          '31.3 °/s',
    '转向功率':          '268',
    '水上探测':          '11 km',
    '水下探测':          '4.8 km',
    '主炮装填':          '9.4 s',
    '主炮射程':          '15.6 km',
    '鱼雷装填':          '24.9 s',
    '鱼雷射程':          '10.95 km',
    '暴击几率':          '10 %',
    '碎甲几率':          '3 %',
    '穿甲几率':          '3 %',
  },
});
