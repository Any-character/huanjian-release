/**
 * tsar.js — 沙皇战列舰（2026-08-09）
 *
 * 4 主炮（舰首1 + 舰中1[中轴，同鱼雷] + 舰尾2）+ 4 副炮（左2右2）+ 3 水雷。
 * 3 被动（射击大师/生存专家/血池熔铸）+ 1 主动（红场之魂，键 C）。
 * 血池系统（blood-pool.js）由 main.js 在配置含 bloodPool 时挂载。
 */
const TSAR_CONFIG = Object.freeze({
  name: '沙皇',
  shipType: 'battleship',
  hp: 67777,
  length: 140,
  width: 28,
  color: '#C03030',
  bowColor: '#E05555',
  outlineColor: '#FF8888',
  rotationSpeed: 23.7 * Math.PI / 180,    // 转向转速 23.7 °/s
  weaponRotationSpeed: 28 * Math.PI / 180, // 武器转速 28 °/s
  maxSpeed: 33,           // 最大航速 33 节
  accelPower: 940,        // 加速功率
  turnPower: 236,         // 转向功率
  armor: 3600,            // 装甲强度
  smallCaliberEvasion: 0.25,   // 小口径规避 25%
  mediumCaliberEvasion: 0.15,  // 中口径规避 15%
  largeCaliberEvasion: 0.1,    // 大口径规避 10%
  surfaceRange: 8.8,      // 水上探测 km
  underwaterRange: 7.5,   // 水下探测 km
  critChance: 0,
  shatterChance: 0,
  critDmg: 0,
  penetrationChance: 0,
  burnChance: 0,
  accessoryChance: 0.03,   // 基础配损几率 3%（2026-09-05）
  weaponDamageChance: 0.03,   // 基础武损几率 3%（2026-09-13）
  floodChance: 0,
  weapon: {
    mainGun: {
      mountCount: 4,
      cooldownSec: 15.3,       // 主炮装填 15.3s
      enemyColor: '#DD1111',
      range: 20.9 * PX_PER_KM,  // 主炮射程 20.9km
      holdInterval: 100,
      mountArcs: ['forward', 'centerline', 'aft', 'aft'],   // 舰首1 + 舰中1(中轴同鱼雷) + 舰尾2
    },
    secondary: {
      mountCount: 4,
      cooldownSec: 6.5,        // 副炮装填 6.5s
      damage: 1393,
      enemyColor: '#DD1111',
      range: 12.6 * PX_PER_KM, // 副炮射程 12.6km
      holdInterval: 100,
      mountArcs: ['port', 'port', 'starboard', 'starboard'],   // 左2右2
    },
    torpedo: { mountCount: 0 },
    mine: {
      mountCount: 3,
      cooldownSec: 26,         // 水雷装填 26s
      range: 0,
      holdInterval: 100,
    },
  },
  // ── 战舰技能（2026-08-09 ShipSkills 系统 + 血池）──
  // desc：强化界面完整描述（照抄字人原文）；effects：战斗生效数据；active：主动技能
  skills: Object.freeze([
    Object.freeze({
      id: 'tsar-shooting',
      name: '射击大师',
      desc: '穿甲几率+10%暴击几率+10%穿甲伤害+15%暴击伤害+15%主炮速度+1200',
      effects: Object.freeze([
        { mode: 'always', stat: 'penetrationChance', value: 0.10 },  // 穿甲几率 +10%
        { mode: 'always', stat: 'critChance', value: 0.10 },         // 暴击几率 +10%
        { mode: 'always', stat: 'penDmg', value: 0.15 },             // 穿甲伤害 +15%
        { mode: 'always', stat: 'critDmg', value: 0.15 },            // 暴击伤害 +15%
        { mode: 'always', stat: 'mainGunShellSpeed', value: 1200 },  // 主炮速度 +1200
      ]),
    }),
    Object.freeze({
      id: 'tsar-survival',
      name: '生存专家',
      desc: '延缓燃烧+30%延缓漏水+30%装甲强度+500减免武器伤害+15%',
      effects: Object.freeze([
        // ⚠️ 数值尺度必须与消费端一致（2026-09-19 修复：此前写了 0.30，而 burnDelay/floodDelay
        //   与 reduceXxx 都是「点数」尺度（0~200 / 0~100），写成 0.30 实际只等于 +0.3 点 → 技能几乎无效）
        { mode: 'always', stat: 'burnDelay', value: 30 },   // 延缓燃烧 +30（点数；间隔公式 100+A−B）
        { mode: 'always', stat: 'floodDelay', value: 30 },  // 延缓漏水 +30（点数）
        { mode: 'always', stat: 'armor', value: 500 },        // 装甲强度 +500（原始值）
        { mode: 'always', stat: 'reduceWeaponDmg', value: 15 },  // 减免武器伤害 +15（点数；公式 100−y+x）
      ]),
    }),
    Object.freeze({
      id: 'tsar-bloodpool',
      name: '血池熔铸',
      desc: '每次损失血量时，均会将20%本应损失的血量储入自身血池。但受到单次武器伤害大于自身最大血量5%时，则不降低20%本应损失的血量，而将该次伤害超出自身最大血量5%的部分，储入自身血池。血池上限为进入战场时自身最大血量的50%。血池储满时，则立即清空并在30s内回复相应血量。回复期间如果损失血量，则无法储入血池。血池储量为0时，自身增加20%武器规避、穿甲、暴击伤害，血池每被储入2%，自身降低0.2%武器规避、穿甲、暴击伤害，最高50层；自身增加穿甲伤害减免，2%暴击伤害减免，最高50层。血池储量为自身最大血量25%以上时濒死时，在10s内无敌，立即清空血池并在10s内回复相应血量，该效果冷却时间120s',
      effects: Object.freeze([]),   // 由 bloodPool 系统处理（config.bloodPool 参数）
    }),
    Object.freeze({
      id: 'tsar-redsquare',
      name: '红场之魂',
      desc: '主动使用，使用后，在30s内：每次损失血量时储入血池的血量由20%提升至40%将血池上限提升至进入战场时自身最大血量的100%并立即损失自身55%最大血量（当前血量不足则损失全部当前血量），该损失按40%储入血池，实际扣血为损失量的60%，生成等同于实际扣血量的护盾。期间再次使用技能，将血池上限还原，并触发「血池熔铸」开始回复血量。持续时间结束或血池储满时，则立即清空当前血池，在30s内：自身每秒回复血量，回复的血量总量为血池清空前储量的70%。同时，以自身为圆心，半径为25km的范围内：友军航速提高5%，每秒生成护盾（限时护盾，持续80s），生成的护盾总量为血池清空前储量的15%。圈内敌军航速降低15%，每秒损失血量（持续30s），损失的血量总量为血池清空前储量的15%。冷却110s',
      // 主动技能（ship-skills 主动机制，2026-08-09）：键 C、冷却 110s
      active: Object.freeze({ key: 'shipActiveSkill', cooldownSec: 110 }),
      effects: Object.freeze([]),
    }),
  ]),
  // 血池熔铸参数（main.js 检测到后挂 BloodPool）
  bloodPool: Object.freeze({
    cooldownSec: 110,   // 红场之魂冷却（结束时才开始，2026-08-09）
    maxPct: 0.5,           // 血池上限 = 50% 最大血量
    ratioSmall: 0.2,       // 小伤害储入 20%
    ratioRed: 0.4,         // 红场期小伤害储入 40%
    reviveThreshold: 0.25, // 濒死需池 ≥ 25% 最大血量
    reviveCooldownSec: 120,
    reviveInvincibleSec: 10,
    reviveRecoverSec: 10,
    fullRecoverSec: 30,    // 储满/二次使用回复 30s
    redsquareSec: 30,      // 红场时长 30s
    settleRecoverSec: 30,  // 红场结算回复 30s
    settleRecoverPct: 0.7, // 结算回 70%
    settleAuraSec: 30,     // 结算光环 30s（2026-08-09 字人更正：与 30s 回血同步；总盾/掉血 = 15% 池量均摊到 30s）
    settleAuraKm: 25,      // 半径 25km
    settleAllyPct: 0.15,   // 友军护盾总量 15%
    settleEnemyPct: 0.15,  // 敌军掉血总量 15%
    settleAllySpeed: 0.05,  // 友军航速 +5%
    settleEnemySpeed: 0.15, // 敌军航速 -15%
  }),
});

SHIP_LIBRARY.push({
  id: 'tsar',
  name: '沙皇',
  desc: '战列舰',
  shipType: 'battleship',
  config: TSAR_CONFIG,
  mainGunCount: 4,
  secondaryCount: 4,
  torpedoCount: 0,
  mineCount: 3,
  stats: {
    '血量':             '67777',
    '装甲强度':           '3600',
    '最大航速':          '33 节',
    '加速功率':          '940',
    '转向转速':          '23.7 °/s',
    '转向功率':          '236',
    '水上探测':          '8.8 km',
    '水下探测':          '7.5 km',
    '主炮装填':          '15.3 s',
    '主炮射程':          '20.9 km',
    '副炮装填':          '6.5 s',
    '副炮射程':          '12.6 km',
    '水雷装填':          '26 s',
    '暴击几率':          '0 %',
    '穿甲几率':          '0 %',
    '技能':              '射击大师 / 生存专家 / 血池熔铸 / 红场之魂',
  },
});
