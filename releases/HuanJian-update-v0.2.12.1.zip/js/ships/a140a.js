/**
 * a140a.js — A-140A 战列舰（2026-09-19）
 *
 * 武器槽位（2026-09-19 字人规格）：
 *   主炮 ×3  —— 全舰首炮（mountArcs 全 'forward'）
 *   副炮 ×10 —— 左舷 4 / 右舷 4 / 舰中 2
 *               （左/右舷射界沿用既有规范 'port'/'starboard' = 以船侧为轴 ±60°；
 *                舰中炮走既有 'centerline' = 左右并集、前后无死角）
 *   无鱼雷、无水雷。
 *   武器选型、船模尺寸、外观配色、基础几率均与前卫一致（字人 2026-09-19 确认）。
 *
 * 战舰技能 ×4（结构与沙皇一致，按顺序并列于强化界面）：
 *   ① 生存专家  —— 静态属性
 *   ② 射击大师  —— 静态属性
 *   ③ 国度的雄心 —— 机制类（锁定系统，实现见 js/systems/lock-system.js）
 *   ④ 炮火风暴  —— 被动光环（本文件 aura 数据）+ 主动 20s/冷却 90s（js/systems/a140a-storm.js）
 *
 * 完整规格与实现要点：docs/systems.md §5.29
 * desc 字段逐字照抄字人原文（规范：技能描述不改写）。
 */
const A140A_CONFIG = Object.freeze({
  name: 'A-140A',
  shipType: 'battleship',
  hp: 65922,
  length: 140,
  width: 28,
  color: '#8A6AC8',
  bowColor: '#A98BE8',
  outlineColor: '#C9B0F2',
  rotationSpeed: 24 * Math.PI / 180,        // 转向转速 24 °/s
  weaponRotationSpeed: 30 * Math.PI / 180,  // 武器转速 30 °/s
  maxSpeed: 32.7,                           // 最大航速 32.7 节
  accelPower: 960,
  turnPower: 240,
  armor: 3421,
  smallCaliberEvasion: 0.25,
  mediumCaliberEvasion: 0.15,
  largeCaliberEvasion: 0.10,
  surfaceRange: 9.1,
  underwaterRange: 5.5,
  critChance: 0.10,
  shatterChance: 0.08,
  critDmg: 0,
  penetrationChance: 0.05,
  burnChance: 0.02,
  accessoryChance: 0.03,
  weaponDamageChance: 0.03,
  floodChance: 0.02,
  weapon: {
    mainGun: {
      mountCount: 3,
      cooldownSec: 13.5,
      enemyColor: '#DD1111',
      range: 19.9 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'forward'],   // 全舰首炮
    },
    secondary: {
      mountCount: 10,
      cooldownSec: 7.9,
      damage: 1393,
      enemyColor: '#DD1111',
      range: 13.7 * PX_PER_KM,
      holdInterval: 100,
      // 左舷 4 / 右舷 4 / 舰中 2（舰中走既有 centerline 射界）
      mountArcs: ['port', 'port', 'port', 'port', 'starboard', 'starboard', 'starboard', 'starboard', 'centerline', 'centerline'],
    },
    torpedo: { mountCount: 0 },
    mine: { mountCount: 0 },
  },
  skills: Object.freeze([
    Object.freeze({
      id: 'a140a-survival',
      name: '生存专家',
      desc: '减免鱼雷伤害+10%减免暴击伤害+10%射击精度+5%',
      // 尺度：reduceTorpedoDmg = 点数（0~100）；reduceCritDmg/shotAccuracy = 小数（见 ShipSkills.SCALES）
      effects: Object.freeze([
        { mode: 'always', stat: 'reduceTorpedoDmg', value: 10 },
        { mode: 'always', stat: 'reduceCritDmg', value: 0.10 },
        { mode: 'always', stat: 'shotAccuracy', value: 0.05 },
      ]),
    }),
    Object.freeze({
      id: 'a140a-shooting',
      name: '射击大师',
      desc: '主炮速度+1200副炮速度+1200暴击几率+10%暴击伤害+20%',
      effects: Object.freeze([
        { mode: 'always', stat: 'mainGunShellSpeed', value: 1200 },
        { mode: 'always', stat: 'secondaryShellSpeed', value: 1200 },
        { mode: 'always', stat: 'critChance', value: 0.10 },
        { mode: 'always', stat: 'critDmg', value: 0.20 },
      ]),
    }),
    Object.freeze({
      id: 'a140a-ambition',
      name: '国度的雄心',
      desc: '25km内自身船左右两侧120度内有敌舰时，获得增益：最终减伤+15%，炮弹规避+15%副炮射程提升至与主炮一致，若副炮射程内有敌舰时，副炮对敌舰进行随机锁定，敌舰脱离副炮射程后解除锁定副炮命中敌舰时会优先切换并锁定该目标，若此后15s内自身副炮未再次命中敌舰，敌舰会脱离主动锁定，仅被随机锁定每座副炮可锁定1次副炮跟随主炮瞄准，主炮每次命中，获得一层增益：副炮速度+500，副炮真伤+1%（上限10层）副炮命中被锁定的敌舰时，副炮对敌舰造成的伤害增加10%*锁定次数，副炮对敌舰的暴击几率增加1%锁定次数主炮命中被锁定的敌舰时，额外对敌舰造成10%*基础副炮伤害*锁定次数的固定伤害',
      // 常驻机制标记（静态部分）；锁定/增益逻辑见 js/systems/lock-system.js
      effects: Object.freeze([
        { mode: 'always', stat: 'secondaryAlwaysFollows', value: true },     // 副炮恒跟随主炮瞄准（不受卢金斯开关影响）
        { mode: 'always', stat: 'secondaryRangeFollowsMain', value: true },  // 副炮射程始终 = 主炮射程
      ]),
    }),
    Object.freeze({
      id: 'a140a-storm',
      name: '炮火风暴',
      desc: '副炮射程范围内，本方战舰获得增益：减免武器伤害+10%，抵抗穿甲+10%，抵抗暴击+10%（同类范围效果不叠加）副炮射程范围内，每有一层主动锁定，副炮装填时间-0.3s主动使用技能后20s内，主炮射程+5km，主炮装填时间-3s，每座副炮可锁定2次，被锁定的敌舰获得减益：被发现（不共享队友），自身免疫基础武器损毁，主炮开火即对所有被锁定的敌舰，造成1次10%基础副炮伤害*锁定次数的固定伤害期间敌舰每被锁定1次会随机使1座武器损毁20s（不可清除，不会损毁已损毁的武器，不生效于战役）冷却90s',
      // 被动光环：半径 = 该舰副炮有效射程（= 主炮射程，含主动 +5km）→ radiusFromSecondary；
      //   stack:'unique' = 多艘 A-140A 同类范围效果不叠加（固定 key 互相覆盖）
      aura: Object.freeze({
        radiusFromSecondary: true,
        stack: 'unique',
        mods: Object.freeze({
          reduceWeaponDmgAdd: 10,      // 减免武器伤害 +10（点数；collision-hit ⑧ 消费）
          resistPenetrationAdd: 0.10,  // 抵抗穿甲 +10%（collision-hit ② 消费）
          resistCritChanceAdd: 0.10,   // 抵抗暴击 +10%（collision-hit ③ 消费）
        }),
      }),
      // 主动：键位同沙皇（C，动作名 shipActiveSkill）；冷却 90s——注意从**使用时刻**起算（沙皇是结束时）
      active: Object.freeze({ key: 'shipActiveSkill', cooldownSec: 90 }),
      effects: Object.freeze([]),   // 机制实现见 js/systems/a140a-storm.js
    }),
  ]),
});

SHIP_LIBRARY.push({
  id: 'a140a',
  name: 'A-140A',
  desc: '战列舰',
  shipType: 'battleship',
  config: A140A_CONFIG,
  mainGunCount: 3,
  secondaryCount: 10,
  torpedoCount: 0,
  mineCount: 0,
  stats: {
    '血量':              '65922',
    '装甲强度':            '3421',
    '最大航速':          '32.7 节',
    '加速功率':          '960',
    '转向转速':          '24 °/s',
    '转向功率':          '240',
    '水上探测':          '9.1 km',
    '水下探测':          '5.5 km',
    '主炮装填':          '13.5 s',
    '主炮射程':          '19.9 km',
    '副炮装填':          '7.9 s',
    '副炮射程':          '13.7 km',
    '暴击几率':          '10 %',
    '碎甲几率':          '8 %',
    '穿甲几率':          '5 %',
  },
});
