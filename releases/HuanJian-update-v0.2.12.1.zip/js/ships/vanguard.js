/**
 * vanguard.js — 前卫战列舰
 *
 * 4 主炮（2 舰首 2 舰尾，三联装）+ 8 副炮（4 左舷 4 右舷，二联装 AI 自动开火）。
 * 无鱼雷、无水雷。副炮可暴击/碎甲，不能穿甲/燃烧/漏水。
 */
const VANGUARD_CONFIG = Object.freeze({
  name: '前卫',
  shipType: 'battleship',
  hp: 45077,
  length: 140,
  width: 28,
  color: '#8A6AC8',
  bowColor: '#A98BE8',
  outlineColor: '#C9B0F2',
  rotationSpeed: 23 * Math.PI / 180,       // 23 °/s
  weaponRotationSpeed: 24 * Math.PI / 180, // 24 °/s（主炮瞄准）
  maxSpeed: 30,
  smallCaliberEvasion: 0.25,   // 小口径炮弹规避 25%（战列默认）
  mediumCaliberEvasion: 0.15,  // 中口径炮弹规避 15%
  largeCaliberEvasion: 0.1,    // 大口径炮弹规避 10%
  accelPower: 780,
  turnPower: 220,
  armor: 3303,
  surfaceRange: 7,
  underwaterRange: 3.5,
  critChance: 0.10,
  shatterChance: 0.08,
  critDmg: 0,
  penetrationChance: 0.05,
  burnChance: 0.02,
  accessoryChance: 0.03,   // 基础配损几率 3%（2026-09-05）
  weaponDamageChance: 0.03,   // 基础武损几率 3%（2026-09-13）
  floodChance: 0.02,
  weapon: {
    mainGun: {
      mountCount: 4,
      cooldownSec: 15.2,
      enemyColor: '#DD1111',
      range: 18.5 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'aft', 'aft'],
    },
    secondary: {
      mountCount: 8,
      cooldownSec: 5.75,
      damage: 1393,
      enemyColor: '#DD1111',
      range: 11 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['port', 'port', 'port', 'port', 'starboard', 'starboard', 'starboard', 'starboard'],
    },
    torpedo: { mountCount: 0 },
    mine: { mountCount: 0 },
  },
});

SHIP_LIBRARY.push({
  id: 'vanguard',
  name: '前卫',
  desc: '战列舰',
  shipType: 'battleship',
  config: VANGUARD_CONFIG,
  mainGunCount: 4,
  secondaryCount: 8,
  torpedoCount: 0,
  mineCount: 0,
  stats: {
    '血量':              '45077',
    '装甲强度':            '3303',
    '最大航速':          '30 节',
    '加速功率':          '780',
    '转向转速':          '23 °/s',
    '转向功率':          '220',
    '水上探测':          '7 km',
    '水下探测':          '3.5 km',
    '主炮装填':          '15.2 s',
    '主炮射程':          '18.5 km',
    '副炮装填':          '5.75 s',
    '副炮射程':          '11 km',
    '暴击几率':          '10 %',
    '碎甲几率':          '8 %',
    '穿甲几率':          '5 %',
  },
});
