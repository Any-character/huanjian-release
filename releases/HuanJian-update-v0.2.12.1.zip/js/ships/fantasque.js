/**
 * fantasque.js — 空想驱逐舰
 */
const FANTASQUE_CONFIG = Object.freeze({
  name: '空想',
  shipType: 'destroyer',
  hp: 15084,
  length: 70,            // bow–stern (px)
  width: 14,             // port–starboard (px)
  color: '#44AA66',      // hull fill
  bowColor: '#66CC88',   // bow triangle fill
  outlineColor: '#88EEAA',
  rotationSpeed: 42 * Math.PI / 180, // 42 °/s
  weaponRotationSpeed: 60 * Math.PI / 180, // 60 °/s
  // 战斗核心属性
  maxSpeed: 45.5,     // 极速 px/s（= 节）
  smallCaliberEvasion: 0.1,   // 小口径炮弹规避 10%（驱逐默认）
  accelPower: 1804,   // 加速功率
  turnPower: 362,     // 转向功率
  armor: 1304,        // 基础装甲
  surfaceRange: 15,   // 水上探测 km
  underwaterRange: 10.1, // 水下探测 km
  critChance: 0.05,
  shatterChance: 0.08,
  critDmg: 0,          // 暴击伤害加成（0=默认×2.0）
  penetrationChance: 0.05,  // 穿甲几率 5%
  burnChance: 0.08,        // 基础燃烧几率 8%
  accessoryChance: 0.03,   // 基础配损几率 3%（2026-09-05）
  weaponDamageChance: 0.03,   // 基础武损几率 3%（2026-09-13）
  floodChance: 0.05,       // 基础漏水几率 5%
  weapon: {
    mainGun: {
      mountCount: 5,
      cooldownSec: 5.1,
      enemyColor: '#DD1111',
      range: 13.6 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'aft', 'aft', 'aft'],
    },
    torpedo: {
      mountCount: 3,
      cooldownSec: 16.4,
      enemyColor: '#CC3333',
      range: 17.4 * PX_PER_KM,
      holdInterval: 300,
      mountArcs: ['port', 'starboard', 'centerline'],
    },
    mine: {
      mountCount: 3,
      cooldownSec: 26,
      holdInterval: 500,
    },
  },
});

SHIP_LIBRARY.push({
  id: 'fantasque',
  name: '空想',
  desc: '驱逐舰',
  shipType: 'destroyer',
  config: FANTASQUE_CONFIG,
  mainGunCount: 5,
  torpedoCount: 3,
  mineCount: 3,
  stats: {
    '血量':              '15084',
    '装甲强度':            '1304',
    '最大航速':          '45.5 节',
    '加速功率':          '1804',
    '转向转速':          '42 °/s',
    '转向功率':          '362',
    '水上探测':          '15 km',
    '水下探测':          '10.1 km',
    '主炮装填':          '5.1 s',
    '主炮射程':          '13.6 km',
    '鱼雷装填':          '16.4 s',
    '鱼雷射程':          '17.4 km',
    '水雷装填':          '26 s',
    '暴击几率':          '5 %',
    '碎甲几率':          '8 %',
    '穿甲几率':          '5 %',
  },
});
