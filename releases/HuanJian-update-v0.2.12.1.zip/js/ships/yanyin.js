/**
 * yanyin.js — 阳炎-利刃驱逐舰（2026-10-01）
 *
 * 武器槽位（字人 2026-10-01 规格）：
 *   主炮 ×3 —— 前 1 后 2（mountArcs forward / aft / aft）
 *   鱼雷 ×2 —— 舰中（centerline ×2，前后无死角）
 *   水雷 ×5 —— 尾铺
 *   武器选型沿用驱-127mm-契约 / 驱-610mm-契约 / 驱-水压水雷4-1A（与空想同库）。
 *
 * 战舰技能 ×4（结构与 A-140A 一致，按顺序并列于强化界面）：
 *   ① 干扰大师 —— 静态属性 + 舰体固有字段（雷达干扰/水雷半径/抵抗漏水）
 *   ② 鱼雷大师 —— 静态属性（鱼雷速度 / 主炮速度 / 暴击几率）
 *   ③ 鱼雷追击 —— 机制类（js/systems/yanyin-pursuit.js，已实现）
 *   ④ 蜃光猎影 —— 机制类（js/systems/yanyin-hunt.js，已实现）+ 主动 15s / 冷却 60s
 *
 * ⚠️ ③ ④ 本 Task 只做**声明**，机制系统文件尚未落地（技能系统按 id 自判断有无，无则直接 return，
 *    不影响开局）。鱼雷速度 +30 节走新 APPLYERS `torpedoSpeed`（单位「节」，
 *    消费链：APPLYERS → ship.torpedoSpeedBonus → fireTorpedo 的 baseStats.torpedoSpeedAdd
 *    → weaponToMountConfig 鱼雷分支 `weapon.speed + add`）。
 */
const YANYIN_CONFIG = Object.freeze({
  name: '阳炎-利刃',
  shipType: 'destroyer',
  hp: 23243,
  length: 74,            // bow–stern (px)
  width: 15,             // port–starboard (px)
  color: '#A8483C',      // hull fill（阳炎：暗红钢）
  bowColor: '#D0705A',   // bow triangle fill
  outlineColor: '#F0A080',
  rotationSpeed: 41.7 * Math.PI / 180,   // 转向转速 41.7 °/s
  weaponRotationSpeed: 60 * Math.PI / 180, // 武器转速 60 °/s
  // 战斗核心属性
  maxSpeed: 46.3,        // 极速 px/s（= 节）
  smallCaliberEvasion: 0.1,   // 小口径炮弹规避 10%（驱逐默认）
  accelPower: 1880,      // 加速功率
  turnPower: 342,        // 转向功率
  armor: 1466,           // 基础装甲
  surfaceRange: 16.3,    // 水上探测 km
  underwaterRange: 13.4, // 水下探测 km
  critChance: 0.05,
  shatterChance: 0.08,
  critDmg: 0,            // 暴击伤害加成（0=默认×2.0）
  penetrationChance: 0.05,
  burnChance: 0.08,
  accessoryChance: 0.03,
  weaponDamageChance: 0.03,
  floodChance: 0.05,
  // ── 「干扰大师」写在**舰体固有字段**的三项（非 effects 通道）──
  radarJamming: 13.5,        // 雷达干扰 km（Phase 2 三态词条；Detection.canSeeShip ①c 消费）
  detonationRadius: 0.95,    // 水雷引爆半径 km（0.75 + 0.2）
  explosionRadius: 2.95,     // 水雷爆炸半径 km（2.45 + 0.5）
  resistFloodChance: 0.15,   // 15% 几率不触发漏水（对冲 collision.js 的漏水几率判定）
  resistAccessoryChance: 0.06, // 抵抗配件损毁 6%（面板值）
  weapon: {
    mainGun: {
      mountCount: 3,
      cooldownSec: 4.1,
      enemyColor: '#DD1111',
      range: 15.5 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['forward', 'aft', 'aft'],   // 前 1 后 2
    },
    torpedo: {
      mountCount: 2,
      cooldownSec: 15.5,
      enemyColor: '#CC3333',
      range: 18.2 * PX_PER_KM,
      holdInterval: 300,
      mountArcs: ['centerline', 'centerline'],  // 舰中
    },
    mine: {
      mountCount: 5,
      cooldownSec: 23.5,
      holdInterval: 500,
    },
  },
  skills: Object.freeze([
    Object.freeze({
      id: 'yanyin-jamming',
      name: '干扰大师',
      // 一行一条效果（2026-10-02：照《巅峰战舰》原版格式改写，逗号流水账 → 分行）
      desc: '雷达干扰13.5km\n水雷引爆半径+0.2km\n水雷爆炸半径+0.5km\n减免鱼雷伤害+10%\n受到漏水攻击时，有15%几率不触发漏水效果',
      // 尺度：reduceTorpedoDmg = 点数（0~100，见 ShipSkills.SCALES）
      // ⚠️ 雷达干扰/水雷半径/抵抗漏水是**舰体固有字段**（见上 config 顶层），不进 effects
      effects: Object.freeze([
        { mode: 'always', stat: 'reduceTorpedoDmg', value: 10 },
      ]),
    }),
    Object.freeze({
      id: 'yanyin-torpedo-master',
      name: '鱼雷大师',
      desc: '鱼雷速度+30节\n主炮速度+1200\n暴击几率+10%',
      effects: Object.freeze([
        { mode: 'always', stat: 'torpedoSpeed', value: 30 },      // raw，单位「节」
        { mode: 'always', stat: 'mainGunShellSpeed', value: 1200 }, // raw，炮速单位 → ×0.057
        { mode: 'always', stat: 'critChance', value: 0.10 },       // pct（0.10 = 10%）
      ]),
    }),
    Object.freeze({
      id: 'yanyin-pursuit',
      name: '鱼雷追击',
      // 每行一条效果（2026-10-02 分行重写；机制实现见 js/systems/yanyin-pursuit.js）
      // ⚠️ 触发条件顺序 = 实现顺序：布雷 onMineFired → 射鱼雷 onTorpedoFired
      //    → 鱼雷命中 onTorpedoHit → 击沉/助攻 scanKills → 层数换算 _refreshReloadBuff
      desc: '每次释放水雷，立即装填当前剩余装填时间最长的一座鱼雷炮位（全部就绪则浪费）\n每次释放水雷，机动性+10%，反雷达干扰+1km，持续10s\n每次释放鱼雷，随机使下一颗释放的水雷获得以下一项强化：引爆半径+1km、爆炸半径+2.5km、暴击几率+50%、无效果（各25%）\n鱼雷命中敌舰时，获得1层水雷装填加速，持续30s，最多5层\n击沉或助攻敌舰时，额外永久获得1层水雷装填加速，最多5层\n临时层与永久层各自封顶5层（合计最多10层），每层使水雷装填时间-0.5s',
      effects: Object.freeze([]),   // 机制实现见 js/systems/yanyin-pursuit.js
    }),
    Object.freeze({
      id: 'yanyin-hunt',
      name: '蜃光猎影',
      // ⚠️ 触发源必须与 yanyin-hunt.js 逐行对齐（单测 77.20 / 82.12 静态守卫）：
      //    主动第 3 行「每次释放水雷，鱼雷速度+5节」→ onMineFired（布雷，真的触发鱼雷加速层）
      //    主动第 4 行「每次释放鱼雷，水雷装填-2s」→ onTorpedoFired（射鱼雷，加速对象才是水雷）
      //    主动第 5 行「鱼雷命中→减伤降低」→ onTorpedoHit（鱼雷命中）
      //    被动第 2 行「水雷命中→10%固定伤害+漏水」→ onMineHit（水雷命中，别改成鱼雷）
      // 主动技能三段式：被动效果 / 主动使用，X秒内 / 冷却（2026-10-02 照原版格式）
      // ⚠️ 空行（\n\n）会被 enhance.js 的 `if (descLines[dl])` 跳过、不产生视觉留白，
      //    故三段靠「段落首行自带标签」区分（被动效果 / 主动使用，15s内 / 冷却60s）。
      desc: '被动效果\n每次释放水雷，为自身提供500点护盾（该来源累计不超过自身最大血量的50%）\n水雷命中敌舰时，造成其最大血量10%的固定伤害并必定触发漏水（每艘敌舰60s冷却）\n\n主动使用，15s内\n减免水雷伤害+50%\n每次释放水雷，鱼雷速度+5节、鱼雷伤害+5%（最多4层，持续10s）\n每次释放鱼雷，使所有正在装填中的水雷炮位装填时间-2s\n鱼雷命中敌舰时，使其鱼雷、水雷减伤各降低5%（最多4层，持续10s）\n\n冷却60s',
      active: Object.freeze({ key: 'shipActiveSkill', cooldownSec: 60 }),   // 与沙皇/A-140A 同一个键（2026-10-02 统一）：一艘舰只开一个主动技能，不存在同屏争用
      effects: Object.freeze([]),   // 机制实现见 js/systems/yanyin-hunt.js
    }),
  ]),
});

SHIP_LIBRARY.push({
  id: 'yanyin',
  name: '阳炎-利刃',
  desc: '驱逐舰',
  shipType: 'destroyer',
  config: YANYIN_CONFIG,
  mainGunCount: 3,
  torpedoCount: 2,
  mineCount: 5,
  stats: {
    '血量':              '23243',
    '装甲强度':            '1466',
    '最大航速':          '46.3 节',
    '加速功率':          '1880',
    '转向转速':          '41.7 °/s',
    '转向功率':          '342',
    '水上探测':          '16.3 km',
    '水下探测':          '13.4 km',
    '主炮装填':          '4.1 s',
    '主炮射程':          '15.5 km',
    '鱼雷装填':          '15.5 s',
    '鱼雷射程':          '18.2 km',
    '水雷装填':          '23.5 s',
    '抵抗配件损毁':        '6 %',
    '暴击几率':          '5 %',
    '碎甲几率':          '8 %',
    '穿甲几率':          '5 %',
  },
});
