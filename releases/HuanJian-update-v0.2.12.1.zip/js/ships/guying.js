/**
 * guying.js — 古鹰巡洋舰
 */
const PLAYER_CONFIG = Object.freeze({
  name: '古鹰',
  hp: 20000,
  length: 100,           // bow–stern (px)  → 1 km
  width: 20,              // port–starboard (px) → 0.2 km
  color: '#3A7BD5',      // hull fill
  bowColor: '#5B9EF5',   // bow triangle fill
  outlineColor: '#88CCFF',
  rotationSpeed: 45 * Math.PI / 180, // 45 °/s → rad/s
  weaponRotationSpeed: 36 * Math.PI / 180, // 36 °/s
  // 战斗核心属性
  maxSpeed: 35,       // 极速 px/s（= 节）
  accelPower: 1300,   // 加速功率
  armor: 2000,        // 基础装甲
  critChance: 0,       // 基础暴击几率 0（2026-08-05 调零，方便「加成」测试）
  shatterChance: 0,    // 基础碎甲几率 0（同上）
  critDmg: 0,          // 暴击伤害加成（0=默认×2.0）
  penetrationChance: 0,  // 基础穿甲几率 0（同上）
  executeChance: 0,      // 基础收割几率 0（2026-08-05，方便「加成」测试）
  burnChance: 0,        // 基础燃烧几率 0（2026-08-05 调零，方便「加成」测试）
  accessoryChance: 0.03,  // 基础配损几率 3%（2026-09-05）
  weaponDamageChance: 0.03,  // 基础武损几率 3%（2026-09-13）
  floodChance: 0,       // 基础漏水几率 0（同上）
  weapon: {
    mainGun: {
      mountCount: 3,
      cooldownSec: 4,
      enemyColor: '#DD1111',
      range: 15 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'aft'],
    },
    torpedo: {
      mountCount: 2,
      cooldownSec: 10,
      enemyColor: '#CC3333',
      range: 12 * PX_PER_KM,
      holdInterval: 300,
      mountArcs: ['port', 'starboard'],
    },
    // 副炮（2026-08-08 字人）：4 座 AI 自动开火，左舷 2 + 右舷 2，冷却 5s，射程 10km
    // 实际装配武器由 loadout 决定（DEFAULT_LOADOUT.guying.secondary → 巡-130mm原型）
    secondary: {
      mountCount: 4,
      cooldownSec: 5,
      damage: 1247,
      enemyColor: '#DD1111',
      range: 10 * PX_PER_KM,
      holdInterval: 100,
      mountArcs: ['port', 'port', 'starboard', 'starboard'],   // 左舷 2 右舷 2
    },
    // 水雷（2026-08-08 字人）：2 个，冷却 16s（武器：巡-强袭者）
    mine: {
      mountCount: 2,
      cooldownSec: 16,
    },
  },
});

SHIP_LIBRARY.push({
  id: 'guying',
  name: '古鹰',
  desc: '巡洋舰',
  shipType: 'cruiser',
  config: PLAYER_CONFIG,
  mainGunCount: 3,
  torpedoCount: 2,
  secondaryCount: 4,   // 2026-08-08：左 2 右 2
  mineCount: 2,         // 2026-08-08
  stats: {
    '血量':              '20000',
    '装甲强度':            '2000',
    '最大航速':          '35 节',
    '加速功率':          '1300',
    '转向转速':          '45 °/s',
    '转向功率':          '350',
    '水上探测':          '12 km',
    '水下探测':          '6 km',
    '主炮装填':          '4 s',
    '主炮射程':          '15 km',
    '鱼雷装填':          '10 s',
    '鱼雷射程':          '12 km',
    '副炮装填':          '5 s',      // 2026-08-08
    '副炮射程':          '10 km',    // 2026-08-08
    '水雷装填':          '16 s',     // 2026-08-08
  },
});
