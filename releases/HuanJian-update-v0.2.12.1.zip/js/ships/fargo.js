/**
 * fargo.js — 法戈巡洋舰（2026-08-08）
 * 4 主炮（前 2 后 2）+ 6 副炮（左 3 右 3），带 4 个战舰技能（skills，ShipSkills 系统生效）。
 * 注意：强化界面预留的「技能」tab 是舰种技能系统（未来另做），与本舰技能无关。
 */
const FARGO_CONFIG = Object.freeze({
  name: '法戈',
  hp: 44482,
  length: 110,             // 船模尺寸（巡洋中大型）
  width: 22,
  color: '#3A7BD5',
  bowColor: '#5B9EF5',
  outlineColor: '#88CCFF',
  rotationSpeed: 30.18 * Math.PI / 180,   // 30.18 °/s
  weaponRotationSpeed: 42 * Math.PI / 180, // 武器转速 42 °/s
  // 战斗核心属性
  maxSpeed: 36.4,          // 最大航速 36.4 节
  accelPower: 1440,        // 加速功率
  armor: 1903,             // 装甲强度
  smallCaliberEvasion: 0.15,   // 小口径规避 15%
  mediumCaliberEvasion: 0.05,  // 中口径规避 5%
  critChance: 0,
  shatterChance: 0,
  critDmg: 0,
  penetrationChance: 0,
  executeChance: 0,
  burnChance: 0,
  accessoryChance: 0.03,   // 基础配损几率 3%（2026-09-05）
  weaponDamageChance: 0.03,   // 基础武损几率 3%（2026-09-13）
  floodChance: 0,
  // 探测（km）
  surfaceRange: 12.9,
  underwaterRange: 7,
  weapon: {
    mainGun: {
      mountCount: 4,
      cooldownSec: 6,          // 主炮装填 6s
      enemyColor: '#DD1111',
      range: 17 * PX_PER_KM,   // 主炮射程 17km
      holdInterval: 100,
      mountArcs: ['forward', 'forward', 'aft', 'aft'],   // 前 2 后 2
    },
    secondary: {
      mountCount: 6,
      cooldownSec: 5.7,        // 副炮装填 5.7s
      damage: 1247,
      enemyColor: '#DD1111',
      range: 11 * PX_PER_KM,   // 副炮射程 11km
      holdInterval: 100,
      mountArcs: ['port', 'port', 'port', 'starboard', 'starboard', 'starboard'],   // 左 3 右 3
    },
    torpedo: { mountCount: 0 },
    mine: { mountCount: 0 },
  },
  // ── 战舰技能（2026-08-08 ShipSkills 系统）──
  // mode: 'always'（全模式生效，UI 不加任何标记）| 'battle'（仅战役/视同战役生效；
  //   UI 在文本前加「战役」前缀 + 左侧竖条，见 enhance.js _skillEffectHtml）
  // ⚠ mode 字段本身是功能性的，ship-skills.js:154/178 靠它跳过非战役效果，删不得
  // shellEvasion = 三口径规避全加（字人确认）；aura = 12km 本方光环（含自己）
  skills: Object.freeze([
    Object.freeze({
      id: 'fargo-dura',
      name: '耐久大师',
      effects: Object.freeze([
        { mode: 'battle', stat: 'maxHp', value: 2000 },        // 战役血量+2000
        { mode: 'battle', stat: 'shellEvasion', value: 0.02 },  // 战役炮弹规避+2%
        { mode: 'always', stat: 'maxHp', value: 1000 },        // 血量+1000
        { mode: 'always', stat: 'shellEvasion', value: 0.01 },  // 炮弹规避+1%
      ]),
    }),
    Object.freeze({
      id: 'fargo-critpen',
      name: '暴穿大师',
      effects: Object.freeze([
        { mode: 'battle', stat: 'critChance', value: 0.03 },        // 战役暴击几率+3%
        { mode: 'battle', stat: 'penetrationChance', value: 0.03 }, // 战役穿甲几率+3%
        { mode: 'always', stat: 'critChance', value: 0.02 },        // 暴击几率+2%
        { mode: 'always', stat: 'penetrationChance', value: 0.02 }, // 穿甲几率+2%
      ]),
    }),
    Object.freeze({
      id: 'fargo-cruiser',
      name: '巡洋大师',
      effects: Object.freeze([
        { mode: 'battle', stat: 'burnChance', value: 0.03 },  // 战役燃烧几率+3%
        { mode: 'battle', stat: 'penDmg', value: 0.05 },      // 战役穿甲伤害+5%
        { mode: 'always', stat: 'burnChance', value: 0.06 },  // 燃烧几率+6%
        { mode: 'always', stat: 'penDmg', value: 0.05 },      // 穿甲伤害+5%
      ]),
    }),
    Object.freeze({
      id: 'fargo-pensniper',
      name: '穿甲尖兵',
      effects: Object.freeze([
        { mode: 'always', stat: 'mainGunShellSpeed', value: 500 },   // 主炮速度+500（炮速单位）
      ]),
      // 12km 本方战舰穿甲伤害+12%（含自己）；stack:'unique' = 相同增益不叠加（多艘同名只生效一次）
      aura: Object.freeze({ radiusKm: 12, mods: Object.freeze({ penDmgAdd: 0.12 }), stack: 'unique' }),
    }),
  ]),
});

SHIP_LIBRARY.push({
  id: 'fargo',
  name: '法戈',
  desc: '巡洋舰',
  shipType: 'cruiser',
  config: FARGO_CONFIG,
  mainGunCount: 4,
  secondaryCount: 6,
  torpedoCount: 0,
  mineCount: 0,
  stats: {
    '血量':              '44482',
    '装甲强度':            '1903',
    '最大航速':          '36.4 节',
    '加速功率':          '1440',
    '转向转速':          '30.18 °/s',
    '转向功率':          '262',
    '水上探测':          '12.9 km',
    '水下探测':          '7 km',
    '主炮装填':          '6 s',
    '主炮射程':          '17 km',
    '副炮装填':          '5.7 s',
    '副炮射程':          '11 km',
  },
});
