/**
 * collision.js — Collision detection routines.
 *
 * 1. MainGunShell → enemy/player  (radius check on landing)
 * 2. TorpedoProjectile → enemy/player  (OBB collision box check every frame)
 * 3. 舰船 ↔ 舰船 实体碰撞 —— 实现在 ship-collision.js（2026-11-08 重写，此处只保留入口）
 *
 * Dead projectiles are filtered out after processing.
 */

const Collision = {

  /** Set to true by custom battle config to disable ±10% damage variance. */
  _noDamageVariance: false,

  /** @param {boolean} disabled — true = damage never floats */
  setNoDamageVariance: function(disabled) { this._noDamageVariance = !!disabled; },

  /**
   * Check if a world point is inside a ship's oriented bounding box.
   * The ship's box is length × width, centred at (ship.x, ship.y),
   * rotated by ship.heading (0 = north).
   */
  _isPointInShipOBB(px, py, ship) {
    var dx = px - ship.x;
    var dy = py - ship.y;
    // rotate to ship-local coordinates
    var cos = Math.cos(-ship.heading);
    var sin = Math.sin(-ship.heading);
    var localX = dx * cos - dy * sin;
    var localY = dx * sin + dy * cos;
    return Math.abs(localX) <= ship.width / 2
        && Math.abs(localY) <= ship.length / 2;
  },

  /**
   * Run all collision checks for one frame.
   * Modifies `projectiles` in place (filters dead).
   * 阵营规则：弹丸按 team 判定目标——蓝方（player/friend）弹丸只打 enemies；
   * 敌方弹丸打 player + allies。无 team 的旧弹丸按 isPlayer 推导。
   *
   * @param {PlayerShip}       player
   * @param {Array<Ship>}      enemies     — may be single EnemyShip or CustomEnemy[]
   * @param {Array<Ship>}      [allies]    — 友军（AI 盟友）
   * @param {Array}            projectiles
   * @param {Array}            [hitEvents] — pushed with {type,damage,x,y,isPlayerProjectile,targetEnemy,target,attacker}
   * @param {number}           now
   */
  checkAll(player, enemies, allies, projectiles, hitEvents, now) {
    hitEvents = hitEvents || [];
    now = now || 0;
    allies = allies || [];

    for (var pi = 0; pi < projectiles.length; pi++) {
      var proj = projectiles[pi];
      if (!proj.alive) continue;

      var team = proj.team || (proj.isPlayer ? 'player' : 'enemy');
      var targets = (team === 'enemy') ? Collision._blueShips(player, allies) : enemies;

      // ── MainGunShell: only check when it just landed ──────────────────
      if (proj instanceof MainGunShell && proj.hasLanded) {
        var hit = proj.getHitPosition();
        for (var ti = 0; ti < targets.length; ti++) {
          var t = targets[ti];
          if (!t || !t.isAlive) continue;
          var tdist = Math.hypot(hit.x - t.x, hit.y - t.y);
          var thitRadius = t.width * 1.5 + MAIN_GUN_CONFIG.landingDeviation;
          if (tdist <= thitRadius) {
            Collision._applyMGHit(proj, t, hit.x, hit.y, proj.isPlayer, now, hitEvents, player ? player.maxHp : 20000);
            break;  // 一发只命中一个目标
          }
        }
      }

      // ── TorpedoProjectile: contact check every frame ──────────────────
      if (proj instanceof TorpedoProjectile) {
        // 鱼雷撞任何阵营的船都消失；仅异阵营有伤害判定；发射者自己的船不撞（出生点在船体内，2026-08-05）
        var allShips = Collision._blueShips(player, allies).concat(enemies);
        for (var ti2 = 0; ti2 < allShips.length; ti2++) {
          var t2 = allShips[ti2];
          if (!t2 || !t2.isAlive) continue;
          if (t2 === proj.owner) continue;   // 自己撞自己不消失
          if (Collision._isPointInShipOBB(proj.x, proj.y, t2)) {
            var tIsEnemy = (t2.team === 'enemy') || (!t2.team && !t2.isPlayer);
            if ((team === 'enemy') !== tIsEnemy) {
              Collision._applyTorpedoHit(proj, t2, proj.x, proj.y, proj.isPlayer, now, hitEvents, player ? player.maxHp : 20000);
            }
            proj.alive = false;
            break;
          }
        }
      }
    }
  },

  /**
   * 蓝方（玩家 + 友军）存活舰列表。
   * @private
   */
  _blueShips(player, allies) {
    var arr = [];
    if (player && player.isAlive) arr.push(player);
    for (var i = 0; i < (allies || []).length; i++) {
      var a = allies[i];
      if (a && a.isAlive) arr.push(a);
    }
    return arr;
  },

  /**
   * 水雷引爆检测：舰中心距水雷中心 ≤ 引爆半径 → 爆炸一次。
   * 对爆炸半径内所有敌方各造成一次独立伤害（蓝方水雷只炸敌人，敌方水雷只炸蓝方）。
   * 每帧调用一次（main.js 在玩家开火后调用，覆盖"布雷时敌舰已在半径内"的情况）。
   */
  checkMines(player, enemies, allies, projectiles, hitEvents, now) {
    hitEvents = hitEvents || [];
    now = now || 0;
    allies = allies || [];
    for (var pi = 0; pi < projectiles.length; pi++) {
      var proj = projectiles[pi];
      if (!(proj instanceof SeaMine) || !proj.alive) continue;
      var team = proj.team || (proj.isPlayer ? 'player' : 'enemy');
      if (team !== 'enemy') {
        for (var ei = 0; ei < enemies.length; ei++) {
          var e = enemies[ei];
          if (!e || !e.isAlive) continue;
          if (Math.hypot(proj.x - e.x, proj.y - e.y) <= proj.detonationRadius) {
            Collision._explodeMine(proj, enemies, proj.isPlayer, now, hitEvents, player ? player.maxHp : 20000);
            proj.alive = false;
            break;
          }
        }
      } else {
        var blue = Collision._blueShips(player, allies);
        for (var bi = 0; bi < blue.length; bi++) {
          var b = blue[bi];
          if (!b || !b.isAlive) continue;
          if (Math.hypot(proj.x - b.x, proj.y - b.y) <= proj.detonationRadius) {
            Collision._explodeMine(proj, blue, proj.isPlayer, now, hitEvents, player ? player.maxHp : 20000);
            proj.alive = false;
            break;
          }
        }
      }
    }
  },

/** Apply main-gun hit damage + crit + penetration + shatter + burn to a single target */
  _applyMGHit(proj, target, hx, hy, isPlayerProj, now, hitEvents, playerMaxHp) {
    // 跳弹（主副炮 only，2026-08-05）：跳弹率 = max(0, 100 − 射击精度 + 对应口径规避)%；跳弹等效没命中
    if (proj.shellCaliber) {
      var evKey = proj.shellCaliber === 'small' ? 'smallCaliberEvasion'
        : proj.shellCaliber === 'medium' ? 'mediumCaliberEvasion' : 'largeCaliberEvasion';
      var bounceRate = Math.max(0, 1 - (proj.shotAccuracy != null ? proj.shotAccuracy : 1) + (target[evKey] || 0) + (target.getBuffMod ? target.getBuffMod('evasionAllAdd') : 0));  // 学有所成：全口径规避 buff
      if (Math.random() < bounceRate) {
        if (hitEvents) hitEvents.push({ type: 'ricochet', x: hx, y: hy, isPlayerProjectile: isPlayerProj, target: target });
        return;  // 跳弹：无伤害/无效果/不计命中统计
      }
    }
    // ── 伤害公式公共段（2026-08-07 抽 _computeHitDamage；主炮可穿甲，减伤字段 mainPen/reduceMainDmg）──
    var r = this._computeHitDamage(proj, target, now, playerMaxHp, {
      enablePen: true, reduceKey: 'reduceMainDmg', penKey: 'mainPen',
    });
    var finalDamage = r.finalDamage, isCrit = r.isCrit, isExecute = r.isExecute, isPen = r.isPen, isShatter = r.isShatter;

    // 燃烧（主炮专属状态效果；抵抗燃烧对冲）
    var isBurn = false;
    if (Math.random() < Math.max(0, (proj.burnChance || 0) - (target.resistBurnChance || 0))) {  // 抵抗燃烧（对冲）
      // 燃烧伤害 = 百分比扣血基数 × 2% × (1 + 燃烧程度 − 目标抵抗燃烧程度)
      //   基数规范（2026-09-19 字人，唯一入口 Ship.getPercentDamageBase，AGENTS §5.30）：
      //   非战役 → 被燃烧者自身 maxHp；战役（含自定义战斗「视同战役」）→ 玩家舰 maxHp（平衡）
      var pHp = target.getPercentDamageBase(playerMaxHp);
      var dmgPerTick = Math.round(pHp * BURN_DAMAGE_PCT * Math.max(0, 1 + (proj.burnPower || 0) - (target.resistBurnPower || 0)));
      var burnDelayVal = target.burnDelay || 0;
      var tickInterval = BURN_INTERVAL / ((100 + (proj.burnSpeed || 0) - burnDelayVal) / 100);
      if (tickInterval < 2) tickInterval = 2;  // 燃烧间隔下限 2s
      if (tickInterval > 8) tickInterval = 8;  // 燃烧间隔上限 8s（延缓燃烧至多 +100%，2026-08-06）
      var duration = BURN_DURATION * (1 + (proj.burnDuration || 0));
      target.applyBurn(dmgPerTick, tickInterval, duration, now, proj.owner || null);
      isBurn = true;
    }

    // 配件损毁（主炮命中触发，副炮 isSecondary 已跳过，2026-09-05）
    var accMG = this._tryApplyAccessoryDamage(proj, target, now);
    var wedMG = this._tryApplyWeaponDamage(proj, target, now);   // 武器损毁（2026-09-13）

    // 水镜盾被打爆后（杜尔曼）：被主炮命中 → 使敌舰获得「疲弱」（武器伤害-20% 10s，2026-08-06）
    // 放 takeDamage 之后：盾被打爆的当发主炮也能触发（takeDamage 里爆盾置 mirrorBurstBroken）
    var totalDmg = target.takeDamage(finalDamage, 'gun') || 0;   // 总伤害 = 护盾吸收 + 实际扣血（2026-08-09 承伤含护盾）
    var dmT = target.commander && target.commander.durman;
    if (dmT && dmT.mirrorBurstBroken && Date.now() < dmT.mirrorEnd && proj.owner && proj.owner.addBuff) {
      proj.owner.addBuff('weary', '疲弱', Date.now() + 10000, { weaponDmgPen: 0.2 });
    }
    // 威斯康星 [重击炮弹]（2026-11-08）：命中 → 额外 4% 最大血量固定伤害 + 一次普通武损 + 敌舰减益
    //   放 takeDamage 之后：固定伤害吃护盾（与阳炎固定伤害同口径）；本发已经结算，不会递归
    if (proj.isHeavyShell && proj.owner && typeof WisconsinHeavy !== 'undefined') {
      WisconsinHeavy.onHeavyHit(proj.owner, target, now);
    }
    // 绝望讴歌（战列舰「毁灭」，2026-11-15）：主炮每次命中 → 回 1% 最大生命（无次数上限）
    if (!proj.isSecondary && proj.owner && typeof ClassSkillActives !== 'undefined' && ClassSkillActives.onMainGunHit) {
      ClassSkillActives.onMainGunHit(proj.owner, now);
    }
    if (totalDmg > 0) {
      // P2-2 命中战舰烟火粒子（2026-08-16 字人"炮弹命中战舰就有烟火的粒子特效，追求自然真实"）。
      //   只在有伤害时触发（layerShield/mirrorShield/takeDamage=0 免疫的情况不触发——避免免疫时仍冒烟）。
      var _fxR = (window.__testHooks && window.__testHooks.renderer) || null;   // renderer 经 __testHooks 统一挂载（2026-09-18 M1）
      if (_fxR && _fxR.spawnHitFirework) _fxR.spawnHitFirework(hx, hy);
      hitEvents.push({
        type: proj.isSecondary ? 'secondary' : 'mainGun',
        damage: totalDmg,
        x: hx, y: hy,
        isPlayerProjectile: isPlayerProj,
        isCritical: isCrit,
        isExecute: isExecute,
        isPenetration: isPen,
        isShatter: isShatter,
        isBurn: isBurn,
        isAccessory: !!accMG,
        accessoryType: accMG,
        isWeaponDamage: !!wedMG,
        wepDamageType: wedMG ? wedMG.type : null,
        wepDamageIndex: wedMG ? wedMG.index : null,
        targetEnemy: isPlayerProj ? target : null,
        target: target,
        attacker: proj.owner || null,
      });
    }
  },

  /** Apply torpedo hit damage + crit + shatter + flood to a single target (no penetration) */
  _applyTorpedoHit(proj, target, hx, hy, isPlayerProj, now, hitEvents, playerMaxHp) {
    // 鱼雷规避（2026-08-06）：敌方鱼雷精度固定 100%，跳弹率 = 目标鱼雷规避；跳弹等效没命中
    // 鱼雷规避（2026-08-06）：跳弹率 = max(0, 1 − 弹丸武器精度 + 目标鱼雷规避)（杜尔曼武器精度 buff 后）
    var tBounce = Math.max(0, 1 - (proj.shotAccuracy != null ? proj.shotAccuracy : 1) + (target.torpedoEvasion || 0) + (target.getBuffMod ? target.getBuffMod('torpedoEvasionAdd') : 0));  // 沙皇血池武器规避（2026-08-09）
    if (tBounce > 0 && Math.random() < tBounce) {
      if (hitEvents) hitEvents.push({ type: 'torpedoRicochet', x: hx, y: hy, isPlayerProjectile: isPlayerProj, target: target });
      return;  // 跳弹：无伤害/无效果/不计命中统计
    }
    // ── 伤害公式公共段（2026-08-07 抽 _computeHitDamage；鱼雷无穿甲，减伤字段 torpPen/reduceTorpedoDmg）──
    var r = this._computeHitDamage(proj, target, now, playerMaxHp, {
      enablePen: false, reduceKey: 'reduceTorpedoDmg', penKey: 'torpPen',
    });
    var finalDamage = r.finalDamage, isCrit = r.isCrit, isExecute = r.isExecute, isShatter = r.isShatter;

    // 漏水（鱼雷/水雷状态效果；抵抗漏水对冲）
    var isFlood = false;
    // 漏水伤害基数同燃烧（AGENTS §5.30）：非战役 → 被漏水者自身 maxHp；战役（含视同战役）→ 玩家舰 maxHp
    var pHp = target.getPercentDamageBase(playerMaxHp);
    if (Math.random() < Math.max(0, (proj.floodChance || 0) - (target.resistFloodChance || 0))) {  // 抵抗漏水（对冲）
      var dmgPerTick = Math.round(pHp * FLOOD_DAMAGE_PCT * Math.max(0, 1 + (proj.floodPower || 0) - (target.resistFloodPower || 0)));
      var floodDelayVal = target.floodDelay || 0;
      var tickInterval = FLOOD_INTERVAL / ((100 + (proj.floodSpeed || 0) - floodDelayVal) / 100);
      if (tickInterval < 1) tickInterval = 1;  // 漏水间隔下限 1s
      if (tickInterval > 4) tickInterval = 4;  // 漏水间隔上限 4s（延缓漏水至多 +100%，2026-08-06）
      var duration = FLOOD_DURATION * (1 + (proj.floodDuration || 0));
      if (target.applyFlood(dmgPerTick, tickInterval, duration, now, proj.owner || null)) {
        isFlood = true;
      }
    }

    // 配件损毁（鱼雷命中触发，2026-09-05）
    var accTp = this._tryApplyAccessoryDamage(proj, target, now);
    var wedTp = this._tryApplyWeaponDamage(proj, target, now);   // 武器损毁（2026-09-13）

    var totalDmg = target.takeDamage(finalDamage, 'torp') || 0;   // 总伤害 = 护盾吸收 + 实际扣血（2026-08-09 承伤含护盾）
    // 阳炎-利刃「鱼雷追击」：鱼雷命中（实际造成伤害；跳弹已在上面 return）→ 临时层 +1（2026-10-01）
    //   ⚠️ 每颗鱼雷**弹丸**各触发一次 → 一次齐射 N 管齐中即 N 层（见汇报「需注意」）
    if (totalDmg > 0 && proj.owner) {
      if (typeof YanyinPursuit !== 'undefined' && YanyinPursuit.hasPursuit(proj.owner)) YanyinPursuit.onTorpedoHit(proj.owner, target, now);
      if (typeof YanyinHunt !== 'undefined' && YanyinHunt.hasHunt && YanyinHunt.hasHunt(proj.owner)) YanyinHunt.onTorpedoHit(proj.owner, target, now);
    }
    if (totalDmg > 0) {
      // P2-2 命中战舰烟火粒子（2026-08-16）
      var _fxR = (window.__testHooks && window.__testHooks.renderer) || null;   // renderer 经 __testHooks 统一挂载（2026-09-18 M1）
      if (_fxR && _fxR.spawnHitFirework) _fxR.spawnHitFirework(hx, hy);
      hitEvents.push({
        type: 'torpedo',
        damage: totalDmg,
        x: hx, y: hy,
        isPlayerProjectile: isPlayerProj,
        isCritical: isCrit,
        isExecute: isExecute,
        isShatter: isShatter,
        isFlood: isFlood,
        isAccessory: !!accTp,
        accessoryType: accTp,
        isWeaponDamage: !!wedTp,
        wepDamageType: wedTp ? wedTp.type : null,
        wepDamageIndex: wedTp ? wedTp.index : null,
        targetEnemy: isPlayerProj ? target : null,
        target: target,
        attacker: proj.owner || null,
      });
    }
  },

  /**
   * 水雷爆炸：对 targets（爆炸半径内者）各造成一次独立伤害。
   * @param {SeaMine} proj
   * @param {Array}   targets   — 敌方列表（玩家水雷→敌人；敌方水雷→[player]）
   * @param {boolean} isPlayerProj
   */
  _explodeMine(proj, targets, isPlayerProj, now, hitEvents, playerMaxHp) {
    for (var i = 0; i < targets.length; i++) {
      var t = targets[i];
      if (!t || !t.isAlive) continue;
      if (Math.hypot(proj.x - t.x, proj.y - t.y) > proj.explosionRadius) continue;
      Collision._applyMineHit(proj, t, proj.x, proj.y, isPlayerProj, now, hitEvents, playerMaxHp);
    }
  },

  /** 水雷命中：浮动→暴击→装甲→最终增伤→碎甲→漏水（无穿甲、无燃烧） */
  _applyMineHit(proj, target, hx, hy, isPlayerProj, now, hitEvents, playerMaxHp) {
    // 水雷规避（2026-08-06）：敌方水雷精度固定 100%，跳弹率 = 目标水雷规避（每船独立判定）；跳弹等效没命中
    // 水雷规避（2026-08-06）：跳弹率 = max(0, 1 − 弹丸武器精度 + 目标水雷规避)（每船独立判定）
    var mBounce = Math.max(0, 1 - (proj.shotAccuracy != null ? proj.shotAccuracy : 1) + (target.mineEvasion || 0) + (target.getBuffMod ? target.getBuffMod('mineEvasionAdd') : 0));  // 沙皇血池武器规避（2026-08-09）
    if (mBounce > 0 && Math.random() < mBounce) {
      if (hitEvents) hitEvents.push({ type: 'mineRicochet', x: hx, y: hy, isPlayerProjectile: isPlayerProj, target: target });
      return;  // 跳弹：无伤害/无效果/不计命中统计
    }
    // ── 伤害公式公共段（2026-08-07 抽 _computeHitDamage；水雷无穿甲，减伤字段 minePen/reduceMineDmg）──
    var r = this._computeHitDamage(proj, target, now, playerMaxHp, {
      enablePen: false, reduceKey: 'reduceMineDmg', penKey: 'minePen',
    });
    var finalDamage = r.finalDamage, isCrit = r.isCrit, isExecute = r.isExecute, isShatter = r.isShatter;

    // 漏水（鱼雷/水雷状态效果；抵抗漏水对冲）
    var isFlood = false;
    // 漏水伤害基数同燃烧（AGENTS §5.30）：非战役 → 被漏水者自身 maxHp；战役（含视同战役）→ 玩家舰 maxHp
    var pHp = target.getPercentDamageBase(playerMaxHp);
    if (Math.random() < Math.max(0, (proj.floodChance || 0) - (target.resistFloodChance || 0))) {  // 抵抗漏水（对冲）
      var dmgPerTick = Math.round(pHp * FLOOD_DAMAGE_PCT * Math.max(0, 1 + (proj.floodPower || 0) - (target.resistFloodPower || 0)));
      // 漏水间隔：与鱼雷一致，吃 floodSpeed↔floodDelay 逆属性（2026-08-06 修，原缺 delay 项 + 无下限）
      var floodDelayVal = target.floodDelay || 0;
      var tickInterval = FLOOD_INTERVAL / ((100 + (proj.floodSpeed || 0) - floodDelayVal) / 100);
      if (tickInterval < 1) tickInterval = 1;  // 漏水间隔下限 1s
      if (tickInterval > 4) tickInterval = 4;  // 漏水间隔上限 4s（延缓漏水至多 +100%，2026-08-06）
      var duration = FLOOD_DURATION * (1 + (proj.floodDuration || 0));
      if (target.applyFlood(dmgPerTick, tickInterval, duration, now, proj.owner || null)) {
        isFlood = true;
      }
    }

    // 配件损毁（水雷命中触发，2026-09-05）
    var accMn = this._tryApplyAccessoryDamage(proj, target, now);
    var wedMn = this._tryApplyWeaponDamage(proj, target, now);   // 武器损毁（2026-09-13）

    var totalDmg = target.takeDamage(finalDamage, 'mine') || 0;   // 总伤害 = 护盾吸收 + 实际扣血（2026-08-09 承伤含护盾）
    // 阳炎-利刃「蜃光猎影」：水雷命中（实际造成伤害；跳弹已在上面 return）→ 固定伤害 + 漏水（2026-10-01）
    if (totalDmg > 0 && proj.owner) {
      // 必漏水成功 → 计入 ev.isFlood：命中统计「漏水」药丸 +1，与普通漏水同一统计显示（2026-10-18 字人要求）
      if (typeof YanyinHunt !== 'undefined' && YanyinHunt.hasHunt && YanyinHunt.hasHunt(proj.owner)) {
        if (YanyinHunt.onMineHit(proj.owner, target, now)) isFlood = true;
      }
    }
    if (totalDmg > 0) {
      // P2-2 命中战舰烟火粒子（2026-08-16）
      var _fxR = (window.__testHooks && window.__testHooks.renderer) || null;   // renderer 经 __testHooks 统一挂载（2026-09-18 M1）
      if (_fxR && _fxR.spawnHitFirework) _fxR.spawnHitFirework(hx, hy);
      hitEvents.push({
        type: 'mine',
        damage: totalDmg,
        x: hx, y: hy,
        isPlayerProjectile: isPlayerProj,
        isCritical: isCrit,
        isExecute: isExecute,
        isShatter: isShatter,
        isFlood: isFlood,
        isAccessory: !!accMn,
        accessoryType: accMn,
        isWeaponDamage: !!wedMn,
        wepDamageType: wedMn ? wedMn.type : null,
        wepDamageIndex: wedMn ? wedMn.index : null,
        targetEnemy: isPlayerProj ? target : null,
        target: target,
        attacker: proj.owner || null,
      });
    }
  },

  /**
   * 舰船 ↔ 舰船 实体碰撞入口（2026-11-08 重写，实现见 ship-collision.js）。
   * 传入的舰船会**两两**判定——不再是「只处理玩家、AI 之间穿模」：
   * 玩家↔敌舰、玩家↔友军、敌舰↔敌舰、友军↔敌舰都按真实船体轮廓分离。
   *
   * @param {Ship}        player — 玩家舰（同时是 ships 的去重基准）
   * @param {Array<Ship>} ships  — 其它参战舰船
   * @param {number}      [dt]   — 秒；限制单帧最大推移，防深度重叠时瞬移
   * @returns {number} 本帧检测到的重叠对数
   */
  checkShipBump(player, ships, dt) {
    var list = [];
    if (player) list.push(player);
    if (ships) {
      for (var i = 0; i < ships.length; i++) {
        if (ships[i] && list.indexOf(ships[i]) < 0) list.push(ships[i]);
      }
    }
    return ShipCollision.resolve(list, dt);
  },

  /**
   * Remove all dead projectiles from the array.
   */
  cullDead(projectiles) {
    for (var i = projectiles.length - 1; i >= 0; i--) {
      if (!projectiles[i].alive) projectiles.splice(i, 1);
    }
    return projectiles;
  },
};
