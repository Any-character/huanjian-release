/**
 * durman.js — 卡尔·杜尔曼 指挥官（数据注册，状态机由 CommanderRuntime 处理）
 *
 * 被动效果词条（effect）：
 *   ignoreArmorFlat       — 无视装甲固定加成（value 点，直接加 player.ignoreArmor）
 *   hpFlat                — 血量固定加成（maxHp/hp +value，与坚固护甲共用 hpFlat 字段）
 *   cdPctFlatAll          — 全武器装填 -value（走 getCdPct，参考雷德尔 Z计划：基础减）
 *   shieldShredFlat       — 护盾撕裂加成（已有）
 *   resistShatterDegreeFlat — 抵抗碎甲程度加成（目标侧字段 +value）
 *   hullProtectFlat       — 舰体保护加成（目标侧字段 +value）
 *   learnMaster           — 学有所长（三触发，collision 检测，见 T6）
 *   defenseMatrix         — 防御矩阵（20km 光环 + 低血触发 20 层护盾）
 *   attackTransform       — 进攻转化（按装甲/血量动态加成暴击穿甲概率与伤害）
 *
 * 主动技能（activeSkills[0] = 水镜之盾 mirrorShield，充能制）：
 *   充能：冷却循环一次=充能 1 层；使用消耗 1 层；击沉 1 舰解锁上限 1→2
 *   开启：获得 maxHp×45% 水镜数值盾 30s + 移除燃烧/漏水/碎甲 + 30s 舰体保护+40%
 *   盾爆（被打爆/到期都触发）：22km 内敌舰 maxHp×10% 技能伤害 + 被点亮 15s
 *   被打爆专属：剩余技能时间火炮伤害固定-600 + 被主炮命中 → 敌舰疲弱（武器伤害-20% 10s）
 */
COMMANDER_LIBRARY.push({
  id: 'durman',
  name: '卡尔·杜尔曼',
  title: '荷兰皇家海军少将',
  color: '#2F6FB2',        // 深蓝
  desc: '荷兰皇家海军少将，美英荷澳联合（ABDA）舰队司令。1942 年爪哇海战中率舰队迎击日军舰队，发出最后命令「我发动攻击，跟随我」后与旗舰「德·鲁伊特」号同沉殉国。启用后获得 6 项被动技能与 1 个主动技能「水镜之盾」。',
  passives: [
    {
      id: 'fortified',
      name: '坚固护甲',
      desc: '无视装甲 +600、血量 +2000',
      effect: 'ignoreArmorFlat',
      value: 600,          // 无视装甲 +600 点
      hpFlat: 2000,        // 血量 +2000
    },
    {
      id: 'loader',
      name: '装填大师',
      desc: '武器装填 -8%、护盾撕裂 +10%、射击精度 +10%、武器伤害 +8%',
      effect: 'cdPctFlatAll',
      value: 0.08,          // 全武器装填 -8%（基础减，参考 Z计划）
      shieldShredFlat: 0.1, // 护盾撕裂 +10%
      accuracyFlat: 0.1,    // 射击精度 +10%（常驻 buff weaponAccuracyAdd，2026-08-06）
      dmgPctFlatAll: 0.08,  // 武器伤害 +8%（全武器，走 getDmgPct，2026-08-06）
    },
    {
      id: 'hull',
      name: '船体加固',
      desc: '抵抗碎甲程度 +10%、舰体保护 +20%、抵抗暴击 +10%、减免暴击伤害 +20%',
      effect: 'resistShatterDegreeFlat',
      value: 0.1,          // 抵抗碎甲程度 +10%
      hullProtectFlat: 0.2, // 舰体保护 +20%
      resistCritChanceFlat: 0.1,  // 抵抗暴击 +10%（2026-08-06）
      reduceCritDmgFlat: 0.2,     // 减免暴击伤害 +20%（2026-08-06）
    },
    {
      id: 'learned',
      name: '学有所长',
      desc: '被打出碎甲时移除本次碎甲并获得 5s 免疫碎甲（冷却 60s）；被打出暴击时获得 10s装甲+500 增益（冷却 60s）；被打出穿甲时获得 10s全口径规避+5% 增益（冷却 60s）。',
      effect: 'learnMaster',
      // 三触发独立冷却 60s
      shatterImmuneSec: 5,   // 碎甲触发：免疫碎甲 5s
      shatterCdSec: 60,
      critArmorBuff: 500,    // 暴击触发：装甲+500
      critBuffSec: 10,
      critCdSec: 60,
      penEvasionBuff: 0.05,  // 穿甲触发：全口径规避+5%
      penBuffSec: 10,
      penCdSec: 60,
    },
    {
      id: 'matrix',
      name: '防御矩阵',
      desc: '20km内敌舰减益：武器伤害-8%（出圈消失）。自身血量低于 30% 时：清除全部普通异常（燃烧/漏水/碎甲）、回复 30% 血量、获得特殊 20 层护盾（45s，每层免疫一次火炮伤害，每层 +1% 武器精度 +1% 主炮真伤）。每场战斗至多触发一次。',
      effect: 'defenseMatrix',
      auraRadiusKm: 20,     // 光环范围
      weaponDmgPen: 0.08,   // 敌舰武器伤害-8%
      lowHpPct: 0.3,        // 低于 30% 触发
      healPct: 0.3,         // 回 30% 血
      layerShield: 20,      // 20 层特殊护盾
      layerSec: 45,         // 持续 45s
      layerAccuracyPct: 0.01,   // 每层 +1% 武器精度
      layerTrueDmgPct: 0.01,    // 每层 +1% 主炮真伤
    },
    {
      id: 'transform',
      name: '进攻转化',
      desc: '每有 1000 装甲额外提高自身 0.6% 暴击穿甲概率；每有 5000 血量额外提高自身 0.5% 暴击穿甲伤害（按精确比例）。受到致死伤害时：免疫此次伤害、回复 20% 血量、免费触发一次「水镜之盾」（不消耗充能/不进入冷却），此后永久获得 30% 固定伤害减免（仅对非武器伤害：燃烧/漏水/技能伤害）。每场战斗触发一次。',
      effect: 'attackTransform',
      armorPerK: 1000,       // 每 1000 装甲
      critPenPctPerK: 0.006, // +0.6% 暴击率 +0.6% 穿甲率
      hpPerK: 5000,          // 每 5000 血量
      critPenDmgPerK: 0.005, // +0.5% 暴击伤害 +0.5% 穿甲伤害
      deathSave: true,       // 致死伤害免疫（一次，2026-08-06）
      reviveHpPct: 0.2,      // 免疫后回 20% 血
      freeMirror: true,      // 免费触发一次水镜之盾（不消耗充能/不冷却）
      reducePct: 0.3,        // 此后永久固定伤害减免 +30%（仅非武器伤害）
    },
  ],
  activeSkills: [
    {
      id: 'mirrorShield',
      name: '水镜之盾',
      desc: '开启后获得 45% 生命值的护盾持续 30s，移除普通异常（燃烧/漏水/碎甲）。盾被打爆或到期消失都会爆炸：对 25km内所有敌舰造成相当于自身最大血量 12.5% 的技能伤害，并全部附加「被点亮」15s。技能期间自身 +40% 舰体保护；若盾被打掉，剩余技能时间内受到火炮伤害固定降低 600 点，且被主炮命中时使敌舰获得「疲弱」（武器伤害-20% 10s）。冷却 100s；击沉一次敌舰后变为充能形式，至多充能两层，效果可叠加、时间分别计算。',
      type: 'mirrorShield',
      chargeSec: 100,        // 充能循环时间（冷却循环一次 = 充能一层）
      maxCharge: 1,          // 初始充能上限（击沉敌舰后解锁 2）
      unlockMaxCharge: 2,    // 击沉后上限
      shieldPct: 0.45,       // 45% 生命值护盾
      durationSec: 30,       // 持续 30s
      explodeRadiusKm: 25,   // 爆炸范围 25km（2026-08-06 22→25）
      explodeDmgPct: 0.125,  // 技能伤害 = maxHp×12.5%（2026-08-06 0.1→0.125）
      litSec: 15,            // 被点亮 15s
      hullProtectBonus: 0.4, // 技能期间舰体保护 +40%
      flatReduce: 600,       // 被打爆后剩余时间火炮伤害固定 -600
      wearySec: 10,          // 疲弱 10s
      wearyWeaponDmgPen: 0.2, // 疲弱：武器伤害-20%
    },
  ],
});
