/**
 * mahan.js — 塞耶·马汉 指挥官（数据注册，无逻辑）
 *
 * 被动效果词条（effect）：
 *   critBuff   — 暴击炮术：每 intervalSec 检查一次，无 buff 则暴击几率 +value，
 *                不可叠加，打出暴击（玩家自己的攻击）后移除（无自然时限）
 *   burnBuff   — 燃烧炮术：同上，燃烧几率 +value，打出燃烧后移除
 *   lowHpRegen — 战略论：血量 < threshold（小数）时，每 intervalSec 回复
 *                maxHp×value 血量，回到阈值以上停止
 *
 * 主动技能（activeSkills）：
 *   seapower — 海权论：移除自身燃烧/漏水 + 己方所有人回 maxHp×healPct，
 *              冷却 cooldownSec，至多 maxUses 次（次数不显示，用完不可用）
 */
COMMANDER_LIBRARY.push({
  id: 'mahan',
  name: '塞耶·马汉',
  title: '海权论奠基人',
  color: '#4A90D9',        // 头像/主题色（海军蓝，区别于雷德尔金色）
  desc: '海权论的奠基者。启用后获得 3 项被动技能与 1 个主动技能「海权论」。',
  passives: [
    {
      id: 'critArtillery',
      name: '暴击炮术',
      desc: '每分钟获得增益「暴击炮术」：暴击几率 +10%，不可叠加，打出暴击后移除',
      effect: 'critBuff',
      value: 0.1,
      intervalSec: 60,
    },
    {
      id: 'burnArtillery',
      name: '燃烧炮术',
      desc: '每分钟获得增益「燃烧炮术」：燃烧几率 +10%，不可叠加，打出燃烧后移除',
      effect: 'burnBuff',
      value: 0.1,
      intervalSec: 60,
    },
    {
      id: 'strategy',
      name: '战略论',
      desc: '血量低于 20% 时，每 30s回复 1% 血量',
      effect: 'lowHpRegen',
      threshold: 0.2,
      intervalSec: 30,
      value: 0.01,
    },
  ],
  activeSkills: [
    {
      id: 'seapower',
      name: '海权论',
      desc: '使用后移除自身燃烧、漏水，己方所有人回复 5% 血量。冷却 30s，至多使用 3 次。',
      type: 'seapower',
      cooldownSec: 30,
      maxUses: 3,
      healPct: 0.05,
    },
  ],
});
