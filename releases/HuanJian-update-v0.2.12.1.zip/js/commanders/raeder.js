/**
 * raeder.js — 埃里希·雷德尔 指挥官（数据注册，无逻辑）
 *
 * 被动效果词条（effect）：
 *   mainGunShellSpeed — 主炮弹速加成（单位：游戏炮速单位，运行时 ×0.057 → px/s）
 *   armorFlat         — 装甲固定加成（数值）
 *   dmgPct            — 武器伤害百分比加成（小数，作用于 weapons 列表中的武器，面板伤害后乘，2026-08-06 语义由最终伤害改武器伤害）
 *   cdPct             — 冷却百分比缩短（小数，作用于 weapons 列表中的武器）
 *   surfaceBuffOnEnemyHit — 受敌方主炮命中时获得探测范围增益
 *                          { value: 范围加成 km, duration: 秒, cooldown: 秒 }
 *
 * 主动技能（activeSkills）：
 *   zplan — Z计划：被动部分 = 命中累计升级（每 hitsPerLevel 次 +1 级，至 maxLevel），
 *           perLevelDmgPct / perLevelCdPct 按当前等级常驻生效（不限窗口）；
 *           主动部分 = 清异常窗口 + 命中回血窗口，窗口结束返回 1 级
 */
COMMANDER_LIBRARY.push({
  id: 'raeder',
  name: '埃里希·雷德尔',
  title: '第三帝国海军总司令',
  color: '#C9A227',        // 头像/主题色（金色）
  desc: '狼群之父，精通炮术与战略机动。启用后获得 4 项被动技能与 1 个主动技能「Z计划」。',
  passives: [
    {
      id: 'gunkraft',
      name: '空炮增强',
      desc: '主炮弹速 +500',
      effect: 'mainGunShellSpeed',
      value: 500,
    },
    {
      id: 'nordsee',
      name: '北海枭雄',
      desc: '装甲 +500',
      effect: 'armorFlat',
      value: 500,
    },
    {
      id: 'kriegslage',
      name: '战争局势',
      desc: '受敌方主炮命中后，探测范围 +8km，持续 15s（冷却 90s）',
      effect: 'surfaceBuffOnEnemyHit',
      value: 8,          // km
      duration: 15,      // s
      cooldown: 90,      // s
    },
    {
      id: 'zepter',
      name: '权杖掌握者',
      desc: '主炮/鱼雷伤害 +15%',
      effect: 'dmgPct',
      weapons: ['mainGun', 'torpedo'],
      value: 0.15,
    },
  ],
  activeSkills: [
    {
      id: 'zplan',
      name: 'Z计划',
      desc: '被动：进场默认 1 级，主炮/鱼雷命中累计 8 次增加 1 级（至多 5 级），每级主炮/鱼雷伤害 +1% 及主炮/鱼雷冷却 -3%，按当前等级常驻生效。主动（冷却 60s）：使用后 5s内持续清除燃烧、漏水；30s内，每次主炮或鱼雷命中恢复血量（1 级 0.2%，每级增加 0.1%，按当前等级计算），效果持续时间结束后返回 1 级。',
      type: 'zplan',
      cooldownSec: 60,
      maxLevel: 5,
      hitsPerLevel: 8,
      perLevelDmgPct: 0.01,   // 每级 +1% 武器伤害（主炮/鱼雷）
      perLevelCdPct: 0.03,    // 每级 -3% 冷却
      clearWindowSec: 5,      // 前段：清除异常窗口（0.5s 一次）
      clearTickMs: 500,
      healWindowSec: 30,      // 全程：命中回血窗口
      healBasePct: 0.002,     // 基础回血 maxHp×0.2%
      healPerLevelPct: 0.001, // 每级 +maxHp×0.1%
    },
  ],
});
