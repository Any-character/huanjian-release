/**
 * lutjens.js — 根舍·卢金斯 指挥官（数据注册 + 状态机由 CommanderRuntime 处理，2026-09-13）
 *
 * 历史原型：京特·吕特晏斯（Günther Lütjens），俾斯麦号舰队司令——与战役「截击俾斯麦」呼应。
 *
 * 被动效果词条（effect）：
 *   secondaryRangeFlat   — 副炮射程加成（km，运行时 ×PX_PER_KM；消费点 getSecondaryRangePx）
 *   critDmgFlat          — 暴击伤害加成（小数）
 *   perfectArmor         — 完美装甲：静态 4 项抵抗 +3%；动态部分（受敌舰伤害累计 20% maxHp
 *                          → 移除普通异常状态 + 武器精度层）由 main.js hitEvents + commander 状态机处理
 *   resistDamageFlat     — 抵抗武损/抵抗配损（小数）
 *   professionalDispatch — 专业调度：副炮击沉→主炮立即装填；主炮击沉→副炮立即装填
 *                          （main.js hitEvents 检测击沉 + 武器类型分发）
 *
 * 主动技能（activeSkills[0] = 齐射模式 salvoSwitch，**模式切换类**）：
 *   commanderMain（默认鼠标中键）切换开/关，切换后 1s 内不能再次切换（防连点）。
 *   开（齐射模式）：副炮射程+2.5km、主炮炮速+1000、副炮真伤+5%；副炮变为主动武器跟随主炮瞄准
 *                  （不再自动开火；有发射角度限制/射程限制，同主炮操作方式）；
 *                  每次发射主炮时同步发射一门副炮（编号最靠前且就绪的）。
 *   关（常规模式）：主炮射程+1km、副炮炮速+1000、主炮命中使敌舰获得减益「最大航速-5%」10s
 *                  （不可叠加，每次命中刷新持续时间）。
 *
 * 「普通异常状态」定义（计入词条库 other 类）：燃烧、漏水、碎甲、武损、配损五种。
 */
COMMANDER_LIBRARY.push({
  id: 'lutjens',
  name: '根舍·卢金斯',
  title: '俾斯麦号舰队司令',
  color: '#7A8B99',        // 钢灰蓝（俾斯麦号涂装色）
  desc: '冷静的舰队指挥官，将副炮运用到极致。启用后获得 5 项被动技能与 1 个模式切换技能「齐射模式」。',
  passives: [
    {
      id: 'extremeSecondary',
      name: '极限副炮',
      desc: '副炮射程 +2km',
      effect: 'secondaryRangeFlat',
      value: 2,             // km
    },
    {
      id: 'critDmgBoost',
      name: '暴伤提升',
      desc: '暴击伤害 +5%',
      effect: 'critDmgFlat',
      value: 0.05,
    },
    {
      id: 'perfectArmor',
      name: '完美装甲',
      desc: '抵抗燃烧、抵抗漏水、抵抗暴击、抵抗穿甲 +3%。受到敌舰伤害每达到自身 20% 最大血量，触发一次：移除全部「普通异常状态」（燃烧/漏水/碎甲/武损/配损），并获得增益：武器精度 +2%（最高 5 层，战斗内持续）。',
      effect: 'perfectArmor',
      resistBurn: 0.03,
      resistFlood: 0.03,
      resistCrit: 0.03,
      resistPen: 0.03,
      hpThresholdPct: 0.20,     // 每 20% 最大血量
      accuracyPerLayer: 0.02,   // 每层武器精度 +2%
      maxLayers: 5,
    },
    {
      id: 'resistDamage',
      name: '抵抗损毁',
      desc: '抵抗武损 +30%，抵抗配损 +5%',
      effect: 'resistDamageFlat',
      resistWeaponDamage: 0.30,
      resistAccessory: 0.05,
    },
    {
      id: 'professionalDispatch',
      name: '专业调度',
      desc: '自身副炮击沉敌舰时，主炮立即装填；主炮击沉敌舰时，副炮立即装填。',
      effect: 'professionalDispatch',
    },
  ],
  activeSkills: [
    {
      id: 'salvoMode',
      name: '齐射模式',
      desc: '模式切换类技能（切换冷却 1s）。开启（齐射模式）：副炮射程 +2.5km、主炮炮速 +1000、副炮真伤 +5%；副炮跟随主炮瞄准，变为和主炮一样的主动武器（不再自动开火，受发射角度限制与副炮射程限制），每次发射主炮时同步发射一门副炮（编号最靠前且就绪的那门）。关闭（常规模式）：主炮射程 +1km、副炮炮速 +1000、主炮命中使敌舰获得减益「最大航速 -5%」持续 10s（不可叠加，每次命中刷新持续时间）。',
      type: 'salvoSwitch',
      cooldownSec: 1,           // 切换冷却（防连点，2026-09-13 字人确认）
      salvoSecRangeKm: 2.5,     // 开：副炮射程 +2.5km
      salvoMainGunShellSpeed: 1000,  // 开：主炮炮速 +1000（炮速单位）
      salvoSecTrueDmg: 0.05,    // 开：副炮真伤 +5%
      normalMainGunRangeKm: 1,  // 关：主炮射程 +1km
      normalSecShellSpeed: 1000,     // 关：副炮炮速 +1000（炮速单位）
      slowMaxSpeedPct: 0.05,    // 关：主炮命中 → 敌舰最大航速 -5%
      slowDurationSec: 10,      // 关：减速持续 10s（不可叠加，刷新）
    },
  ],
});
