/**
 * huasheng.js — 华晟 指挥官（虚拟人物，数据注册 + 军魂状态机由 CommanderRuntime 处理）
 *
 * 被动效果词条（effect）：
 *   penFlat          — 全武器穿透加成（mainPen/torpPen/minePen 各 +value）
 *   shieldShredFlat  — 护盾撕裂加成（玩家攻击侧字段 +value）
 *   hpFlat           — 血量固定加成（maxHp/hp +value）
 *   dmgToOneFlat     — 受到武器伤害为1几率（目标侧字段 +value）
 *   negateCritFlat   — 被普通暴击豁免概率（目标侧字段 +value）
 *   fearAura         — 畏惧光环（value=范围 km；范围内敌舰获得 buff，mods 见下）
 *
 * 主动技能（activeSkills[0] = 军魂 warsoul）：
 *   被动获取：被打掉 10% 血 / 造成敌舰 10% 血伤害 / 每 40s → +1 军魂（上限 6）
 *   每军魂：暴击伤害+2% / 最终增伤+2% / 武器冷却-2% / 全武器穿透+2% / 最终减伤+2% / 水上水下探测+0.5km
 *   主动：消耗全部军魂 → 战神模式（每层回 4% 血 + 4% 血护盾 + 命中附加自身 0.6% 血伤害，25s）
 *         护盾被打破 → 无敌 3.5s + 22km 敌舰被点亮 6s；冷却 90s
 */
COMMANDER_LIBRARY.push({
  id: 'huasheng',
  name: '华晟',
  title: '虚拟人物',
  color: '#4A90D9',        // 海军蓝
  desc: '充满亲和力的虚拟人物，擅长外交与成长型战斗。启用后获得 6 项被动技能与 1 个主动技能「军魂」。',
  passives: [
    {
      id: 'ambition',
      name: '志向高远',
      desc: '全武器穿透 +12.5%',
      effect: 'penFlat',
      value: 0.125,
    },
    {
      id: 'vigor',
      name: '年富力强',
      desc: '护盾撕裂 +100%',
      effect: 'shieldShredFlat',
      value: 1.0,
    },
    {
      id: 'diplomacy',
      name: '外交大师',
      desc: '血量 +1000',
      effect: 'hpFlat',
      value: 1000,
    },
    {
      id: 'affinity',
      name: '充满亲和力',
      desc: '受到武器伤害为 1 概率 +8%',
      effect: 'dmgToOneFlat',
      value: 0.08,
    },
    {
      id: 'innocent',
      name: '无邪气场',
      desc: '被普通暴击有 25% 概率不触发',
      effect: 'negateCritFlat',
      value: 0.25,
    },
    {
      id: 'fearAura',
      name: '畏惧光环',
      desc: '自身范围 22km内敌舰获得减益：全武器速度-10%、射击精度-10%、暴击伤害-20%。敌舰离开 22km时减益消失。',
      effect: 'fearAura',
      value: 22,            // 范围 km
      shellSpeedMul: 0.9,   // 弹丸速度 ×0.9
      shotAccuracyPen: 0.1, // 射击精度 -0.1
      critDmgPen: 0.2,      // 暴击伤害 -0.2
    },
  ],
  activeSkills: [
    {
      id: 'warsoul',
      name: '军魂',
      desc: '被动：每因敌舰伤害损失 10% 血量、或累计造成敌舰 10% 血量的伤害、或每经过 40s，获得 1 个「军魂」（至多 6 个）。每有 1 个军魂：暴击伤害+2%、最终增伤+2%、武器冷却-2%、全武器穿透+2%、最终减伤+2%、水上/水下探测+0.5km。主动（冷却 90s）：消耗当前全部军魂进入战神模式，每消耗 1 层回复 4% 血量并获得 4% 血量的战神护盾，武器命中敌舰额外造成自身最大血量 0.6% 的伤害，持续 25s；期间战神护盾若被打破，获得「无敌」增益持续 3.5s，并为 22km 内全部敌舰附加「被点亮」减益持续 6s。',
      type: 'warsoul',
      cooldownSec: 90,
      maxSouls: 6,
      // 每军魂属性（小数）
      perSoulCritDmg: 0.02,       // 暴击伤害 +2%
      perSoulFinalDmg: 0.02,      // 最终增伤 +2%
      perSoulCdPct: 0.02,         // 武器冷却 -2%
      perSoulPen: 0.02,           // 全武器穿透 +2%
      perSoulResistFinal: 0.02,   // 最终减伤 +2%
      perSoulDetectKm: 0.5,       // 水上/水下探测 +0.5km
      // 战神模式
      warGodDurationSec: 25,
      healPctPerSoul: 0.04,       // 每层回 4% 血
      shieldPctPerSoul: 0.04,     // 每层 4% 血护盾
      hitMaxHpDmgPct: 0.006,      // 命中额外造成自身 maxHp 0.6% 伤害
      invincibleSec: 3.5,         // 护盾破 → 无敌 3.5s
      litRadiusKm: 22,            // 被点亮半径
      litSec: 6,                  // 被点亮 6s
    },
  ],
});
