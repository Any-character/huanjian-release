@echo off
REM ============================================================
REM  HuanJian updater (friend side)
REM  Put this file in the game folder (next to index.html),
REM  double-click to update. Your mods in js\mods are NEVER touched.
REM
REM  NOTE: this file is ASCII-only on purpose.
REM    Windows 7's cmd reads .bat files using the system code page
REM    (GBK on Chinese Windows), so Chinese text stored in a .bat
REM    file turns into garbage. All Chinese messages live in
REM    update.ps1 (UTF-8 with BOM, which PowerShell 5.1 reads fine,
REM    and it switches the console to UTF-8 by itself).
REM
REM  The window NEVER closes on its own: it always waits for a key
REM  press at the end, so "I clicked it and nothing happened" can
REM  no longer happen silently.
REM ============================================================
title HuanJian Updater
setlocal

if not exist "%~dp0update.ps1" goto NO_PS1
where powershell >nul 2>&1
if errorlevel 1 goto NO_PS1_EXE

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
set RC=%ERRORLEVEL%
echo.
if not "%RC%"=="0" (
  echo [FAILED] The updater stopped with an error ^(exit code %RC%^).
  echo [FAILED] Please send the file update-log.txt from this folder to the author.
)
echo.
echo Press any key to close this window...
pause >nul
exit /b %RC%

:NO_PS1
echo.
echo [ERROR] update.ps1 was not found next to this file.
echo [ERROR] Keep update.bat AND update.ps1 in the same folder.
echo         (Unzip the whole update package - do not move single files.)
echo.
echo Press any key to close this window...
pause >nul
exit /b 1

:NO_PS1_EXE
echo.
echo [ERROR] Windows PowerShell was not found on this computer.
echo [ERROR] Your antivirus may have blocked powershell.exe.
echo         Allow it, then run update.bat again.
echo.
echo Press any key to close this window...
pause >nul
exit /b 1
